window.boot = function () {
    var settings = window._CCSettings;
    //window._CCSettings = undefined;
    var onProgress = null;

    var RESOURCES = cc.AssetManager.BuiltinBundleName.RESOURCES;
    var INTERNAL = cc.AssetManager.BuiltinBundleName.INTERNAL;
    var MAIN = cc.AssetManager.BuiltinBundleName.MAIN;
    function setLoadingDisplay() {
        // Loading splash scene
        var splash = document.getElementById('splash');
        cc.director.once(cc.Director.EVENT_AFTER_SCENE_LAUNCH, function () {
            splash.style.display = 'none';
        });
    }

    var onStart = function () {

        cc.view.enableRetina(true);
        cc.view.resizeWithBrowserSize(true);

        if (cc.sys.isBrowser) {
            setLoadingDisplay();
        }

        function getHttpKeysAndValus() {
            var url = window.document.location.href.toString(); //获取的完整url
            var u = url.split("?");
            if (typeof (u[1]) == "string") {
                u = u[1].split("&");
                var get = {};
                for (var i in u) {
                    var j = u[i].split("=");
                    get[j[0]] = j[1];
                }
                return get;
            } else {
                return {};
            }
        }
        function getUrlGameId() {
            let url = window.document.location.href.toLowerCase();
            var u = url.split("?");
            if (typeof (u[1]) == "string") {
                u = u[1].split("&");
                var get = {};
                for (var i in u) {
                    var j = u[i].split("=");
                    get[j[0]] = j[1];
                }
                return get;
            } else {
                return {};
            }
        }
        let gameId = getUrlGameId()["pvpgameid"];
        //好运平台設置橫豎屏
        //let vcode = getHttpKeysAndValus()["vcode"];
        if (window.platform == "ace" || window.platform == "zhizun") {
            const orientationData = {
                type: 'action',
                data: {
                    action: 503,
                    param: gameId == "sicbo" ? 1 : 2
                }
            }
            document.location = 'paparicher://' + encodeURIComponent(JSON.stringify(orientationData));
            console.log("orientation");
        }

        if (cc.sys.isMobile) {
            if (settings.orientation === 'landscape') {
                cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
            }
            else if (settings.orientation === 'portrait') {
                cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
            }
            cc.view.enableAutoFullScreen([
                cc.sys.BROWSER_TYPE_BAIDU,
                cc.sys.BROWSER_TYPE_BAIDU_APP,
                cc.sys.BROWSER_TYPE_WECHAT,
                cc.sys.BROWSER_TYPE_MOBILE_QQ,
                cc.sys.BROWSER_TYPE_MIUI,
                cc.sys.BROWSER_TYPE_HUAWEI,
                cc.sys.BROWSER_TYPE_UC,
            ].indexOf(cc.sys.browserType) < 0);
        }

        //動態修改資源
        var splash = document.getElementById('splash');


        let language = "zh-tw";
        if (getHttpKeysAndValus()["language"]) {
            language = getHttpKeysAndValus()["language"];
        }
        if (gameId) {
            let splashImg = "";
            if (gameId == "classic21") {
                if (window.platform == "zhizun" || window.platform == "A777") {
                    splashImg = "./gameIcon/" + language + "/classic21_zhizun.png";
                } else if (window.platform == "ace") {
                    splashImg = "./gameIcon/" + language + "/classic21_ace.png";
                } else if (window.platform == "08" || window.platform == "myoasis") {
                    splashImg = "./gameIcon/" + language + "/classic21_08.png";
                }
            } else if (gameId == "magic21" || window.platform == "myoasis") {
                if (window.platform == "08") {
                    splashImg = "./gameIcon/" + language + "/magic21_08.png";
                } else {
                    splashImg = "./gameIcon/" + language + "/magic21_ace.png";
                }
            } else if (gameId == "boatracing") {
                if (window.platform == "08" || window.platform == "myoasis") {
                    splashImg = "./gameIcon/" + language + "/boatracing_08.png";
                } else if (window.platform == "ace") {
                    splashImg = "./gameIcon/" + language + "/boatracing_ace.png";
                } else if (window.platform == "zhizun") {
                    splashImg = "./gameIcon/" + language + "/boatracing_zhizun.png";
                }
            } else {
                splashImg = "./gameIcon/" + language + "/" + gameId + ".png";
            }
            /*
            if (gameId == "classic21") {
                if (window.platform == "zhizun" || window.platform == "A777") {
                    if(language == "en-us"){
                        splashImg = "./classic21_zhizun_en.png";
                    }else{
                        splashImg = "./classic21_zhizun.png";
                    }
                   
                } else {
                    splashImg = "./classic21_ace.png";
                }
            } else if (gameId == "magic21") {
                if (window.platform == "08") {
                    splashImg = "./magic21_08.png";
                } else {
                    splashImg = "./magic21_ace.png";
                }
            } else if (gameId == "gof") {
                splashImg = "./gof.png";
            } else if (gameId == "richer3") {
                splashImg = "./richer3.png";
            } else if (gameId == "treasure") {
                splashImg = "./treasure.png";
            } else if (gameId == "golden21") {
                splashImg = "./golden21.png";
            } else if (gameId == "horseracing") {
                splashImg = "./horseracing.png";
            } else if (gameId == "caspasusun_table") {
                splashImg = "./caspasusun_table.png";
            } else if (gameId == "mahjong_table") {
                splashImg = "./twmj.png";
            } else if (gameId == "pushdots") {
                splashImg = "./pushdots.png";
            } else if (gameId == "six_poker") {
                splashImg = "./six_poker.png";
            } else if (gameId == "boatracing") {
                if (window.platform == "08") {
                    splashImg = "./boatracing_08.png";
                } else if (window.platform == "ace") {
                    splashImg = "./boatracing_ace.png";
                } else if (window.platform == "zhizun") {
                    splashImg = "./boatracing_zhizun.png";
                }
            }  else if (gameId == "casinoholdem") {
                splashImg = "./casinoholdem.png";
            }*/
            splash.style.display = 'block'
            splash.style = 'background:url(' + splashImg + ') no-repeat center;';
        }

        // Limit downloading max concurrent task to 2,
        // more tasks simultaneously may cause performance draw back on some android system / browsers.
        // You can adjust the number based on your own test result, you have to set it before any loading process to take effect.
        if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_ANDROID) {
            cc.assetManager.downloader.maxConcurrency = 2;
            cc.assetManager.downloader.maxRequestsPerFrame = 2;
        }

        var launchScene = settings.launchScene;
        var bundle = cc.assetManager.bundles.find(function (b) {
            return b.getSceneInfo(launchScene);
        });

        bundle.loadScene(launchScene, null, onProgress,
            function (err, scene) {
                if (!err) {
                    cc.director.runSceneImmediate(scene);
                    if (cc.sys.isBrowser) {
                        // show canvas
                        var canvas = document.getElementById('GameCanvas');
                        canvas.style.visibility = '';
                        var div = document.getElementById('GameDiv');
                        if (div) {
                            div.style.backgroundImage = '';
                        }
                        console.log('Success to load scene: ' + launchScene);
                    }
                }
            }
        );

    };

    var option = {
        id: 'GameCanvas',
        debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
        showFPS: settings.debug,
        frameRate: 60,
        groupList: settings.groupList,
        collisionMatrix: settings.collisionMatrix,
    };

    cc.assetManager.init({
        bundleVers: settings.bundleVers,
        remoteBundles: settings.remoteBundles,
        server: settings.server
    });

    var bundleRoot = [INTERNAL];
    settings.hasResourcesBundle && bundleRoot.push(RESOURCES);

    var count = 0;
    function cb(err) {
        if (err) return console.error(err.message, err.stack);
        count++;
        if (count === bundleRoot.length + 1) {
            cc.assetManager.loadBundle(MAIN, function (err) {
                if (!err) cc.game.run(option, onStart);
            });
        }
    }

    cc.assetManager.loadScript(settings.jsList.map(function (x) { return 'src/' + x; }), cb);

    for (var i = 0; i < bundleRoot.length; i++) {
        cc.assetManager.loadBundle(bundleRoot[i], cb);
    }
};

if (window.jsb) {
    var isRuntime = (typeof loadRuntime === 'function');
    if (isRuntime) {
        require('src/settings.22452.js');
        require('src/cocos2d-runtime.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('src/physics.js');
        }
        require('jsb-adapter/engine/index.js');
    }
    else {
        require('src/settings.22452.js');
        require('src/cocos2d-jsb.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('src/physics.js');
        }
        require('jsb-adapter/jsb-engine.js');
    }

    cc.macro.CLEANUP_IMAGE_CACHE = true;
    window.boot();
}