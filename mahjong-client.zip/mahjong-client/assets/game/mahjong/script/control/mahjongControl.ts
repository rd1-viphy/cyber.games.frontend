import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import consts = require("../../../../script/model/Consts");
import MahjongBackModel from "../../../../script/model/mahjongBackModel";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../script/model/Utils";
import NetConnect from "../../../../script/network/NetConnect";
import MahjongClock from "../component/mahjongClock";
import { MAHJONG_CONST, MAHJONG_GAME_STAGE, MAHJONG_HAND_TYPE, MAHJONG_OPERATION_ANIM, MAHJONG_PLAYERS, MAHJONG_PLAYER_OPERATION, MAHJONG_ROOM_TYPE, Mahjong_SettleCardType, MAHJONG_SETTLE_ANIM, MAHJONG_SETTLE_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";

import MahjongPlayBackView from "../view/mahjongPlayBackView";
import MahjongView from "../view/mahjongView";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongControl extends cc.Component {

    @property({
        tooltip: "麻将主界面View",
        type: MahjongView
    })
    protected gameView: MahjongView = null;

    @property({
        tooltip: "麻将回放view",
        type: MahjongPlayBackView
    })
    protected backView: MahjongPlayBackView = null;

    protected gameProxy: MahjongProxy = null;

    protected playerMgr: PlayerMgr = PlayerMgr.getInstance();

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    onLoad() {
        this.gameProxy = new MahjongProxy(this);
        this.gameView.init(this, this.gameProxy);
    }

    start() {
        this.initView();
    }

    initView() {
        this.gameView.initGameView();
        this.setGameInfo();

        if (this.backView && MahjongRoomMgr.getInstance().isBackView) {
            this.backView.init(this.gameView, this);
            this.onPlayBackReplay();
        }
    }

    onFastWord() {
        this.backView.onFastWord();
    }

    onPlayBackReplay() {
        this.gameModel.isSmallSettle = false;
        MahjongBackModel.rePlayBack();
    }

    onDestroy() {
        this.gameProxy.destroy();
        this.gameProxy = null;
    }

    setGameInfo() {
        // 遊戲是否開始
        if (this.gameModel.gameInfo.isGameStart) {
            this.gameModel.isGameStart = true;
            App.isGameStart = true;
        } else {
            this.gameModel.isGameStart = false;
            App.isGameStart = false;
            if (this.gameModel.gameInfo.waitReadyTime) {
                this.gameView.showDissRoomCountDown(this.gameModel.gameInfo.waitReadyTime);
            }
        }

        if (this.gameModel.roomConfig.freeEmotionSwitch) {
            MahjongRoomMgr.getInstance().isFreeEmoji = this.gameModel.roomConfig.freeEmotionSwitch ? true : false;
            MahjongRoomMgr.getInstance().startTime = this.gameModel.roomConfig.startFreeTime;
            MahjongRoomMgr.getInstance().endTime = this.gameModel.roomConfig.endFreeTime;
            MahjongRoomMgr.getInstance().isFreeTable = this.gameModel.roomConfig.freeTableSwitch ? true : false;
        }

        App.isWatchGame = this.gameModel.getIsWatchTheBattle() ? true : false;

        if (this.gameModel.gameInfo.phase < MAHJONG_GAME_STAGE.Start) {
            if (!this.gameModel.getIsWatchTheBattle()) {
                this.gameView.nodeInvite.active = true;
                if (this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
                    if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                        this.gameView.nodeStartGame.active = true;
                        const isAllReady = this.gameModel.isCheckOtherReady();
                        this.gameView.nodeStartGame.getComponent(cc.Button).interactable = isAllReady;
                        this.gameView.nodeStartGame.getChildByName("spFinger").active = isAllReady;
                        this.gameView.nodeReadyStart.active = false;
                    } else {
                        App.showToast("mahjong_intend_hint", 1);
                        this.gameView.nodeReadyStart.active = true;
                        this.gameView.nodeStartGame.active = false;
                    }
                } else {
                    App.showToast("mahjong_intend_hint", 1);
                    this.gameView.nodeReadyStart.active = true;
                    this.gameView.nodeStartGame.active = false;
                }
            } else {
                this.gameView.nodeWatchGame.active = true;
                this.gameView.nodeSitDown.active = true;
            }
        } else {
            if (!MahjongRoomMgr.getInstance().isBackView) {
                if (this.gameModel.getIsWatchTheBattle()) {
                    this.gameView.nodeWatchGame.active = true;
                }
            }
        }

        // 设置玩家信息
        this.gameModel.playersInfo.forEach((player) => {
            const seatId = this.gameModel.changSeatId(player.chairId);
            this.gameView.players[seatId].node.active = true;
            this.gameView.players[seatId].setPlayerInfo(player);
        })

        // 是否准备
        if (this.gameModel.gameInfo.phase < MAHJONG_GAME_STAGE.Start) {
            this.gameModel.playersInfo.forEach((player) => {
                const seatId = this.gameModel.changSeatId(player.chairId);
                this.gameView.players[seatId].node.active = true;
                this.gameView.players[seatId].setPlayerInfo(player);

                if (player.playerId && player.isReady) {
                    if (player.isReady) {
                        this.gameView.players[seatId].setPlayerReady(true);
                        if (player.playerId == PlayerMgr.getInstance().uid) {
                            this.gameView.nodeReadyStart.active = false;
                            this.gameView.nodeStartGame.active = false;
                        }
                    }
                }
            })
        }

        // 游戏开始
        if (this.gameModel.gameInfo.phase >= MAHJONG_GAME_STAGE.Start && this.gameModel.gameInfo.isGameStart) {
            this.gameView.nodeReadyStart.active = false;
            this.gameView.nodeStartGame.active = false;
            this.gameView.nodeInvite.active = false;
            this.gameView.onShowCardPiles();

            // 定庄
            if (this.gameModel.gameInfo.phase >= MAHJONG_GAME_STAGE.SelectDealer) {
                this.gameModel.playersInfo.forEach((player) => {
                    const seatId = this.gameModel.changSeatId(player.chairId);
                    if (player.isDealer) {
                        this.gameModel.bankChariId = seatId;
                        cc.log("庄家座位号: " + seatId);
                    }
                    if (player.wind == 1) {
                        this.gameModel.grabCardSeatId = seatId;
                    }
                    this.gameView.nodeClock.getComponent(MahjongClock).changePosFrame(seatId, player.wind);
                })
            }

            this.gameModel.playersInfo.forEach((player) => {
                const seatId = this.gameModel.changSeatId(player.chairId);
                this.gameView.players[seatId].setPlayerReady(false);
                this.gameView.nodeClock.getComponent(MahjongClock).changePosFrame(seatId, player.wind);

                // 庄家
                if (player.isDealer) {
                    this.gameView.players[seatId].showBank(true);
                }

                // 连庄次数
                if (player.dealerCount && player.dealerCount > 0) {
                    this.gameView.players[seatId].showLianBank(player.dealerCount);
                }

                this.gameModel.playerReadyStatus[seatId] = 1;

                // 是否有操作按钮
                if (player.options && player.options.length > 0) {
                    player.options.forEach((option) => {
                        this.gameModel.curPlayerOptions.push(option.reqType);
                        if (option.reqType == MAHJONG_PLAYER_OPERATION.discard) {
                            this.gameModel.curOperator = player.playerId;
                            this.gameModel.isDisCard = true;
                            this.gameModel.curPlayerDisCards = option.cards;
                        } else if (option.reqType == MAHJONG_PLAYER_OPERATION.eatCard) {
                            this.gameModel.curPlayerEatCards.push(option.cards);
                        } else if (option.reqType == MAHJONG_PLAYER_OPERATION.anGangCard) {
                            this.gameModel.curAnPongGangCards.push(option);
                        } else if (option.reqType == MAHJONG_PLAYER_OPERATION.pongKongCard) {
                            this.gameModel.curAnPongGangCards.push(option);
                        } else if (option.reqType == MAHJONG_PLAYER_OPERATION.readyHand) {
                            this.gameModel.curPlayerTingCards.push(option);
                        } else if (option.reqType == MAHJONG_PLAYER_OPERATION.robFlowerWin) {
                            this.gameModel.lastCardData = option.cards;
                        }
                    })
                    this.gameView.onShowOperation(player);
                }

                // 显示手牌
                if (player.handCards && player.handCards.length > 0) {
                    this.gameView.gameCardsView.onReconnetDealCard({
                        handCards: [{
                            "chairId": player.chairId,
                            "cards": player.handCards
                        }]
                    })
                }

                // 显示碰杠牌
                if (player.otherCards && player.otherCards.length > 0) {
                    player.otherCards.forEach((otherCard) => {
                        if (otherCard.cardType == Mahjong_SettleCardType.chow) {
                            const eatList = [otherCard.cards[0], otherCard.chowCard, otherCard.cards[1]]
                            this.gameView.gameCardsView.onEatCardOperation(seatId, eatList, false);
                        } else if (otherCard.cardType == Mahjong_SettleCardType.pong) {
                            this.gameView.gameCardsView.onPengCardOperation(seatId, otherCard.cards, false)
                        } else if (otherCard.cardType == Mahjong_SettleCardType.exposedKong) {
                            this.gameModel.flowersGangCount += 1;
                            this.gameView.gameCardsView.onMingGangOperation(seatId, otherCard.cards, false)
                        } else if (otherCard.cardType == Mahjong_SettleCardType.concealedKong) {
                            this.gameModel.flowersGangCount += 1;
                            this.gameView.gameCardsView.onAnGangOperation(seatId, otherCard.cards, false)
                        } else if (otherCard.cardType == Mahjong_SettleCardType.pongKong) {
                            this.gameModel.flowersGangCount += 1;
                            this.gameView.gameCardsView.onMingGangOperation(seatId, otherCard.cards, false)
                        }
                    })
                }

                // 显示花牌
                if (player.flowerCards && player.flowerCards.length > 0) {
                    this.gameView.gameCardsView.onShowFlowersCard(player, seatId, true);
                }

                // 显示弃牌
                if (player.discardCards && player.discardCards.length > 0) {
                    player.discardCards.forEach((disCard) => {
                        const card = JSON.parse("[" + disCard + "]");
                        this.gameView.gameCardsView.onPlayDisCard(seatId, card, false);
                    })
                }

                // 是否听牌
                if (player.readyHandCards && player.readyHandCards.length > 0) {
                    if (player.playerId == PlayerMgr.getInstance().uid) {
                        this.gameModel.isMySelfTing = true;
                        this.gameModel.curPlayerWinCards = player.readyHandCards;
                        this.gameView.gameCardsView.onPlayerTing(seatId, true);
                        this.gameView.gameCardsView.onReconnectDisCard();
                    }
                    this.gameView.players[seatId].showTing(true);
                }
            })

            // 发牌
            if (this.gameModel.gameInfo.phase >= MAHJONG_GAME_STAGE.DealCard) {
                this.gameModel.openCardPos = this.gameModel.gameInfo.dealTotalNum;

                cc.log("骰子数: " + this.gameModel.openCardPos)
                this.gameView.onRecShowCardPiles();
            }
        }

        // 解散房间
        if (this.gameModel.gameInfo.voteDetail) {
            if (this.gameModel.gameInfo.voteDetail.voteStartPlayerId) {
                const obj = {
                    gameId: platform_game_id.mahjong_table,
                    roomId: this.gameModel.tableId,
                    playerId: this.gameModel.gameInfo.voteDetail.voteStartPlayerId,
                    delayTime: this.gameModel.gameInfo.voteDetail.delayTime,
                    delayRemain: this.gameModel.gameInfo.voteDetail.delayRemain,
                    agreePlayerIds: this.gameModel.gameInfo.voteDetail.agreePlayerIds,
                    refusePlayerIds: this.gameModel.gameInfo.voteDetail.refusePlayerIds,
                }
                this.gameView.startDissolveRoom(obj);
                this.scheduleOnce(() => {
                    this.gameView.playerDissolve(obj);
                }, 2.0)
            }
        }

        this.gameView.setRoomInfo();

        let waitPlayerId = null;
        if (this.gameModel.gameInfo.currActionSit != null) {
            waitPlayerId = this.gameModel.getPlayerIdToChariId(this.gameModel.gameInfo.currActionSit);
        }
        let delayTime = null;
        if (this.gameModel.gameInfo.delayTime) {
            delayTime = Math.ceil(this.gameModel.gameInfo.delayTime / 1000);
        }

        this.onGameStageMsg({ phase: this.gameModel.gameInfo.phase, waitPlayerId: waitPlayerId, delayTime: delayTime }, true);

        let msg = NetConnect.pomelo.msgQueue;
        if (msg.length && msg.length > 0) {
            this.scheduleOnce(() => {
                while (msg.length > 0) {
                    let msgItem = msg.shift();
                    this.gameProxy.processServerMsg(msgItem.route, msgItem.body);
                }
            }, 0.1)
        }
    }

    /**
     * 牌桌状态数据
     * @param data 
     * @param isAgain 
     */
    onGameStageMsg(data, isAgain = false) {
        this.gameModel.gameInfo.phase = data.phase;
        switch (data.phase) {
            case MAHJONG_GAME_STAGE.Start:
                this.gameView.initGameView();
                this.gameView.onShowCardPiles();
                break;
            case MAHJONG_GAME_STAGE.replaceFlowersCard:
                this.gameModel.curOperator = "";
                this.gameView.nodeClock.getComponent(MahjongClock).onHidelbClock();
                break;
            case MAHJONG_GAME_STAGE.WaitOption:
            case MAHJONG_GAME_STAGE.WaitOtherOptions:
                if (MAHJONG_GAME_STAGE.WaitOption) {
                    if (data.waitPlayerId) {
                        this.gameModel.curOperator = data.waitPlayerId;
                    }
                }
                this.gameView.players.forEach(player => player.closeCountDown());
                this.gameModel.playersInfo.forEach((player) => {
                    if (data.waitPlayerId) {
                        if (data.waitPlayerId == player.playerId) {
                            const seatId = this.gameModel.changSeatId(player.chairId);
                            this.gameView.nodeClock.getComponent(MahjongClock).setMahjongClock(seatId, data.delayTime);
                            this.gameView.players[seatId].startOperationDown(data.delayTime);
                        }
                    }
                })
                break;
            case MAHJONG_GAME_STAGE.Settle:
                if (isAgain) {
                    this.gameModel.isRecSettle = true;
                }
                this.gameModel.settleDelayTime = data.delayTime;
                this.gameModel.isDisCard = false;
                this.gameView.players.forEach(player => player.closeCountDown());
                break;
            case MAHJONG_GAME_STAGE.GameEnd:
                this.gameView.initGameView();
                break;
            default:
                break;
        }
    }

    /**
     * 玩家坐下
     * @param data 
     */
    onPlayerSit(data) {
        if (data.players) {
            data.players.forEach((player) => {
                const seatId = this.gameModel.changSeatId(player.chairId);
                this.gameView.players[seatId].node.active = true;
                this.gameView.players[seatId].setPlayerInfo(player);
                if (player.playerId && player.isReady) {
                    this.gameModel.playerReadyStatus[seatId] = player.isReady;
                }
                if (player.playerId != PlayerMgr.getInstance().uid) {
                    this.gameModel.playersInfo.push(player);
                    if (this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                        if (this.gameView.players[seatId].node.getChildByName("agoraView")) {
                            this.gameView.agoraClient.addUser({ userId: player.playerId, agoraView: this.gameView.players[seatId].node.getChildByName("agoraView"), videoTrack: null, audioTrack: null, interval: null });
                        }
                    }
                } else {
                    this.gameView.nodeWatchGame.active = false;
                    //加入聲網
                    if (CC_BUILD && this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                        this.scheduleOnce(() => {
                            this.gameView.startAccessAgora();
                        }, 0.5);
                    }
                }
            })
        }
    }

    /**
     * 游戏开始
     * @param data 
     */
    onGameStart(data) {
        this.gameModel.playersInfo.forEach((player) => {
            let seatId = this.gameModel.changSeatId(player.chairId);
            this.gameView.players[seatId].setPlayerReady(false);
        })
        this.gameModel.currentRound = data.roundNum;
        this.gameModel.gameInfo.remainCardNum = data.totalCardNum;
        this.gameModel.isGameStart = true;
        this.gameModel.isWaterHu = false;
        this.gameModel.isDissRoom = false;
        App.isGameStart = true;
        this.gameModel.isRecSettle = false;
        this.gameView.onShowCardPiles();
        this.gameView.onStartGame();
    }

    /**
     * 玩家准备
     * @param data 
     */
    onPlayerReady(data) {
        if (data.readyPlayerIds) {
            data.readyPlayerIds.forEach(playerId => {
                this.gameModel.playersInfo.forEach((player) => {
                    if (playerId == player.playerId) {
                        player.isReady = 1;
                        let seatId = this.gameModel.changSeatId(player.chairId);
                        this.gameView.players[seatId].setPlayerReady(true);
                    }
                })
            })
        }
        if (this.gameModel.isCheckOtherReady() && this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
            if (this.gameModel.masterUid != PlayerMgr.getInstance().uid) {
                App.showToast("mahjong_contact_master_start", 1);
            } else {
                this.gameView.nodeStartGame.getComponent(cc.Button).interactable = true;
                this.gameView.nodeStartGame.getChildByName("spFinger").active = true;
                App.showToast("mahjong_start_tip", 1);
            }
        }
    }

    /**
     * 抓位
     * @param data 
     */
    onGameSureWind(data) {
        this.gameView.onShowZhuaWeiAnim();
        this.scheduleOnce(() => {
            if (data.diceList) {
                this.gameView.nodeClock.getComponent(MahjongClock).onHideDice();
                this.gameView.onShowDiceAnim(data.diceList);
            }
        }, 1.0)

        this.gameModel.playersInfo.forEach((player) => {
            if (data.playerList) {
                data.playerList.forEach((playerWind) => {
                    if (playerWind.playerId == player.playerId) {
                        if (playerWind.playerId == PlayerMgr.getInstance().uid) {
                            this.gameModel.selfChairId = playerWind.chairId;
                        }
                    }
                })
            }
        })

        let sureWindDelayTime = MahjongRoomMgr.getInstance().isBackView ? 0 : 2.5;

        this.scheduleOnce(() => {
            this.gameModel.playersInfo.forEach((player) => {
                if (data.playerList) {
                    data.playerList.forEach((playerWind) => {
                        if (playerWind.playerId == player.playerId) {
                            player.chairId = playerWind.chairId;
                            const seatId = this.gameModel.changSeatId(playerWind.chairId);
                            this.gameView.players[seatId].setPlayerInfo(player);
                            this.gameView.players[seatId].showPlayerWind(playerWind.wind);
                        }
                    })
                }
            })
            this.gameView.changeSeatAgoraView();
        }, sureWindDelayTime)
    }

    /**
     * 定庄
     * @param data 
     */
    onGameSureBank(data) {
        this.gameModel.grabCardSeatId = 0;
        this.gameModel.openCardPos = 0;
        let delayTime1 = 1.8;
        let delayTime2 = 2.8;

        this.gameModel.gameInfo.currRound = data.roundNum;
        this.gameModel.gameInfo.windRound = data.windRound;

        if (data.diceList) {
            for (let i = 0; i < data.diceList.length; i++) {
                const dice = data.diceList[i];
                this.gameModel.openCardPos += dice;
            }
            cc.log("定庄骰子数: " + this.gameModel.openCardPos);
        }

        if (data.isLastDealer) {
            App.showToast("mahjong_disslute_room_tip", 1);
        }

        this.gameModel.playersInfo.forEach((player) => {
            if (data.playerWinds) {
                data.playerWinds.forEach((playerWind) => {
                    if (player.playerId == playerWind.playerId) {
                        const seatId = this.gameModel.changSeatId(player.chairId);
                        if (playerWind.wind == 1) {
                            this.gameModel.grabCardSeatId = seatId;
                        }
                        this.scheduleOnce(() => {
                            this.gameView.nodeClock.getComponent(MahjongClock).changePosFrame(seatId, playerWind.wind);
                        }, 3.0)

                        if (player.playerId == data.dealerId) {
                            cc.log("庄家座位号: " + seatId);
                            if (this.gameModel.bankId) {
                                delayTime1 = 2.0;
                                delayTime2 = 1.5;
                                this.gameView.onSureBank(seatId, false);
                                this.gameView.players[seatId].showBank(true);
                                if (data.dealerCount && data.dealerCount > 0) {
                                    this.gameView.players[seatId].showLianBank(data.dealerCount);
                                }
                                this.scheduleOnce(() => {
                                    this.gameView.onShowDiceAnim(data.diceList);
                                }, 1.3)
                            } else {
                                this.gameView.onShowDiceAnim(data.diceList);
                                this.scheduleOnce(() => {
                                    this.gameView.onSureBank(seatId, true);
                                }, delayTime1)
                                this.scheduleOnce(() => {
                                    this.gameView.players[seatId].showBank(true);
                                    if (data.dealerCount && data.dealerCount > 0) {
                                        this.gameView.players[seatId].showLianBank(data.dealerCount);
                                    }
                                }, delayTime2)
                            }
                            this.gameModel.bankChariId = seatId;
                            this.gameModel.bankId = data.dealerId;
                        }
                    }
                })
            }
        })
    }

    /**
     * 发牌
     * @param data 
     */
    onDealCard(data) {
        this.gameView.onGameDealCards(data);
    }

    /**
     * 玩家替换花牌
     * @param data 
     */
    onExchangeFlowerCard(data) {
        this.gameModel.playersInfo.forEach((player) => {
            if (data.playerId == player.playerId) {
                const seatId = this.gameModel.changSeatId(player.chairId);
                this.gameView.onExChangeFlowerCard(data, seatId);
            }
        })
    }

    /**
     * 玩家可以进行的操作
     * @param data 
     */
    onPlayerOperation(data) {
        let isRobFlowerWin = false;
        this.gameModel.isBuGang = false;
        this.gameModel.curOperator = "";
        this.gameModel.curPlayerOptions = [];
        this.gameModel.curPlayerEatCards = [];
        this.gameModel.curPlayerTingCards = [];
        this.gameModel.curAnPongGangCards = [];
        this.gameModel.curPlayerDisCards = null;
        this.gameModel.isTingPush = false;
        this.gameModel.playersInfo.forEach((player) => {
            if (data.actionPlayerId == player.playerId)
                data.options.forEach((option) => {
                    this.gameModel.curPlayerOptions.push(option.reqType);
                    if (option.reqType == MAHJONG_PLAYER_OPERATION.discard) {
                        this.gameModel.curOperator = data.actionPlayerId;
                        this.gameModel.curPlayerDisCards = option.cards;
                        this.gameModel.isDisCard = true;
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.eatCard) {
                        this.gameModel.curPlayerEatCards.push(option.cards);
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.anGangCard) {
                        this.gameModel.isBuGang = true;
                        this.gameModel.curAnPongGangCards.push(option);
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.pongKongCard) {
                        this.gameModel.isBuGang = true;
                        this.gameModel.curAnPongGangCards.push(option);
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.readyHand) {
                        this.gameModel.curPlayerTingCards.push(option);
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.robFlowerWin ||
                        option.reqType == MAHJONG_PLAYER_OPERATION.robKongHu) {
                        this.gameModel.lastCardData = option.cards;
                        if (option.reqType == MAHJONG_PLAYER_OPERATION.robFlowerWin) {
                            isRobFlowerWin = true;
                        }
                    } else if (option.reqType == MAHJONG_PLAYER_OPERATION.ziMo) {
                        isRobFlowerWin = true;
                    }
                })
        })

        if ((this.gameModel.isDelyHuTime && isRobFlowerWin) || (this.gameModel.isMySelfTing && this.gameModel.isBuGang)) {
            this.scheduleOnce(() => {
                this.gameView.onShowOperation(data);
            }, 2.5)
        } else {
            this.gameView.onShowOperation(data);
        }

        if (this.gameModel.isDisCard && this.gameModel.curOperator == PlayerMgr.getInstance().uid &&
            !this.gameModel.getIsWatchTheBattle() && !MahjongRoomMgr.getInstance().isBackView) {
            this.gameView.gameCardsView.spDisCardHintAnim.node.active = true;
        } else {
            this.gameView.gameCardsView.spDisCardHintAnim.node.active = false;
        }
    }

    /**
     * 玩家摸牌
     * @param data 
     */
    onPlayerDrawCard(data) {
        this.gameModel.playersInfo.forEach((player) => {
            if (data.waitPlayerId == player.playerId) {
                let seatId = this.gameModel.changSeatId(player.chairId);
                this.gameView.onGameAddCard(seatId, data.cards);
            }
        })
    }

    /**
     * 广播玩家操作
     * @param data 
     */
    onPlayerAction(data) {
        if (data.actionPlayerId) {
            this.gameModel.isDisCard = false;
            this.gameModel.playersInfo.forEach((player) => {
                if (data.actionPlayerId == player.playerId) {
                    let seatId = this.gameModel.changSeatId(player.chairId);
                    this.gameView.onShowOtherOperation(seatId, data.actionType, data.cards);
                    if (data.actionType == MAHJONG_PLAYER_OPERATION.huCard ||
                        data.actionType == MAHJONG_PLAYER_OPERATION.ziMo ||
                        data.actionType == MAHJONG_PLAYER_OPERATION.robFlowerWin ||
                        data.actionType == MAHJONG_PLAYER_OPERATION.flowerWin) {
                        this.gameModel.winPlayerId = data.actionPlayerId;
                    }
                }
                if (data.targetId) {
                    if (data.targetId == player.playerId) {
                        let seatId = this.gameModel.changSeatId(player.chairId);
                        if (data.actionType == MAHJONG_PLAYER_OPERATION.huCard) {
                            this.scheduleOnce(() => {
                                AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Gun, true, true);
                                this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.fangPao, this.gameView.gameCardsView.spFangPaoGangHu[seatId]);
                                if (this.gameModel.lastCard) {
                                    this.gameView.gameCardsView.spDisCardTag.node.active = false;
                                    let pos = Utils.changToNodePoint(this.gameModel.lastCard, this.gameView.spLightWuAnim.node);
                                    pos.y += 100;
                                    this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.light_chupai, pos);
                                    this.scheduleOnce(() => {
                                        if (this.gameModel.lastCard) {
                                            this.gameModel.lastCard.destroy();
                                            this.gameModel.lastCard = null;
                                        }
                                    }, 1.5)
                                }
                            }, 1.0)
                        } else if (data.actionType == MAHJONG_PLAYER_OPERATION.robFlowerWin) {
                            this.gameView.gameCardsView.onDeleteQiQiangYiFlower(data.cards[0])
                        }
                    }
                }
            })
        }
    }

    /**
     * 听牌后的番型变化
     * @param data 
     */
    onTingCardPoint(data) {
        if (data.winCards && data.winCards.length > 0) {
            if (this.gameModel.curPlayerWinCards.length == 0) {
                this.gameModel.curPlayerWinCards = data.winCards;
                this.gameView.gameCardsView.spTingBulb.active = true;
            } else {
                for (let m = 0; m < data.winCards.length; m++) {
                    const tmpCard = data.winCards[m];
                    for (let i = 0; i < this.gameModel.curPlayerWinCards.length; i++) {
                        const card = this.gameModel.curPlayerWinCards[i];
                        if (tmpCard.winCard == card.winCard) {
                            card.totalPoint = tmpCard.totalPoint;
                        }
                    }
                }
            }
        }
    }

    /**
     * 行牌限制
     * @param data 
     */
    onLimitPushCard(data) {
        this.gameView.onShowLimitTips(data);
    }

    /**
     * 玩家发送互动表情
     * @param data 
     */
    onPlayerEomotion(data: MahjongServerToClient.onPlayerEmotion) {
        this.gameView.onShowEmojiProps(data);
    }

    /**
     * 玩家聊天文字
     */
    onPlayerChat(data) {
        const seatId = this.gameModel.getChariIdToPlayerId(data.sendPlayerId);
        if (data.id >= 200) {
            this.gameView.players[seatId].setPlayerExpreesion(data.id);
        } else {
            this.gameView.players[seatId].setPlayerMsg(data.id);
        }
    }

    /**
     * 房主解散退出房间
     */
    onExitRoom() {
        if (this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
            this.gameView.agoraClient.leaveCall();
        }
        App.showToast("mahjong_dissolve_end", 1);
        this.scheduleOnce(() => {
            App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
        }, 1.0)
    }

    /**
     * 游戏单局结算
     * @param data 
     */
    onGameSettle(data) {
        if (this.gameModel.gameInfo.phase != MAHJONG_GAME_STAGE.Settle) { return }
        this.gameModel.isSmallSettle = true;
        this.gameModel.isDisCard = false;
        this.gameView.gameCardsView.spDisCardHintAnim.node.active = false;

        if (this.gameModel.isRecSettle) {
            if (this.gameModel.settleDelayTime < 16) {
                this.onReconnectSettleView(data);
            } else {
                this.showSettleView(data);
            }
        } else {
            this.showSettleView(data);
        }
    }

    showSettleView(data) {
        let delayTime = 0;
        if (data.details) {
            for (let i = 0; i < data.details.length; i++) {
                const settlePlayer = data.details[i];
                for (let m = 0; m < this.gameModel.playersInfo.length; m++) {
                    const player = this.gameModel.playersInfo[m];
                    if (player.playerId == settlePlayer.playerId) {
                        if (settlePlayer.settleScore > 0) {
                            if (settlePlayer.fanList && settlePlayer.fanList.length > 0) {
                                const isAddFan = this.gameModel.isCheckAddFanAnim(settlePlayer.fanList);
                                if (isAddFan.pointType > -1) {
                                    delayTime = 5.0;
                                    const addFanList = [];
                                    addFanList.push(isAddFan);
                                    this.scheduleOnce(() => {
                                        this.gameModel.showCardTypeAnim(addFanList, true);
                                    }, 2.0)

                                    const isHaveCardType = this.gameModel.isCheckCardTypeAnim(settlePlayer.fanList);
                                    if (isHaveCardType > -1) {
                                        this.scheduleOnce(() => {
                                            this.gameModel.showCardTypeAnim(settlePlayer.fanList, false);
                                        }, 4.0)
                                    }
                                } else {
                                    delayTime = 2.0;
                                    const isHaveCardType = this.gameModel.isCheckCardTypeAnim(settlePlayer.fanList);
                                    if (isHaveCardType > -1) {
                                        this.scheduleOnce(() => {
                                            this.gameModel.showCardTypeAnim(settlePlayer.fanList, false);
                                        }, 2.0)
                                    }
                                }
                            }
                        }
                        this.scheduleOnce(() => {
                            const seatId = this.gameModel.changSeatId(player.chairId);
                            this.gameView.players[seatId].updatePlayerScore(settlePlayer.totalScore);
                        }, 5.0)
                    }
                }
            }

            let tanCardTime = this.gameModel.isMySelfTing ? 2.0 : 0;
            this.scheduleOnce(() => {
                this.gameView.gameCardsView.onShowDownCard(data.details);
            }, tanCardTime);

            delayTime += 2;
            const time = this.gameModel.settleDelayTime - delayTime;
            this.scheduleOnce(() => {
                if (this.gameModel.isSmallSettle) {
                    App.loadGamePopul({
                        prefabName: "smallResultView",
                        prefabPath: "prefab/mahjongCard",
                        prefabComponent: "mahjongSmallResultView",
                        zIndex: 1200,
                        data: {
                            settle: data.details,
                            roundWind: data.roundWind,
                            gameProxy: this.gameProxy,
                            gameModel: this.gameModel,
                            gameEndType: data.gameEndType,
                            delayTime: time
                        }
                    })
                }
            }, delayTime)
        }

        if (data.gameEndType == MAHJONG_SETTLE_TYPE.Peace) {
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Draw, true, true);
            this.gameView.onShowGameSettleAnim(MAHJONG_SETTLE_ANIM.HeJu);
        } else if (data.gameEndType == MAHJONG_SETTLE_TYPE.Flow) {
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Streaming, true, true);
            this.gameView.onShowGameSettleAnim(MAHJONG_SETTLE_ANIM.LiuJu)
        }
    }

    /**
     * 小结算断线调整
     * @param data 
     */
    onReconnectSettleView(data) {
        let delayTime = 0;
        if (this.gameModel.settleDelayTime < 8) {
            if (data.details) {
                this.gameView.gameCardsView.onShowDownCard(data.details);
                for (let i = 0; i < data.details.length; i++) {
                    const settlePlayer = data.details[i];
                    for (let m = 0; m < this.gameModel.playersInfo.length; m++) {
                        const player = this.gameModel.playersInfo[m];
                        if (player.playerId == settlePlayer.playerId) {
                            const seatId = this.gameModel.changSeatId(player.chairId);
                            this.gameView.players[seatId].updatePlayerScore(settlePlayer.totalScore);
                        }
                    }
                }

                const time = this.gameModel.settleDelayTime;
                App.loadGamePopul({
                    prefabName: "smallResultView",
                    prefabPath: "prefab/mahjongCard",
                    prefabComponent: "mahjongSmallResultView",
                    data: {
                        settle: data.details,
                        roundWind: data.roundWind,
                        gameProxy: this.gameProxy,
                        gameModel: this.gameModel,
                        gameEndType: data.gameEndType,
                        delayTime: time
                    }
                })
            }
        } else if (8 <= this.gameModel.settleDelayTime && this.gameModel.settleDelayTime < 16) {
            if (data.details) {
                for (let i = 0; i < data.details.length; i++) {
                    const settlePlayer = data.details[i];
                    for (let m = 0; m < this.gameModel.playersInfo.length; m++) {
                        const player = this.gameModel.playersInfo[m];
                        if (player.playerId == settlePlayer.playerId) {
                            this.scheduleOnce(() => {
                                const seatId = this.gameModel.changSeatId(player.chairId);
                                this.gameView.players[seatId].updatePlayerScore(settlePlayer.totalScore);
                            }, 8.0)
                            if (settlePlayer.settleScore > 0) {
                                if (settlePlayer.fanList) {
                                    const result = cc.find('Canvas').getChildByName("smallResultView");
                                    if (!!result) {
                                        App.loadGamePopul({
                                            prefabName: "cardTypeAnim",
                                            prefabPath: "prefab/mahjongCard/cardTypeAnim",
                                            prefabComponent: "mahjongCardTypeAnim",
                                            data: settlePlayer.fanList
                                        })
                                    }
                                }
                            }
                        }
                    }
                }

                this.gameView.gameCardsView.onShowDownCard(data.details);

                delayTime += 2;
                const time = this.gameModel.settleDelayTime - delayTime;
                this.scheduleOnce(() => {
                    App.loadGamePopul({
                        prefabName: "smallResultView",
                        prefabPath: "prefab/mahjongCard",
                        prefabComponent: "mahjongSmallResultView",
                        data: {
                            settle: data.details,
                            roundWind: data.roundWind,
                            gameProxy: this.gameProxy,
                            gameModel: this.gameModel,
                            gameEndType: data.gameEndType,
                            delayTime: time
                        }
                    })
                }, delayTime)

                if (data.gameEndType == MAHJONG_SETTLE_TYPE.Peace) {
                    AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Draw, true, true);
                    this.gameView.onShowGameSettleAnim(MAHJONG_SETTLE_ANIM.HeJu);
                } else if (data.gameEndType == MAHJONG_SETTLE_TYPE.Flow) {
                    AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Streaming, true, true);
                    this.gameView.onShowGameSettleAnim(MAHJONG_SETTLE_ANIM.LiuJu)
                }
            }
        }
    }

    /**
     * 游戏总结算
     * @param data 
     */
    onGameTotalSettle(data) {
        if (MahjongRoomMgr.getInstance().isBackView) { return };
        this.gameModel.bankId = null;
        let delayTime = this.gameModel.isSmallSettle ? 8.0 : 0;
        this.gameView.players.forEach(player => player.closeCountDown());
        if (data.details) {
            this.scheduleOnce(() => {
                if (this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                    this.gameView.agoraClient.leaveCall();
                }
                App.loadGamePopul({
                    prefabName: "totalResultView",
                    prefabPath: "prefab/mahjongCard",
                    prefabComponent: "mahjongTotalResultView",
                    data: {
                        settle: data,
                        gameProxy: this.gameProxy,
                        gameModel: this.gameModel
                    }
                })
            }, delayTime)
        }
    }

    /**
     * 游戏流局
     * @param data 
     */
    onGameFlow(data) {
        this.gameView.lbCardCount.string = "0";
    }

    /**
     * 玩家离线通知
     * @param data 
     */
    setPlayerStatusChanged(data) {
        if (data.playerId) {
            this.gameModel.playersInfo.forEach((player) => {
                if (player.playerId == data.playerId) {
                    if (data.playerId != PlayerMgr.getInstance().uid) {
                        const seatId = this.gameModel.changSeatId(player.chairId);
                        this.gameView.players[seatId].setPlayerOnLineStatue(data);
                    }
                }
            })
        }
    }

    /**
     * 玩家离开房间
     * @param data 
     */
    onPlayerLeaveTable(data) {
        if (data.leavePlayerId) {
            this.gameModel.playersInfo.forEach((player, idx) => {
                if (player.playerId == data.leavePlayerId) {
                    let seatId = this.gameModel.changSeatId(player.chairId);
                    let leaveUid = data.leavePlayerId;
                    if (data.leavePlayerId == PlayerMgr.getInstance().uid) {

                    } else {
                        if (this.gameView.agoraClient && leaveUid && !this.gameModel.getIsWatchTheBattle() && CC_BUILD) {
                            this.gameView.agoraClient.removeVideo(leaveUid);
                            this.gameView.agoraClient.removeAudio(leaveUid);
                            this.gameView.agoraClient.delectUser(leaveUid);
                        }
                    }

                    this.gameView.players[seatId].onStandUp();
                    this.gameModel.playersInfo.splice(idx, 1);
                }
            })
            if (!this.gameModel.isCheckOtherReady() && this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
                this.gameView.nodeStartGame.getComponent(cc.Button).interactable = false;
                this.gameView.nodeStartGame.getChildByName("spFinger").active = false;
            }
        }
    }

    /**
     * 踢出房间
     * @param data 
     */
    onKickOutRoom(data) {
        if (data.reason == 1) {
            // 房主主動踢出
            App.showToast("mahjong_kickout_room", 1);
        } else if (data.reason == 2) {
            // 房間超時解散
            App.showToast("mahjong_dissRoom_timeout", 1);
        }
        this.scheduleOnce(() => {
            App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
        }, 1.0)
    }

    /**
     * 其他玩家準備後遊戲不開始解散倒計時
     * @param data 
     */
    setRoomDissTimer(data) {
        this.gameView.showDissRoomCountDown(data.waitTime);
        if (data.players) {
            data.players.forEach((player) => {
                const seatId = this.gameModel.changSeatId(player.chairId);
                let isInGame = this.gameModel.isCheckPlayerInGame(player);
                if (!isInGame) {
                    this.gameView.players[seatId].node.active = true;
                    this.gameView.players[seatId].setPlayerInfo(player);

                    if (player.playerId != PlayerMgr.getInstance().uid) {
                        this.gameModel.playersInfo.push(player);
                        if (this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                            this.gameView.agoraClient.addUser({ userId: player.playerId, agoraView: this.gameView.players[seatId].node.getChildByName("agoraView"), videoTrack: null, audioTrack: null, interval: null });
                        }
                    } else {
                        this.gameView.nodeWatchGame.active = false;
                        //加入聲網
                        if (CC_BUILD && this.gameView.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                            this.scheduleOnce(() => {
                                this.gameView.startAccessAgora();
                            }, 0.5);
                        }
                    }
                }
            })
        }
        if (this.gameModel.isCheckOtherReady() && this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
            if (this.gameModel.masterUid != PlayerMgr.getInstance().uid) {
                App.showToast("mahjong_contact_master_start", 1);
            } else {
                this.gameView.nodeStartGame.getComponent(cc.Button).interactable = true;
                this.gameView.nodeStartGame.getChildByName("spFinger").active = true;
                App.showToast("mahjong_start_tip", 1);
            }
        }
    }

    /**
     * 开始解散
     */
    onStartDissilution(data) {
        this.gameView.startDissolveRoom(data);
    }

    /**
     * 解散玩家操作
     */
    onDissilutionPlayerAction(data) {
        this.gameView.playerDissolve(data);
        this.gameModel.refusePlayer = data.agreePlayerIds;
    }

    /**
     * 解散结束
     */
    onDissilutionResult(data: MahjongServerToClient.onVoteResultPush) {
        let dissolutionRoomNode = cc.find("Canvas/mahjongDissolutionRoomNode");
        if (dissolutionRoomNode) {
            dissolutionRoomNode.destroy();
        }
        if (!data.disband) {
            let playersId = [];
            this.gameModel.playersInfo.forEach((player) => {
                playersId.push(player.playerId);
            })

            let difference = playersId
                .filter(x => this.gameModel.refusePlayer.indexOf(x) == -1)
                .concat(this.gameModel.refusePlayer.filter(x => playersId.indexOf(x) == -1));

            this.gameModel.playersInfo.forEach((player) => {
                if (player.playerId == difference[0]) {
                    App.showToast("mahjong_refuseDissRoom", 2, [player.nickname]);
                }
            })

            this.gameView.nodeClock.getComponent(MahjongClock).lbClock.string = this.gameModel.recordOperationTime.toString();
            this.gameModel.isDissRoom = false;
        } else {
            this.gameModel.isDissRoom = false;
        }
    }

}
