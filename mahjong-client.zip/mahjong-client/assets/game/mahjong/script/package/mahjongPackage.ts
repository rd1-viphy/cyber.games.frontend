
declare namespace MahjongCommon {

    /**
     * 房间配置
     */
    interface RoomInfo {
        /**房间ID**/
        readonly roomId: number;
        /** 游戏ID */
        readonly gameId: number;
        /**房间名称**/
        readonly roomName: string;
        /**最大房间人数**/
        readonly maxPlayerNum: number;
        /**当前房间人数**/
        readonly playerNum: number;
        /**最大游戏局数**/
        readonly maxRoundNum: number;
        /**游戏局数**/
        readonly roundNum: number;
        /**底注**/
        readonly baseScore: number;
        /**该房间的唯一ID**/
        readonly privateKey: number;
    }

    /**
     * 房间配置
     */
    interface RoomConfig {
        /**配置房间人数**/
        readonly maxPlayerNum: number;
        /**配置游戏局数**/
        readonly maxRoundNum: number;
        /**底注**/
        readonly baseScore: number;
        /** 出牌思考时间 */
        readonly thinkTime: number;
        /** 有无花牌 */
        readonly hasFlowerCard: number;
        /** 每番的点数 */
        readonly fanPoint: number;
        /** 是否强制胡牌 */
        readonly isAutoHu: number;
        /** 是否限听 */
        readonly isReadyHand: number;
        /** 是否限自摸 */
        readonly isLimitSelfDraw: number;
        /** 庄家无台 */
        readonly isDealerNoPoint: number;
        /** 见花见字 */
        readonly hasFlowerWord: number;
        /** 封顶 */
        readonly maxFan: number;
        /** 是否是代开房 */
        readonly isAgent: number;
        /**道具配置 */
        readonly emotions: number[],
        /**密碼 */
        readonly password: string,
        /**是否观战 */
        readonly isWatchGame: number,
        /** 七抢一 */
        readonly hasRobFlower: number,
        /** 天胡地胡 */
        readonly hasTianDi: number,
        /** 八枝花 */
        readonly hasEightFlower: number,
        /** 加入房间的分享链接Key */
        readonly tableJoinKey: string,
        /** 是否是AA创房 */
        readonly isShareEquallyRoom: number,
        /** 创房方式 1-普通创房 2-代理创房 3-公桌房 */
        readonly createType: number,
        /** 支付方式 1-房主支付 2-AA支付*/
        readonly costType: number,
        /** 限时免费开关 0：关闭 1：开启, */
        readonly freeTableSwitch: number
        /** 表情限时免费开关 0：关闭 1：开启, */
        readonly freeEmotionSwitch: number, 
        /** 限时免费开始时间 */
        readonly startFreeTime: number,
        /** 限时免费结束时间 */
        readonly endFreeTime: number,
    }

    /**
     * 牌桌信息
     */
    interface TableInfo {
        //房间ID
        readonly roomId: number;
        //牌桌ID
        readonly tableId: number;
        //房间配置
        readonly roomConfig: RoomInfo;
        //牌桌玩家数量
        readonly playerCount: number;
        //当前局号
        readonly roundId: string;
        //座位上的玩家列表
        readonly playerList: PlayerInfo[];
        //当前阶段
        readonly phase: number;
    }

    /**
     * 游戏信息
     */
    interface GameInfo {
        /** 当前状态 */
        phase: number;
        /** 游戏是否开始 */
        isGameStart: number;
        /** 风圈 */
        windRound: number;
        /** 当前局数 */
        currRound: number;
        /** 当前操作玩家 */
        currActionSit: number;
        /** 当前剩余牌张数 */
        remainCardNum: number;
        /** 上一个操作玩家 */
        lastDiscardPlayerId: string,
        /** 操作时间 */
        delayTime: number;
        /** 掷骰子的点数 */
        dealTotalNum: number;
        /** 剩余的总牌数 */
        retainCardNum: number;
        /** 当前回合摸牌玩家 */
        currDrawCardPlayerId: string,
        /** 遊戲未開始倒計時 */
        waitReadyTime: number;
        /** 解散房间投票详情 */
        voteDetail: {
            /** 同意玩家列表*/
            agreePlayerIds: string[],
            /**拒绝玩家列表 */
            refusePlayerIds: string[],
            /** 发起投票者 */
            voteStartPlayerId: string,
            /** 总时长 */
            delayTime: number,
            /** 剩余时长 */
            delayRemain: number,
        }
    }

    /**
     * 牌桌上的玩家信息
     */
    interface PlayerInfo {
        //玩家ID
        readonly playerId: string;
        //玩家头像
        readonly avatar: string;
        //玩家累计的输赢分
        readonly totalScore: number;
        //椅子ID
        chairId: number;
        //玩家昵称
        readonly nickname: string;
        //是否准备
        isReady: number;
        //是否是庄家
        readonly isDealer: number;
        //连庄次数
        dealerCount: number;
        //玩家的风位
        wind: number;
        //玩家手牌
        handCards: [],
        //花牌
        flowerCards: [],
        //弃牌
        discardCards: [],
        //其他吃碰杠
        otherCards: MahjongCommon.PengGangCard[],
        //听牌
        readyHandCards: [],
        //操作提示
        options: MahjongCommon.OpeartionType[],
    }

    /**
     * 操作提示
     */
    interface OpeartionType {
        // 操作类型
        readonly reqType: number,
        // 操作牌
        readonly cards: number[],
        // 胡牌列表
        readonly winCards: MahjongCommon.WinCardTint[]
    }

    /**
     * 胡牌提示
     */
    interface WinCardTint {
        // 胡牌
        winCard: number,
        // 台数
        totalPoint: number
    }

    /**
     * 吃碰杠牌
     */
    interface PengGangCard {
        // 操作类型
        readonly cardType: number;
        // 牌数据
        readonly cards: number[],
        // 吃的牌
        readonly chowCard: number
    }

    /**
     * 代開房間列表
     */
    interface AgentRoomInfo {
        /**房间ID   */
        roomId: string,
        /**房间名称   */
        roomName: string,
        /** 房间最大局数 */
        maxRoundNum: number,
        /**房间当前局数 */
        roundNum: number,
        /**房间开始的游戏人数 */
        maxPlayerNum: number,
        /**房间当前人数     */
        playerNum: number,
        /**底注 */
        baseScore: number,
        /**出牌思考时间 */
        thinkTime: number,
        /** 最大结算番*/
        maxFan: number,
        /**有无花牌 */
        hasFlowerCard: number,
        /**每台的点数 */
        fanPoint: number,
        /**是否强制胡牌 0-不强制 1-强制胡牌 */
        isAutoHu: number,
        /** 是否是演绎房 */
        isWatchRoom: number,
        /** 消耗金币 */

        /** AA支付 */
        isShareEquallyRoom: number,
        /** 游戏状态 */
        gameStatus: number,
        /** 創房方式 1-普通创房 2-代理创房 3-公桌房*/
        createType: number,
    }

    /**
     * 黑名单信息
     */
    interface blacklistInfo {
        /**玩家ID */
        playerId: string,
        /**昵称 */
        nickname: string,
        /** 头像 */
        avatar: string
    }

    /**
     * 对局数据
     */
    interface RoundData {
        /**局号*/
        roundLimit: number,
        /**椅子数据 */
        chairData: ChairData[]
    }

    /**
     * 椅子数据
     */
    interface ChairData {
        /**用户id */
        uid: string,
        /**用户昵称 */
        nickName: string,
        /**分数 */
        score: number
    }

    /**
     * 每个座位的游戏记录
     */
    interface chairRoundRecordInfo {
        /**玩家昵称 */
        nickName: string,
        /**玩家头像 */
        avatar: string,
        /**玩家id */
        uid: string,
        /**合计积分 */
        totalScore: number,
        /**每局的积分  */
        scoreArr: number[]
    }

    /**
   * 视频数据
   */
    interface videoCallInfo {
        /**token */
        token: string,
        /**频道名称 */
        channelName: string
    }
}

/**
 * 前端发给后端的消息包
 */
declare namespace MahjongClientToServer {
    interface CreateRoom {
        /**游戏id */
        gameId: number,
        /**房间名称 */
        roomName: string,
        /**房间密码 */
        password: string,
        /**玩家人数 */
        maxPlayerNum: number,
        /**局数 */
        maxRoundNum: number,
        /**底注 */
        baseScore: number,
        /**出牌思考时间 */
        thinkTime: number,
        /**最大结算番数 */
        maxFan: number,
        /** 有无花牌  0-没有  1-有*/
        hasFlowerCard: number,
        /** 0-普通创房 1-代开房间 */
        isAgent: number,
        /**代表每台的点数 */
        fanPoint: number,
        /**是否强制胡牌 0-不强制 1-强制胡牌 */
        isAutoHu: number,
        /**见花见字 */
        hasFlowerWord: number,
        /**限听    */
        isReadyHand: number,
        /**限自摸 */
        isLimitSelfDraw: number,
        /**庄家无台 */
        isDealerNoPoint: number,
        /**七抢一 */
        hasRobFlower: number,
        /**天胡地胡*/
        hasTianDi: number,
        /**八枝花*/
        hasEightFlower: number,
        /**是否可以观战 */
        isWatchGame: number,
        /** 是否AA创房 */
        isShareEquallyRoom: number,
        /** 创房类型 1-普通创房 2-代理创房 3-公桌房 */
        createType: number,
        /** 支付方式 */
        costType: number,
        /** 游戏状态 */
        gameStatus?: number
    }

    /**
     * 创建牌桌
     */
    interface CreateTable {
        /**游戏ID**/
        readonly gameId: number;
        /**房间名称**/
        readonly roomName: string;
        /**房间密码**/
        readonly password: string;
        /**对局人数**/
        readonly maxPlayerNum: number;
        /**游戏最大局数**/
        readonly maxRoundNum: number;
        /**底注**/
        readonly baseScore: number;
    }

    /**
     * 请求牌桌列表
     */
    interface RequestTableList {
        /** 游戏 Id */
        readonly gameId: number;
        /**开始页**/
        readonly pageStart: number;
        /**结束页**/
        readonly pageEnd: number;
    }

    /**
     * 加入牌桌
     */
    interface JoinTable {
        /**游戏Id*/
        readonly gameId: number;
        /**房间ID**/
        readonly roomId: number;
        /**房间密码**/
        readonly password: string;
    }

    /**
     * 请求观战
     */
    interface RequestWatchGame {
        /**游戏Id*/
        readonly gameId: number;
        /**房间ID**/
        readonly roomId: number;
        /**房间密码**/
        readonly password: string;
    }

    /**
     * 离开牌桌
     */
    interface LeaveTable {
        //游戏ID
        readonly gameId: number;
        //房间ID
        readonly roomId: number;
        //牌桌ID
        readonly tableId: number;
    }
}

/**
 * 后端发给前端的消息包
 */
declare namespace MahjongServerToClient {

    /**
     * 牌桌信息
     */
    interface TableInfo {
        //房间ID
        readonly roomId: string;
        //牌桌ID
        readonly tableId: number;
        roomName: string,
        //房间唯一Id
        readonly roomUniqueID: string;
        //游戏信息
        readonly gameInfo: MahjongCommon.GameInfo;
        //玩家信息
        readonly playerList: MahjongCommon.PlayerInfo[];
        //房间配置
        readonly roomConfig: MahjongCommon.RoomConfig;
        //我的座位号
        readonly sitChairId: number;
        /**房主 */
        masterId: string;
        /**声网参数 */
        videoCallInfo: MahjongCommon.videoCallInfo;
    }

    /**
     * 玩家信息
     */
    interface PlayersInfo {
        /** 房间Id */
        readonly roomId: number;
        /** 游戏Id */
        readonly gameId: number;
        /** 玩家信息 */
        readonly players: MahjongCommon.PlayerInfo[];
    }

    /**
     * 创建房间的配置
     */
    interface CreateRoomConfig {
        /**游戏ID  */
        gameId: number,
        /**底分*/
        baseScore: number[],
        /** 底分输入范围 */
        baseScoreRange: number[];
        /**台分*/
        pointScore: number[],
        /** 台分输入范围 */
        fanPointRange: number[];
        /**出牌思考时间 */
        thinkTime: number[],
        /**圈数*/
        roundLimit: number[],
        /**台数限制 */
        pointLimit: [],
        /**创建房间的基础费用(每圈) */
        roundCost: number,
        /** 当前金币数 */
        currMoney: number,
        /** 春节活动开关 */
        festivalSwitch: number,
        /** 创建房间类型 */
        createType: number[],
        /** 支付类型 */
        costType: number[],
        /** 限时免费进桌开关 */
        freeTableSwitch: number,
        /** 限时免费表情开关 */
        freeEmotionSwitch: number,
        /** 限时免费开始时间 */
        startFreeTime: number,
        /** 限时免费结束时间 */
        endFreeTime: number,
    }

    /**
     * 加入房间
     */
    interface JoinRoom {
        /**房间ID */
        roomId: number,
        /**是否有密码 */
        hasPassword: number,
        /**房间名称 */
        roomName: string,
        /** 消耗金币 */
        costMoney: number,
        /**房间信息 */
        roomConfig: MahjongClientToServer.CreateRoom
    }

    /**
     * 獲取房間列表
     */
    interface GetRoomList {
        /**开始页 */
        pageStart: number,
        /**结束页 */
        pageEnd: number,
        /**房間列表 */
        rooms: MahjongCommon.AgentRoomInfo[],
        /** 当前金币数 */
        money: number;
    }

    /**
     * 玩家发起解散房间投票开始广播
     */
    interface onVoteDisbandStartPush {
        /**游戏ID*/
        gameId: number,
        /**房间ID */
        roomId: string,
        /**投票发起人ID */
        playerId: string,
        /**投票倒计时时间 */
        delayTime: number,
        /** 投票剩余时间 */
        delayRemain: number,
    }

    /**
     * 房间内解散投票结果广播
     */
    interface onVoteResultPush {
        /**游戏ID */
        gameId: number,
        /**房间ID */
        roomId: number,
        /**解散结果 0-不解散 1-解散 */
        disband: number
    }

    /**
     * 房间内玩家确认投票动作广播
     */
    interface onVotePlayerActionPush {
        /**游戏ID */
        gameId: number,
        /**房间ID */
        roomId: string,
        /** 同意玩家列表*/
        agreePlayerIds: string[],
        /**拒绝玩家列表 */
        refusePlayerIds: string[],
    }

    /**
     * 房主拉取黑名单列表
     */
    interface getBlacklist {
        blackList: MahjongCommon.blacklistInfo[]
    }

    /**
     * 玩家使用互动表情
     */
    interface onPlayerEmotion {
        /**游戏ID */
        gameId: number,
        /**牌桌id */
        tableId: number,
        /**座位id */
        chairId: number,
        /**被使用道具的椅子 */
        toChairId: number,
        /**互动表情id */
        emotionId: number
    }

}

