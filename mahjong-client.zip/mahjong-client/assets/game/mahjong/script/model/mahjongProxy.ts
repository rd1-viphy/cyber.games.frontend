import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import AppEmitter from "../../../../script/network/AppEmitter";

import NetConnect from "../../../../script/network/NetConnect";
import MahjongControl from "../control/mahjongControl";
import { MAHJONG_REQUEST_ROUTE } from "./mahjongEnum";
import MahjongModel from "./mahjongModel";
import mahjongTestData = require("./mahjongTestData");

const MahjongServerMsg = {

    /** 游戏状态切换 */
    GAME_STAGE_MSG: "onPhaseChangePush",

    /** 发牌 */
    DEAL_CARD_MSG: "onDealCardsPush",

    /** 掷骰子 */
    DICE_RANDOM_MSG: "OnDiceRandomPush",

    /** 广播玩家可以进行操作 */
    PLAYER_OPERATION_MSG: "OnPreOperation",

    /** 广播玩家摸牌 */
    PLAYER_DRAW_CARD_MSG: "OnDrawCardPush",

    /** 结算消息 */
    SETTLE_MSG: "onSettlePush",

    /** 流局 */
    FLOWPUSH_MSG: "onFlowPush",

    /** 玩家操作 */
    PLAYER_ACTION_MSG: "onPlayerActionPush",

    /** 广播有其他玩家坐下 */
    PLAYER_SIT_MSG: "onNoticePlayerSitPush",

    /** 其他玩家准备 */
    PLAYER_READY: "onPlayerReadyPush",

    /** 游戏开始 */
    GAME_START: "onNoticeGameStartPush",

    /** 广播玩家替花 */
    EXCHANGE_FLOWER: "onExchangeFlowerPush",

    /** 离开房间 */
    LEAVE_TABLE: "onNoticePlayerLeave",

    /**房间内玩家确认投票动作广播 */
    VOTE_PLATER_ACTION_PUSH: "onVotePlayerActionPush",

    /**玩家发起解散房间投票开始广播 */
    VOTE_START_PUSH: "onVoteDisbandStartPush",

    /** 解散投票广播 */
    DISROOM_MSG: "onVoteResultPush",

    /** 总战绩广播 */
    TOTAL_RESULT_MSG: "onPlayerTotalRecords",

    /** 踢出房间 */
    KICK_OUT_MSG: "onPlayerKickOutPush",

    /** 确定抓风位置 */
    GRAB_WIND_MSG: "onRandomWindPush",

    /** 定庄 */
    SURE_BANK_MSG: "onRandomDealerPush",

    /** 听牌后番型变换 */
    TINGCARDPOINT_CHANGE_MSG: "onPlayerReadyPointChange",

    /** 行牌限制 */
    LIMITPUSHCARD: "onPlayerOptLimitPush",

    /** 广播表情 */
    EMOJI_MSG: "onSendEmojiPush",

    /** 房间解散 */
    ROOM_DISBAND: "onRoomDisbandPush",

    /** 聊天 */
    PLAYER_CHAT_MSG: "onSendMessagePush",

    /** 离线通知 */
    PLAYER_OFFLINE_MSG: "onPlayerStatusChange",

    /** 其他玩家準備後遊戲不開始解散後倒計時 */
    ROOM_DISS_TIMER: "onPlayerAllReadyPush",
}

export default class MahjongProxy {

    protected control: MahjongControl = null;

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    protected listenerFunMap: Map<string, Function> = new Map<string, Function>();

    constructor(control: MahjongControl) {
        this.control = control;
        this.gameModel.initData(MahjongRoomMgr.getInstance().gameData)
        NetConnect.pomelo.isLoadingScene = false;
        this.listenerGameEvents();
    }

    /**
     * 游戏消息的监听
     */
    protected listenerGameEvents() {
        Object.values(MahjongServerMsg).forEach((value) => {
            this.listenerFunMap.set(value, this.processServerMsg.bind(this, value));
            AppEmitter.on(value, this.listenerFunMap.get(value), this);
        });
    }

    /**
     * 取消游戏消息的监听
     */
    protected unListenerGameEvents() {
        Object.values(MahjongServerMsg).forEach((value) => {
            if (this.listenerFunMap.has(value)) {
                AppEmitter.off(value, this.listenerFunMap.get(value));
                this.listenerFunMap.delete(value);
            }
        });
    }

    public processServerMsg(type: string, data) {
        if (!this.gameModel.isCurrectRoom(data)) {
            return;
        }
        const timestamp = new Date();
        App.showLog(timestamp + type, data);
        switch (type) {
            case MahjongServerMsg.GAME_STAGE_MSG:
                this.control.onGameStageMsg(data);
                break;
            case MahjongServerMsg.PLAYER_SIT_MSG:
                this.control.onPlayerSit(data);
                break;
            case MahjongServerMsg.GAME_START:
                this.control.onGameStart(data);
                break;
            case MahjongServerMsg.GRAB_WIND_MSG:
                this.control.onGameSureWind(data);
                break;
            case MahjongServerMsg.SURE_BANK_MSG:
                this.control.onGameSureBank(data);
                break;
            case MahjongServerMsg.PLAYER_READY:
                this.control.onPlayerReady(data);
                break;
            case MahjongServerMsg.PLAYER_CHAT_MSG:
                this.control.onPlayerChat(data);
                break;
            case MahjongServerMsg.DEAL_CARD_MSG:
                this.control.onDealCard(data);
                break;
            case MahjongServerMsg.PLAYER_OPERATION_MSG:
                this.control.onPlayerOperation(data);
                break;
            case MahjongServerMsg.EXCHANGE_FLOWER:
                this.control.onExchangeFlowerCard(data);
                break;
            case MahjongServerMsg.PLAYER_DRAW_CARD_MSG:
                this.control.onPlayerDrawCard(data);
                break;
            case MahjongServerMsg.PLAYER_ACTION_MSG:
                this.control.onPlayerAction(data);
                break;
            case MahjongServerMsg.SETTLE_MSG:
                this.control.onGameSettle(data);
                break;
            case MahjongServerMsg.TOTAL_RESULT_MSG:
                this.control.onGameTotalSettle(data);
                break;
            case MahjongServerMsg.FLOWPUSH_MSG:
                this.control.onGameFlow(data);
                break;
            case MahjongServerMsg.TINGCARDPOINT_CHANGE_MSG:
                this.control.onTingCardPoint(data);
                break;
            case MahjongServerMsg.LEAVE_TABLE:
                this.control.onPlayerLeaveTable(data);
                break;
            case MahjongServerMsg.KICK_OUT_MSG:
                this.control.onKickOutRoom(data);
                break;
            case MahjongServerMsg.VOTE_START_PUSH:          //开始解散
                this.control.onStartDissilution(data);
                break;
            case MahjongServerMsg.VOTE_PLATER_ACTION_PUSH:  //玩家解散操作
                this.control.onDissilutionPlayerAction(data);
                break;
            case MahjongServerMsg.DISROOM_MSG:               //解散结束
                this.control.onDissilutionResult(data);
                break;
            case MahjongServerMsg.ROOM_DISBAND:
                this.control.onExitRoom();
                break;
            case MahjongServerMsg.EMOJI_MSG:
                this.control.onPlayerEomotion(data);
                break;
            case MahjongServerMsg.LIMITPUSHCARD:
                this.control.onLimitPushCard(data);
                break;
            case MahjongServerMsg.PLAYER_OFFLINE_MSG:
                this.control.setPlayerStatusChanged(data);
                break;
            case MahjongServerMsg.ROOM_DISS_TIMER:
                this.control.setRoomDissTimer(data);
                break;
            default:
                break;
        }
    }

    /**
     * 向服务器发送请求
     * @param route             消息
     * @param requestData       请求数据  
     * @param successCallback   成功回调 
     * @param isShowLoading     是否显示加载圈
     * @param failCallback      失败回调
     */
    protected sendMessageToServer(route: string, requestData: object = {}, successCallback: Function = null, isShowLoading: boolean = true, failCallback: Function = null) {
        const commonData = {
            gameId: platform_game_id.mahjong_table,
            roomId: this.gameModel.tableId,
        }
        const sendData = Object.assign(commonData, requestData);
        NetConnect.sendRequest(route, sendData, successCallback, isShowLoading, failCallback);
    }

    /**
     * 操作请求
     * @param operationData 
     * @param opeartionType 
     */
    public sendPlayerOperationType(operationData, opeartionType, cb) {
        const data = {
            "reqBody": {
                reqType: opeartionType,
                cards: operationData,
            }
        }
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.OPERATION, data, cb);
    }

    /**
     * 玩家准备
     */
    public sendPlayerReady(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_READY, {}, cb);
    }

    /**
     * 离开房间
     */
    public sendPlayerLeaveRoom(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.LEAVE_TABLE, {}, cb);
    }

    /**
     * 结束游戏投票
     * @param vote 
     * @param cb 
     */
    public sendEndGameVote(vote, cb: Function = null, failcb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_END_VOTE, vote, cb, true, failcb);
    }

    /**
     * 确认结束游戏投票
     * @param vote 
     * @param cb 
     */
    public sendSureEndGameVote(vote, cb: Function = null) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_SURE_ENDGAME, vote, cb);
    }

    /**
     * 继续游戏
     */
    public sendContinueGame(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_CONTINUE, {}, cb);
    }

    /**
     * 踢出房间、加入黑名单
     * @param requestData 
     * @param cb 
     */
    public sendPlayerKick(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_KICK_OUT_PLAYER, requestData, cb);
    }

    /**
     * 移除黑名單
     */
    public sendRemoveFromBlacklist(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_REMOVE_FROME_BLACKLIST, requestData, cb);
    }

    /**
     * 发送互动表情
     * @param requestData 
     */
    public sendEmoij(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_SEND_EMOJI, requestData, cb);
    }

    /**
    * 发送聊天消息
    * @param requestData 
    */
    public sendMessage(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_SEND_MSG, requestData, cb);
    }

    /**
     * 游戏内拉取游戏战绩
     * @param requestData 
     * @param cb 
     */
    public getGameDetail(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_GET_GAME_DETAIL, requestData, cb);
    }

    /**
     * 游戏内拉取游戏记录
     */
    public getGameScoreRecords(requestData, cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_GET_GAME_SCORE_RECORD, requestData, cb);
    }

    /**
     * 游戏内拉取黑名单
     * @param cb 
     */
    public getGameBlackList(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_GET_GAME_BLACKLIST, {}, cb);
    }

    /**
     * 观战玩家坐下参与游戏
     * @param requestData 
     * @param cb 
     */
    public sendPlayerSitDown(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_SITDOWN_PLAY, {}, cb);
    }

    /**
     * 座位玩家站起加入观战
     * @param requestData 
     * @param cb 
     */
    public sendPlayerSitUpWatch(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_SITUP_WATCH, {}, cb);
    }

    /**
     * 房主在游戏开始之前发起解散房间请求
     * @param cb 
     */
    public sendGameMasterDissRoom(cb) {
        this.sendMessageToServer(MAHJONG_REQUEST_ROUTE.GAME_MASTER_DISSROOM, {}, cb);
    }

    destroy() {
        this.control = null;
        this.unListenerGameEvents();
        this.listenerFunMap.clear();
        this.gameModel = null;
    }

}