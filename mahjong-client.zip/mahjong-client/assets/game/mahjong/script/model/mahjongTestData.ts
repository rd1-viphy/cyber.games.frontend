
const mahjongTestData = {

    onSettleData: { "gameId": 15, "roomId": 208869, "roundWind": 1, "gameEndType": 1, "details": [{ "playerId": "615522a915f05900fe3f7438", "avatar": "1", "nickname": "111111", "totalScore": 3800, "handCards": [49, 50, 51, 52, 53, 54, 55, 56, 57, 33, 34, 35, 20, 20, 23, 24, 22], "flowerCards": [], "otherCards": [], "wind": 1, "isDealre": 0, "isShot": 0, "totalFan": 11, "fanList": [{ "pointType": 4, "point": 8 }, { "pointType": 24, "point": 1 }, { "pointType": 21, "point": 2 }], "winCards": [22], "settleScore": 210 }, { "playerId": "61b8b20372fa23aab06f0d2e", "avatar": "https://localhost.livesystem168.com/avatar/ssz_touxing02.png", "nickname": "44544", "totalScore": -3800, "handCards": [68, 83, 17, 38, 82, 33, 37, 40, 66, 65, 65, 40, 52, 38, 49, 24], "flowerCards": [100, 103, 104], "otherCards": [], "wind": 2, "isDealre": 1, "isShot": 1, "totalFan": 11, "fanList": [{ "pointType": 4, "point": 8 }, { "pointType": 24, "point": 1 }, { "pointType": 21, "point": 2 }], "winCards": [], "settleScore": -210 }] },

    onPlayBackData1: {
        "records": [
            {
                "_id": ("61dd4439a78689d77d2545f5"),
                "msgId": 1,
                "route": "onPlayerJoinGamePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "roomName": "Guest的牌桌",
                    "gameState": 2,
                    "masterId": "61dcee7fa20c4db4a0d93a25",
                    "roomUniqueID": "ffe2402cf993bbebfe35dfb6258c0b81",
                    "isWatch": 0,
                    "roomConfig": {
                        "isAgent": 0,
                        "maxPlayerNum": 4,
                        "maxRoundNum": 1,
                        "baseScore": 100,
                        "thinkTime": 20,
                        "maxFan": 0,
                        "hasFlowerCard": 1,
                        "fanPoint": 20,
                        "isAutoHu": 0,
                        "emotions": [
                            1,
                            0,
                            2,
                            0,
                            3,
                            0,
                            4,
                            0,
                            5,
                            0,
                            6,
                            100,
                            7,
                            200,
                            8,
                            300
                        ],
                        "hasFlowerWord": 0,
                        "isReadyHand": 0,
                        "isLimitSelfDraw": 0,
                        "isDealerNoPoint": 0,
                        "hasRobFlower": 1,
                        "hasTianDi": 1,
                        "hasEightFlower": 1,
                        "tableJoinKey": "qaVB4eGot",
                        "password": "",
                        "isWatchGame": 1,
                        "isShareEquallyRoom": 0
                    },
                    "gameInfo": {
                        "phase": 1,
                        "windRound": 1,
                        "remainCardNum": 128,
                        "currRound": 1,
                        "delayTime": 0,
                        "dealTotalNum": 0,
                        "lastDiscardPlayerId": "",
                        "retainCardNum": 16,
                        "voteDetail": {
                            "agreePlayerIds": [],
                            "refusePlayerIds": [],
                            "delayTime": 10,
                            "delayRemain": 0
                        },
                        "isGameStart": 0
                    },
                    "playerList": [
                        {
                            "playerId": "61dcee7fa20c4db4a0d93a25",
                            "avatar": "",
                            "nickname": "Guest-326",
                            "totalScore": 0,
                            "chairId": 0,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        },
                        {
                            "playerId": "606d5bfb4c4b8f86e8b3168e",
                            "avatar": "https://cdn.qc1.iamrich.wz3.bet/upload/1dcbd8883d056a6521b39694cd34f09f1617780117.jpg",
                            "nickname": "大貓咪戰略家",
                            "totalScore": 0,
                            "chairId": 1,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        },
                        {
                            "playerId": "61dbcdda944732668cfc6f13",
                            "avatar": "",
                            "nickname": "Guest-67",
                            "totalScore": 0,
                            "chairId": 2,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        },
                        {
                            "playerId": "608f599809a78d0a77bc3e71",
                            "avatar": "",
                            "nickname": "Guest-537",
                            "totalScore": 0,
                            "chairId": 3,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        }
                    ],
                    "videoCallInfo": null
                }
            },
            {
                "_id": ("61dd4439a78689835d2545f6"),
                "msgId": 2,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 1,
                    "delayTime": 1,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd4439a78689344a2545f7"),
                "msgId": 3,
                "route": "onNoticeGameStartPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "totalCardNum": 128
                }
            },
            {
                "_id": ("61dd4439a786896ec42545f8"),
                "msgId": 4,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 2,
                    "delayTime": 3,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd4439a78689652d2545f9"),
                "msgId": 5,
                "route": "onRandomWindPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "diceList": [
                        3,
                        5,
                        4
                    ],
                    "playerList": [
                        {
                            "playerId": "61dcee7fa20c4db4a0d93a25",
                            "chairId": 0,
                            "wind": 1
                        },
                        {
                            "playerId": "606d5bfb4c4b8f86e8b3168e",
                            "chairId": 1,
                            "wind": 2
                        },
                        {
                            "playerId": "61dbcdda944732668cfc6f13",
                            "chairId": 2,
                            "wind": 3
                        },
                        {
                            "playerId": "608f599809a78d0a77bc3e71",
                            "chairId": 3,
                            "wind": 4
                        }
                    ]
                }
            },
            {
                "_id": ("61dd4439a7868907d32545fa"),
                "msgId": 6,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 3,
                    "delayTime": 5,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd4439a786893aaf2545fb"),
                "msgId": 7,
                "route": "onRandomDealerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 3,
                    "diceList": [
                        5,
                        5,
                        5
                    ],
                    "dealerId": "606d5bfb4c4b8f86e8b3168e",
                    "dealerCount": 0,
                    "windRound": 1,
                    "roundNum": 1,
                    "playerWinds": [
                        {
                            "playerId": "61dcee7fa20c4db4a0d93a25",
                            "wind": 4
                        },
                        {
                            "playerId": "606d5bfb4c4b8f86e8b3168e",
                            "wind": 1
                        },
                        {
                            "playerId": "61dbcdda944732668cfc6f13",
                            "wind": 2
                        },
                        {
                            "playerId": "608f599809a78d0a77bc3e71",
                            "wind": 3
                        }
                    ],
                    "isLastDealer": 0
                }
            },
            {
                "_id": ("61dd4439a7868942f72545fc"),
                "msgId": 8,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 4,
                    "delayTime": 3,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd4439a78689b2ea2545fd"),
                "msgId": 9,
                "route": "onDealCardsPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "handCards": [
                        {
                            "chairId": 0,
                            "playerId": "61dcee7fa20c4db4a0d93a25",
                            "cards": [
                                83,
                                41,
                                40,
                                68,
                                104,
                                52,
                                22,
                                81,
                                21,
                                52,
                                33,
                                22,
                                40,
                                57,
                                67,
                                39
                            ]
                        },
                        {
                            "chairId": 1,
                            "playerId": "606d5bfb4c4b8f86e8b3168e",
                            "cards": [
                                36,
                                102,
                                36,
                                38,
                                66,
                                57,
                                41,
                                83,
                                38,
                                68,
                                38,
                                81,
                                25,
                                57,
                                23,
                                65,
                                18
                            ]
                        },
                        {
                            "chairId": 2,
                            "playerId": "61dbcdda944732668cfc6f13",
                            "cards": [
                                49,
                                41,
                                54,
                                17,
                                24,
                                18,
                                19,
                                23,
                                34,
                                65,
                                100,
                                81,
                                98,
                                68,
                                34,
                                37
                            ]
                        },
                        {
                            "chairId": 3,
                            "playerId": "608f599809a78d0a77bc3e71",
                            "cards": [
                                41,
                                34,
                                19,
                                53,
                                82,
                                36,
                                55,
                                82,
                                103,
                                21,
                                83,
                                18,
                                66,
                                35,
                                22,
                                49
                            ]
                        }
                    ]
                }
            },
            {
                "_id": ("61dd4439a78689504e2545fe"),
                "msgId": 10,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a7868972412545ff"),
                "msgId": 11,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "flowerCards": [
                        102
                    ],
                    "exchangeCards": [
                        39
                    ]
                }
            },
            {
                "_id": ("61dd4439a78689d222254600"),
                "msgId": 12,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689dd3c254601"),
                "msgId": 13,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "61dbcdda944732668cfc6f13",
                    "flowerCards": [
                        98,
                        100
                    ],
                    "exchangeCards": [
                        37,
                        66
                    ]
                }
            },
            {
                "_id": ("61dd4439a78689d8ed254602"),
                "msgId": 14,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689d4fe254603"),
                "msgId": 15,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "608f599809a78d0a77bc3e71",
                    "flowerCards": [
                        103
                    ],
                    "exchangeCards": [
                        37
                    ]
                }
            },
            {
                "_id": ("61dd4439a786890540254604"),
                "msgId": 16,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868901f6254605"),
                "msgId": 17,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "flowerCards": [
                        104
                    ],
                    "exchangeCards": [
                        50
                    ]
                }
            },
            {
                "_id": ("61dd4439a786892d89254606"),
                "msgId": 18,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786893dcf254607"),
                "msgId": 19,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786890eca254608"),
                "msgId": 20,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786891ea4254609"),
                "msgId": 21,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868995ac25460a"),
                "msgId": 22,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        50
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a78689272425460b"),
                "msgId": 23,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868902fe25460c"),
                "msgId": 24,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786897e0825460d"),
                "msgId": 25,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689dbef25460e"),
                "msgId": 26,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        67
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786895f0b25460f"),
                "msgId": 27,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786894185254610"),
                "msgId": 28,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689931a254611"),
                "msgId": 29,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786894147254612"),
                "msgId": 30,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        33
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786892d21254613"),
                "msgId": 31,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786897036254614"),
                "msgId": 32,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786897b4a254615"),
                "msgId": 33,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689024c254616"),
                "msgId": 34,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        82
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a786896bf0254617"),
                "msgId": 35,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689db7d254618"),
                "msgId": 36,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786897838254619"),
                "msgId": 37,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689e06625461a"),
                "msgId": 38,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        55
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a78689448125461b"),
                "msgId": 39,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868954ad25461c"),
                "msgId": 40,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868916d425461d"),
                "msgId": 41,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689831625461e"),
                "msgId": 42,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        35
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786894c3325461f"),
                "msgId": 43,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            83
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689ea82254620"),
                "msgId": 44,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        83
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a786894780254621"),
                "msgId": 45,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786890613254622"),
                "msgId": 46,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        38
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a78689e783254623"),
                "msgId": 47,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            83
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895ac3254624"),
                "msgId": 48,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        83
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786890cd5254625"),
                "msgId": 49,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689e03e254626"),
                "msgId": 50,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        56
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a786892895254627"),
                "msgId": 51,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            82
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786890dd5254628"),
                "msgId": 52,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        82
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786890f61254629"),
                "msgId": 53,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786890c2625462a"),
                "msgId": 54,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            82
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868990de25462b"),
                "msgId": 55,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        82
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 4,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a7868922eb25462c"),
                "msgId": 56,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689b42925462d"),
                "msgId": 57,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            67
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689410525462e"),
                "msgId": 58,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        67
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689516325462f"),
                "msgId": 59,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a78689e2ad254630"),
                "msgId": 60,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        34
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786898883254631"),
                "msgId": 61,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            67
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786894014254632"),
                "msgId": 62,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        67
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786893bde254633"),
                "msgId": 63,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786897449254634"),
                "msgId": 64,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        39
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a78689a88b254635"),
                "msgId": 65,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895352254636"),
                "msgId": 66,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786897e83254637"),
                "msgId": 67,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689ec82254638"),
                "msgId": 68,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        67
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a786892675254639"),
                "msgId": 69,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689832925463a"),
                "msgId": 70,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786896be325463b"),
                "msgId": 71,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689825725463c"),
                "msgId": 72,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        50
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786897be125463d"),
                "msgId": 73,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            41
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786891e4225463e"),
                "msgId": 74,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        41
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689196f25463f"),
                "msgId": 75,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a7868908a4254640"),
                "msgId": 76,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a78689e7d9254641"),
                "msgId": 77,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        23
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786897880254642"),
                "msgId": 78,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689f517254643"),
                "msgId": 79,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a78689dd5c254644"),
                "msgId": 80,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786893f92254645"),
                "msgId": 81,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        40
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a786897273254646"),
                "msgId": 82,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            83
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689d392254647"),
                "msgId": 83,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        83
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689926a254648"),
                "msgId": 84,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868918bf254649"),
                "msgId": 85,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        35
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a78689218a25464a"),
                "msgId": 86,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            67
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689028e25464b"),
                "msgId": 87,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        67
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786893e1425464c"),
                "msgId": 88,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a786899ce925464d"),
                "msgId": 89,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        20
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a78689c12f25464e"),
                "msgId": 90,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            49
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689794e25464f"),
                "msgId": 91,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a786895a5e254650"),
                "msgId": 92,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868947e4254651"),
                "msgId": 93,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        101
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786897b8f254652"),
                "msgId": 94,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "flowerCards": [
                        101
                    ],
                    "exchangeCards": [
                        54
                    ]
                }
            },
            {
                "_id": ("61dd4439a78689ccb2254653"),
                "msgId": 95,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786892aa1254654"),
                "msgId": 96,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786891b56254655"),
                "msgId": 97,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786898b14254656"),
                "msgId": 98,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895cc6254657"),
                "msgId": 99,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 4,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786890e06254658"),
                "msgId": 100,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689f43c254659"),
                "msgId": 101,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            65
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786897adf25465a"),
                "msgId": 102,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        65
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a7868976c625465b"),
                "msgId": 103,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868914fb25465c"),
                "msgId": 104,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        33
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a7868909b025465d"),
                "msgId": 105,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            65
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689f35425465e"),
                "msgId": 106,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        65
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689acc225465f"),
                "msgId": 107,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689691e254660"),
                "msgId": 108,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        97
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786891c83254661"),
                "msgId": 109,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "playerId": "608f599809a78d0a77bc3e71",
                    "flowerCards": [
                        97
                    ],
                    "exchangeCards": [
                        36
                    ]
                }
            },
            {
                "_id": ("61dd4439a786892847254662"),
                "msgId": 110,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            50
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689472d254663"),
                "msgId": 111,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        50
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a7868983b0254664"),
                "msgId": 112,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786899876254665"),
                "msgId": 113,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        35
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786894e5f254666"),
                "msgId": 114,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            34
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689daa7254667"),
                "msgId": 115,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        34
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a78689284b254668"),
                "msgId": 116,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a78689776d254669"),
                "msgId": 117,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            34
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786894ee825466a"),
                "msgId": 118,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        34
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 4,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868950c725466b"),
                "msgId": 119,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689461325466c"),
                "msgId": 120,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            41
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868941a925466d"),
                "msgId": 121,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        41
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689344225466e"),
                "msgId": 122,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689de9e25466f"),
                "msgId": 123,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        51
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a78689a9c3254670"),
                "msgId": 124,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            35
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895581254671"),
                "msgId": 125,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        35
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689cf34254672"),
                "msgId": 126,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868981c2254673"),
                "msgId": 127,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        17
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786899285254674"),
                "msgId": 128,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            17
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895ce5254675"),
                "msgId": 129,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        17
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786893eb0254676"),
                "msgId": 130,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a786891b9d254677"),
                "msgId": 131,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        53
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a7868964e4254678"),
                "msgId": 132,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            56
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786890761254679"),
                "msgId": 133,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        56
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689618e25467a"),
                "msgId": 134,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689a51325467b"),
                "msgId": 135,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 3,
                        "cards": [
                            54,
                            55,
                            56
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786897e2225467c"),
                "msgId": 136,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        54,
                        55,
                        56
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 3,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689ba7925467d"),
                "msgId": 137,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786897ad325467e"),
                "msgId": 138,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            49
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786893fcb25467f"),
                "msgId": 139,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786893fd7254680"),
                "msgId": 140,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689844b254681"),
                "msgId": 141,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        82
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786893a74254682"),
                "msgId": 142,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 11,
                        "cards": [
                            82
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786899e3f254683"),
                "msgId": 143,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        82
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 11,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a7868979c8254684"),
                "msgId": 144,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a786896d8c254685"),
                "msgId": 145,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        51
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786891abd254686"),
                "msgId": 146,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            37
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689a46d254687"),
                "msgId": 147,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        37
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689fa38254688"),
                "msgId": 148,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689352a254689"),
                "msgId": 149,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            37
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689632325468a"),
                "msgId": 150,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        37
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 4,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786896a9025468b"),
                "msgId": 151,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689393a25468c"),
                "msgId": 152,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            33
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868980e125468d"),
                "msgId": 153,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        33
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a786890d5425468e"),
                "msgId": 154,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689a21b25468f"),
                "msgId": 155,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            33
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868909a2254690"),
                "msgId": 156,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        33
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 4,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868951f4254691"),
                "msgId": 157,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868959e1254692"),
                "msgId": 158,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            54
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689b70a254693"),
                "msgId": 159,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        54
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868976e4254694"),
                "msgId": 160,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689f3e6254695"),
                "msgId": 161,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        23
                    ],
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd4439a7868925a5254696"),
                "msgId": 162,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            18
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786893fa6254697"),
                "msgId": 163,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        18
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a7868952ee254698"),
                "msgId": 164,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689047b254699"),
                "msgId": 165,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 1,
                        "cards": []
                    }
                }
            },
            {
                "_id": ("61dd4439a78689249525469a"),
                "msgId": 166,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a7868930b325469b"),
                "msgId": 167,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        39
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a78689723925469c"),
                "msgId": 168,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            39
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689c68825469d"),
                "msgId": 169,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        39
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689e7f825469e"),
                "msgId": 170,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689036625469f"),
                "msgId": 171,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            39
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786895a572546a0"),
                "msgId": 172,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        39
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 4,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a78689cd332546a1"),
                "msgId": 173,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 20,
                    "waitPlayerId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a7868928292546a2"),
                "msgId": 174,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "606d5bfb4c4b8f86e8b3168e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            53
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868937eb2546a3"),
                "msgId": 175,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        53
                    ],
                    "actionPlayerId": "606d5bfb4c4b8f86e8b3168e",
                    "actionType": 2,
                    "targetId": "606d5bfb4c4b8f86e8b3168e"
                }
            },
            {
                "_id": ("61dd4439a7868910392546a4"),
                "msgId": 176,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689091d2546a5"),
                "msgId": 177,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        25
                    ],
                    "waitPlayerId": "61dbcdda944732668cfc6f13",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61dd4439a786891f8c2546a6"),
                "msgId": 178,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 10,
                        "cards": [
                            50
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868946542546a7"),
                "msgId": 179,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        50
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 2,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689dc262546a8"),
                "msgId": 180,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 10,
                    "targetId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689018f2546a9"),
                "msgId": 181,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a786895ab72546aa"),
                "msgId": 182,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        53
                    ],
                    "waitPlayerId": "608f599809a78d0a77bc3e71",
                    "waitChairId": 3
                }
            },
            {
                "_id": ("61dd4439a786896c792546ab"),
                "msgId": 183,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "608f599809a78d0a77bc3e71",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            55
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a786896c402546ac"),
                "msgId": 184,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        55
                    ],
                    "actionPlayerId": "608f599809a78d0a77bc3e71",
                    "actionType": 2,
                    "targetId": "608f599809a78d0a77bc3e71"
                }
            },
            {
                "_id": ("61dd4439a78689544c2546ad"),
                "msgId": 185,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "delayTime": 20,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868978362546ae"),
                "msgId": 186,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 6,
                    "cards": [
                        22
                    ],
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd4439a786890a2e2546af"),
                "msgId": 187,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dcee7fa20c4db4a0d93a25",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            35
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a78689fb4e2546b0"),
                "msgId": 188,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        35
                    ],
                    "actionPlayerId": "61dcee7fa20c4db4a0d93a25",
                    "actionType": 2,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a786899fdf2546b1"),
                "msgId": 189,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868970232546b2"),
                "msgId": 190,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61dbcdda944732668cfc6f13",
                    "reqBody": {
                        "reqType": 7,
                        "cards": [
                            35
                        ]
                    }
                }
            },
            {
                "_id": ("61dd4439a7868925932546b3"),
                "msgId": 191,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 244575,
                    "gameId": 15,
                    "cards": [
                        35
                    ],
                    "actionPlayerId": "61dbcdda944732668cfc6f13",
                    "actionType": 7,
                    "targetId": "61dcee7fa20c4db4a0d93a25"
                }
            },
            {
                "_id": ("61dd4439a7868960862546b4"),
                "msgId": 192,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "phase": 8,
                    "delayTime": 20,
                    "waitPlayerId": "61dbcdda944732668cfc6f13"
                }
            },
            {
                "_id": ("61dd4439a78689dbeb2546b5"),
                "msgId": 193,
                "route": "onSettlePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 244575,
                    "roundWind": 1,
                    "gameEndType": 1,
                    "details": [
                        {
                            "playerId": "61dcee7fa20c4db4a0d93a25",
                            "avatar": "",
                            "nickname": "Guest-326",
                            "totalScore": -140,
                            "handCards": [
                                41,
                                40,
                                52,
                                22,
                                21,
                                52,
                                22,
                                40,
                                39,
                                50,
                                38,
                                23,
                                22
                            ],
                            "flowerCards": [
                                101,
                                104
                            ],
                            "otherCards": [
                                {
                                    "cardType": 2,
                                    "cards": [
                                        33
                                    ],
                                    "targetId": "61dbcdda944732668cfc6f13",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "316",
                            "chairId": 0,
                            "wind": 4,
                            "isDealre": 0,
                            "isShot": 1,
                            "totalFan": 2,
                            "fanList": [
                                {
                                    "pointType": 28,
                                    "point": 1
                                },
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [],
                            "settleScore": -140
                        },
                        {
                            "playerId": "606d5bfb4c4b8f86e8b3168e",
                            "avatar": "https://cdn.qc1.iamrich.wz3.bet/upload/1dcbd8883d056a6521b39694cd34f09f1617780117.jpg",
                            "nickname": "大貓咪戰略家",
                            "totalScore": 0,
                            "handCards": [
                                36,
                                36,
                                38,
                                41,
                                38,
                                38,
                                25,
                                23,
                                40,
                                23
                            ],
                            "flowerCards": [
                                102
                            ],
                            "otherCards": [
                                {
                                    "cardType": 2,
                                    "cards": [
                                        57
                                    ],
                                    "targetId": "61dcee7fa20c4db4a0d93a25",
                                    "chowCard": 0
                                },
                                {
                                    "cardType": 2,
                                    "cards": [
                                        39
                                    ],
                                    "targetId": "61dbcdda944732668cfc6f13",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "242",
                            "chairId": 1,
                            "wind": 1,
                            "isDealre": 1,
                            "isShot": 0,
                            "totalFan": 2,
                            "fanList": [
                                {
                                    "pointType": 28,
                                    "point": 1
                                },
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [],
                            "settleScore": 0
                        },
                        {
                            "playerId": "61dbcdda944732668cfc6f13",
                            "avatar": "",
                            "nickname": "Guest-67",
                            "totalScore": 140,
                            "handCards": [
                                17,
                                24,
                                18,
                                19,
                                23,
                                35,
                                25,
                                35
                            ],
                            "flowerCards": [
                                98,
                                100
                            ],
                            "otherCards": [
                                {
                                    "cardType": 2,
                                    "cards": [
                                        34
                                    ],
                                    "targetId": "61dcee7fa20c4db4a0d93a25",
                                    "chowCard": 0
                                },
                                {
                                    "cardType": 1,
                                    "cards": [
                                        54,
                                        55
                                    ],
                                    "targetId": "606d5bfb4c4b8f86e8b3168e",
                                    "chowCard": 56
                                },
                                {
                                    "cardType": 2,
                                    "cards": [
                                        37
                                    ],
                                    "targetId": "608f599809a78d0a77bc3e71",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "57",
                            "chairId": 2,
                            "wind": 2,
                            "isDealre": 0,
                            "isShot": 0,
                            "totalFan": 2,
                            "fanList": [
                                {
                                    "pointType": 28,
                                    "point": 1
                                },
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [
                                35
                            ],
                            "settleScore": 140
                        },
                        {
                            "playerId": "608f599809a78d0a77bc3e71",
                            "avatar": "",
                            "nickname": "Guest-537",
                            "totalScore": 0,
                            "handCards": [
                                34,
                                19,
                                53,
                                36,
                                21,
                                18,
                                22,
                                35,
                                20,
                                36,
                                51,
                                51,
                                53
                            ],
                            "flowerCards": [
                                97,
                                103
                            ],
                            "otherCards": [
                                {
                                    "cardType": 5,
                                    "cards": [
                                        82
                                    ],
                                    "targetId": "606d5bfb4c4b8f86e8b3168e",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "527",
                            "chairId": 3,
                            "wind": 3,
                            "isDealre": 0,
                            "isShot": 0,
                            "totalFan": 2,
                            "fanList": [
                                {
                                    "pointType": 28,
                                    "point": 1
                                },
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [],
                            "settleScore": 0
                        }
                    ]
                }
            }
        ]
    },

    onPlayBackData2: {
        "records": [
            {
                "_id": ("61dd47a08bdfcef2ec63533f"),
                "msgId": 1,
                "route": "onPlayerJoinGamePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "roomName": "派囝仔的牌桌",
                    "gameState": 2,
                    "masterId": "61405af8c50be1438ee52938",
                    "roomUniqueID": "a682fbb9f9f42ee4e8fbdeb96fe0c867",
                    "isWatch": 0,
                    "roomConfig": {
                        "isAgent": 1,
                        "maxPlayerNum": 2,
                        "maxRoundNum": 1,
                        "baseScore": 200,
                        "thinkTime": 12,
                        "maxFan": 0,
                        "hasFlowerCard": 1,
                        "fanPoint": 25,
                        "isAutoHu": 0,
                        "emotions": [
                            1,
                            100,
                            2,
                            100,
                            3,
                            100,
                            4,
                            100,
                            5,
                            100,
                            6,
                            100,
                            7,
                            100,
                            8,
                            100
                        ],
                        "hasFlowerWord": 0,
                        "isReadyHand": 0,
                        "isLimitSelfDraw": 0,
                        "isDealerNoPoint": 0,
                        "hasRobFlower": 1,
                        "hasTianDi": 1,
                        "hasEightFlower": 1,
                        "tableJoinKey": "2XQ61XVNy",
                        "password": "",
                        "isWatchGame": 1,
                        "isShareEquallyRoom": 0
                    },
                    "gameInfo": {
                        "phase": 1,
                        "windRound": 1,
                        "currActionSit": 1,
                        "remainCardNum": 72,
                        "currRound": 1,
                        "delayTime": 0,
                        "dealTotalNum": 0,
                        "lastDiscardPlayerId": "",
                        "retainCardNum": 72,
                        "voteDetail": {
                            "agreePlayerIds": [],
                            "refusePlayerIds": [],
                            "voteStartPlayerId": "",
                            "delayTime": 10,
                            "delayRemain": 0
                        },
                        "isGameStart": 0
                    },
                    "playerList": [
                        {
                            "playerId": "61405af8c50be1438ee52938",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/271-A.gif",
                            "nickname": "派囝仔",
                            "totalScore": 575,
                            "chairId": 0,
                            "isReady": 0,
                            "isDealer": 1,
                            "wind": 2,
                            "dealerCount": 1
                        },
                        {
                            "playerId": "611f1999af15512b920fea13",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/247-A.gif",
                            "nickname": "超級馬子狗",
                            "totalScore": -575,
                            "chairId": 1,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        }
                    ],
                    "videoCallInfo": null
                }
            },
            {
                "_id": ("61dd47a08bdfcef7f9635340"),
                "msgId": 2,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 1,
                    "delayTime": 1,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd47a08bdfceb947635341"),
                "msgId": 3,
                "route": "onNoticeGameStartPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "totalCardNum": 72
                }
            },
            {
                "_id": ("61dd47a08bdfce3a28635342"),
                "msgId": 4,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 3,
                    "delayTime": 5,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd47a08bdfce4352635343"),
                "msgId": 5,
                "route": "onRandomDealerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 3,
                    "diceList": [
                        6,
                        6,
                        6
                    ],
                    "dealerId": "61405af8c50be1438ee52938",
                    "dealerCount": 2,
                    "windRound": 1,
                    "roundNum": 1,
                    "playerWinds": [
                        {
                            "playerId": "61405af8c50be1438ee52938",
                            "wind": 2
                        },
                        {
                            "playerId": "611f1999af15512b920fea13",
                            "wind": 1
                        }
                    ],
                    "isLastDealer": 1
                }
            },
            {
                "_id": ("61dd47a08bdfce38b8635344"),
                "msgId": 6,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 4,
                    "delayTime": 3,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61dd47a08bdfce5ff7635345"),
                "msgId": 7,
                "route": "onDealCardsPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "handCards": [
                        {
                            "chairId": 0,
                            "playerId": "61405af8c50be1438ee52938",
                            "cards": [
                                33,
                                21,
                                51,
                                68,
                                35,
                                25,
                                39,
                                53,
                                41,
                                17,
                                20,
                                83,
                                50,
                                17,
                                40,
                                57,
                                98
                            ]
                        },
                        {
                            "chairId": 1,
                            "playerId": "611f1999af15512b920fea13",
                            "cards": [
                                22,
                                66,
                                21,
                                55,
                                41,
                                57,
                                51,
                                36,
                                54,
                                33,
                                67,
                                103,
                                34,
                                17,
                                20,
                                67
                            ]
                        }
                    ]
                }
            },
            {
                "_id": ("61dd47a08bdfce8001635346"),
                "msgId": 8,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce415a635347"),
                "msgId": 9,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "playerId": "61405af8c50be1438ee52938",
                    "flowerCards": [
                        98
                    ],
                    "exchangeCards": [
                        24
                    ]
                }
            },
            {
                "_id": ("61dd47a08bdfce2e25635348"),
                "msgId": 10,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce4df1635349"),
                "msgId": 11,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "playerId": "611f1999af15512b920fea13",
                    "flowerCards": [
                        103
                    ],
                    "exchangeCards": [
                        49
                    ]
                }
            },
            {
                "_id": ("61dd47a08bdfcec9de63534a"),
                "msgId": 12,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce6e1463534b"),
                "msgId": 13,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce502a63534c"),
                "msgId": 14,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce5fb463534d"),
                "msgId": 15,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce00d363534e"),
                "msgId": 16,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        40
                    ],
                    "waitPlayerId": "611f1999af15512b920fea13",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd47a08bdfced6b663534f"),
                "msgId": 17,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce45e7635350"),
                "msgId": 18,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce5d7c635351"),
                "msgId": 19,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce5105635352"),
                "msgId": 20,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        83
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfce63f9635353"),
                "msgId": 21,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce4194635354"),
                "msgId": 22,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfceda6c635355"),
                "msgId": 23,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce9882635356"),
                "msgId": 24,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        82
                    ],
                    "waitPlayerId": "611f1999af15512b920fea13",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd47a08bdfce009a635357"),
                "msgId": 25,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfcef65c635358"),
                "msgId": 26,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce771b635359"),
                "msgId": 27,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfcef8f163535a"),
                "msgId": 28,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        66
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfce338f63535b"),
                "msgId": 29,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce655263535c"),
                "msgId": 30,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce104363535d"),
                "msgId": 31,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce27ea63535e"),
                "msgId": 32,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        81
                    ],
                    "waitPlayerId": "611f1999af15512b920fea13",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61dd47a08bdfce653863535f"),
                "msgId": 33,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            82
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce1ba8635360"),
                "msgId": 34,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        82
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfced61e635361"),
                "msgId": 35,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfcea518635362"),
                "msgId": 36,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        35
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfcea946635363"),
                "msgId": 37,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            35
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce5d01635364"),
                "msgId": 38,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        35
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce3ab1635365"),
                "msgId": 39,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce02a6635366"),
                "msgId": 40,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 3,
                        "cards": [
                            34,
                            35,
                            36
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce2b49635367"),
                "msgId": 41,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        34,
                        35,
                        36
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 3,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce5d4f635368"),
                "msgId": 42,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce1780635369"),
                "msgId": 43,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            33
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce708763536a"),
                "msgId": 44,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        33
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfceb87663536b"),
                "msgId": 45,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfceda2963536c"),
                "msgId": 46,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        102
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfce56f663536d"),
                "msgId": 47,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "playerId": "61405af8c50be1438ee52938",
                    "flowerCards": [
                        102
                    ],
                    "exchangeCards": [
                        22
                    ]
                }
            },
            {
                "_id": ("61dd47a08bdfce170763536e"),
                "msgId": 48,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            39
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce089763536f"),
                "msgId": 49,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        39
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce31db635370"),
                "msgId": 50,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce5b2f635371"),
                "msgId": 51,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 3,
                        "cards": [
                            39,
                            40,
                            41
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce0418635372"),
                "msgId": 52,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        39,
                        40,
                        41
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 3,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce9eee635373"),
                "msgId": 53,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfcea33a635374"),
                "msgId": 54,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce17c8635375"),
                "msgId": 55,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce68a2635376"),
                "msgId": 56,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce903c635377"),
                "msgId": 57,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        67
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfce3631635378"),
                "msgId": 58,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            50
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce7ca7635379"),
                "msgId": 59,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        50
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce9e8a63537a"),
                "msgId": 60,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce2d4663537b"),
                "msgId": 61,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 3,
                        "cards": [
                            49,
                            50,
                            51
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce1a6e63537c"),
                "msgId": 62,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        49,
                        50,
                        51
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 3,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce357663537d"),
                "msgId": 63,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 12,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce16b363537e"),
                "msgId": 64,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            17
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce670863537f"),
                "msgId": 65,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        17
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 2,
                    "targetId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce6fb8635380"),
                "msgId": 66,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce079a635381"),
                "msgId": 67,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 1,
                        "cards": []
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce8f85635382"),
                "msgId": 68,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "delayTime": 12,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfcec2ab635383"),
                "msgId": 69,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 6,
                    "cards": [
                        39
                    ],
                    "waitPlayerId": "61405af8c50be1438ee52938",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61dd47a08bdfce5b2b635384"),
                "msgId": 70,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61405af8c50be1438ee52938",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            53
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfcef8ed635385"),
                "msgId": 71,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        53
                    ],
                    "actionPlayerId": "61405af8c50be1438ee52938",
                    "actionType": 2,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce215c635386"),
                "msgId": 72,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfce0a4f635387"),
                "msgId": 73,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "611f1999af15512b920fea13",
                    "reqBody": {
                        "reqType": 7,
                        "cards": [
                            53
                        ]
                    }
                }
            },
            {
                "_id": ("61dd47a08bdfce2958635388"),
                "msgId": 74,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 161180,
                    "gameId": 15,
                    "cards": [
                        53
                    ],
                    "actionPlayerId": "611f1999af15512b920fea13",
                    "actionType": 7,
                    "targetId": "61405af8c50be1438ee52938"
                }
            },
            {
                "_id": ("61dd47a08bdfced142635389"),
                "msgId": 75,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "phase": 8,
                    "delayTime": 20,
                    "waitPlayerId": "611f1999af15512b920fea13"
                }
            },
            {
                "_id": ("61dd47a08bdfce133e63538a"),
                "msgId": 76,
                "route": "onSettlePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "roundWind": 1,
                    "gameEndType": 1,
                    "details": [
                        {
                            "playerId": "61405af8c50be1438ee52938",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/271-A.gif",
                            "nickname": "派囝仔",
                            "totalScore": 250,
                            "handCards": [
                                33,
                                21,
                                51,
                                25,
                                41,
                                17,
                                20,
                                83,
                                17,
                                40,
                                24,
                                83,
                                35,
                                22,
                                67,
                                39
                            ],
                            "flowerCards": [
                                98,
                                102
                            ],
                            "otherCards": [],
                            "agent": "1602896",
                            "chairId": 0,
                            "wind": 2,
                            "isDealre": 1,
                            "isShot": 1,
                            "totalFan": 5,
                            "fanList": [
                                {
                                    "pointType": 24,
                                    "point": 1
                                },
                                {
                                    "pointType": 25,
                                    "point": 4
                                }
                            ],
                            "winCards": [],
                            "settleScore": -325
                        },
                        {
                            "playerId": "611f1999af15512b920fea13",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/247-A.gif",
                            "nickname": "超級馬子狗",
                            "totalScore": -250,
                            "handCards": [
                                22,
                                21,
                                55,
                                54,
                                67,
                                20,
                                67,
                                53
                            ],
                            "flowerCards": [
                                103
                            ],
                            "otherCards": [
                                {
                                    "cardType": 1,
                                    "cards": [
                                        34,
                                        36
                                    ],
                                    "targetId": "61405af8c50be1438ee52938",
                                    "chowCard": 35
                                },
                                {
                                    "cardType": 1,
                                    "cards": [
                                        40,
                                        41
                                    ],
                                    "targetId": "61405af8c50be1438ee52938",
                                    "chowCard": 39
                                },
                                {
                                    "cardType": 1,
                                    "cards": [
                                        49,
                                        51
                                    ],
                                    "targetId": "61405af8c50be1438ee52938",
                                    "chowCard": 50
                                }
                            ],
                            "agent": "1602864",
                            "chairId": 1,
                            "wind": 1,
                            "isDealre": 0,
                            "isShot": 0,
                            "totalFan": 5,
                            "fanList": [
                                {
                                    "pointType": 24,
                                    "point": 1
                                },
                                {
                                    "pointType": 25,
                                    "point": 4
                                }
                            ],
                            "winCards": [
                                53
                            ],
                            "settleScore": 325
                        }
                    ]
                }
            },
            {
                "_id": ("61dd47a08bdfce0b1563538b"),
                "msgId": 77,
                "route": "onPlayerTotalRecords",
                "msg": {
                    "gameId": 15,
                    "roomId": 161180,
                    "roundNum": 7,
                    "gameDuration": 855,
                    "baseScore": 200,
                    "pointsScore": 25,
                    "details": [
                        {
                            "playerId": "61405af8c50be1438ee52938",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/271-A.gif",
                            "nickname": "派囝仔",
                            "totalScore": 250,
                            "chairId": 0,
                            "winNum": 2,
                            "selfDrawNum": 0,
                            "shotNum": 1
                        },
                        {
                            "playerId": "611f1999af15512b920fea13",
                            "avatar": "https://cdn.08online.com/Html/UploadFiles/Label/247-A.gif",
                            "nickname": "超級馬子狗",
                            "totalScore": -250,
                            "chairId": 1,
                            "winNum": 1,
                            "selfDrawNum": 0,
                            "shotNum": 2
                        }
                    ],
                    "waitTime": 30
                }
            }
        ]
    },

    onPlayBackData3: {
        "records": [
            {
                "_id": ("61f0f52af83e5ccd9cc62efd"),
                "msgId": 1,
                "route": "onPlayerJoinGamePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "roomName": "Guest的牌桌",
                    "gameState": 2,
                    "masterId": "61f0f1f5c4fb79e4966f6b59",
                    "roomUniqueID": "263ae29a62234bb1438511a23e74f9c2",
                    "isWatch": 0,
                    "roomConfig": {
                        "isAgent": 0,
                        "maxPlayerNum": 3,
                        "maxRoundNum": 1,
                        "baseScore": 50,
                        "thinkTime": 10,
                        "maxFan": 0,
                        "hasFlowerCard": 1,
                        "fanPoint": 20,
                        "isAutoHu": 0,
                        "emotions": [
                            1,
                            0,
                            2,
                            0,
                            3,
                            0,
                            4,
                            0,
                            5,
                            0,
                            6,
                            100,
                            7,
                            200,
                            8,
                            300
                        ],
                        "hasFlowerWord": 0,
                        "isReadyHand": 0,
                        "isLimitSelfDraw": 0,
                        "isDealerNoPoint": 0,
                        "hasRobFlower": 1,
                        "hasTianDi": 1,
                        "hasEightFlower": 1,
                        "tableJoinKey": "f5G6nHpOG",
                        "password": "",
                        "isWatchGame": 1,
                        "isShareEquallyRoom": 0,
                        "createType": 3,
                        "costType": 1
                    },
                    "gameInfo": {
                        "phase": 1,
                        "windRound": 1,
                        "remainCardNum": 100,
                        "currRound": 1,
                        "delayTime": 0,
                        "dealTotalNum": 0,
                        "lastDiscardPlayerId": "",
                        "retainCardNum": 44,
                        "voteDetail": {
                            "agreePlayerIds": [],
                            "refusePlayerIds": [],
                            "delayTime": 10,
                            "delayRemain": 0
                        },
                        "isGameStart": 0
                    },
                    "playerList": [
                        {
                            "playerId": "61f0f1f5c4fb79e4966f6b59",
                            "avatar": "",
                            "nickname": "Guest113",
                            "totalScore": 0,
                            "chairId": 0,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        },
                        {
                            "playerId": "61f0f111560a8bac9730433d",
                            "avatar": "",
                            "nickname": "Guest112",
                            "totalScore": 0,
                            "chairId": 1,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        },
                        {
                            "playerId": "61db9e6ea20c4d3d9fd9399e",
                            "avatar": "",
                            "nickname": "Guest31",
                            "totalScore": 0,
                            "chairId": 2,
                            "isReady": 0,
                            "isDealer": 0,
                            "wind": 1,
                            "dealerCount": 0
                        }
                    ],
                    "videoCallInfo": null
                }
            },
            {
                "_id": ("61f0f52af83e5c2b07c62efe"),
                "msgId": 2,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 1,
                    "delayTime": 1,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61f0f52af83e5c18fdc62eff"),
                "msgId": 3,
                "route": "onNoticeGameStartPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "totalCardNum": 100
                }
            },
            {
                "_id": ("61f0f52af83e5cdd87c62f00"),
                "msgId": 4,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 2,
                    "delayTime": 3,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61f0f52af83e5c6aa1c62f01"),
                "msgId": 5,
                "route": "onRandomWindPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "diceList": [
                        5,
                        6,
                        4
                    ],
                    "playerList": [
                        {
                            "playerId": "61f0f111560a8bac9730433d",
                            "chairId": 0,
                            "wind": 1
                        },
                        {
                            "playerId": "61db9e6ea20c4d3d9fd9399e",
                            "chairId": 1,
                            "wind": 2
                        },
                        {
                            "playerId": "61f0f1f5c4fb79e4966f6b59",
                            "chairId": 2,
                            "wind": 3
                        }
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5ca228c62f02"),
                "msgId": 6,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 3,
                    "delayTime": 5,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61f0f52af83e5cc8d1c62f03"),
                "msgId": 7,
                "route": "onRandomDealerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 3,
                    "diceList": [
                        2,
                        2,
                        5
                    ],
                    "dealerId": "61f0f1f5c4fb79e4966f6b59",
                    "dealerCount": 0,
                    "windRound": 1,
                    "roundNum": 1,
                    "playerWinds": [
                        {
                            "playerId": "61f0f111560a8bac9730433d",
                            "wind": 2
                        },
                        {
                            "playerId": "61db9e6ea20c4d3d9fd9399e",
                            "wind": 3
                        },
                        {
                            "playerId": "61f0f1f5c4fb79e4966f6b59",
                            "wind": 1
                        }
                    ],
                    "isLastDealer": 0
                }
            },
            {
                "_id": ("61f0f52af83e5cdb69c62f04"),
                "msgId": 8,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 4,
                    "delayTime": 3,
                    "waitPlayerId": ""
                }
            },
            {
                "_id": ("61f0f52af83e5c14c4c62f05"),
                "msgId": 9,
                "route": "onDealCardsPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "handCards": [
                        {
                            "chairId": 0,
                            "playerId": "61f0f111560a8bac9730433d",
                            "cards": [
                                35,
                                20,
                                17,
                                40,
                                66,
                                39,
                                98,
                                54,
                                40,
                                34,
                                51,
                                19,
                                56,
                                39,
                                23,
                                17
                            ]
                        },
                        {
                            "chairId": 1,
                            "playerId": "61db9e6ea20c4d3d9fd9399e",
                            "cards": [
                                39,
                                82,
                                19,
                                82,
                                57,
                                34,
                                52,
                                24,
                                38,
                                81,
                                56,
                                35,
                                25,
                                56,
                                99,
                                100
                            ]
                        },
                        {
                            "chairId": 2,
                            "playerId": "61f0f1f5c4fb79e4966f6b59",
                            "cards": [
                                20,
                                68,
                                49,
                                65,
                                33,
                                18,
                                23,
                                22,
                                39,
                                34,
                                54,
                                52,
                                67,
                                82,
                                25,
                                36,
                                66
                            ]
                        }
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5cc5bbc62f06"),
                "msgId": 10,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5cf002c62f07"),
                "msgId": 11,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c083fc62f08"),
                "msgId": 12,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "playerId": "61f0f111560a8bac9730433d",
                    "flowerCards": [
                        98
                    ],
                    "exchangeCards": [
                        18
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5cac01c62f09"),
                "msgId": 13,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 5,
                    "delayTime": 2,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5cb3e9c62f0a"),
                "msgId": 14,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "flowerCards": [
                        99,
                        100
                    ],
                    "exchangeCards": [
                        20,
                        41
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5cae68c62f0b"),
                "msgId": 15,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5cc474c62f0c"),
                "msgId": 16,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        82
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c4c5dc62f0d"),
                "msgId": 17,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c59bac62f0e"),
                "msgId": 18,
                "route": "onVoteDisbandStartPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "delayTime": 10
                }
            },
            {
                "_id": ("61f0f52af83e5c07a7c62f0f"),
                "msgId": 19,
                "route": "onVotePlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "agreePlayerIds": [
                        "61db9e6ea20c4d3d9fd9399e"
                    ],
                    "refusePlayerIds": []
                }
            },
            {
                "_id": ("61f0f52af83e5c25c3c62f10"),
                "msgId": 20,
                "route": "onVotePlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "agreePlayerIds": [
                        "61db9e6ea20c4d3d9fd9399e",
                        "61f0f1f5c4fb79e4966f6b59"
                    ],
                    "refusePlayerIds": []
                }
            },
            {
                "_id": ("61f0f52af83e5ccf3dc62f11"),
                "msgId": 21,
                "route": "onVotePlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "agreePlayerIds": [
                        "61db9e6ea20c4d3d9fd9399e",
                        "61f0f1f5c4fb79e4966f6b59"
                    ],
                    "refusePlayerIds": [
                        "61f0f111560a8bac9730433d"
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5cd4d2c62f12"),
                "msgId": 22,
                "route": "onVoteResultPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "disband": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c575cc62f13"),
                "msgId": 23,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c4c8bc62f14"),
                "msgId": 24,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        34
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c6fe5c62f15"),
                "msgId": 25,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f111560a8bac9730433d",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c7916c62f16"),
                "msgId": 26,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c3231c62f17"),
                "msgId": 27,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c529ac62f18"),
                "msgId": 28,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        25
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c2436c62f19"),
                "msgId": 29,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c75bec62f1a"),
                "msgId": 30,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c1167c62f1b"),
                "msgId": 31,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c4459c62f1c"),
                "msgId": 32,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        41
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c8693c62f1d"),
                "msgId": 33,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c6a56c62f1e"),
                "msgId": 34,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c4372c62f1f"),
                "msgId": 35,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c0900c62f20"),
                "msgId": 36,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        83
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c9eb8c62f21"),
                "msgId": 37,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f111560a8bac9730433d",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            83
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c1685c62f22"),
                "msgId": 38,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        83
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c2efdc62f23"),
                "msgId": 39,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c22ddc62f24"),
                "msgId": 40,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        67
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5cd0f0c62f25"),
                "msgId": 41,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            67
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c77b3c62f26"),
                "msgId": 42,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        67
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c25c6c62f27"),
                "msgId": 43,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c2f78c62f28"),
                "msgId": 44,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        65
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c627ac62f29"),
                "msgId": 45,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            67
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c8389c62f2a"),
                "msgId": 46,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        67
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c3ae1c62f2b"),
                "msgId": 47,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5cb7c9c62f2c"),
                "msgId": 48,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        24
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c446fc62f2d"),
                "msgId": 49,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        24
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c0124c62f2e"),
                "msgId": 50,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5ccd17c62f2f"),
                "msgId": 51,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        57
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c2ea4c62f30"),
                "msgId": 52,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            52
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c7635c62f31"),
                "msgId": 53,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        52
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c2956c62f32"),
                "msgId": 54,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c4b6ac62f33"),
                "msgId": 55,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        50
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5cccefc62f34"),
                "msgId": 56,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c532cc62f35"),
                "msgId": 57,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c1998c62f36"),
                "msgId": 58,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c704dc62f37"),
                "msgId": 59,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        37
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c7117c62f38"),
                "msgId": 60,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f111560a8bac9730433d",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            51
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c32ccc62f39"),
                "msgId": 61,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        51
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c60bac62f3a"),
                "msgId": 62,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c1453c62f3b"),
                "msgId": 63,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        49
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c8c8dc62f3c"),
                "msgId": 64,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            49
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c5e30c62f3d"),
                "msgId": 65,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c264ac62f3e"),
                "msgId": 66,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c0925c62f3f"),
                "msgId": 67,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        81
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c543ac62f40"),
                "msgId": 68,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            81
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5cd1f7c62f41"),
                "msgId": 69,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        81
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c2359c62f42"),
                "msgId": 70,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c4527c62f43"),
                "msgId": 71,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        25
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c7e25c62f44"),
                "msgId": 72,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f111560a8bac9730433d",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            35
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c9e08c62f45"),
                "msgId": 73,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        35
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c0d40c62f46"),
                "msgId": 74,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c6509c62f47"),
                "msgId": 75,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        66
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5cb8a2c62f48"),
                "msgId": 76,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            66
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5ce8a7c62f49"),
                "msgId": 77,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        66
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c0ba6c62f4a"),
                "msgId": 78,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c8d79c62f4b"),
                "msgId": 79,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        23
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c10d1c62f4c"),
                "msgId": 80,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            25
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c42b1c62f4d"),
                "msgId": 81,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        25
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c5817c62f4e"),
                "msgId": 82,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c407dc62f4f"),
                "msgId": 83,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            25
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c5905c62f50"),
                "msgId": 84,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        25
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 4,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c82fbc62f51"),
                "msgId": 85,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5ca53fc62f52"),
                "msgId": 86,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            24
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c26b4c62f53"),
                "msgId": 87,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        24
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c3ad5c62f54"),
                "msgId": 88,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c1cd3c62f55"),
                "msgId": 89,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c3f6bc62f56"),
                "msgId": 90,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        65
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c13e4c62f57"),
                "msgId": 91,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            49
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c7894c62f58"),
                "msgId": 92,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c0d4ac62f59"),
                "msgId": 93,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c2fd1c62f5a"),
                "msgId": 94,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        104
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c7b64c62f5b"),
                "msgId": 95,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "playerId": "61f0f111560a8bac9730433d",
                    "flowerCards": [
                        104
                    ],
                    "exchangeCards": [
                        54
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5c5a5cc62f5c"),
                "msgId": 96,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f111560a8bac9730433d",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            56
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c0b9dc62f5d"),
                "msgId": 97,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        56
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c7e2bc62f5e"),
                "msgId": 98,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c70e7c62f5f"),
                "msgId": 99,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 4,
                        "cards": [
                            56
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c1583c62f60"),
                "msgId": 100,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        56
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 4,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c66dbc62f61"),
                "msgId": 101,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c655fc62f62"),
                "msgId": 102,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            41
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c39d2c62f63"),
                "msgId": 103,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        41
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c3d4cc62f64"),
                "msgId": 104,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c23fdc62f65"),
                "msgId": 105,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        24
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5cd9dac62f66"),
                "msgId": 106,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            23
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c7107c62f67"),
                "msgId": 107,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        23
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c0610c62f68"),
                "msgId": 108,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c7209c62f69"),
                "msgId": 109,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        50
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c9192c62f6a"),
                "msgId": 110,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        50
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c548bc62f6b"),
                "msgId": 111,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5cc0cfc62f6c"),
                "msgId": 112,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        68
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c69aac62f6d"),
                "msgId": 113,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            68
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5cb7ebc62f6e"),
                "msgId": 114,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        68
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c4e9fc62f6f"),
                "msgId": 115,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5cedcdc62f70"),
                "msgId": 116,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        53
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c15b1c62f71"),
                "msgId": 117,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            50
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c6badc62f72"),
                "msgId": 118,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        50
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c8abbc62f73"),
                "msgId": 119,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c139fc62f74"),
                "msgId": 120,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        52
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c352cc62f75"),
                "msgId": 121,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        52
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c53d1c62f76"),
                "msgId": 122,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c291cc62f77"),
                "msgId": 123,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        97
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c68e4c62f78"),
                "msgId": 124,
                "route": "onExchangeFlowerPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "flowerCards": [
                        97
                    ],
                    "exchangeCards": [
                        17
                    ]
                }
            },
            {
                "_id": ("61f0f52af83e5cca36c62f79"),
                "msgId": 125,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            17
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c893dc62f7a"),
                "msgId": 126,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        17
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5cce15c62f7b"),
                "msgId": 127,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c1d27c62f7c"),
                "msgId": 128,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c124ec62f7d"),
                "msgId": 129,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        23
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c7f07c62f7e"),
                "msgId": 130,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            23
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5cd595c62f7f"),
                "msgId": 131,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        23
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5cc438c62f80"),
                "msgId": 132,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c5e2ec62f81"),
                "msgId": 133,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        51
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c212cc62f82"),
                "msgId": 134,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        51
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c30fbc62f83"),
                "msgId": 135,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5cd8cec62f84"),
                "msgId": 136,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        21
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c81e8c62f85"),
                "msgId": 137,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c93f3c62f86"),
                "msgId": 138,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5cf469c62f87"),
                "msgId": 139,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c7a31c62f88"),
                "msgId": 140,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        55
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c66cbc62f89"),
                "msgId": 141,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            55
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c8322c62f8a"),
                "msgId": 142,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        55
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5ce588c62f8b"),
                "msgId": 143,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c32aec62f8c"),
                "msgId": 144,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        54
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5cbd29c62f8d"),
                "msgId": 145,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        54
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c63d4c62f8e"),
                "msgId": 146,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c24a2c62f8f"),
                "msgId": 147,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        49
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c74b9c62f90"),
                "msgId": 148,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            49
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c2d2dc62f91"),
                "msgId": 149,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c425cc62f92"),
                "msgId": 150,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5cc745c62f93"),
                "msgId": 151,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        33
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5cdd0ec62f94"),
                "msgId": 152,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            36
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5cc9a9c62f95"),
                "msgId": 153,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        36
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c0dd3c62f96"),
                "msgId": 154,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c4f1dc62f97"),
                "msgId": 155,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        65
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c42b8c62f98"),
                "msgId": 156,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        65
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c2a61c62f99"),
                "msgId": 157,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c2900c62f9a"),
                "msgId": 158,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 5,
                        "cards": [
                            65
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c9d0dc62f9b"),
                "msgId": 159,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        65
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 5,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c7395c62f9c"),
                "msgId": 160,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c249dc62f9d"),
                "msgId": 161,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        51
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5c3bb8c62f9e"),
                "msgId": 162,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            51
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c71f0c62f9f"),
                "msgId": 163,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        51
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c0d44c62fa0"),
                "msgId": 164,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c8bc7c62fa1"),
                "msgId": 165,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        49
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c44a7c62fa2"),
                "msgId": 166,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        49
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5cae3ac62fa3"),
                "msgId": 167,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c59f9c62fa4"),
                "msgId": 168,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        33
                    ],
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "waitChairId": 1
                }
            },
            {
                "_id": ("61f0f52af83e5c9018c62fa5"),
                "msgId": 169,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 10,
                        "cards": [
                            57
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c6e7cc62fa6"),
                "msgId": 170,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        57
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 2,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c6899c62fa7"),
                "msgId": 171,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 10,
                    "targetId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5c9ff0c62fa8"),
                "msgId": 172,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c00b7c62fa9"),
                "msgId": 173,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        18
                    ],
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "waitChairId": 2
                }
            },
            {
                "_id": ("61f0f52af83e5cb7cbc62faa"),
                "msgId": 174,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61f0f1f5c4fb79e4966f6b59",
                    "reqBody": {
                        "reqType": 2,
                        "cards": [
                            34
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c8092c62fab"),
                "msgId": 175,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        34
                    ],
                    "actionPlayerId": "61f0f1f5c4fb79e4966f6b59",
                    "actionType": 2,
                    "targetId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c7d3dc62fac"),
                "msgId": 176,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f1f5c4fb79e4966f6b59"
                }
            },
            {
                "_id": ("61f0f52af83e5c1de7c62fad"),
                "msgId": 177,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "delayTime": 10,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5cf9a5c62fae"),
                "msgId": 178,
                "route": "OnDrawCardPush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 6,
                    "cards": [
                        40
                    ],
                    "waitPlayerId": "61f0f111560a8bac9730433d",
                    "waitChairId": 0
                }
            },
            {
                "_id": ("61f0f52af83e5c80bec62faf"),
                "msgId": 179,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        40
                    ],
                    "actionPlayerId": "61f0f111560a8bac9730433d",
                    "actionType": 2,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c663bc62fb0"),
                "msgId": 180,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 7,
                    "delayTime": 5,
                    "waitPlayerId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c469ec62fb1"),
                "msgId": 181,
                "route": "mahjong.mahjongGameHandler.playerAction",
                "msg": {
                    "playerId": "61db9e6ea20c4d3d9fd9399e",
                    "reqBody": {
                        "reqType": 7,
                        "cards": [
                            40
                        ]
                    }
                }
            },
            {
                "_id": ("61f0f52af83e5c8fa7c62fb2"),
                "msgId": 182,
                "route": "onPlayerActionPush",
                "msg": {
                    "roomId": 5495375,
                    "gameId": 15,
                    "cards": [
                        40
                    ],
                    "actionPlayerId": "61db9e6ea20c4d3d9fd9399e",
                    "actionType": 7,
                    "targetId": "61f0f111560a8bac9730433d"
                }
            },
            {
                "_id": ("61f0f52af83e5c742bc62fb3"),
                "msgId": 183,
                "route": "onPhaseChangePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "phase": 8,
                    "delayTime": 20,
                    "waitPlayerId": "61db9e6ea20c4d3d9fd9399e"
                }
            },
            {
                "_id": ("61f0f52af83e5ca4c2c62fb4"),
                "msgId": 184,
                "route": "onSettlePush",
                "msg": {
                    "gameId": 15,
                    "roomId": 5495375,
                    "roundWind": 1,
                    "gameEndType": 1,
                    "details": [
                        {
                            "playerId": "61f0f111560a8bac9730433d",
                            "avatar": "",
                            "nickname": "Guest112",
                            "totalScore": -70,
                            "handCards": [
                                20,
                                17,
                                39,
                                40,
                                34,
                                19,
                                39,
                                23,
                                17,
                                18,
                                34,
                                37,
                                25,
                                54,
                                54,
                                40
                            ],
                            "flowerCards": [
                                98,
                                104
                            ],
                            "otherCards": [],
                            "agent": "100112",
                            "chairId": 0,
                            "wind": 2,
                            "isDealer": 0,
                            "isShot": 1,
                            "totalFan": 1,
                            "fanList": [
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [],
                            "settleScore": -70
                        },
                        {
                            "playerId": "61db9e6ea20c4d3d9fd9399e",
                            "avatar": "",
                            "nickname": "Guest31",
                            "totalScore": 70,
                            "handCards": [
                                39,
                                82,
                                19,
                                82,
                                34,
                                38,
                                35,
                                20,
                                21,
                                33,
                                40
                            ],
                            "flowerCards": [
                                97,
                                99,
                                100
                            ],
                            "otherCards": [
                                {
                                    "cardType": 2,
                                    "cards": [
                                        25
                                    ],
                                    "targetId": "61f0f1f5c4fb79e4966f6b59",
                                    "chowCard": 0
                                },
                                {
                                    "cardType": 2,
                                    "cards": [
                                        56
                                    ],
                                    "targetId": "61f0f111560a8bac9730433d",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "100031",
                            "chairId": 1,
                            "wind": 3,
                            "isDealer": 0,
                            "isShot": 0,
                            "totalFan": 1,
                            "fanList": [
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [
                                40
                            ],
                            "settleScore": 70
                        },
                        {
                            "playerId": "61f0f1f5c4fb79e4966f6b59",
                            "avatar": "",
                            "nickname": "Guest113",
                            "totalScore": 0,
                            "handCards": [
                                20,
                                33,
                                18,
                                22,
                                39,
                                54,
                                52,
                                41,
                                24,
                                53,
                                23,
                                33,
                                18
                            ],
                            "flowerCards": [],
                            "otherCards": [
                                {
                                    "cardType": 3,
                                    "cards": [
                                        65
                                    ],
                                    "targetId": "61f0f111560a8bac9730433d",
                                    "chowCard": 0
                                }
                            ],
                            "agent": "100113",
                            "chairId": 2,
                            "wind": 1,
                            "isDealer": 1,
                            "isShot": 0,
                            "totalFan": 1,
                            "fanList": [
                                {
                                    "pointType": 37,
                                    "point": 1
                                }
                            ],
                            "winCards": [],
                            "settleScore": 0
                        }
                    ]
                }
            }
        ],
    }

}

export = mahjongTestData;