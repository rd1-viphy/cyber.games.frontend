import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import { Utils } from "../../../../script/model/Utils";
import { MAHJONG_ANIM, MAHJONG_CARD_TYPE, MAHJONG_CONST, MAHJONG_OPERATION_ANIM, MAHJONG_PLAYERS, MAHJONG_PLAYER_OPERATION, Mahjong_SettleCardType, MAHJONG_SETTLE_ANIM } from "./mahjongEnum";

export default class MahjongModel {

    /**
     * 实例化model对象
     */
    private static _instance = null;

    public static getInstance(): MahjongModel {
        if (!this._instance) {
            this._instance = new MahjongModel();
        }
        return this._instance;
    }

    /** 游戏Id */
    public gameId: number = platform_game_id.mahjong_table;
    /**房间玩家信息 */
    public playersInfo: MahjongCommon.PlayerInfo[] = [];
    /** 游戏信息 */
    public gameInfo: MahjongCommon.GameInfo = null;
    /**房间信息 */
    public tableInfo: MahjongCommon.TableInfo = null;
    /**房间配置*/
    public roomConfig: MahjongCommon.RoomConfig = null;
    /** 房间名称 */
    public roomName: string = null;
    /**创建房间配置 */
    public createConfig: MahjongClientToServer.CreateTable = null;
    /**自己当前的网络座位号 */
    public selfChairId: number = -1;
    /**自己手牌 */
    public selfHandCards: number[] = [];
    /**牌桌id */
    public tableId: string = "";
    /** 房间内唯一Id */
    public roomUniqueID: string = null;
    /**底注 */
    public ante: number = 0;
    /**游戏的当前状态 */
    public phase: number = 0;
    /**当前局数 */
    public currentRound: number = 0;
    /**总局数 */
    public totalRound: number = 0;
    /**自己是否准备 */
    public selfIsReady: boolean = false;
    /** 庄家PlayerId */
    public bankId: string = null;
    /** 庄家椅子号 */
    public bankChariId: number = 0;
    /**玩家准备 */
    public playerReadyStatus: number[] = [0, 0, 0, 0];
    /** 最后一张打出去的牌数据 */
    public lastCardData = null;
    /** 最后一张抓的牌数据 */
    public lastDrawData = null;
    /** 最后一张打出去的牌节点 */
    public lastCard = null;
    /** 最后一张打出去的玩家座位号 */
    public lastSeatId = 0;
    /** 当前操作玩家 */
    public curOperator: string = "";
    /** 当前玩家可以操作的类型 */
    public curPlayerOptions: number[] = [];
    /** 当前玩家可以吃的牌 */
    public curPlayerEatCards = [];
    /** 当前可以暗杠、碰杠的牌 */
    public curAnPongGangCards = [];
    /** 听牌列表 */
    public curPlayerTingCards = [];
    /** 胡牌列表 */
    public curPlayerWinCards = [];
    /** 所有打出吃碰杠的牌 */
    public AllDisCardPongGangCardItem = [];
    /** 玩家打出就听的牌 */
    public curPlayerDisTingCard = null;
    /** 当前玩家可以出的牌 */
    public curPlayerDisCards = null;
    /** 其他玩家的手牌 */
    public otherHandCards = [[], [], [], []];
    /** 我的风刻位 */
    public myWind: number = 0;
    /** 当前玩家是否听牌 */
    public isMySelfTing: boolean = false;
    /** 所有打出的牌 */
    public allDisCards: number[] = [];
    /** 胡牌玩家 */
    public winPlayerId = null;
    /** 房主id */
    public masterUid: string = null;
    /** 抓牌玩家 */
    public grabCardSeatId: number = 0;
    /** 开牌位置 */
    public openCardPos: number = 0;
    /** 游戏是否开始 */
    public isGameStart: boolean = false;
    /** 是否有小结算 */
    public isSmallSettle: boolean = false;
    /** 摸牌牌摞位置 */
    public moCardSeat: number = 0;
    /** 摸牌具体位置 */
    public moCardPos: number = 0;
    /** 补花和杠牌时牌摞位置 */
    public flowerGangSeat: number = 0;
    /** 补花和杠牌具体位置 */
    public flowerGangPos: number = 0;
    /** 铁八墩牌摞 */
    public eightPileSeat: number = 0;
    /** 铁八墩位置 */
    public eightPilePos: number = 0;
    /** 解散时风圈中间的时间 */
    public recordOperationTime: number = 0;
    /** 拒绝玩家 */
    public refusePlayer = null;
    /** 结算倒计时 */
    public settleDelayTime: number = 0;
    /** 中途摸到花牌 */
    public isMoFlowerCard: boolean = false;
    /** 是否断线结算 */
    public isRecSettle: boolean = false;
    /** 是否有补花动画 */
    public isBuFlowerAnim: boolean = false;
    /** 补花和杠牌数量 */
    public flowersGangCount: number = 0;
    /** 是否有杠 */
    public isHaveGang: boolean = false;
    /** 是否可以出牌 */
    public isDisCard: boolean = false;
    /** 是否报听 */
    public isTingPush: boolean = false;
    /** 是否是回放 */
    public isBackView: boolean = false;
    /** 胡牌动画是否延时 */
    public isDelyHuTime: boolean = false;
    /** 隐藏牌数量 */
    public hideCount: number = 0;
    /** 是否过水胡 */
    public isWaterHu: boolean = false;
    /** 是否可以補槓 */
    public isBuGang: boolean = false;
    /** 是否正在解散房間 */
    public isDissRoom: boolean = false;
    /** 是否取消虚妄 */
    public isCancleXuWan: boolean = false;
    /** 当前是否有预操作 */
    public isHaveOperation: boolean = false;

    public videoCallInfo: MahjongCommon.videoCallInfo = null;

    public backPlayData = null;

    /**
     * 初始化房间信息
     * @param roomData 
     */
    initData(data) {
        this.selfChairId = -1;
        this.playersInfo = [];
        this.selfIsReady = false;
        this.playerReadyStatus = [0, 0, 0, 0];
        const roomData: MahjongServerToClient.TableInfo = JSON.parse(JSON.stringify(data));
        if (roomData) {
            this.roomConfig = roomData.roomConfig;
            this.tableId = roomData.roomId;
            this.roomName = roomData.roomName
            if (roomData.playerList) {
                for (let i = 0; i < roomData.playerList.length; i++) {
                    const playerInfo = roomData.playerList[i];
                    if (playerInfo.playerId) {
                        this.playersInfo.push(playerInfo);
                    }
                    if (playerInfo.playerId == PlayerMgr.getInstance().uid) {
                        this.selfChairId = playerInfo.chairId;
                    }
                }
            }

            this.masterUid = roomData.masterId;
            this.gameInfo = roomData.gameInfo;
            this.roomUniqueID = roomData.roomUniqueID;
            this.videoCallInfo = roomData.videoCallInfo;
        }
    }

    /**
     * 网络座位号的转换为当前座位号
     * @param netId 网络座位号
     * @returns 
     */
    public changSeatId(netId: number) {
        let selfChairId: number = this.getSelfChairId();
        let seatNum = this.roomConfig.maxPlayerNum;
        let seatId: number = netId;
        if (selfChairId >= 0) {
            if (netId >= selfChairId) {
                seatId = netId - selfChairId;
            } else {
                seatId = netId - selfChairId + seatNum;
            }
        }
        if (seatNum == 3 && seatId == 2) {
            seatId = 3;
        }
        if (seatNum == 2 && seatId == 1) {
            seatId = 2;
        }
        return seatId;
    }

    /**
     * 将吃的牌放中间 
     * @param disCard 
     * @param eatCardData 
     */
    public getEatCardList(disCard, eatCardData) {
        let list = null;
        if (disCard == eatCardData[0]) {
            list = [eatCardData[1], disCard, eatCardData[2]];
        } else if (disCard == eatCardData[1]) {
            list = eatCardData;
        } else if (disCard == eatCardData[2]) {
            list = [eatCardData[0], disCard, eatCardData[1]];
        }
        return list;
    }

    /**
     * 获取最后一张打出去的牌位置
     * @returns 
     */
    public onGetLastDiaCardPos() {
        if (this.lastCard && this.lastCard.parent) {
            const bg = cc.find('Canvas').getChildByName('bg');
            const lastCardPos = Utils.changToNodePoint(this.lastCard, bg)
            return cc.v2(lastCardPos.x, lastCardPos.y + 50);
        }
    }

    /**
     * 展示补花抓位动画
     * @param AnimName 
     */
    public onShowAnim(spAnim, AnimName) {
        spAnim.node.active = true;
        spAnim.setAnimation(0, AnimName, false);
        spAnim.setCompleteListener(() => {
            spAnim.node.active = false;
        })
    }

    /**
     * 碰杠胡动画
     * @param type 
     * @param spAnim 
     */
    public onPengGangHuAnim(type, spAnim) {
        let animName = null
        switch (type) {
            case MAHJONG_PLAYER_OPERATION.eatCard:
                animName = MAHJONG_OPERATION_ANIM.eat;
                break;
            case MAHJONG_PLAYER_OPERATION.pengCard:
                animName = MAHJONG_OPERATION_ANIM.pong;
                break;
            case MAHJONG_PLAYER_OPERATION.mingGangCard:
                animName = MAHJONG_OPERATION_ANIM.gang;
                break;
            case MAHJONG_PLAYER_OPERATION.huCard:
            case MAHJONG_PLAYER_OPERATION.flowerWin:
            case MAHJONG_PLAYER_OPERATION.robFlowerWin:
                animName = MAHJONG_OPERATION_ANIM.hu;
                AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Hu, true, true);
                break;
            case MAHJONG_PLAYER_OPERATION.robKongHu:
                animName = MAHJONG_SETTLE_ANIM.QiangGangHu;
                break;
            case MAHJONG_PLAYER_OPERATION.ziMo:
                animName = MAHJONG_OPERATION_ANIM.zimo;
                AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_ZiMo, true, true);
                break;
            case MAHJONG_PLAYER_OPERATION.fangPao:
                animName = MAHJONG_SETTLE_ANIM.FangPao;
                break;
            case MAHJONG_PLAYER_OPERATION.readyHand:
                animName = MAHJONG_OPERATION_ANIM.ting;
                break;
            default:
                break;
        }

        if (animName != null) {
            if (spAnim && spAnim.node) {
                spAnim.node.active = true;
                spAnim.setAnimation(0, animName, false);
                spAnim.setCompleteListener(() => {
                    spAnim.node.active = false
                })
            }
        }
    }

    /**
     * 获取抓牌位置
     * 从右往左数出“骰子点数之和”的牌墩，下一个位置即为开牌位置
     * @returns 
     */
    public getDealCardPos() {
        if (this.roomConfig.hasFlowerCard == 0) {
            // 无花，牌摞17墩
            this.openCardPos += 1;
            if (this.openCardPos > 17) {
                this.flowerGangSeat = this.grabCardSeatId;
                this.flowerGangPos = 35;
                this.onGetgrabCardSeatId();
                this.openCardPos -= 17;
            } else {
                this.flowerGangSeat = this.grabCardSeatId;
                this.flowerGangPos = (this.openCardPos - 1) * 2 + 1;
            }
        } else if (this.roomConfig.hasFlowerCard == 1) {
            // 有花，牌摞18墩
            this.openCardPos += 1;
            if (this.openCardPos > 18) {
                this.flowerGangSeat = this.grabCardSeatId;
                this.flowerGangPos = 37;
                this.onGetgrabCardSeatId();
                this.openCardPos = 1;
            } else {
                this.flowerGangSeat = this.grabCardSeatId;
                this.flowerGangPos = (this.openCardPos - 1) * 2 + 1;
            }
        }
    }

    onGetgrabCardSeatId() {
        if (this.grabCardSeatId == 0) {
            this.grabCardSeatId = 3;
        } else if (this.grabCardSeatId == 3) {
            this.grabCardSeatId = 2;
        } else if (this.grabCardSeatId == 2) {
            this.grabCardSeatId = 1;
        } else if (this.grabCardSeatId == 1) {
            this.grabCardSeatId = 0;
        } 
    }

    /**
     * 根据PlayerId获取SeatId
     * @param playerId 
     * @returns 
     */
    public getChariIdToPlayerId(playerId) {
        let seatId = 0;
        this.playersInfo.forEach((player) => {
            if (playerId == player.playerId) {
                seatId = this.changSeatId(player.chairId);
            }
        })
        return seatId;
    }

    /**
     * 根据座位号获取PlayerId
     * @param chairId 
     * @returns 
     */
    public getPlayerIdToChariId(chairId) {
        let playerId = null;
        this.playersInfo.forEach((player) => {
            if (chairId == player.chairId) {
                playerId = player.playerId;
            }
        })
        return playerId;
    }

    /**
     * 牌组排序
     * @param list 
     * @returns 
     */
    public onSortCardList(list) {
        if (list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < list.length - i; j++) {
                    if (list[j] > list[j + 1]) {
                        let temp = list[j];
                        list[j] = list[j + 1];
                        list[j + 1] = temp;
                    }
                }
            }
        }
    }

    /**
     * 吃牌数组排序
     * @param list 
     */
    public onSortEatList(list) {
        if (list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < list.length - 1; j++) {
                    if (list[j][0] > list[j + 1][0]) {
                        let temp = list[j];
                        list[j] = list[j + 1];
                        list[j + 1] = temp;
                    }
                }
            }
        }
    }

    /**
     * 检测是否自摸
     * @param data 
     * @returns 
     */
    public isCheckZiMo(data) {
        let isFangPao = true;
        data.forEach(player => {
            if (player.isShot) {
                isFangPao = false;
            }
        })
        return isFangPao;
    }

    /**
     * 行牌限制排序
     * @param limit 
     */
    public onSortLimitType(limit) {
        for (let i = 0; i < limit.length; i++) {
            for (let j = 0; j < limit.length - i; j++) {
                if (limit[j].limitType > limit[j + 1].limitType) {
                    let temp = limit[j];
                    limit[j] = limit[j + 1];
                    limit[j + 1] = temp;
                }
            }
        }
    }

    /**
     * 获取自己的网络座位号
     * @returns 
     */
    private getSelfChairId(): number {
        return this.selfChairId;
    }

    /**
     * map排序(key排序)
     */
    mapSort(map) {
        let mapArray = Array.from(map);
        let newArray = mapArray.sort(function (a, b) { return a[1] - b[1] });
        let newMap = new Map(newArray.map(i => [i[0], i[1]]));
        return newMap;
    }

    /**
     * 获取当前是不是观战
     */
    public getIsWatchTheBattle(): boolean {
        return this.selfChairId == -1;
    }

    /**
     * 管理打出的明牌
     * @param pongGangItem 
     * @param data 
     * @param seatId 
     */
    public onManageMingCard(pongGangItem, data, seatId) {
        if (data.length == 3 && seatId == 1) {
            data.reverse();
        }
        for (let i = 0; i < pongGangItem.children.length; i++) {
            const item = pongGangItem.children[i];
            if (data.length == 1) {
                item["card"] = data[0];
            } else {
                item["card"] = data[i];
            }
            this.AllDisCardPongGangCardItem.push(item);
            cc.log("item： " + item.name)
        }
    }

    /**
     * 听牌后检测摸得牌是否可以胡
     * @param moCard 
     * @returns 
     */
    public isCheckHuCard(moCard): boolean {
        for (let i = 0; i < this.curPlayerWinCards.length; i++) {
            const card = this.curPlayerWinCards[i];
            if (card.winCard == moCard && !this.isWaterHu) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检测摸到的牌是否是花牌
     * @param moCard 
     * @returns 
     */
    public isCheckFlowersCard(moCard): boolean {
        let flowersCard = [97, 98, 99, 100, 101, 102, 103, 104];
        for (let i = 0; i < flowersCard.length; i++) {
            const flower = flowersCard[i];
            if (moCard == flower) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检测房间内玩家是否坐满
     * @returns 
     */
    public isCheckRoomFull(): boolean {
        if (this.roomConfig.maxPlayerNum == this.playersInfo.length) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 检测其他玩家是否全部准备
     * @returns 
     */
    public isCheckOtherReady(): boolean {
        let count = 0;
        this.playersInfo.forEach((player) => {
            if (player.isReady) {
                count += 1;
            }
        })
        return count == (this.getIsWatchTheBattle() ? this.roomConfig.maxPlayerNum : this.roomConfig.maxPlayerNum - 1);
    }

    public isCheckPlayerInGame(data) {
        let InGame = false;
        this.playersInfo.forEach((player, idx) => {
            if (player.playerId == data.playerId) {
                InGame = true;
            }
        })
        return InGame;
    }

    /**
     * 获取胡牌的id
     * @param data 
     * @returns 
     */
    public onGetWinCardIdx(data) {
        for (let i = 0; i < data.handCards.length; i++) {
            const handData = data.handCards[i];
            if (handData == data.winCards[0]) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 设置初始摸牌Idx
     * @returns 
     */
    public onSetMoCardIdx() {
        // 获取每摞牌的数量
        let pilesCount = this.roomConfig.hasFlowerCard ? 18 : 17;

        this.getDealCardPos();

        // 哪个玩家位置抓牌
        let openSeat = this.grabCardSeatId;

        cc.log("抓牌起始牌摞 :" + openSeat + " 抓牌起始位置 :" + this.openCardPos);
        cc.log("花牌起始牌摞 :" + this.flowerGangSeat + " 花牌起始位置 :" + this.flowerGangPos);

        // 第一位抓牌玩家可一抓多少张牌
        let curCount = (pilesCount - this.openCardPos + 1) * 2;
        // 发牌时需要发多少张
        let dealCount = this.roomConfig.maxPlayerNum * 16;
        // 一摞牌有多少张
        let pileCards = pilesCount * 2;

        if (curCount >= dealCount) {
            // 第一位玩家足够发牌
            this.moCardPos = dealCount / 2;
            this.moCardSeat = openSeat;
        } else if (curCount + pileCards >= dealCount) {
            // 第二位玩家牌摞就可以够发
            this.moCardPos = (dealCount - curCount) / 2;
            this.moCardSeat = this.onGetSeatIdx(openSeat);
        } else {
            // 第三位玩家牌摞
            this.moCardPos = (dealCount - curCount - pileCards) / 2;
            let secondSeat = this.onGetSeatIdx(openSeat);
            this.moCardSeat = this.onGetSeatIdx(secondSeat);
        }
        cc.log("第17张: " + this.moCardPos, " 牌摞 :" + this.moCardSeat)
    }

    /**
     * 获取摸牌Idx
     * @param seat 
     * @param pos 
     * @returns 
     */
    public onGetMoCardIdx(seat, pos) {
        // 获取每摞牌的数量
        let pilesCount = this.roomConfig.hasFlowerCard ? 18 : 17;
        let count = pilesCount * 2 - 1;
        if (pos == count) {
            let moCardSeat = this.onGetSeatIdx(seat);
            this.moCardSeat = moCardSeat
            this.moCardPos = -1;
            return { seat: moCardSeat, moCardPos: 0 }
        } else {
            return { seat: seat, moCardPos: pos + 1 }
        }
    }

    /**
     * 获取花牌杠牌的Idx
     * @param seat 
     * @param pos 
     * @returns 
     */
    public onGetFlowerGangIdx(seat, pos) {
        // 获取每摞牌的数量
        let pilesCount = this.roomConfig.hasFlowerCard ? 18 : 17;
        let count = pilesCount * 2 - 1;
        if (pos == 1) {
            let flowerGangSeat = this.onGetReverseSeatIdx(seat);
            this.flowerGangSeat = flowerGangSeat;
            this.flowerGangPos = count - 1;
            return { seat: flowerGangSeat, flowerGangPos: this.flowerGangPos }
        } else {
            if (pos % 2 == 0) {
                this.flowerGangPos += 1;
            } else {
                this.flowerGangPos -= 3;
            }
            return { seat: seat, flowerGangPos: this.flowerGangPos }
        }
    }

    /**
     * 铁八墩位置
     * @param seat 
     * @param pos 
     * @returns 
     */
    public onGetEightPileIdx(seat, pos, idx) {
        // 获取每摞牌的数量
        let pilesCount = this.roomConfig.hasFlowerCard ? 18 : 17;
        let count = pilesCount * 2 - 1;
        let eightPileCount = 0;
        if (this.roomConfig.maxPlayerNum == 4) {
            eightPileCount = 15;
        } else if (this.roomConfig.maxPlayerNum == 3) {
            eightPileCount = 43;
        } else if (this.roomConfig.maxPlayerNum == 2) {
            eightPileCount = 71;
        }
        if (idx == eightPileCount) {
            if (pos == 1) {
                this.eightPileSeat = this.onGetReverseSeatIdx(seat);
                this.eightPilePos = count;
                return { seat: this.eightPileSeat, eightPilePos: this.eightPilePos }
            } else {
                if (pos % 2 == 0) {
                    this.eightPilePos += 1;
                } else {
                    this.eightPilePos -= 2;
                }
                return { seat: seat, eightPilePos: this.eightPilePos }
            }

        } else {
            if (pos == 1) {
                this.eightPileSeat = this.onGetReverseSeatIdx(seat);
                this.eightPilePos = count - 1;
                return { seat: this.eightPileSeat, eightPilePos: this.eightPilePos }
            } else {
                if (pos % 2 == 0) {
                    this.eightPilePos += 1;
                } else {
                    this.eightPilePos -= 3;
                }
                return { seat: seat, eightPilePos: this.eightPilePos }
            }
        }
    }

    /**
     * 顺时针获取seat
     * @param seat 
     * @returns 
     */
    public onGetSeatIdx(seat) {
        if (seat == 0) {
            return 3;
        } else {
            return seat - 1;
        }
    }

    /**
     * 逆时针获取seat
     * @param seat 
     * @returns 
     */
    public onGetReverseSeatIdx(seat) {
        if (seat == 3) {
            return 0;
        } else {
            return seat + 1;
        }
    }

    /**
     * 打开提示框
     * @param opts 
     */
    public onShowDialog(data) {
        const opts = data;
        App.loadGamePopul({
            prefabName: "mahjongTipNode",
            prefabPath: "prefab",
            zIndex: 1400,
            data: opts,
            prefabComponent: "dialogBox"
        })
    }

    /**
     * 结算战绩按照东南西北顺序排列
     * @param data 
     */
    public onSortSettleWind(data) {
        if (data) {
            for (let i = 0; i < data.length - 1; i++) {
                for (let j = 0; j < data.length - i - 1; j++) {
                    if (data[j].wind > data[j + 1].wind) {
                        let temp = data[j];
                        data[j] = data[j + 1];
                        data[j + 1] = temp;
                    }
                }
            }
        }
    }

    /**
     * 检测是否有无七抢一
     * @returns 
     */
    public isCheckQiQiangYi() {
        for (let i = 0; i < this.curPlayerOptions.length; i++) {
            const option = this.curPlayerOptions[i];
            if (option == MAHJONG_PLAYER_OPERATION.robFlowerWin) {
                return option;
            }
        }
        return -1;
    }

    /**
     * 检测是否有无加番动画
     * @param data 
     * @returns 
     */
    public isCheckAddFanAnim(data) {
        for (let i = 0; i < data.length; i++) {
            const cardType = data[i].pointType;
            if (cardType == MAHJONG_CARD_TYPE.HaiDiLaoYue || cardType == MAHJONG_CARD_TYPE.HeDiLaoYu ||
                cardType == MAHJONG_CARD_TYPE.GangShangKaiHua) {
                return data[i];
            }
        }
        return -1;
    }

    /**
     * 检测是否有牌型动画
     * @param data 
     */
    public isCheckCardTypeAnim(data) {
        const cardTypeAnimName = [
            0, MAHJONG_ANIM.TianHu, MAHJONG_ANIM.DiHu, MAHJONG_ANIM.Dasixi, MAHJONG_ANIM.RenHu, 0, 0, MAHJONG_ANIM.DaSanYuan,
            MAHJONG_ANIM.XiaoSiXi, MAHJONG_ANIM.EightFlower, MAHJONG_ANIM.ZiYiSe, MAHJONG_ANIM.QingYiSe, MAHJONG_ANIM.SiGangPai,
            MAHJONG_ANIM.QiQiangYi, 0, 0, MAHJONG_ANIM.XiaoSanYuan, MAHJONG_ANIM.HunYiSe, MAHJONG_ANIM.PongPongHu, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, MAHJONG_ANIM.HaiDiLaoYue, MAHJONG_ANIM.GangShangKaiHua, MAHJONG_ANIM.HeDiLaoYu, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0
        ]
        for (let i = 0; i < data.length; i++) {
            const cardType = data[i].pointType;
            if (cardTypeAnimName[cardType] != 0) {
                if (cardType != MAHJONG_CARD_TYPE.HaiDiLaoYue && cardType != MAHJONG_CARD_TYPE.HeDiLaoYu &&
                    cardType != MAHJONG_CARD_TYPE.GangShangKaiHua) {
                    return cardType;
                }
            }
        }
        return -1;
    }

    /**
     * 展示牌型动画
     * @param data 
     * @param isAddFan 
     */
    public showCardTypeAnim(data, isAddFan) {
        const result = cc.find('Canvas').getChildByName("smallResultView");
        if (!result && this.isSmallSettle) {
            App.loadGamePopul({
                prefabName: "cardTypeAnim",
                prefabPath: "prefab/mahjongCard/cardTypeAnim",
                prefabComponent: "mahjongCardTypeAnim",
                data: {
                    fanlist: data,
                    isAddFan: isAddFan
                }
            })
        }
    }

    public formatCoinNum(num: number, isLower: boolean = false): string {
        if (num >= 0) {
            let numStr = num.toString();
            if (num >= 1000 && num < 1000000) {
                numStr = (num / 1000).toString();
                if (numStr.indexOf(".") > -1) {
                    numStr = parseFloat(numStr).toString().substring(0, numStr.indexOf(".") + 2) + (isLower ? "k" : "K");
                } else {
                    numStr += (isLower ? "k" : "K");
                }

            } else if (num >= 1000000) {
                numStr = (num / 1000000).toString();
                if (numStr.indexOf(".") > -1) {
                    numStr = parseFloat(numStr).toString().substring(0, numStr.indexOf(".") + 2) + (isLower ? "m" : "M");
                } else {
                    numStr += (isLower ? "m" : "M");
                }
            }
            return numStr;
        }
    }

    /**
     * 获取出牌音效
     * @param card 
     * @returns 
     */
    public getCardVoice(card) {
        const CardVoice = {
            17: MAHJONG_CONST.Sound.voice_Character1,
            18: MAHJONG_CONST.Sound.voice_Character2,
            19: MAHJONG_CONST.Sound.Voice_Character3,
            20: MAHJONG_CONST.Sound.Voice_Character4,
            21: MAHJONG_CONST.Sound.Voice_Character5,
            22: MAHJONG_CONST.Sound.Voice_Character6,
            23: MAHJONG_CONST.Sound.Voice_Character7,
            24: MAHJONG_CONST.Sound.Voice_Character8,
            25: MAHJONG_CONST.Sound.Voice_Character9,
            33: MAHJONG_CONST.Sound.Voice_Circle1,
            34: MAHJONG_CONST.Sound.Voice_Circle2,
            35: MAHJONG_CONST.Sound.Voice_Circle3,
            36: MAHJONG_CONST.Sound.Voice_Circle4,
            37: MAHJONG_CONST.Sound.Voice_Circle5,
            38: MAHJONG_CONST.Sound.Voice_Circle6,
            39: MAHJONG_CONST.Sound.Voice_Circle7,
            40: MAHJONG_CONST.Sound.Voice_Circle8,
            41: MAHJONG_CONST.Sound.Voice_Circle9,
            49: MAHJONG_CONST.Sound.Voice_Bamboo1,
            50: MAHJONG_CONST.Sound.voice_Bamboo2,
            51: MAHJONG_CONST.Sound.Voice_Bamboo3,
            52: MAHJONG_CONST.Sound.Voice_Bamboo4,
            53: MAHJONG_CONST.Sound.Voice_Bamboo5,
            54: MAHJONG_CONST.Sound.Voice_Bamboo6,
            55: MAHJONG_CONST.Sound.Voice_Bamboo7,
            56: MAHJONG_CONST.Sound.Voice_Bamboo8,
            57: MAHJONG_CONST.Sound.Voice_Bamboo9,
            65: MAHJONG_CONST.Sound.Voice_East,
            66: MAHJONG_CONST.Sound.Voice_South,
            67: MAHJONG_CONST.Sound.Voice_West,
            68: MAHJONG_CONST.Sound.Voice_North,
            81: MAHJONG_CONST.Sound.Voice_RedDragon,
            82: MAHJONG_CONST.Sound.Voice_GreenDragon,
            83: MAHJONG_CONST.Sound.Voice_WhiteDragon,
        }
        return CardVoice[card];
    }

    /**
     * 判断房间号是否正确
     */
    public isCurrectRoom(data): boolean {
        const isCurrect = this.isSameGameInfo(data);
        if (!isCurrect) {
            console.error("not currect room");
        }
        return isCurrect;
    }

    /**
     * 是否是同一个房间的消息
     * @param data 
     * @returns 
     */
    public isSameGameInfo(data): boolean {
        return (this.tableId === data.roomId && platform_game_id.mahjong_table === this.gameId);
    }

}