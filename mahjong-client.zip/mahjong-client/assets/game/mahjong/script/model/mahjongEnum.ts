
/**
 * 请求路由
 */
export enum MAHJONG_REQUEST_ROUTE {
    /** 准备 */
    GAME_READY = "mahjong.mahjongGameHandler.ready",
    /** 操作请求 */
    OPERATION = "mahjong.mahjongGameHandler.playerAction",
    /** 离开房间 */
    LEAVE_TABLE = "mahjong.mahjongGameHandler.playerLeave",
    /** 发起结束游戏投票 */
    GAME_END_VOTE = "mahjong.mahjongGameHandler.startVoteDisband",
    /** 确认结束游戏投票 */
    GAME_SURE_ENDGAME = "mahjong.mahjongGameHandler.confirmVote",
    /** 继续游戏 */
    GAME_CONTINUE = "mahjong.mahjongGameHandler.confirmSettle",
    /** 房主踢人 */
    GAME_KICK_OUT_PLAYER = "mahjong.mahjongGameHandler.kickOutPlayer",
    /** 房主拉取黑名单列表 */
    GAME_GET_GAME_BLACKLIST = "mahjong.mahjongGameHandler.getBlacklist",
    /** 房主移除黑名單 */
    GAME_REMOVE_FROME_BLACKLIST = "mahjong.mahjongGameHandler.clearBlacklist",
    /**游戏内拉取游戏战绩 */
    GAME_GET_GAME_DETAIL = "mahjong.mahjongGameHandler.getGameDetail",
    /** 游戏内拉取游戏记录 */
    GAME_GET_GAME_SCORE_RECORD = "mahjong.mahjongGameHandler.getGameScoreRecords",
    /** 发送互动表情 */
    GAME_SEND_EMOJI = "mahjong.mahjongGameHandler.sendEmoji",
    /** 发送聊天消息 */
    GAME_SEND_MSG = "mahjong.mahjongGameHandler.sendMessage",
    /** 观战玩家在房间内坐下(只允许在游戏开始前) */
    GAME_SITDOWN_PLAY = "mahjong.mahjongGameHandler.sitDown",
    /** 座位玩家站起加入观战(只允许在游戏开始前)  */
    GAME_SITUP_WATCH = "mahjong.mahjongGameHandler.standUp",
    /** 房主在游戏开始之前发起解散房间请求 */
    GAME_MASTER_DISSROOM = "mahjong.mahjongGameHandler.disbandRoom",
    /** 邀请加入房间 */
    GAME_INVITE_PLAYER = "onInviteJoinRoomPush"
}

/**
 * 麻将人数
 */
export enum MAHJONG_PLAYERS {
    TWO = 2,
    THREE = 3,
    FOUR = 4,
}

/**
 * 玩家座位号
 */
export enum MAHJONG_PLAYER_CHARID {
    SOUTH = 1,
    WEST = 2,
    NORTH = 3,
    EAST = 4,
}

/**
 * 结算类型
 */
export enum MAHJONG_SETTLE_TYPE {
    /**正常结算**/
    Normal = 1,
    /**流局**/
    Flow = 2,
    /**和局**/
    Peace = 3
}

/**
 * 牌番类型
 */
export enum MAHJONG_CARD_TYPE {
    /**天胡**/
    TianHu = 1,
    /**地胡**/
    DiHu = 2,
    /**大四喜**/
    DaSiXi = 3,
    /**人胡**/
    RenHu = 4,
    /**天听**/
    TianTing = 5,
    /**五暗刻**/
    WuAnKe = 6,
    /**大三元**/
    DaSanYuan = 7,
    /**小四喜**/
    XiaoSiXi = 8,
    /**八仙过海**/
    BaXianGuoHai = 9,
    /**字一色**/
    ZiYiSe = 10,
    /**清一色**/
    QingYiSe = 11,
    /**四杠牌**/
    SiGangPai = 12,
    /**七抢一**/
    QiQiangYi = 13,
    /**四暗刻**/
    SiAnKe = 14,
    /**地听**/
    DiTing = 15,
    /**小三元**/
    XiaoSanYuan = 16,
    /**混一色**/
    HunYiSe = 17,
    /**碰碰胡**/
    PongHu = 18,
    /**自摸门清**/
    ZiMoMenQing = 19,
    /**全求人**/
    QuanQiuRen = 20,
    /**平胡**/
    PingHu = 21,
    /**三暗刻**/
    SanAnKe = 22,
    /**花杠**/
    HuaGang = 23,
    /**庄家**/
    Dealer = 24,
    /**连庄**/
    MultiDealer = 25,
    /**自摸**/
    ZiMo = 26,
    /**门清**/
    MenQing = 27,
    /**独听**/
    DuTing = 28,
    /**海底捞月**/
    HaiDiLaoYue = 29,
    /**杠上开花**/
    GangShangKaiHua = 30,
    /**河底捞鱼**/
    HeDiLaoYu = 31,
    /**三元台**/
    SanYuanTai = 32,
    /**抢杠**/
    QiangGang = 33,
    /**花牌**/
    HuaPai = 34,
    /**门风刻**/
    MenFengKe = 35,
    /**圈风刻**/
    QuanFengKe = 36,
    /**报听**/
    ReadyHand = 37,
    /**见花见台**/
    HasFlowerCard = 38,
    /**见风见台**/
    HasWindCard = 39,
    /**无字无花**/
    NoWordCard = 40,
    /**杠牌**/
    HasKong = 41,
    /**暗杠**/
    HasConcealedKong = 42,
}

/** 游戏状态 */
export enum MAHJONG_GAME_STAGE {
    /** 休息 */
    Intermission = 0,
    /** 开始游戏 */
    Start = 1,
    /** 随机抓位置 */
    RandomWind = 2,
    /** 定庄家 */
    SelectDealer = 3,
    /** 发牌 */
    DealCard = 4,
    /** 替花 */
    replaceFlowersCard = 5,
    /** 等待玩家摸牌后的行为阶段 **/
    WaitOption = 6,
    /** 等待其他玩家操作阶段 **/
    WaitOtherOptions = 7,
    /** 游戏结算 */
    Settle = 8,
    /** 流局 */
    Flow = 9,
    /** 本局游戏结束 */
    GameEnd = 11,
    /** 房间对局结束 */
    TableEnd = 12
}

/**
 * 房间类型
 */
export enum MAHJONG_ROOM_TYPE {
    /** 普通创房 */
    COMMON = 1,
    /** 代开创房 */
    AGENT = 2,
    /** 公桌房 */
    PUBLIC = 3
}

/**
 * 房间列表
 */
export enum MAHJONGROOMLIST_TYPE {
    /** 公开桌 */
    PublicRoom = 1,
    /** 私人桌 */
    PrivateRoom = 2
}

/**
 * 战绩类型
 */
export enum MAHJONG_RECORD_TYPE {
    /** 代开战绩 */
    AGENT = 1,
    /** 个人战绩 */
    PERSONAL = 2,
}

/**
 * 玩家可操作列表
 */
export enum MAHJONG_PLAYER_OPERATION {
    /** 跳过 **/
    overLeap = 1,
    /** 打牌 **/
    discard = 2,
    /** 吃 **/
    eatCard = 3,
    /** 碰 */
    pengCard = 4,
    /** 明杠 */
    mingGangCard = 5,
    /** 暗杠 **/
    anGangCard = 6,
    /** 胡牌 */
    huCard = 7,
    /** 自摸 **/
    ziMo = 8,
    /** 抢杠胡 */
    robKongHu = 9,
    /**请求听牌**/
    readyHand = 10,
    /**碰杠**/
    pongKongCard = 11,
    /**自摸花胡(8仙过海的花胡)**/
    flowerWin = 12,
    /**七抢一花胡**/
    robFlowerWin = 13,
    /** 放炮 */
    fangPao = 14
}

/**
 * 结算手牌类型
 */
export enum Mahjong_SettleCardType {
    /**吃牌**/
    chow = 1,
    /**碰手牌**/
    pong = 2,
    /**明杠**/
    exposedKong = 3,
    /**暗杠**/
    concealedKong = 4,
    /**补杠**/
    pongKong = 5,
}

/**
 * 风圈位
 */
export enum MAHJONG_WINDS {
    /** 东 */
    east = 1,
    /** 南 */
    south = 2,
    /** 西 */
    west = 3,
    /** 北 */
    north = 4,
}

/**
 * 吃碰杠动画
 */
export enum MAHJONG_OPERATION_ANIM {
    /** 吃 */
    eat = "text_Chow",
    /** 碰 */
    pong = "text_Pong",
    /** 杠 */
    gang = "text_Kong",
    /** 听 */
    ting = "text_ReadyHand",
    /** 胡 */
    hu = "text_Win",
    /** 自摸 */
    zimo = "text_SelfDrawWin",
    /** 打出牌闪电 */
    light_chupai = "mahjongabove _Win_dachupai",
    /** 收回牌 */
    light_shoupai = "mahjongabove _Win_shouhuipai",
    /** 吃碰杠云雾 */
    wu_chipanggang = "mahjongabove _chowpongkong",
}

/**
 * 行牌限制类型
 */
export enum MAHJONG_LIMIT_TIPS {
    /**过水未解除,不允许胡牌**/
    Limit_OverWater_Win = 1,
    /**明杠之后不允许自摸**/
    Limit_Kong_SelfDraw = 2,
    /**吃牌之后不允许开杠**/
    Limit_Chow_And_Kong = 3,
    /**不允许杠上家打出的牌**/
    Limit_Kong_Last_Sit_Discard = 4,
    /**碰牌后不允许开杠**/
    Limit_Pong_And_Kong = 5,
    /**过水碰未解除，不允许碰牌**/
    Limit_OverWater_Pong = 6,
    /**吃牌时不允许打相同的牌**/
    Limit_Chow_Not_Discard = 7,
    /**碰牌时不允许打出相同的牌**/
    Limit_Pong_Not_Discard = 8
}

/**
 * 手的动画操作类型
 */
export enum MAHJONG_HAND_TYPE {
    /** 打牌 */
    DisCard = 1,
    /** 碰杠吃 */
    PongKongChi = 2,
    /** 理牌 */
    LiCard = 3,
    /** 胡牌 */
    HuCard = 4,
    /** 摊牌 */
    TanCard = 5,
}

/**
 * 手的动画名称
 */
export enum MAHJONG_HAND_ANIM {
    /** 本家打牌 */
    MySelf_DisCard = "benjia_dapai",
    /** 本家胡牌 */
    MySelf_HuCard = "benjia_hu",
    /** 本家碰杠吃 */
    MySelf_PengGangChi = "benjia_penggangchi",
    /** 本家左手摊牌 */
    MySelf_TanCard_Left = "benjia_tanpai_L",
    /** 本家右手摊牌 */
    MySelf_TanCard_Right = "benjia_tanpai_R",
    /** 对家打牌 */
    DuiJia_DisCard = "duijia_dapai",
    /** 对家胡 */
    DuiJia_HuCard = "duijia_hu",
    /** 对家理牌 */
    DuiJia_LiCard = "duijia_lipai",
    /** 对家碰杠吃 */
    DuiJia_PengGangChi = "duijia_penggangchi",
    /** 对家摊牌 */
    DuiJia_TanCard = "duijia_tanpai",
    /** 上家打牌 */
    ShangJia_DisCard = "shangjia_dapai",
    /** 上家胡 */
    ShangJia_HuCard = "shangjia_hu",
    /** 上家理牌 */
    ShangJia_LiCard = "shangjia_lipai",
    /** 上家碰杠吃 */
    ShangJia_PengGangChi = "shangjia_penggangchi",
    /** 上家摊牌 */
    ShangJia_TanCard = "shangjia_tanpai",
    /** 下家打牌 */
    XiaJia_DisCard = "xiajia_dapai",
    /** 下家胡 */
    XiaJia_HuCard = "xiajia_hu",
    /** 下家理牌 */
    XiaJia_LiCard = "xiajia_lipai",
    /** 下家碰杠吃 */
    XiaJia_PengGangChi = "xiajia_penggangchi",
    /** 下家摊牌 */
    XiaJia_TanCard = "xiajia_tanpai",
}

/**
 * 每局结果动画
 */
export enum MAHJONG_SETTLE_ANIM {
    /** 流局 */
    LiuJu = "liuju",
    /** 放炮 */
    FangPao = "fangqiang",
    /** 和局 */
    HeJu = "heju",
    /** 抢杠胡 */
    QiangGangHu = "qiangganghu",
    /** 听 */
    Ting = "ting_tips",
}

/**
 * 眯牌动画名称
 */
export enum MAHJONG_MICARDANIM {
    /** 快速手 */
    Hand_Fast = "hand_fast",
    /** 慢速手 */
    Hand_Slow = "hand_slow",
    /** 快速手指 */
    Finger_Fast = "finger_fast",
    /** 慢速手指 */
    Finger_Slow = "finger_slow",
    /** 手指滑动 */
    Finger_Slide = "fireworks",
}

/**
 * 麻将动画
 */
export enum MAHJONG_ANIM {
    /** 抓位 */
    RandomWind = "zhuawei",
    /** 补花 */
    ReplaceFlower = "buhua",
    /** 八枝花 */
    EightFlower = "bazhihua",
    /** 大四喜 */
    Dasixi = "dasixi",
    /** 天胡  */
    TianHu = "tianhu",
    /** 地胡 */
    DiHu = "dihu",
    /** 人胡 */
    RenHu = "renhu",
    /** 碰碰胡 */
    PongPongHu = "pengpenghu",
    /** 清一色 */
    QingYiSe = "qingyise",
    /** 小三元 */
    XiaoSanYuan = "xiaosanyuan",
    /** 字一色 */
    ZiYiSe = "ziyise",
    /** 大三元 */
    DaSanYuan = "dasanyuan",
    /** 杠上开花 */
    GangShangKaiHua = "gangshangkaihua",
    /** 海底捞月 */
    HaiDiLaoYue = "haidilaoyue",
    /** 河底捞鱼 */
    HeDiLaoYu = "hedilaoyu",
    /** 混一色 */
    HunYiSe = "hunyise",
    /** 七抢一 */
    QiQiangYi = "qiqiangyi",
    /** 四杠牌 */
    SiGangPai = "sigangpai",
    /** 小四喜 */
    XiaoSiXi = "xiaosixi",
}

/**
 * 麻将常量
 */
export const MAHJONG_CONST = {
    /** 我的位置 */
    MY_SEATID: 0,

    /** 游戏人数 */
    PLAYERS_NUM: 4,

    /** 剩余最后8墩牌不发 */
    RemainCardPile: 8,

    /** 其他玩家的手牌数量 */
    OTHER_HANDCARDS: 16,

    /** 总共牌张数 */
    TotalCardCount: 144,

    /** 杠牌 */
    GANG_CARD: 5,

    /** 胡牌 */
    HU_CARD: 7,

    /** 玩家操作类型 */
    MAHJONG_LOCAL_OPERATOR: "mahjongOperator",

    /** 聊天文字 */
    msgLabels: [
        "給點甜的好嗎",
        "你就繼續吃沒關係啊",
        "就等你放這支",
        "餵點好料行嗎～",
        "屎都拉完了還不出牌?",
        "連我阿嬤都打得比你快",
        "上碰～下自摸！",
        "可以胡我嗎？拜託",
        "快餓死拉 給點牌來吃",
        "再吃噎死你"
    ],

    WangPaiMsgLabels: [
        "給點甜的好嗎",
        "你就繼續吃沒關係啊",
        "就等你放這支",
        "餵點好料行嗎～",
        "屎都拉完了還不出牌?",
        "連我阿嬤都打得比你快",
        "上碰～下自摸！",
        "可以胡我嗎？拜託",
        "快餓死拉 給點牌來吃",
        "再吃噎死你"
    ],

    /** 表情动画名 */
    expressName: ["se", "dianzan", "bixin", "daxiao", "kiss", "money", "yun", "sleep", "han", "wenhao", "mojing",
        "xu", "tuxue", "fahuo", "shangxin"],

    /** 表情音效名称 */
    expreseeSoundNames: ["envy", "great", "love", "laugh", "kiss", "greedy", "dizzy", "sleep", "sweat", "doubt",
        "cool", "hush", "blood", "anger", "cry"],

    Sound: {
        /** 大廳新年背景音樂 */
        NewYearBGM: "music_hall_newyear",
        /** 大厅背景音乐 */
        HallBGM: "music_bgm01",
        /** 游戏内背景音乐 */
        GameBGM: "music_bgm02",
        /** 按钮音效 */
        SoundBtn: "sound_btn",
        /** 进入游戏 */
        Sound_EnterRoom: "sound_player_enter",
        /** 开始游戏 */
        Sound_StartGame: "sound_StartGame",
        /** 发牌 */
        Sound_DealCard: "sound_DrawCards",
        /** 定庄 */
        Sound_SureBank: "sound_Banker_logo",
        /** 选择手牌时播放，只需弹起一张牌的声音即可 */
        Sound_PickCard: "sound_PickCard",
        /** 剩余3秒时播放 */
        Sound_Timer3: "sound_CountdownTimer",
        /** 剩余0秒时播放  */
        Sound_Timer0: "sound_CountdownTimer_end",
        /** 将一张牌按照理牌顺序插入手牌时播放 */
        Sound_LiCard: "sound_CardManagement",
        /** 手出牌音效 */
        sound_RowOfCards: "sound_RowOfCards",
        /** 胡 */
        Sound_Hu: "sound_Hu",
        /** 自摸 */
        Sound_ZiMo: "sound_ZiMo",
        /** 听牌 */
        Sound_WaitOne: "sound_WaitOne",
        /** 碰 */
        Sound_Peng: "sound_Pung",
        /** 杠 */
        Sound_Kong: "sound_Kong",
        /** 吃 */
        Sound_Chow: "sound_Chow",
        /** 吃别人放枪的牌，自己手牌摊开时播放，之后会配合手 */
        Sound_Cardeffects: "sound_Cardeffects",
        /** 将牌张吃碰杠到自己手牌区域时的特效，见右侧玩家 */
        Sound_DisplayBoards: "sound_DisplayBoards",
        /** 其他玩家吃碰杠时，拿走吃碰杠牌张时播放的特效 */
        Sound_TakeAwayCards: "sound_TakeAwayCards",
        /** 八枝花 */
        Sound_EightFlowers: "sound_EightFlowers",
        /** 大三元 */
        Sound_BigThree: "sound_BigThree",
        /** 大四喜 */
        Sound_DaSiXi: "sound_DaSiXi",
        /** 地胡 */
        Sound_Dihu: "sound_Dihu",
        /** 清一色 */
        Sound_ClearOne: "sound_ClearOne",
        /** 人胡 */
        Sound_Renhu: "sound_Renhu",
        /** 天胡 */
        Sound_HeavenlyHu: "sound_HeavenlyHu",
        /** 小四喜 */
        Sound_SmallFour_Hu: "sound_SmallFour_Hu",
        /** 字一色 */
        Sound_WordOneColor: "sound_WordOneColor",
        /** 小三元 */
        Sound_SmallThreeDollars: "sound_SmallThreeDollars",
        /** 四杠牌 */
        Sound_FourKongs: "sound_FourKongs",
        /** 七抢一 */
        Sound_SevenforOne: "sound_SevenforOne",
        /** 碰碰胡 */
        Sound_BumperHoop: "sound_BumperHoop",
        /** 混一色 */
        Sound_MixedOneColor: "sound_MixedOneColor",
        /** 河底捞鱼 */
        Sound_FishBottomRiver: "sound_FishBottomRiver",
        /** 海底捞月 */
        Sound_MoonBottomSea: "sound_MoonBottomSea",
        /** 杠上开花 */
        Sound_KongsonFlower: "sound_KongsonFlower",
        /** 掷骰子 */
        Sound_RollTheDice: "sound_RollTheDice",
        /** 补花 */
        Sound_Mulligan: "sound_Mulligan",
        /** 抓位 */
        Sound_Catchingposition: "sound_Catchingposition",
        /** 连庄 */
        Sound_ContinuousBanker: "sound_ContinuousBanker",
        /** 放炮 */
        Sound_Gun: "sound_Gun",
        /** 和局 */
        Sound_Draw: "sound_Draw",
        /** 流局 */
        Sound_Streaming: "sound_Streaming",
        /** 抢杠胡 */
        Sound_GrabbingKongs: "sound_GrabbingKongs",

        /** 一万 */
        voice_Character1: "voice_Character1",
        /** 二万 */
        voice_Character2: "voice_Character2_er",
        /** 三万 */
        Voice_Character3: "voice_Character3",
        /** 四万 */
        Voice_Character4: "voice_Character4",
        /** 五万 */
        Voice_Character5: "voice_Character5",
        /** 六万 */
        Voice_Character6: "voice_Character6",
        /** 七万 */
        Voice_Character7: "voice_Character7",
        /** 八万 */
        Voice_Character8: "voice_Character8",
        /** 九万 */
        Voice_Character9: "voice_Character9",
        /** 一筒 */
        Voice_Circle1: "voice_Circle1",
        /** 二筒 */
        Voice_Circle2: "voice_Circle2_er",
        /** 三筒 */
        Voice_Circle3: "voice_Circle3",
        /** 四筒 */
        Voice_Circle4: "voice_Circle4",
        /** 五筒 */
        Voice_Circle5: "voice_Circle5",
        /** 六筒 */
        Voice_Circle6: "voice_Circle6",
        /** 七筒 */
        Voice_Circle7: "voice_Circle7",
        /** 八筒 */
        Voice_Circle8: "voice_Circle8",
        /** 九筒 */
        Voice_Circle9: "voice_Circle9",
        /** 一条 */
        Voice_Bamboo1: "voice_Bamboo1",
        /** 二条 */
        voice_Bamboo2: "voice_Bamboo2_er",
        /** 三条 */
        Voice_Bamboo3: "voice_Bamboo3",
        /** 四条 */
        Voice_Bamboo4: "voice_Bamboo4",
        /** 五条 */
        Voice_Bamboo5: "voice_Bamboo5",
        /** 六条 */
        Voice_Bamboo6: "voice_Bamboo6",
        /** 七条 */
        Voice_Bamboo7: "voice_Bamboo7",
        /** 八条 */
        Voice_Bamboo8: "voice_Bamboo8",
        /** 九条 */
        Voice_Bamboo9: "voice_Bamboo9",
        /** 东风*/
        Voice_East: "voice_East",
        /** 南风 */
        Voice_South: "voice_South",
        /** 西风 */
        Voice_West: "voice_West",
        /** 北风 */
        Voice_North: "voice_North",
        /** 红中 */
        Voice_RedDragon: "voice_RedDragon",
        /** 发财 */
        Voice_GreenDragon: "voice_GreenDragon",
        /** 白板 */
        Voice_WhiteDragon: "voice_WhiteDragon",
    },

    shareRoomInfo:
        "遊戲：【%s】\n揪咖名稱：【%s】\n牌桌號：【%s】\n密碼：【%s】\n揪咖方式: 【%s】\n底分：【%s】\n台分：【%s】\n封頂【%s】\n花牌【%s】\n玩家人數：【%s】\n圈數：【%s】\n揪咖設置：【%s】\n特殊玩法：【%s】\n特殊牌型：【%s】\n支付方式：【%s】",
    shareText:
        "遊戲：【%s】\n揪咖名稱：【%s】\n牌桌號：【%s】\n密碼：【%s】\n揪咖方式: 【%s】\n底分：【%s】\n台分：【%s】\n封頂【%s】\n花牌【%s】\n玩家人數：【%s】\n圈數：【%s】\n揪咖設置：【%s】\n特殊玩法：【%s】\n特殊牌型：【%s】\n支付方式：【%s】\nurl：\n%s",
}

/**
 * 加入房间的输入类型
 * 
 */
export enum InputType {
    roomName = 0,   //输入房号
    password = 1    //输入密码
}

/**
* 解散房间玩家操作
*/
export enum PLAYER_DISSOLVE {
    DISAGREE = 0,     //拒绝
    AGREE         //同意
}