

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongInputScrollViewEvent extends cc.Component {

    @property({
        tooltip: "",
        type: cc.ScrollView
    })
    targetScrollView: cc.ScrollView = null;

    start() {
        this.node.on(cc.Node.EventType.TOUCH_START, () => {
            this.targetScrollView.vertical = false;
        }, this);

        this.node.on(cc.Node.EventType.TOUCH_MOVE, () => {
            this.targetScrollView.vertical = false;
        }, this);

        this.node.on(cc.Node.EventType.TOUCH_END, () => {
            this.targetScrollView.vertical = true;
        }, this);

        this.node.on(cc.Node.EventType.TOUCH_CANCEL, () => {
            this.targetScrollView.vertical = true;
        }, this);
    }

}
