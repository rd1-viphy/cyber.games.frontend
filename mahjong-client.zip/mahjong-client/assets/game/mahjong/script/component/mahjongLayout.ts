import { MAHJONG_PLAYER_CHARID } from "../model/mahjongEnum";


let { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongLayout extends cc.Component {

    /** 玩家方位 */
    @property
    type = 0;

    @property
    cardWidth = 0;

    @property
    cardHeight = 0;


    addHandCard(card: cc.Node) {
        if (this.type === MAHJONG_PLAYER_CHARID.SOUTH) {
            let startPosX = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posX = startPosX + curCards * this.cardWidth;
            card.setPosition(posX, 0);
        } else if (this.type === MAHJONG_PLAYER_CHARID.EAST) {
            let startPosY = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posY = startPosY - curCards * this.cardWidth;
            card.setPosition(0, posY);
        } else if (this.type === MAHJONG_PLAYER_CHARID.NORTH) {
            let startPosX = -this.cardWidth / 2 - 13;
            let curCards = this.node.children.length;
            let posX = startPosX - curCards * (this.cardWidth - 3);
            card.setPosition(posX, 0);
        } else if (this.type === MAHJONG_PLAYER_CHARID.WEST) {
            let startPosY = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posY = startPosY + curCards * this.cardWidth;
            card.setPosition(0, posY);
            card.zIndex = 100 - curCards;
        }
    }

    addDisCard(card) {
        if (this.type === MAHJONG_PLAYER_CHARID.SOUTH) {
            let startPosX = -this.node.width / 2 + this.cardWidth / 2;
            let startPosY = -this.cardHeight / 2;
            let rowCount = parseInt((this.node.width / (this.cardWidth - 3)).toString())
            let index = this.node.children.length;
            let line = parseInt((index / rowCount).toString())
            let row = index % rowCount;
            let x = startPosX + row * (this.cardWidth - 3) + this.cardWidth;
            let y = startPosY - line * (this.cardHeight - 12)
            card.setPosition(x, y);
        } else if (this.type === MAHJONG_PLAYER_CHARID.WEST) {
            let startPosX = -this.node.width / 2;
            let startPosY = -this.node.height / 2 + this.cardHeight / 2;
            let lineCount = parseInt((this.node.height / (this.cardHeight - 15)).toString())
            let index = this.node.children.length;
            let line = parseInt((index / lineCount).toString());
            let row = index % lineCount;
            card.zIndex = 100 - index;
            let x = startPosX + line * (this.cardWidth - 3);
            let y = startPosY + row * (this.cardHeight - 17) + this.cardHeight;
            card.setPosition(x, y);
        } else if (this.type === MAHJONG_PLAYER_CHARID.NORTH) {
            let startPosX = this.node.width / 2 + this.cardWidth / 2;
            let startPosY = this.cardHeight / 2;
            let rowCount = parseInt((this.node.width / (this.cardWidth - 3)).toString())
            let index = this.node.children.length;
            let line = parseInt((index / rowCount).toString())
            let row = index % rowCount;
            let x = startPosX - row * (this.cardWidth - 3);
            let y = startPosY + line * (this.cardHeight - 12);
            card.setPosition(x, y);
        } else if (this.type === MAHJONG_PLAYER_CHARID.EAST) {
            let startPosX = this.cardWidth / 2;
            let startPosY = -this.node.height / 2 + this.cardHeight / 2;
            let lineCount = parseInt((this.node.height / (this.cardHeight - 15)).toString())
            let index = this.node.children.length;
            let line = parseInt((index / lineCount).toString());
            let row = index % lineCount;
            card.zIndex = 100 - index;
            card.setPosition(startPosX + row * (this.cardWidth - 3), startPosY - line * (this.cardHeight - 12));
        }
    }

    addMoCard(card: cc.Node) {
        if (this.type === MAHJONG_PLAYER_CHARID.SOUTH) {
            let startPosX = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posX = startPosX + curCards * this.cardWidth + this.cardWidth / 2;
            card.setPosition(posX, 0);
        } else if (this.type === MAHJONG_PLAYER_CHARID.EAST) {
            let startPosY = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posY = startPosY - curCards * this.cardWidth;
            card.setPosition(0, posY);
        } else if (this.type === MAHJONG_PLAYER_CHARID.NORTH) {
            let startPosX = -this.cardWidth / 2 - 13;
            let curCards = this.node.children.length;
            let posX = startPosX - curCards * (this.cardWidth - 3) - this.cardWidth / 2;
            card.setPosition(posX, 0);
        } else if (this.type === MAHJONG_PLAYER_CHARID.WEST) {
            let startPosY = this.cardWidth / 2;
            let curCards = this.node.children.length;
            let posY = startPosY + curCards * this.cardWidth;
            card.setPosition(0, posY);
            card.zIndex = 100 - curCards;
        }
    }

}
