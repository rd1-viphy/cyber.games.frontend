import { MAHJONG_MICARDANIM } from "../model/mahjongEnum";
import MahjongCard from "../view/mahjongCard";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongMiCardAnim extends cc.Component {

    @property({
        tooltip: "手背动画",
        type: sp.Skeleton
    })
    spHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "手指动画",
        type: sp.Skeleton
    })
    spFingerAnim: sp.Skeleton = null;

    @property({
        tooltip: "咪的牌",
        type: cc.Node
    })
    nodeCard: cc.Node = null;

    protected endPos = cc.v3(-120, 5, 0);

    init(data) {
        this.nodeCard.getComponent(MahjongCard).setCardNum(data.cardData);
        cc.tween(this.nodeCard)
            .to(0.1, { position: this.endPos })
            .start();

        if (data.hu) {
            this.spHandAnim.setAnimation(0, MAHJONG_MICARDANIM.Hand_Slow, false);
            this.spFingerAnim.setAnimation(0, MAHJONG_MICARDANIM.Finger_Slow, false);
            this.spFingerAnim.setCompleteListener(() => {
                this.spHandAnim.setAnimation(0, MAHJONG_MICARDANIM.Finger_Slide, false);
                this.spFingerAnim.setAnimation(0, MAHJONG_MICARDANIM.Finger_Slide, false);
                this.spFingerAnim.setCompleteListener(() => {
                    if (this.node) {
                        this.node.destroy();
                    } 
                })
            })
        } else {
            this.spHandAnim.setAnimation(0, MAHJONG_MICARDANIM.Hand_Fast, false);
            this.spFingerAnim.setAnimation(0, MAHJONG_MICARDANIM.Finger_Fast, false);
            this.spFingerAnim.setCompleteListener(() => {
                if (this.node) {
                    this.node.destroy();
                }
            })
        }
    }

}
