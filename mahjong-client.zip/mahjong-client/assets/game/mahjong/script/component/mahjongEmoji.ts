
import AudioMgr from "../../../../script/model/AudioMgr";
import MahjongModel from "../model/mahjongModel";
const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongEmoji extends cc.Component {

    @property({
        tooltip: "道具动画item",
        type: cc.Prefab
    })
    propsItem: cc.Prefab = null;

    @property({
        tooltip: "道具动画集",
        type: sp.SkeletonData
    })
    propsSkeletonDatas: sp.SkeletonData[] = [];

    @property({
        tooltip: "玩家座位",
        type: cc.Node
    })

    seats: cc.Node[] = [];
    gameModel: MahjongModel = MahjongModel.getInstance();
    moveTime: number = 0.5;
    animationNames: string[] = ["fanqie", "ganbei", "daocha", "poshui", "dianzan", "zhadan", "zhuaji2", "meigui"];
    soundNames: string[] = ["tomato", "clink", "tea", "icewater", "great", "bomb", "chicken", "rose"];

    /**
     * 设置动画道具
     */
    setPropsAnimation(data) {
        let propsItem = cc.instantiate(this.propsItem);
        this.node.addChild(propsItem);
        let propsSkeleton = propsItem.getComponent(sp.Skeleton);
        let anmitionIndex = data.id - 1;
        let animationName = this.animationNames[anmitionIndex];
        propsSkeleton.node.active = true;
        propsSkeleton.skeletonData = this.propsSkeletonDatas[anmitionIndex];
        let startSeatId = this.gameModel.getChariIdToPlayerId(data.sendPlayerId);
        let endSeatId = this.gameModel.getChariIdToPlayerId(data.targetPlayerId);
        propsSkeleton.node.setPosition(this.seats[startSeatId].getPosition());
        propsSkeleton.node.setScale(0.6);
        propsSkeleton.setAnimation(0, "fly", false);
        let endPos = this.seats[endSeatId].getPosition();
        if (endSeatId == 0) {
            endPos.x += 25;
        }

        cc.tween(propsSkeleton.node)
            .to(this.moveTime, { position: cc.v3(endPos.x, endPos.y, 0) })
            .call(() => {
                propsSkeleton.setAnimation(0, animationName, false);
                propsSkeleton.setCompleteListener(() => {
                    if (propsSkeleton.animation == animationName) {
                        propsSkeleton.node.destroy();
                    }
                });
            })
            .start()
        AudioMgr.playSFX("sound_interactive_" + this.soundNames[anmitionIndex], true);
    }

}
