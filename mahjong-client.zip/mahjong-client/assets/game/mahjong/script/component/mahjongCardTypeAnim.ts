import AudioMgr from "../../../../script/model/AudioMgr";
import { MAHJONG_ANIM, MAHJONG_CARD_TYPE, MAHJONG_CONST } from "../model/mahjongEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongCardTypeAnim extends cc.Component {

    @property({
        tooltip: "牌型动画",
        type: sp.Skeleton
    })
    spCardTypeAnim: sp.Skeleton = null;

    @property({
        tooltip: "牌型骨骼动画",
        type: sp.SkeletonData
    })
    spCardTypeSkeleData: sp.SkeletonData[] = [];

    protected readonly cardTypeAnimName = [
        0, MAHJONG_ANIM.TianHu, MAHJONG_ANIM.DiHu, MAHJONG_ANIM.Dasixi, MAHJONG_ANIM.RenHu, 0, 0, MAHJONG_ANIM.DaSanYuan,
        MAHJONG_ANIM.XiaoSiXi, MAHJONG_ANIM.EightFlower, MAHJONG_ANIM.ZiYiSe, MAHJONG_ANIM.QingYiSe, MAHJONG_ANIM.SiGangPai,
        MAHJONG_ANIM.QiQiangYi, 0, 0, MAHJONG_ANIM.XiaoSanYuan, MAHJONG_ANIM.HunYiSe, MAHJONG_ANIM.PongPongHu, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, MAHJONG_ANIM.HaiDiLaoYue, MAHJONG_ANIM.GangShangKaiHua, MAHJONG_ANIM.HeDiLaoYu, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0
    ]

    init(data) {
        for (let i = 0; i < data.fanlist.length; i++) {
            const cardType = data.fanlist[i].pointType;
            if (this.cardTypeAnimName[cardType] != 0) {
                if (data.isAddFan) {
                    if (cardType == MAHJONG_CARD_TYPE.HaiDiLaoYue || cardType == MAHJONG_CARD_TYPE.HeDiLaoYu ||
                        cardType == MAHJONG_CARD_TYPE.GangShangKaiHua) {
                        this.spCardTypeAnim.node.active = true;
                        if (cardType < 12) {
                            this.spCardTypeAnim.skeletonData = this.spCardTypeSkeleData[0];
                        } else {
                            this.spCardTypeAnim.skeletonData = this.spCardTypeSkeleData[1];
                        }
                        this.onPlayCardTypeAnim(cardType);
                        break;
                    }
                } else {
                    if (cardType != MAHJONG_CARD_TYPE.HaiDiLaoYue && cardType != MAHJONG_CARD_TYPE.HeDiLaoYu &&
                        cardType != MAHJONG_CARD_TYPE.GangShangKaiHua) {
                        this.spCardTypeAnim.node.active = true;
                        if (cardType < 12) {
                            this.spCardTypeAnim.skeletonData = this.spCardTypeSkeleData[0];
                        } else {
                            this.spCardTypeAnim.skeletonData = this.spCardTypeSkeleData[1];
                        }
                        this.onPlayCardTypeAnim(cardType);
                        break;
                    }
                }
            }
        }
    }

    isCheckAddFan(cardType) {
        if (cardType == MAHJONG_CARD_TYPE.HaiDiLaoYue || cardType == MAHJONG_CARD_TYPE.HeDiLaoYu ||
            cardType == MAHJONG_CARD_TYPE.GangShangKaiHua) {

        }

    }

    /**
     * 检查是否有加番类型动画
     * @param data 
     * @returns 
     */
    isCheckAddFanAnim(data) {
        let isHaveAddFan = false;
        for (let i = 0; i < data.length; i++) {
            const cardType = data[i].pointType;
            if (this.cardTypeAnimName[cardType] != 0) {
                if (cardType == MAHJONG_CARD_TYPE.HaiDiLaoYue || cardType == MAHJONG_CARD_TYPE.HeDiLaoYu ||
                    cardType == MAHJONG_CARD_TYPE.GangShangKaiHua) {
                    isHaveAddFan = true;
                    this.spCardTypeAnim.node.active = true;
                    this.spCardTypeAnim.skeletonData = this.spCardTypeSkeleData[1];
                    this.onPlayCardTypeAnim(cardType);
                }
            }
        }
        return isHaveAddFan;
    }

    onPlayCardTypeAnim(cardType) {
        const animVoice = this.getCardTypeAnimVoice(cardType);
        AudioMgr.playSFX(animVoice, true, true);
        this.spCardTypeAnim.setAnimation(0, this.cardTypeAnimName[cardType].toString(), false);
        this.spCardTypeAnim.setCompleteListener(() => {
            if (this.node) {
                this.node.destroy();
            }
        })
    }

    /**
     * 获取牌型动画音效
     * @param cardType 
     * @returns 
     */
    getCardTypeAnimVoice(cardType) {
        const CardTypeAnimVoice = {
            1: MAHJONG_CONST.Sound.Sound_HeavenlyHu,
            2: MAHJONG_CONST.Sound.Sound_Dihu,
            3: MAHJONG_CONST.Sound.Sound_DaSiXi,
            4: MAHJONG_CONST.Sound.Sound_Renhu,
            7: MAHJONG_CONST.Sound.Sound_BigThree,
            8: MAHJONG_CONST.Sound.Sound_SmallFour_Hu,
            9: MAHJONG_CONST.Sound.Sound_EightFlowers,
            10: MAHJONG_CONST.Sound.Sound_WordOneColor,
            11: MAHJONG_CONST.Sound.Sound_ClearOne,
            12: MAHJONG_CONST.Sound.Sound_FourKongs,
            13: MAHJONG_CONST.Sound.Sound_SevenforOne,
            16: MAHJONG_CONST.Sound.Sound_SmallThreeDollars,
            17: MAHJONG_CONST.Sound.Sound_MixedOneColor,
            18: MAHJONG_CONST.Sound.Sound_BumperHoop,
            29: MAHJONG_CONST.Sound.Sound_MoonBottomSea,
            30: MAHJONG_CONST.Sound.Sound_KongsonFlower,
            31: MAHJONG_CONST.Sound.Sound_FishBottomRiver,
        }
        return CardTypeAnimVoice[cardType];
    }

}
