import AudioMgr from "../../../../script/model/AudioMgr";
import { MAHJONG_CONST } from "../model/mahjongEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongClock extends cc.Component {

    @property([cc.Node])
    nodeClockBg: cc.Node[] = [];

    @property([cc.Sprite])
    nodeClock: cc.Sprite[] = [];

    @property(cc.Label)
    lbClock: cc.Label = null;

    @property([cc.SpriteFrame])
    spPosFrame: cc.SpriteFrame[] = [];

    @property(cc.Node)
    nodeDice: cc.Node = null;

    setMahjongClock(seatId, time) {
        this.nodeDice.active = false;
        this.lbClock.node.active = true;
        this.node.active = true;
        this.nodeClockBg.forEach((item, index) => {
            item.active = index == seatId;
        })
        this.nodeClockBg[seatId].active = true;
        this.lbClock.string = time;
        this.unscheduleAllCallbacks();
        this.schedule(this.changeClocke, 1);

        cc.tween(this.nodeClockBg[seatId])
            .to(0.5, { opacity: 1 }, { easing: "smooth" })
            .to(0.5, { opacity: 255 }, { easing: "smooth" })
            .repeatForever(
                cc.tween()
                    .to(0.5, { opacity: 1 }, { easing: "smooth" })
                    .to(0.5, { opacity: 255 }, { easing: "smooth" })
            )
            .start()
    }

    changeClocke() {
        if (parseInt(this.lbClock.string) >= 0) {
            if (parseInt(this.lbClock.string) <= 1) {
                AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Timer0, true);
                this.unschedule(this.changeClocke);
            } else {
                if (parseInt(this.lbClock.string) <= 4) {
                    AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Timer3, true);
                }
            }
            this.lbClock.string = (parseInt(this.lbClock.string) - 1).toString();
        }
    }

    changePosFrame(seatId: number, wind: number) {
        if (wind != 0) {
            this.node.active = true;
            this.nodeClock[seatId].node.active = true;
            this.nodeClock[seatId].spriteFrame = this.spPosFrame[wind - 1];
        }
    }

    onHideClock() {
        this.nodeClockBg.forEach((clockBg, idx) => {
            clockBg.active = false;
            this.nodeClock[idx].node.active = false;
        })
        this.lbClock.node.active = false;
        this.unscheduleAllCallbacks();
    }

    onHideDice() {
        this.nodeDice.active = false;
    }

    onHidelbClock() {
        this.lbClock.node.active = false;
        this.nodeClockBg.forEach((clockBg, idx) => {
            clockBg.active = false;
        })
        this.unscheduleAllCallbacks();
    }

    onDestroy() {
        this.unscheduleAllCallbacks();
    }

}
