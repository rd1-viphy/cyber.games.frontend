import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import MahjongBackModel from "../../../../script/model/mahjongBackModel";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";



const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongPlayBackNode extends cc.Component {

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;      //进度条

    @property(cc.Node)
    stopBtn: cc.Node = null;                //暂停按钮

    @property(cc.Node)
    playBtn: cc.Node = null;                //播放按钮

    @property(cc.Node)
    closeBtn: cc.Node = null;                //关闭按钮

    backView = null;
    totalTime = 0;
    clockTime = 0;
    isPlay = false;
    exitCb: Function = null
    init(backView, totalTime, exitCb: Function = null) {
        this.backView = backView;
        this.totalTime = totalTime;
        this.clockTime = 0;
        this.progressBar.progress = 0;
        this.isPlay = true;
        this.exitCb = exitCb;
        this.closeBtn.active = !App.isCustomerPlayBack;
    }

    btnClicked(event, data) {
        switch (data) {
            case "stop":
                this.playBtn.active = true;
                this.stopBtn.active = false;
                MahjongBackModel.destoryTimer();
                AudioMgr.pauseBGM();
                cc.director.pause();
                break;
            case "play":
                this.playBtn.active = false;
                this.stopBtn.active = true;
                MahjongBackModel.fastForward();
                AudioMgr.resumeBGM();
                cc.director.resume();
                break;
            case "again":
                this.playBtn.active = false;
                this.stopBtn.active = true;
                this.backView.gameControl.initView();
                cc.director.resume();
                break;
            case "fastWord":
                this.playBtn.active = false;
                this.stopBtn.active = true;
                MahjongBackModel.fastForward();
                AudioMgr.resumeBGM();
                cc.director.resume();
                this.backView.gameControl.onFastWord();
                break;
            case "exit":
                if (this.exitCb) {
                    this.exitCb();
                }
                break;
        }
    }

    stopClock() {
        this.isPlay = false;
    }

    setProgress() {
        this.progressBar.progress = this.clockTime / this.totalTime;
    }

    update(dt) {
        if (this.isPlay) {
            if (this.clockTime >= this.totalTime) {
                this.playBtn.active = true;
                this.stopBtn.active = false;
                this.stopClock();
            } else {
                this.clockTime += dt;
                this.setProgress();
            }
        }
    }

    onDestroy() {
        cc.director.resume();
        MahjongRoomMgr.getInstance().isBackView = false;
        MahjongBackModel.destoryTimer();
    }

}
