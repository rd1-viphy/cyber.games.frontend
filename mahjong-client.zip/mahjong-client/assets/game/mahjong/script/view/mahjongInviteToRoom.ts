import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../script/model/Utils";
import mahjongShowRoomInfo from "./mahjongShowRoomInfo";
import mahjongApplyClock from "./mghjongApplyClock";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongInviteToRoom extends cc.Component {

    @property({
        tooltip: "房間信息",
        type: mahjongShowRoomInfo
    })
    mahjongRoomInfo: mahjongShowRoomInfo = null;

    @property({
        tooltip: "玩家暱稱",
        type: cc.Label
    })
    nickNameLabel: cc.Label = null;

    @property({
        tooltip: "倒計時",
        type: mahjongApplyClock
    })
    clock: mahjongApplyClock = null;

    inviteData = null;

    curTime: number = 0;

    /**
     * 设置房间消息
     */
    init(data) {
        const roomInfo = data.roomConfig;
        this.mahjongRoomInfo.setRoomInfo(data);
        if (data.remainWaitTime) {
            this.curTime = data.remainWaitTime;
        } else {
            this.curTime = data.waitTime;
        }
        const waitTime = data.waitTime;
        this.clock.startClock(this.curTime, waitTime, () => {
            this.node.destroy();
        });
        this.nickNameLabel.string = Utils.tailoringNickName(data.masterName);
        this.inviteData = data;
    }

    /**
     * 按钮的点击
     * @param event 
     * @param data 
     */
    btnClicked(event: cc.Event, data: string) {
        switch (data) {
            case 'sure':    // 是否是AA支付
                let isFree = (MahjongRoomMgr.getInstance().isFreeTable && MahjongRoomMgr.getInstance().getIsIncludeActivities(MahjongRoomMgr.getInstance().startTime, MahjongRoomMgr.getInstance().endTime)) ? true : false;
                if (this.inviteData.roomConfig.isShareEquallyRoom && !isFree) {
                    let opts = {
                        confirmCallback: () => {
                            const money = PlayerMgr.getInstance().money;
                            let haveEnoughMoney = money >= this.inviteData.costMoney ? true : false;;
                            if (haveEnoughMoney) {
                                //确认加入
                                MahjongRoomMgr.getInstance().confirmJoinRoom({
                                    gameId: platform_game_id.mahjong_table,
                                    roomId: this.inviteData.roomId,
                                    confirmRes: 2
                                }, () => {
                                    PlayerMgr.getInstance().money -= this.inviteData.costMoney;
                                    App.refreshPlatformScore();
                                    this.node.destroy();
                                }, () => {
                                    this.node.destroy();
                                });
                            } else {
                                Utils.showSDKOpenBroken();
                            }
                        },
                        money: this.inviteData.costMoney,
                        createType: this.inviteData.isAgent,
                        isShareEquallyRoom: this.inviteData.costMoney.isShareEquallyRoom,
                        isCreate: false
                    }

                    App.loadGamePopul({
                        prefabName: "mahjongSureTipNode",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongSureTipNode",
                        data: opts
                    });
                } else {
                    MahjongRoomMgr.getInstance().confirmJoinRoom({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.inviteData.roomId,
                        confirmRes: 2
                    }, () => {
                        PlayerMgr.getInstance().money -= this.inviteData.costMoney;
                        this.node.destroy();
                    }, () => {
                        this.node.destroy();
                    });
                }
                break;
            case 'cancle':  //取消
                MahjongRoomMgr.getInstance().confirmJoinRoom({
                    gameId: platform_game_id.mahjong_table,
                    roomId: this.inviteData.roomId,
                    confirmRes: 1
                }, () => {
                    this.node.destroy();
                }, () => {
                    this.node.destroy();
                });
                break;
            default:
                break;
        }
    }

}
