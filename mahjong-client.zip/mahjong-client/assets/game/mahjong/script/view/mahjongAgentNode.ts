import { platform_game_id } from "../../../../script/common/ClientEnum";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import AppEmitter from "../../../../script/network/AppEmitter";
import { MAHJONGROOMLIST_TYPE } from "../model/mahjongEnum";
import mahjongAgentItem from "./item/mahjongAgentItem";
import MahjongRoomScene from "./room/mahjongRoomScene";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongAgentNode extends cc.Component {

    @property({
        tooltip: "没有数据的节点",
        type: cc.Node
    })
    noDataNode: cc.Node = null;

    @property({
        tooltip: "有数据的节点",
        type: cc.Node
    })
    haveDataNode: cc.Node = null;

    @property({
        tooltip: "代开房间的滑动列表",
        type: cc.ScrollView
    })
    generationScrollView: cc.ScrollView = null;

    @property({
        tooltip: "代开的item",
        type: cc.Prefab
    })
    generationItem: cc.Prefab = null;

    @property({
        tooltip: "当前页数",
        type: cc.Label
    })
    pageLabel: cc.Label = null;

    @property({
        tooltip: "左边箭头",
        type: cc.Button
    })
    leftBtn: cc.Button = null;

    @property({
        tooltip: "右边箭头",
        type: cc.Button
    })
    rightBtn: cc.Button = null;

    @property({
        tooltip: "房間類型的切換",
        type: cc.ToggleContainer
    })
    roomTypeToggleContainer: cc.ToggleContainer = null;

    protected currentPage: number = 1;
    protected maxpage: number = 0;
    protected maxSize: number = 4;
    protected interval = null;
    protected tableType: number = 1;

    onLoad() {
        AppEmitter.on(consts.LOCAL_REFRESH_AGENT_LIST, this.queryAgentList, this);
        AppEmitter.on(consts.SANSHUI_REFRESH_PRIVITE_ROOM, this.refreshPrivateTable, this);
        AppEmitter.on(consts.LOCAL_CLEAR_ROOMSCENETIMER, this.onClearTimer, this);
    }

    start() {
        this.queryAgentList({ gameId: platform_game_id.mahjong_table, pageStart: this.currentPage, pageNum: this.maxSize, roomType: this.tableType });
        //轮询
        this.interval = setInterval(() => {
            this.queryAgentList({ gameId: platform_game_id.mahjong_table, pageStart: this.currentPage, pageNum: this.maxSize, roomType: this.tableType });
        }, 3000);
    }

    /**
     * 获取代开列表
     */
    queryAgentList(requestData) {
        MahjongRoomMgr.getInstance().getMahjongRoomList(requestData, (data) => {
            this.refeshAgentList(data);
        })
    }

    /**
     * 牌桌類型的點擊
     */
    typeToggleClicked(event, data) {
        this.tableType = parseInt(data);
        this.queryAgentList({ gameId: platform_game_id.mahjong_table, pageStart: 1, pageNum: this.maxSize, roomType: this.tableType });
    }

    refreshPrivateTable() {
        this.roomTypeToggleContainer.toggleItems[1].isChecked = true;
        this.tableType = MAHJONGROOMLIST_TYPE.PrivateRoom;
        this.queryAgentList({ gameId: platform_game_id.mahjong_table, pageStart: 1, pageNum: this.maxSize, roomType: this.tableType });
    }

    /**
     * 刷新代开列表
     * @param list 
     */
    refeshAgentList(agentData: MahjongServerToClient.GetRoomList) {
        if (agentData.rooms && this.noDataNode) {
            let list = agentData.rooms;
            this.noDataNode.active = list.length <= 0;
            this.haveDataNode.active = list.length > 0;
            this.currentPage = agentData.pageStart;
            this.maxpage = agentData.pageEnd;
            this.refreshBtnClick();
            this.pageLabel.string = this.currentPage + "/" + this.maxpage;
            if (list.length > 0) {
                let content = this.generationScrollView.content;
                content.removeAllChildren();
                list.forEach(element => {
                    let item = cc.instantiate(this.generationItem);
                    content.addChild(item);
                    item.getComponent(mahjongAgentItem).init(element);
                });
            }
        }

        let money = agentData.money;
        PlayerMgr.getInstance().money = money;
        let mahjongRoom = cc.find("Canvas");
        if (mahjongRoom && mahjongRoom.getComponent(MahjongRoomScene)) {
            mahjongRoom.getComponent(MahjongRoomScene).refreshMoneyLabel();
        }
    }

    /**
     * 按钮的点击
     * @param event 
     * @param data 
     */
    btnClicked(event: cc.Event, data: string) {
        switch (data) {
            case 'left':
                if (this.currentPage >= 2) {
                    this.queryAgentList({
                        gameId: platform_game_id.mahjong_table,
                        pageStart: this.currentPage - 1,
                        pageNum: this.maxSize,
                        roomType: this.tableType
                    })
                }
                break;
            case 'right':
                this.queryAgentList({
                    gameId: platform_game_id.mahjong_table,
                    pageStart: this.currentPage + 1,
                    pageNum: this.maxSize,
                    roomType: this.tableType
                })
                break;
        }
    }

    refreshBtnClick() {
        this.leftBtn.interactable = this.currentPage > 1;
        this.rightBtn.interactable = this.currentPage < this.maxpage;
    }

    onClearTimer() {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }

    onDestroy() {
        AppEmitter.off(consts.LOCAL_REFRESH_AGENT_LIST, this.queryAgentList);
        AppEmitter.off(consts.SANSHUI_REFRESH_PRIVITE_ROOM, this.refreshPrivateTable);
        AppEmitter.off(consts.LOCAL_CLEAR_ROOMSCENETIMER, this.onClearTimer);
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }

}


