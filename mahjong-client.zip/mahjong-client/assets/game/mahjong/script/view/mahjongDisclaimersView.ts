
import consts = require("../../../../script/model/Consts");


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongDisclaimersView extends cc.Component {

    @property({
        tooltip: "公告",
        type: cc.RichText
    })
    lbHint: cc.RichText = null;

    @property({
        tooltip: "公告ScorllView",
        type: cc.ScrollView
    })
    disclaScrollView: cc.ScrollView = null;

    @property({
        tooltip: "content",
        type: cc.Node
    })
    nodeContent: cc.Node = null;

    @property({
        tooltip: "同意按钮",
        type: cc.Button
    })
    agreeButton: cc.Button = null;

    protected timeflg: number = 0;

    protected announcement08: string = "<color=#fff83c>公告:</c><color=#ffffff>\n" +
        "        親愛的用戶您好，為給您最佳的遊戲體驗，目前iPhone手機的視訊語" +
        "音聊天功能僅支援iOS版本14.3以上用戶，Web版本暫時不支持視訊語音功" +
        "能，如有造成您的不便，請見諒。\n" +
        "        創建牌桌與牌桌內互送道具需花費老幣，進入牌桌內遊玩使用揪咖幣，" +
        "揪咖幣退出當局即會歸0。</c>" +
        "<color=#fff83c>\n免責聲明:</c>" +
        "<color=#ffffff>\n" +
        "        本公司，提供遊戲玩家一個全新休閒娛樂的平台，所有" +
        "揪咖遊戲內的遊戲紛爭或輸贏等爭議，概由遊戲玩家自行處理，本公司不會" +
        "介入評判。\n" +
        "        本公司提供的遊戲平台僅供玩家暫時娛樂之用，本公司禁止玩家利用會" +
        "員服務進行任何商業行為。若玩家之間有任何私下交易，其結果或糾紛由玩" +
        "家自行負責，與本公司無涉。\n" +
        "        敬告所有玩家，遊戲內的所有言論與行為不得違反台灣相關的法律規定，" +
        "若有違反由玩家自行負擔相關法律責任。包括但不限於下列行為:\n" +
        "        任何違反法律言論及行為；\n" +
        "        歧視或霸凌之言論或行為；\n" +
        "        暴力、色情、賭博或教唆犯罪的言論或行為；\n" +
        "        言語談論銷售非法商品。";

    protected announcementAce: string = "<color=#fff83c>公告:</c><color=#ffffff>\n" +
        "        創建牌桌與牌桌內互送道具可能需要花費好运幣，進入牌桌內遊玩使用\n" +
        "揪咖幣計算戰績，若退出當局遊戲則揪咖幣會自動歸0。" +
        "<color=#fff83c>\n免責聲明:</c>" +
        "<color=#ffffff>\n" +
        "        好运俱樂部(下稱本公司)，提供遊戲玩家一個全新休閒娛樂的平台，所\n" +
        "有揪咖遊戲內的遊戲紛爭或輸贏等爭議，概由遊戲玩家自行處理，本公司不 \n" +
        "會介入評判。\n" +
        "        本公司提供的遊戲平台僅供玩家暫時娛樂之用，本公司禁止玩家利用會\n" +
        "員服務進行任何商業行為。若玩家之間有任何私下交易，其結果或糾紛由玩家\n " +
        "自行負責，與本公司無涉。\n" +
        "        敬告所有玩家，遊戲內的所有言論與行為不得違反台灣相關的法律規定，\n" +
        "若有違反由玩家自行負擔相關法律責任。包括但不限於下列行為:\n" +
        "        任何違反法律言論及行為；\n" +
        "        歧視或霸凌之言論或行為；\n" +
        "        暴力、色情、賭博或教唆犯罪的言論或行為；\n" +
        "        言語談論銷售非法商品";

    start() {

        this.lbHint.string = this.announcement08;

    }

    onClose() {
        this.node.destroy();
    }

    update(dt) {
        if (!this.agreeButton.interactable) {
            this.timeflg += dt;
            if (this.timeflg >= 1) {
                this.timeflg = 0;
                if (this.nodeContent.y > 325) {
                    this.agreeButton.interactable = true;
                }
            }
        }
    }

}
