import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import AppEmitter from "../../../../script/network/AppEmitter";
import { MAHJONG_REQUEST_ROUTE, MAHJONG_ROOM_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongTotalResultItem from "./item/mahjongTotalResultItem";
import mahjongApplyClock from "./mghjongApplyClock";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongTotalResultView extends cc.Component {

    @property({
        tooltip: "玩家信息节点",
        type: cc.Node
    })
    nodeResultItem: cc.Node[] = [];

    @property({
        tooltip: "倒計時",
        type: mahjongApplyClock
    })
    clock: mahjongApplyClock = null;

    @property({
        tooltip: "一键续玩",
        type: cc.Node
    })
    nodeContinue: cc.Node = null;

    protected gameModel: MahjongModel = null;
    protected gameProxy: MahjongProxy = null;
    protected playerOrder: number[] = [0, 1, 2, 3];
    protected resultList = [];

    onLoad() {
        AppEmitter.on(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame, this);
        App.clearAgoraCache();
    }

    init(data) {
        if (data.gameProxy) {
            this.gameProxy = data.gameProxy;
        }

        if (data.gameModel) {
            this.gameModel = data.gameModel;
            this.gameModel.isCancleXuWan = false;
        }

        if (this.gameModel.getIsWatchTheBattle()) {
            this.nodeContinue.active = false;
        }

        const result = cc.find('Canvas').getChildByName("smallResultView");
        if (result) {
            result.destroy();
        }
        const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
        if (tipView) {
            tipView.destroy();
        }

        this.resultList = [];

        if (!this.gameModel.getIsWatchTheBattle()) {
            let obj = {};
            data.settle.details.forEach((item, idx) => {
                if (item.playerId == PlayerMgr.getInstance().uid) {
                    obj = item;
                    data.settle.details.splice(idx, 1);
                    if (item.playerId == this.gameModel.masterUid && this.gameModel.roomConfig.createType == MAHJONG_ROOM_TYPE.COMMON) {
                        this.nodeContinue.active = true;
                    } else {
                        this.nodeContinue.active = false;
                    }
                    return;
                }
            })
            data.settle.details.unshift(obj);

            if (this.gameModel.selfChairId == 0) {
                this.playerOrder = [0, 1, 2, 3];
            } else if (this.gameModel.selfChairId == 1) {
                this.playerOrder = [1, 2, 3, 0];
            } else if (this.gameModel.selfChairId == 2) {
                this.playerOrder = [2, 3, 0, 1];
            } else if (this.gameModel.selfChairId == 3) {
                this.playerOrder = [3, 0, 1, 2];
            }
        }

        for (let i = 0; i < this.playerOrder.length; i++) {
            const num = this.playerOrder[i];
            const playerData = this.onGetPlayerData(data.settle.details, num);
            if (playerData) {
                this.resultList.push(playerData);
            }
        }

        for (let i = 0; i < this.resultList.length; i++) {
            const palyerSettle = this.resultList[i];
            if (palyerSettle.playerId) {
                this.nodeResultItem[i].active = true;
                this.nodeResultItem[i].getComponent(MahjongTotalResultItem).initItem(palyerSettle);
            }
        }

        const waitTime = data.settle.waitTime;
        if (waitTime) {
            this.clock.startClock(waitTime, waitTime, () => {
                if (this.node) {
                    this.node.destroy();
                }
                this.onReturnLobby();
            });
        }
    }

    onReturnLobby() {
        if (PlayerMgr.getInstance().uid == this.gameModel.masterUid &&
            this.gameModel.roomConfig.createType == MAHJONG_ROOM_TYPE.COMMON) {
                if (!this.gameModel.isCancleXuWan) {
                    MahjongRoomMgr.getInstance().renewRoom({
                        gameId: platform_game_id.mahjong_table,
                        roomId: MahjongModel.getInstance().tableId,
                        step: 2,
                        confirmRes: 1
                    }, () => { },
                    () => {})
                }
        }

        App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
    }

    renewRoom() {
        this.gameModel.isCancleXuWan = true;
        this.nodeContinue.getComponent(cc.Button).interactable = false;
        MahjongRoomMgr.getInstance().renewRoom({
            gameId: platform_game_id.mahjong_table,
            roomId: MahjongModel.getInstance().tableId,
            step: 1,
            confirmRes: 2
        }, (data) => {
            App.loadGamePopul({
                prefabName: "mahjongContinueRoom",
                prefabPath: "prefab",
                prefabComponent: "mahjongContinueRoom",
                data: data
            })
        }, () => {})
    }

    /**
     * 有邀请
     * @param data 
     */
    onInviteToContinueGame(data) {
        App.showLog("onInviteJoinRoomPush", data);
        if (data) {
            this.clock.stopClock()
            App.loadGamePopul({
                prefabName: "mahjongInviteToRoom",
                prefabPath: "prefab",
                prefabComponent: "mahjongInviteToRoom",
                data: data
            })
        }
    }

    onGetPlayerData(data, chairId) {
        for (let i = 0; i < data.length; i++) {
            const element = data[i];
            if (element.chairId == chairId) {
                return element;
            }
        }
        return null;
    }

    onDestroy() {
        AppEmitter.off(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame);
    }

}
