import App from "../../../../script/model/App";
import AppEmitter from "../../../../script/network/AppEmitter";
import { MAHJONG_CONST, MAHJONG_PLAYER_OPERATION } from "../model/mahjongEnum";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongOperation extends cc.Component {

    @property([cc.Node])
    button_operations: cc.Node[] = [];

    setButtonData(operatorType) {
        this.button_operations[4].active = true;
        if (operatorType === MAHJONG_PLAYER_OPERATION.eatCard) {
            this.button_operations[0].active = true;
        } else if (operatorType === MAHJONG_PLAYER_OPERATION.pengCard) {
            this.button_operations[1].active = true;
        } else if (operatorType === MAHJONG_PLAYER_OPERATION.mingGangCard ||
            operatorType === MAHJONG_PLAYER_OPERATION.anGangCard ||
            operatorType === MAHJONG_PLAYER_OPERATION.pongKongCard) {
            this.button_operations[2].active = true;
        } else if (operatorType === MAHJONG_PLAYER_OPERATION.huCard ||
            operatorType === MAHJONG_PLAYER_OPERATION.ziMo ||
            operatorType === MAHJONG_PLAYER_OPERATION.flowerWin ||
            operatorType === MAHJONG_PLAYER_OPERATION.robFlowerWin ||
            operatorType === MAHJONG_PLAYER_OPERATION.robKongHu) {
            this.button_operations[3].active = true;
        } else if (operatorType === MAHJONG_PLAYER_OPERATION.readyHand) {
            this.button_operations[5].active = true;
        }
    }

    onClickOperation(event, evl) {
        const clickType = +evl;
        AppEmitter.emit(MAHJONG_CONST.MAHJONG_LOCAL_OPERATOR, clickType);
    }

    onDisable() {
        this.button_operations.forEach((button) => {
            button.active = false;
        })
    }

}
