

import PlayerMgr from "../../../../script/model/PlayerMgr";
import { Utils } from "../../../../script/model/Utils";
import { PLAYER_DISSOLVE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import mahjongApplyItem from "./item/mahjongApplyItem";
import MahjongView from "./mahjongView";
import mahjongApplyClock from "./mghjongApplyClock";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongDissolutionRoomNode extends cc.Component {

    @property({
        tooltip: "申请玩家名称",
        type: cc.Label
    })
    applyNameLabel: cc.Label = null;

    @property({
        tooltip: '申请所有玩家节点',
        type: cc.Node
    })
    applyLayout: cc.Node = null;

    @property({
        tooltip: "倒计时",
        type: mahjongApplyClock
    })
    dissoluteClock: mahjongApplyClock = null;

    @property({
        tooltip: "申请玩家item",
        type: cc.Prefab
    })
    dissoluteItem: cc.Prefab = null;

    @property({
        tooltip: "",
        type: cc.Node
    })
    opreateBtns: cc.Node[] = [];

    @property({
        tooltip: "自己操作结果",
        type: cc.Label
    })
    selfSelectLabel: cc.Label = null;

    @property({
        tooltip: "自己操作节点",
        type: cc.Node
    })
    selfSelectNode: cc.Node = null;

    gameView: MahjongView = null;
    gameProxy: MahjongProxy = null;
    gameModel: MahjongModel = MahjongModel.getInstance();
    opreateLabel: string[] = ['拒絕', "同意"];
    opreateLabelColor = [[212, 30, 30], [44, 186, 32]];

    /**
     * 初始化数据
     * @param data 
     */
    init(data) {
        this.gameView = data.gameView;
        this.gameProxy = data.gameProxy;
        let dissoulteInfo: MahjongServerToClient.onVoteDisbandStartPush = data.dissoulteInfo;
        const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
        if (tipView) {
            tipView.destroy();
        }
        //显示当前解散的玩家信息
        this.applyLayout.removeAllChildren();
        let persons = this.gameModel.playersInfo;
        persons.forEach(element => {
            let item = cc.instantiate(this.dissoluteItem);
            this.applyLayout.addChild(item);
            item.getComponent(mahjongApplyItem).init(element);
            if (element.playerId == dissoulteInfo.playerId) {
                item.getComponent(mahjongApplyItem).refreshStatus(this.opreateLabel[PLAYER_DISSOLVE.AGREE], this.opreateLabelColor[PLAYER_DISSOLVE.AGREE]);
                //显示申请的玩家姓名
                this.applyNameLabel.string = Utils.tailoringNickName(element.nickname);
                if (element.chairId == this.gameModel.selfChairId) {
                    this.setSelfOprete(PLAYER_DISSOLVE.AGREE);
                }
            }
        })

        //倒计时
        if (dissoulteInfo.delayRemain) {
            this.dissoluteClock.startClock(dissoulteInfo.delayRemain, dissoulteInfo.delayTime);
        } else {
            this.dissoluteClock.startClock(dissoulteInfo.delayTime);
        }
    }

    /**
     * 操作按钮的点击
     * @param event 
     * @param data 
     */
    opreateBtnClicked(event: cc.Event, data: string) {
        this.gameProxy.sendSureEndGameVote({ vote: parseInt(data) });
    }

    /**
     * 设置自己的操作
     * @param type 
     */
    setSelfOprete(type: number) {
        this.selfSelectNode.active = true;
        this.opreateBtns.forEach((item) => {
            item.active = false;
        })
        this.selfSelectLabel.string = this.opreateLabel[type];
        this.selfSelectLabel.node.color = new cc.Color(...this.opreateLabelColor[type]);
    }

    /**
     * 刷新玩家操作结果
     */
    refreshPlayerOpreate(data: MahjongServerToClient.onVotePlayerActionPush) {
        let agreePlayerIds = data.agreePlayerIds;
        let refusePlayerIds = data.refusePlayerIds;
        this.gameModel.refusePlayer = agreePlayerIds;

        let refreshList = (playersArr, actionType) => {
            this.applyLayout.children.forEach((item) => {
                let itemComponent = item.getComponent(mahjongApplyItem);
                playersArr.forEach((playerId) => {
                    if (itemComponent && itemComponent.personInfo.playerId == playerId) {
                        itemComponent.refreshStatus(this.opreateLabel[actionType], this.opreateLabelColor[actionType]);
                        if (playerId == PlayerMgr.getInstance().uid) {
                            this.setSelfOprete(actionType);
                        }
                    }
                });
            });
        }
        //刷新同意列表
        refreshList(agreePlayerIds, 1);
        //刷新拒绝列表
        refreshList(refusePlayerIds, 0);
    }

}
