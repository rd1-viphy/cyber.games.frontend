import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../script/model/Utils";
import mahjongApplyClock from "./mghjongApplyClock";
import MahjongRoomScene from "./room/mahjongRoomScene";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongContinueRoom extends cc.Component {

    @property({
        tooltip: "玩家金幣",
        type: cc.Label
    })
    coinLabel: cc.Label = null;

    @property({
        tooltip: "花費金幣",
        type: cc.Label
    })
    costNum: cc.Label = null;

    @property({
        tooltip: "好运币",
        type: cc.Label
    })
    lbWangPaiCost: cc.Label = null;

    @property({
        tooltip: "金币",
        type: cc.Node
    })
    nodeLaoZiCost: cc.Node = null;

    @property({
        tooltip: "倒计时",
        type: mahjongApplyClock
    })
    clock: mahjongApplyClock = null;

    @property({
        tooltip: "免费提示语",
        type: cc.Label
    })
    lbFreeCreate: cc.Label = null;

    @property({
        tooltip: "正常创建节点",
        type: cc.Node
    })
    normalCreate: cc.Node = null;

    renewData = null;

    init(data) {
        this.renewData = data;
        let createMoney = data.costMoney;
        let waitTime = data.waitTime;

        this.nodeLaoZiCost.active = true;
        this.lbWangPaiCost.node.active = false;
        this.costNum.string = createMoney.toString();


        if (waitTime) {
            this.clock.startClock(waitTime, waitTime, () => {
                this.node.destroy();
            })
        }
        this.coinLabel.node.parent.active = App.currentScene == consts.MAHJONG_SCENE;

        //显示自己金币
        PlayerMgr.getInstance().getPlayerMoney((data) => {
            if (data.money) {
                PlayerMgr.getInstance().money = data.money;
                PlayerMgr.getInstance().showSelfMoneyLabel(this.coinLabel);
            }
        })

        if (MahjongRoomMgr.getInstance().isFreeTable && MahjongRoomMgr.getInstance().getIsIncludeActivities(MahjongRoomMgr.getInstance().startTime, MahjongRoomMgr.getInstance().endTime)) {
            this.normalCreate.active = false;
            this.coinLabel.node.parent.active = false;
            this.lbFreeCreate.node.active = true;
        } else {
            this.normalCreate.active = true;
            this.coinLabel.node.parent.active = true;
            this.lbFreeCreate.node.active = false;
        }
    }

    /**
     * 按鈕的點擊
     * @param event 
     * @param data 
     */
    btnClicked(event: cc.Event, data: string) {
        switch (data) {
            case "cancle":
                const result = cc.find('Canvas').getChildByName("smallResultView");
                if (result) {
                    this.node.destroy();
                } else {
                    MahjongRoomMgr.getInstance().renewRoom({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.renewData.roomId,
                        step: 2,
                        confirmRes: 1
                    }, () => {
                        this.node.destroy();
                    }, () => {
                        this.node.destroy();
                    });
                }
                break;
            case 'confirm':
                if (PlayerMgr.getInstance().money >= this.renewData.costMoney) {
                    MahjongRoomMgr.getInstance().renewRoom({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.renewData.roomId,
                        step: 2,
                        confirmRes: 2
                    }, () => {
                        PlayerMgr.getInstance().money -= this.renewData.costMoney;
                        let mahjongRoom = cc.find("Canvas");
                        if (mahjongRoom && mahjongRoom.getComponent(MahjongRoomScene)) {
                            mahjongRoom.getComponent(MahjongRoomScene).refreshMoneyLabel();
                        }
                        App.refreshPlatformScore();
                        this.node.destroy();
                    }, () => {
                        App.showToast("935");
                        this.node.destroy();
                    });
                } else {
                    Utils.showSDKOpenBroken();
                }
                break;
        }
    }

}
