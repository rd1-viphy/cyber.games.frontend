import { platform_game_id, platform_game_name } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import consts = require("../../../../script/model/Consts");


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongGuideTeachView extends cc.Component {

    @property({
        tooltip: "视频默认图片",
        type: cc.Sprite
    })
    videoSprite: cc.Sprite = null;

    @property({
        tooltip: "视频默认图片集",
        type: cc.SpriteFrame
    })
    videoSpriteFrames: cc.SpriteFrame[] = [];

    currectSelect: number = 1;

    onLoad() {
        cc.sys.localStorage.setItem("mahjongLookTeachView", true);
    }

    toggleCliecked(event, data: string) {
        this.currectSelect = parseInt(data);
        this.refreshVideoSprite();
    }

    refreshVideoSprite() {
        this.videoSprite.spriteFrame = this.videoSpriteFrames[this.currectSelect - 1];
    }

    playBtnClicked() {
        AudioMgr.pauseAll();
        App.isPlayVideo = true;
        //原生端打开webView
        if (cc.sys.isNative) {
            const url = consts.videoWebAdress + "?gameId=mahjong_table&videoId=" + this.currectSelect + "&volume=" + AudioMgr.bgmVolume;
            App.loadGamePopul({
                prefabName: "mahjongWebView",
                prefabPath: "prefab",
                notAction: true,
                prefabComponent: "mahjongWebView",
                data: {
                    url: url
                }
            })
        } else {
            let locationUrl = window.document.location.href.toString().split("?")[0];
            if (locationUrl.charAt(locationUrl.length - 1) != "/") {
                locationUrl += "/";
            }
            const videoUrl = locationUrl + "videoremote/" + platform_game_name.Mahjong + "/" + platform_game_name.Mahjong + "_video" + this.currectSelect + ".mp4";
            App.loadPopalPanel({ prefabName: "gameVideoPlayerView", opts: { data: { url: videoUrl } } });
        }
    }

}
