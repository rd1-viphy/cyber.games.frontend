import AgoraSwitchNode from "../../../../script/agora/AgoraSwitchNode";
import App from "../../../../script/model/App";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import { Utils } from "../../../../script/model/Utils";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import mahjongPrepsItem from "./item/mahjongPrepsItem";
import MahjongView from "./mahjongView";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPlayerInfo extends cc.Component {

    @property({
        tooltip: "金币",
        type: cc.Label
    })
    coinLabel: cc.Label = null;

    @property({
        tooltip: "昵称",
        type: cc.Label
    })
    nickName: cc.Label = null;

    @property({
        tooltip: "头像",
        type: cc.Node
    })
    photo: cc.Node = null;

    @property({
        tooltip: "道具的layout",
        type: cc.Node
    })
    expressLayout: cc.Node = null;

    @property({
        tooltip: "道具的item",
        type: cc.Prefab
    })
    expressItem: cc.Prefab = null;

    @property({
        tooltip: "移除按钮",
        type: cc.Node
    })
    removeBtn: cc.Node = null;

    @property({
        tooltip: "声网开关节点",
        type: AgoraSwitchNode
    })
    agoraSwitchNode: AgoraSwitchNode = null;

    playerMgr: PlayerMgr = PlayerMgr.getInstance();
    gameView: MahjongView = null;
    gameProxy: MahjongProxy = null;
    gameModel: MahjongModel = MahjongModel.getInstance();
    userInfo: MahjongCommon.PlayerInfo = null;

    init(data) {
        this.gameProxy = data.gameProxy;
        this.gameView = data.gameView;
        this.userInfo = data.userInfo;
        //显示移除按钮
        this.removeBtn.active = this.gameModel.masterUid == this.playerMgr.uid && !this.gameModel.isGameStart && this.userInfo.playerId != this.playerMgr.uid;
        //显示自己金币
        Utils.moneyMaxProcess(this.playerMgr.money, this.coinLabel)
        //显示玩家信息
        let userInfo: MahjongCommon.PlayerInfo = data.userInfo;
        Utils.setRemoteSpriteFrame(this.photo, userInfo.avatar);
        this.nickName.string = Utils.tailoringNickName(userInfo.nickname);
        //根据配置显示表情
        let config = this.gameModel.roomConfig.emotions;
        let size = config.length / 2;
        this.expressLayout.removeAllChildren();
        for (let i = 0; i < size; i++) {
            let item = cc.instantiate(this.expressItem);
            this.expressLayout.addChild(item);
            item.getComponent(mahjongPrepsItem).init(config[2 * i], config[2 * i + 1], userInfo.chairId, this.gameProxy, userInfo.playerId);
        }
        //刷新开关
        if (this.agoraSwitchNode && this.gameView.agoraClient) {
            if (!this.gameModel.getIsWatchTheBattle()) {
                this.agoraSwitchNode.node.active = true;
                this.agoraSwitchNode.init(this.gameView.agoraClient, this.userInfo.playerId);
            } else {
                this.agoraSwitchNode.node.active = false;
            }
        } else {
            this.agoraSwitchNode.node.active = false;
        }
    }

    /**
     * 踢出按钮的点击
     */
    kickOutClicked() {
        this.gameProxy.sendPlayerKick({ playerId: this.userInfo.playerId }, () => {
            App.showToast("mahjong_kick_hint", 1);
            this.node.destroy();
        })
    }

}
