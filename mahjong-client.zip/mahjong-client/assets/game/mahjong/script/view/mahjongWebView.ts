import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongWebView extends cc.Component {

    @property({
        tooltip: "webview",
        type: cc.WebView
    })
    webview: cc.WebView = null;

    init(data) {
        var scheme = "testkey";
        let jsCallback = (target, url) => {
            // 这里的返回值是内部页面的 URL 数值，需要自行解析自己需要的数据。
            AudioMgr.resumeAll();
            App.isPlayVideo = false;
            this.node.destroy();
            cc.log("call  back    ===" + JSON.stringify(target));
        }
        this.webview.setJavascriptInterfaceScheme(scheme);
        this.webview.setOnJSCallback(jsCallback);
        let url: string = data.url;
        this.webview.url = url;
    }

}
