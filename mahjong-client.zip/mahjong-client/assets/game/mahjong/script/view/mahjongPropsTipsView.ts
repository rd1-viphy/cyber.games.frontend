
import consts = require("../../../../script/model/Consts");
import { Utils } from "../../../../script/model/Utils";


const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPropsTipsView extends cc.Component {

    // @property(cc.Label)
    // contentLabel: cc.Label = null;

    @property(cc.Node)
    okBtn: cc.Node = null;

    @property(cc.Node)
    confirmBtn: cc.Node = null;

    @property(cc.Node)
    concleBtn: cc.Node = null;

    @property(cc.Label)
    confirmLabel: cc.Label = null;

    @property(cc.Label)
    cancleLabel: cc.Label = null;

    @property({
        tooltip: "金幣節點",
        type: cc.Label
    })
    lbLaoZiCost: cc.Label = null;

    @property({
        tooltip: "好运金幣節點",
        type: cc.Label
    })
    lbWangPaiCost: cc.Label = null;

    @property({
        tooltip: "不再提示",
        type: cc.Toggle
    })
    toggleHint: cc.Toggle = null;

    confirmCallback: Function = null;
    cancleCallback: Function = null;
    okCallback: Function = null;

    init(opts) {
        opts = opts || {};

        this.lbWangPaiCost.node.active = false;
        this.lbLaoZiCost.node.parent.active = true;
        this.lbLaoZiCost.string = opts.money.toString();


        if (opts["confirmLabel"]) {
            Utils.setLabelStrForLanguage(this.confirmLabel, opts["confirmLabel"]);
        }
        if (opts["cancleLabel"]) {
            Utils.setLabelStrForLanguage(this.cancleLabel, opts["cancleLabel"]);
        }

        this.confirmCallback = opts["confirmCallback"];
        this.cancleCallback = opts["cancleCallback"];
        this.okCallback = opts["okCallback"];
        this.okBtn.active = opts["okCallback"];
        this.confirmBtn.active = opts["confirmCallback"];
        this.concleBtn.active = opts["confirmCallback"];
    }

    btnClicked(event: any, data: string) {
        switch (data) {
            case "confirm":
                this.confirmCallback && this.confirmCallback();;
                break;
            case "cancle":
                this.cancleCallback && this.cancleCallback();
                break;
            case "ok":
                this.okCallback && this.okCallback();
                break;
        }
        this.node.removeFromParent();
    }

    onToggle() {
        if (this.toggleHint.isChecked) {
            cc.sys.localStorage.setItem("mahjongPropBuyHint", false);
        } else {
            cc.sys.localStorage.setItem("mahjongPropBuyHint", true);
        }
    }

}
