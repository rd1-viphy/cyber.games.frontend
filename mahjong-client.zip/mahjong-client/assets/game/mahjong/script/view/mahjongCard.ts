
const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongCard extends cc.Component {

    /** 玩家方位 */
    @property
    type = 0;

    @property([cc.Sprite])
    spCards: cc.Sprite[] = [];

    @property(cc.SpriteAtlas)
    spCardRes: cc.SpriteAtlas = null;

    private readonly handCard_path = "mj_0_";

    private readonly leftCard_path = "mj_h_l_h_";

    private readonly rightCard_path = "mj_h_r_h_";

    private readonly flowerTop_path = "mj_t_f_";

    private readonly flowerLeft_path = "mj_l_f_";

    private readonly flowerRight_path = "mj_r_f_";

    private readonly handCardBg = "mj_beimian";

    private readonly leftShowCard_path = "mj_t_r_"

    setCardNum(num) {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCard_path + num;
        } else if (this.type === 1) {
            spPath = this.rightCard_path + num;
        } else if (this.type === 3) {
            spPath = this.leftCard_path + num;
        }

        for (let i = 0; i < this.spCards.length; i++) {
            if (spPath && this.spCardRes) {
                this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
            }
        }
    }

    /**
     * 吃牌
     * @param cards 
     */
    setEatCardNum(cards) {
        let spPath = null;
        if (cards) {
            for (let i = 0; i < cards.length; i++) {
                const card = cards[i];
    
                if (this.type === 0) {
                    spPath = this.handCard_path + card;
                } else if (this.type === 1) {
                    spPath = this.rightCard_path + card;
                } else if (this.type === 3) {
                    spPath = this.leftCard_path + card;
                }
    
                if (spPath && this.spCardRes) {
                    this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
                }
            }
        }
    }

    /**
     * 花牌
     * @param card 
     */
    setFlowerCardNum(card) {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCard_path + card;
        } else if (this.type === 1) {
            spPath = this.flowerRight_path + card;
        } else if (this.type === 2) {
            spPath = this.flowerTop_path + card;
        } else if (this.type === 3) {
            spPath = this.flowerLeft_path + card;
        }

        if (spPath && this.spCardRes) {
            this.spCards[0].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
        }
    }

    /**
     * 发牌时我自己的牌背
     */
    setMySelfCardBg() {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCardBg;
        }

        for (let i = 0; i < this.spCards.length; i++) {
            if (spPath && this.spCardRes) {
                this.spCards[i].node.y = 0;
                this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
            }
        }
    }

    setAnGangCardBg() {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCardBg;
        }

        for (let i = 0; i < this.spCards.length; i++) {
            if (spPath && this.spCardRes) {
                this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
            }
        }
    }

    /**
     * 设置我自己的牌
     * @param num 
     */
    setMySelfCard(num) {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCard_path + num;
        }

        for (let i = 0; i < this.spCards.length; i++) {
            if (spPath && this.spCardRes) {
                this.spCards[i].node.y = -10;
                this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
            }
        }
    }

    /**
     * 摊牌
     * @param num 
     */
    setShowCard(num) {
        let spPath = null;
        if (this.type === 0) {
            spPath = this.handCard_path + num;
        } else if (this.type === 1) {
            spPath = this.leftShowCard_path + num;
        } else if (this.type === 3) {
            spPath = this.leftShowCard_path + num;
        }

        for (let i = 0; i < this.spCards.length; i++) {
            if (spPath && this.spCardRes) {
                if (this.type === 3) {
                    this.spCards[i].node.skewX = 28;
                }
                this.spCards[i].spriteFrame = this.spCardRes.getSpriteFrame(spPath);
            }
        }
    }

}
