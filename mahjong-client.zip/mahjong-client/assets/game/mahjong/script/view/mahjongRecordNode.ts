import MahjongModel from "../model/mahjongModel";
import mahjongRecordItem from "./item/mahjongRecordItem";
import mahjongRecordPlayerNode from "./item/mahjongRecordPlayerNode";


const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongRecordNode extends cc.Component {

    @property({
        tooltip: "玩家记录节点",
        type: cc.ScrollView
    })
    recordScrollView: cc.ScrollView = null;

    @property({
        tooltip: "记录item节点",
        type: cc.Prefab
    })
    recordItem: cc.Prefab = null;

    @property({
        tooltip: "玩家名称显示节点",
        type: cc.Node
    })
    nameNode: cc.Node[] = [];

    @property({
        tooltip: "每个玩家的总战绩节点",
        type: cc.Label
    })
    totalRecord: cc.Label[] = [];

    @property({
        tooltip: "总战绩字体集",
        type: cc.Font
    })
    recordFonts: cc.Font[] = [];

    @property({
        tooltip: "有记录的节点",
        type: cc.Node
    })
    haveRecordNode: cc.Node = null;

    @property({
        tooltip: "没有记录的节点",
        type: cc.Node
    })
    noRecordNode: cc.Node = null;

    protected curRound: number = 0;
    protected gameModel: MahjongModel = MahjongModel.getInstance();

    init(data) {
        this.curRound = 0;
        this.refreshRecordList(data);
    }

    /**
     * 刷新游戏记录
     * @param list 
     */
    refreshRecordList(data) {
        const playerDetails = data.playerDetails;
        const totalDetails = data.totalDetails;

        //显示玩家信息
        totalDetails.forEach((playerInfo) => {
            const seatId = this.gameModel.getChariIdToPlayerId(playerInfo.playerId);
            this.nameNode[seatId].getComponent(mahjongRecordPlayerNode).init(playerInfo, seatId);
            this.totalRecord[seatId].string = playerInfo.totalScore >= 0 ? "+" + playerInfo.totalScore : playerInfo.totalScore.toString();
            this.totalRecord[seatId].font = playerInfo.totalScore >= 0 ? this.recordFonts[0] : this.recordFonts[1];
        })
        this.haveRecordNode.active = playerDetails.length > 0;
        this.noRecordNode.active = playerDetails.length <= 0;

        //显示内容
        if (playerDetails.length > 0) {
            let content = this.recordScrollView.content;
            content.removeAllChildren();
            for (let i = 0; i < playerDetails.length; i++) {
                const playerData = playerDetails[i];

                if (playerData.gameRound >= this.curRound) {
                    if (playerData.gameRound > this.curRound) {
                        let recordItem = cc.instantiate(this.recordItem);
                        content.addChild(recordItem);
                        this.curRound += 1;
                    }
                    let item = content.children[playerData.gameRound - 1];
                    item.getComponent(mahjongRecordItem).initRecord(playerData, this.curRound);
                }
            }
        }
    }

}
