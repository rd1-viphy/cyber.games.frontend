
const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongApplyClock extends cc.Component {

    @property({
        tooltip: "倒计时进度图片",
        type: cc.Sprite
    })
    clockSprie: cc.Sprite = null;

    @property({
        tooltip: "倒计时文字",
        type: cc.Label
    })
    clockLabel: cc.Label = null;

    @property({
        tooltip: "倒计时进度条",
        type: cc.ProgressBar
    })
    progressBar: cc.ProgressBar = null;

    /**是否进行倒计时 */
    isPlay: boolean = false;
    /**倒计时时间 */
    clockTime: number = 0;
    /**倒计时总时间 */
    totalTime: number = 0;
    /**是否在播放5秒倒计时 */
    isFiveEffectPlaying: boolean = false;
    /**五秒提示音 */
    fiveEffectId: number = 0;
    /**五秒提示音是否播放 */
    isFivePlaying: boolean = false;

    clockColor = new cc.Color(0, 255, 0);
    /**倒計時回調 */
    endCb = null;
    /**
     * 开始倒计时
     * @param currentTime 当前时间
     * @param totalTime   总共时间
     */
    startClock(currentTime: number, totalTime: number = currentTime, cb: Function = null) {
        this.endCb = cb;
        this.node.active = true;
        this.clockTime = currentTime;
        this.totalTime = totalTime;
        this.isPlay = true;
        if (this.clockSprie) {
            this.clockSprie.node.color = new cc.Color(0, 255, 0);
            this.clockLabel.node.color = new cc.Color(0, 255, 0);
            this.clockColor = new cc.Color(0, 255, 0);
            this.schedule(this.changeProgressBar, totalTime / 200);
        }
    }

    /**
     * 停止倒计时
     */
    stopClock() {
        this.isPlay = false;
        this.node.active = false;
        if (this.clockSprie) {
            this.clockSprie.fillRange = 0;
        }
        if (this.clockLabel) {
            this.clockLabel.string = "0";
        }
        if (this.progressBar) {
            this.progressBar.progress = 0;
        }

        this.fiveEffectId = 0;
        this.isFivePlaying = false;
        this.unschedule(this.playFiveCountDownSound);
        this.unschedule(this.changeProgressBar);
    }

    /**
     * 暂停定时器
     */
    pauseClock() {
        if (this.node.active) {
            this.isPlay = false;
            //this.unschedule(this.playFiveCountDownSound);
            this.isFivePlaying = false;
        }
    }

    /**
     * 恢复定时器
     */
    resumeClock() {
        if (this.node.active) {
            this.isPlay = true;
            if (this.clockTime < 6 && !this.isFivePlaying) {
                this.isFivePlaying = true;
                //this.schedule(this.playFiveCountDownSound,1);
            }
        }
    }

    /**
     * 设置倒计时进度和文字
     */
    refreshClock() {
        let progress = this.clockTime / this.totalTime;
        if (this.clockSprie) {
            this.clockSprie.fillRange = progress;
        }
        if (this.clockLabel) {
            this.clockLabel.string = Math.ceil(this.clockTime).toString();
        }
        if (this.progressBar) {
            this.progressBar.progress = progress;
        }
    }

    update(dt: number) {
        if (this.isPlay) {
            if (this.clockTime <= 0) {
                this.stopClock();
                this.endCb && this.endCb();
                //AudioMgr.playSFX(sixCardPokerConsts.SOUND.COUNT_DOWN_END,true);
            } else {
                this.clockTime -= dt;
                this.refreshClock();
                if (this.clockTime < 6 && !this.isFivePlaying) {
                    this.isFivePlaying = true;
                    this.schedule(this.playFiveCountDownSound, 1);
                }

            }
        }
    }

    /**
     * 最后几秒倒计时
     * 
     */
    playFiveCountDownSound() {
        if (this.isPlay) {
            // AudioMgr.playSFX(sixCardPokerConsts.SOUND.COUNT_DOWN,true,false,(id:number)=>{
            //     this.fiveEffectId = id;
            // });
        }
    }

    /**
     * 颜色倒计时
     */
    changeProgressBar() {
        if (this.isPlay && this.clockSprie) {
            let color = this.clockSprie.node.color;
            if (this.clockTime / this.totalTime > 0.5) {
                let colorR = color.getR() + parseFloat((255 / 100).toString());
                if (colorR >= 0 && colorR <= 255) {
                    this.clockSprie.node.color = new cc.Color(colorR, 255, 0);
                    this.clockLabel.node.color = new cc.Color(colorR, 255, 0);
                    this.clockColor = new cc.Color(colorR, 255, 0);
                }
            } else {
                let colorG = color.getG() - parseFloat((255 / 100).toString());
                if (colorG >= 0 && colorG <= 255) {
                    this.clockSprie.node.color = new cc.Color(255, colorG, 0);
                    this.clockLabel.node.color = new cc.Color(255, colorG, 0);
                    this.clockColor = new cc.Color(255, colorG, 0);
                }
            }
        }
    }

}
