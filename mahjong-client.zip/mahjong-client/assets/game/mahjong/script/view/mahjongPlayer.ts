
import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import { Utils } from "../../../../script/model/Utils";
import { MAHJONG_CONST } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongView from "./mahjongView";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongPlayer extends cc.Component {

    @property(cc.Sprite)
    spHead: cc.Sprite = null;

    @property(cc.Label)
    lbName: cc.Label = null;

    @property(cc.Label)
    lbScore: cc.Label = null;

    @property(cc.Node)
    nodeBank: cc.Node = null;

    @property(cc.Node)
    nodeReady: cc.Node = null;

    @property(cc.Sprite)
    spEmoji: cc.Sprite = null;

    @property(cc.Label)
    lbMsg: cc.Label = null;

    @property(cc.Node)
    nodeTrust: cc.Node = null;

    @property(cc.Node)
    nodeWind: cc.Node = null;

    @property(cc.Sprite)
    spCards: cc.Sprite = null;

    @property(cc.SpriteAtlas)
    spCardRes: cc.SpriteAtlas = null;

    @property([cc.SpriteFrame])
    headSpriteFrame: cc.SpriteFrame[] = [];

    @property(cc.Node)
    nodeTing: cc.Node = null;

    @property(cc.Label)
    lbLianBank: cc.Label = null;

    @property(cc.Label)
    lbBankCount: cc.Label = null;

    @property(sp.Skeleton)
    expressionSkeloton: sp.Skeleton = null;

    @property(sp.SkeletonData)
    expressionSkelotonDatas: sp.SkeletonData[] = [];

    @property(cc.Node)
    msgNode: cc.Node = null;

    @property(cc.Label)
    msgLabel: cc.Label = null;

    @property(cc.Node)
    nodeKong: cc.Node = null;

    @property({
        tooltip: "离线节点",
        type: cc.Node
    })
    protected offLineNode: cc.Node = null;

    @property({
        tooltip: "倒計時",
        type: sp.Skeleton
    })
    spTimeDown: sp.Skeleton = null;

    @property({
        tooltip: "超時提示",
        type: cc.Node
    })
    nodeDisCardTimeOutHint: cc.Node = null;

    gameProxy: MahjongProxy = null;
    gameModel: MahjongModel = null;
    gameView: MahjongView = null;

    protected playerInfo = null;

    /**当前时间 */
    protected currentTime: number = 0;
    /** 總共時間 */
    protected totalBetTime: number = 0;
    /** 玩家操作完成回调 */
    protected actionFinishFun: Function = null;
    /** 倒计时flag */
    protected timeFlag: number = 0;

    protected windCard = ["mj_0_65", "mj_0_66", "mj_0_67", "mj_0_68"];

    init(gameProxy: MahjongProxy, gameView: MahjongView) {
        this.gameProxy = gameProxy;
        this.gameView = gameView;
        this.gameModel = MahjongModel.getInstance();
    }

    initView() {
        this.nodeBank.active = false;
        this.nodeTrust.active = false;
        this.nodeTing.active = false;
        this.lbLianBank.node.active = false;
    }

    /**
     * 玩家信息
     * @param data 
     */
    setPlayerInfo(data) {
        this.nodeKong.active = false;
        this.spHead.node.active = true;
        this.lbScore.node.parent.active = true;
        this.playerInfo = data;
        this.lbName.string = Utils.tailoringNickName(data.nickname);
        if (Math.abs(data.totalScore) > 99999) {
            this.lbScore.string = data.totalScore >= 0 ? this.gameModel.formatCoinNum(data.totalScore) : "-" + this.gameModel.formatCoinNum(Math.abs(data.totalScore));
        } else {
            this.lbScore.string = data.totalScore;
        }

        if (data.avatar) {
            Utils.setRemoteSpriteFrame(this.spHead, data.avatar);
        }
        if (data.onlineStatus && data.onlineStatus == 1) {
            this.offLineNode.active = true;
            let agoraView = this.node.getChildByName("agoraView");
            if (agoraView) {
                agoraView.active = false;
            }
        }
    }

    /**
     * 玩家是否准备
     * @param isReady 
     */
    setPlayerReady(isReady: boolean) {
        this.nodeReady.active = isReady;
    }

    /**
     * 更新玩家分数
     * @param data 
     */
    updatePlayerScore(data) {
        if (Math.abs(data) > 99999) {
            this.lbScore.string = data >= 0 ? this.gameModel.formatCoinNum(data) : "-" + this.gameModel.formatCoinNum(Math.abs(data));
        } else {
            this.lbScore.string = data;
        }
    }

    /**
     * 设置玩家在或离线
     */
    setPlayerOnLineStatue(data) {
        this.offLineNode.active = data.status == 1;
        let agoraView = this.node.getChildByName("agoraView");
        if (data.status == 1 && agoraView) {
            agoraView.active = false;
        }
    }

    /**
     * 是否庄家
     * @param isShow 
     */
    showBank(isShow: boolean) {
        this.nodeBank.active = isShow;
        this.lbLianBank.node.active = false
    }

    /**
     * 连庄
     * @param count 
     */
    showLianBank(count: number) {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_ContinuousBanker, true, true);
        this.lbLianBank.node.active = true;
        this.lbBankCount.string = "x" + count.toString();
    }

    /**
     * 是否听牌
     * @param isShow 
     */
    showTing(isShow: boolean) {
        this.nodeTing.active = isShow;
    }

    /**
     * 展示风位
     * @param wind 
     */
    showPlayerWind(wind: number) {
        this.nodeWind.active = true;
        this.spCards.spriteFrame = this.spCardRes.getSpriteFrame(this.windCard[wind - 1]);
        this.scheduleOnce(() => {
            this.nodeWind.active = false;
        }, 5.0)
    }

    /**
     * 起立观战
     */
    onStandUp() {
        this.spHead.node.active = false;
        this.lbName.string = "";
        this.lbScore.node.parent.active = false;
        this.nodeReady.active = false;
        this.playerInfo = null;
        this.nodeKong.active = true;
    }

    /**
     * 显示玩家表情
     */
    setPlayerExpreesion(content: number) {
        const expressionId = content - 200;
        this.expressionSkeloton.node.active = true;
        this.expressionSkeloton.skeletonData = this.expressionSkelotonDatas[expressionId];
        this.expressionSkeloton.setAnimation(0, MAHJONG_CONST.expressName[expressionId], false);
        AudioMgr.playSFX("sound_express_" + MAHJONG_CONST.expreseeSoundNames[expressionId], true, true);
        this.expressionSkeloton.setCompleteListener(() => {
            this.expressionSkeloton.node.active = false;
        });
    }

    /**
     * 显示玩家发送文字
     */
    setPlayerMsg(content: number) {
        this.msgNode.active = true;

        this.msgLabel.string = MAHJONG_CONST.msgLabels[content - 100];
        this.msgLabel.fontSize = 28;


        this.msgNode.stopAllActions();
        cc.tween(this.msgNode)
            .delay(2)
            .call(() => {
                this.msgNode.active = false;
            })
            .start();
    }

    onTouchHead() {
        if (this.playerInfo) {
            App.loadGamePopul({
                prefabName: "mahjongPlayerInfoNode",
                prefabPath: "prefab",
                prefabComponent: "mahjongPlayerInfo",
                data: {
                    gameProxy: this.gameProxy,
                    gameView: this.gameView,
                    userInfo: this.playerInfo
                }
            })
        }
    }

    startOperationDown(time) {
        this.spTimeDown.node.active = true;
        if (time > 0) {
            this.currentTime = time;
        }
    }

    closeCountDown() {
        this.spTimeDown.node.active = false;
        this.currentTime = 0;
        // this.spTimeDown.fillRange = 0;
    }

    /** 设定倒计时颜色 */
    // setCountDownSpriteColor() {
    //     let fill = this.spTimeDown.fillRange;
    //     if (fill > 0.6) {
    //         this.spTimeDown.node.color = cc.color(152, 246, 68);
    //     } else if (fill > 0.5) {
    //         this.spTimeDown.node.color = cc.color(160, 212, 113);
    //     } else if (fill > 0.4) {
    //         this.spTimeDown.node.color = cc.color(255, 242, 70);
    //     } else if (fill > 0.3) {
    //         this.spTimeDown.node.color = cc.color(255, 200, 60);
    //     } else if (fill > 0.2) {
    //         this.spTimeDown.node.color = cc.color(255, 190, 49);
    //     } else if (fill > 0.1) {
    //         this.spTimeDown.node.color = cc.color(255, 40, 49);
    //     } else {
    //         this.spTimeDown.node.color = cc.color(255, 40, 40);
    //     }
    // }

    /**
     * 完成倒计时
     */
    finishCountDown(isCallFun: boolean) {
        if (isCallFun) {
            if (this.actionFinishFun) {
                this.actionFinishFun();
            }
        }
    }

    update(dt) {
        if (this.currentTime <= 0) { return }
        this.timeFlag += dt;
        if (this.timeFlag >= 1) {
            this.currentTime--;
            this.timeFlag = 0;
            if (this.currentTime == 2 && this.playerInfo.playerId == PlayerMgr.getInstance().uid && this.gameModel.isDisCard) {
                this.nodeDisCardTimeOutHint.active = true;
                this.scheduleOnce(() => {
                    this.nodeDisCardTimeOutHint.active = false;
                }, 2.0)
            }
        }
    }



}
