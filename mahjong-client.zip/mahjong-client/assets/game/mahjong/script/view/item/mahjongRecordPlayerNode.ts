import { Utils } from "../../../../../script/model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongRecordPlayerNode extends cc.Component {

    @property({
        tooltip: "昵称",
        type: cc.Label,
    })
    nickNameLabel: cc.Label = null;

    @property({
        tooltip: "空位",
        type: cc.Node,
    })
    emptyNode: cc.Node = null;

    @property({
        tooltip: "座位相对位置",
        type: cc.Sprite,
    })
    position: cc.Sprite = null;

    @property({
        tooltip: "座位相对位置的纹理集",
        type: cc.SpriteFrame,
    })
    positionSpriteFrames: cc.SpriteFrame[] = [];

    init(data, seatId) {
        //隐藏空位
        this.emptyNode.active = false;
        //显示昵称
        this.nickNameLabel.node.active = true;
        this.nickNameLabel.string = Utils.tailoringNickName(data.nickname);
        //显示位置(计算位置)
        this.position.node.active = true;
        this.position.spriteFrame = this.positionSpriteFrames[seatId];
    }

}
