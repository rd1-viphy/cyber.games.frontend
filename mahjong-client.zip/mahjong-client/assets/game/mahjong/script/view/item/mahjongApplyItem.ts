import { Utils } from "../../../../../script/model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongApplyItem extends cc.Component {

    @property({
        tooltip: "头像",
        type: cc.Node
    })
    photo: cc.Node = null;

    @property({
        tooltip: "昵称",
        type: cc.Label
    })
    nickName: cc.Label = null;

    @property({
        tooltip: "状态",
        type: cc.Label
    })
    statusLabel: cc.Label = null;

    personInfo: MahjongCommon.PlayerInfo = null;

    init(personInfo: MahjongCommon.PlayerInfo) {
        this.personInfo = personInfo;
        this.nickName.string = Utils.tailoringNickName(personInfo.nickname);
        Utils.setRemoteSpriteFrame(this.photo, personInfo.avatar);
    }

    /**
     * 刷新状态
     * @param typeStr 
     * @param color 
     */
    refreshStatus(typeStr: string, color: number[]) {
        this.statusLabel.string = typeStr;
        this.statusLabel.node.color = new cc.Color(...color);
    }

}
