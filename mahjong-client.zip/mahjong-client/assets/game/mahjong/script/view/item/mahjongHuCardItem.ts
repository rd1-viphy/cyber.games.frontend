

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongHuCardItem extends cc.Component {

    @property({
        tooltip: "台数",
        type: cc.Label
    })
    lbUnits: cc.Label = null;

    @property({
        tooltip: "剩余张数",
        type: cc.Label
    })
    lbSheets: cc.Label = null;

    @property({
        tooltip: "没有这张牌遮罩",
        type: cc.Node
    })
    spMask: cc.Node = null;

    initItem(data) {
        this.lbUnits.string = data.point;
        this.lbSheets.string = data.count;
        if (data.count == 0) {
            this.spMask.active = true;
        } else {
            this.spMask.active = false;
        }
    }

}
