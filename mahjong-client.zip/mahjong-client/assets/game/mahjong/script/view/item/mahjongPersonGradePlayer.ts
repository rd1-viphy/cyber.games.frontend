
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import { Utils } from "../../../../../script/model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPersonGradePlayer extends cc.Component {

    @property({
        tooltip: "字体",
        type: cc.Font
    })
    fonts: cc.Font[] = [];

    @property({
        tooltip: "昵称",
        type: cc.Label
    })
    nameLabel: cc.Label = null;

    @property({
        tooltip: "空位",
        type: cc.Node
    })
    empty: cc.Node = null;

    @property({
        tooltip: "战绩",
        type: cc.Label
    })
    gradeLabel: cc.Label = null;

    init(data) {
        this.empty.active = false;
        this.nameLabel.node.active = true;
        this.nameLabel.string = Utils.tailoringNickName(data.nickname);
        this.nameLabel.node.color = data.playerId == PlayerMgr.getInstance().uid ? new cc.Color(255, 241, 83) : new cc.Color(255, 255, 255);
        this.gradeLabel.string = data.totalScore > 0 ? "+" + data.totalScore : "" + data.totalScore;
        this.gradeLabel.font = data.totalScore >= 0 ? this.fonts[0] : this.fonts[1];
        // gradeLabel.node.color = data.score >= 0 ? new cc.Color(96, 220, 28) : new cc.Color(249, 0, 0);
    }

}
