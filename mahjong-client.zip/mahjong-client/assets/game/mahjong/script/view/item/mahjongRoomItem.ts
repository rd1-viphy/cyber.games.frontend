
import consts = require("../../../../../script/model/Consts");
import { Utils } from "../../../../../script/model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongRoomItem extends cc.Component {

    @property(cc.Node)
    nodeRoomType: cc.Node = null;               //房间类型

    @property(cc.Node)
    nodeRoomSign: cc.Node = null;               //房间标志

    @property(cc.Label)
    lbToplimit: cc.Label = null;                //房间上限

    @property(cc.Label)
    lbLowlimit: cc.Label = null;                //携带金币下限

    @property(cc.Label)
    lbVIPlimit: cc.Label = null;                //VIP等级限制

    @property(cc.Label)
    lbRoomRate: cc.Label = null;                //房间赔率

    @property(cc.Label)
    lbCaiJin: cc.Label = null;                  //彩金数量

    @property(cc.Label)
    lbService: cc.Label = null;                 //服务费

    @property([cc.SpriteFrame])
    bgSpriteFrames: cc.SpriteFrame[] = [];      //房间类型背景图

    @property([cc.SpriteFrame])
    spJackPot: cc.SpriteFrame[] = [];           //JackPot背景图

    @property([cc.SpriteFrame])
    spRateBg: cc.SpriteFrame[] = [];            //房间赔率背景图

    private roomId: number = 0;

    private enterLimit: number = 0;

    init(data: any) {
        this.roomId = data.Id;
        let roomTitle = "room_0";
        Utils.setSpriteStrForLanguage(this.nodeRoomType, roomTitle + this.roomId);

        this.lbLowlimit.string = `${data.EnterLimit}`;
        this.lbRoomRate.string = "1:" + data.CoinRate;

        if (this.roomId == 1) {
            this.lbCaiJin.node.parent.active = false;
        } else {
            //this.lbCaiJin.string = data.JackpotAmount.toFixed(2);
        }

        this.lbService.string = `${data.CoinRate}%`;
        this.node.getComponent(cc.Sprite).spriteFrame = this.bgSpriteFrames[this.roomId - 1];

        let spJackPot = this.node.getChildByName("spJackPot").getComponent(cc.Sprite);
        spJackPot.spriteFrame = this.spJackPot[this.roomId - 1];

        let spRateBg = this.node.getChildByName("rateBg").getComponent(cc.Sprite);
        spRateBg.spriteFrame = this.spRateBg[this.roomId - 1];

        let roomSignIndex = cc.sys.localStorage.getItem("mahjongRoomType");
        if (data.RoomMark > 0 || roomSignIndex) {
            if (roomSignIndex == this.roomId) {
                Utils.setSpriteStrForLanguage(this.nodeRoomSign, "room_sign" + 6);
            } else {
                this.nodeRoomSign.active = true;
                Utils.setSpriteStrForLanguage(this.nodeRoomSign, "room_sign" + data.RoomMark);
            }
        } else {
            this.nodeRoomSign.active = false;
        }

        this.node.active = true;
    }

}
