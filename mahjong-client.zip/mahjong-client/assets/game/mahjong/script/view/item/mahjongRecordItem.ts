import MahjongModel from "../../model/mahjongModel";

const {ccclass, property} = cc._decorator;

@ccclass
export default class mahjongRecordItem extends cc.Component {

    @property({
        tooltip: '每局的记录',
        type: cc.Label
    })
    recordLabel: cc.Label[] = [];

    @property({
        tooltip: '序号',
        type: cc.Label
    })
    recordOrder: cc.Label = null;

    @property({
        tooltip: '背景',
        type: cc.SpriteFrame
    })
    bgSpriteFrame: cc.SpriteFrame[] = [];

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    /**
     * 初始游戏记录内容
     * @param data 
     * @param index 
     */
    initRecord(data, index: number) {
        this.recordOrder.string = index.toString();
        const seatId = this.gameModel.getChariIdToPlayerId(data.playerId);
        this.recordLabel[seatId].string = data.winScore > 0 ? "+" + data.winScore : data.winScore.toString();
        if (this.bgSpriteFrame[index % 2]) {
            this.node.getComponent(cc.Sprite).spriteFrame = this.bgSpriteFrame[index % 2];
        }
    }

    /**
     * 显示战绩详情的数据
     * @param data 
     */
    initPersonGrade(data: MahjongCommon.RoundData) {
        this.recordOrder.string = (data.roundLimit).toString();
        data.chairData.forEach((element, index) => {
            let gradeNum = element.score;
            this.recordLabel[index].string = gradeNum > 0 ? "+" + gradeNum : gradeNum.toString();
        });
        this.node.getComponent(cc.Sprite).spriteFrame = this.bgSpriteFrame[(data.roundLimit - 1) % 2];
    }

}
