import PlayerMgr from "../../../../../script/model/PlayerMgr";
import { Utils } from "../../../../../script/model/Utils";
import MahjongModel from "../../model/mahjongModel";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongTotalResultItem extends cc.Component {

    @property({
        tooltip: "玩家头像",
        type: cc.Sprite
    })
    spHead: cc.Sprite = null;

    @property({
        tooltip: "玩家名字",
        type: cc.Label
    })
    lbName: cc.Label = null;

    @property({
        tooltip: "玩家位置",
        type: cc.Sprite
    })
    spPlayerPos: cc.Sprite = null;

    @property({
        tooltip: "位置Frame",
        type: [cc.SpriteFrame]
    })
    spPosFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "自摸次数",
        type: cc.Label
    })
    lbZiMoCount: cc.Label = null;

    @property({
        tooltip: "胡牌次数",
        type: cc.Label
    })
    lbHuCount: cc.Label = null;

    @property({
        tooltip: "放炮次数",
        type: cc.Label
    })
    lbFangPaoCount: cc.Label = null;

    @property({
        tooltip: "房主",
        type: sp.Skeleton
    })
    spBank: sp.Skeleton = null;

    @property({
        tooltip: "赢了多少分",
        type: cc.Label
    })
    lbWinScore: cc.Label = null;

    @property({
        tooltip: "输了多少分",
        type: cc.Label
    })
    lbLoseScore: cc.Label = null;

    @property({
        tooltip: "单个玩家背景图",
        type: cc.Sprite
    })
    spResultItemBg: cc.Sprite = null;

    @property({
        tooltip: "玩家背景Frame",
        type: cc.SpriteFrame
    })
    spResultItemFrame: cc.SpriteFrame[] = [];

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    protected curItemChairId: number = 0;

    initItem(data) {
        this.lbName.string = Utils.tailoringNickName(data.nickname);
        Utils.setRemoteSpriteFrame(this.spHead, data.avatar);
        this.lbZiMoCount.string = data.selfDrawNum;
        this.lbHuCount.string = data.winNum;
        this.lbFangPaoCount.string = data.shotNum;

        if (data.totalScore >= 0) {
            this.lbLoseScore.node.active = false;
            this.lbWinScore.node.active = true;
            this.lbWinScore.string = data.totalScore;
        } else {
            this.lbWinScore.node.active = false;
            this.lbLoseScore.node.active = true;
            this.lbLoseScore.string = data.totalScore;
        }

        if (data.totalScore > 0 && this.gameModel.selfChairId != -1) {
            this.spResultItemBg.spriteFrame = this.spResultItemFrame[0];
        } else {
            this.spResultItemBg.spriteFrame = this.spResultItemFrame[1];
        }

        if (this.gameModel.masterUid == data.playerId) {
            this.spBank.node.active = true;
        } else {
            this.spBank.node.active = false;
        }

        if (this.gameModel.selfChairId != -1) {
            this.spPlayerPos.node.active = true;
            if (data.playerId == PlayerMgr.getInstance().uid) {
                this.spPlayerPos.spriteFrame = this.spPosFrame[0];
                this.lbName.node.color = new cc.Color(255, 255, 0);
            } else {
                this.gameModel.playersInfo.forEach((player) => {
                    if (player.playerId == data.playerId) {
                        this.curItemChairId = this.gameModel.changSeatId(player.chairId);
                    }
                })
                if (this.curItemChairId == 1) {
                    this.spPlayerPos.spriteFrame = this.spPosFrame[3];
                } else if (this.curItemChairId == 2) {
                    this.spPlayerPos.spriteFrame = this.spPosFrame[1];
                } else if (this.curItemChairId == 3) {
                    this.spPlayerPos.spriteFrame = this.spPosFrame[2];
                }
            }
        } else {
            this.spPlayerPos.node.active = false;
        }
    }

}
