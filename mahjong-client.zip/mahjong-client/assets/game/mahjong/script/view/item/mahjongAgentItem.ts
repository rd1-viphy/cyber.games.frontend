import { GAME_PRESERVE, platform_game_id } from "../../../../../script/common/ClientEnum";
import App from "../../../../../script/model/App";
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";
import { InputType, MAHJONG_CONST } from "../../model/mahjongEnum";
import MahjongRoomScene from "../room/mahjongRoomScene";


const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongAgentItem extends cc.Component {

    @property({
        tooltip: "房间名称",
        type: cc.Label
    })
    roomNameLabel: cc.Label = null;

    @property({
        tooltip: "房号",
        type: cc.Label
    })
    roomNumberLabel: cc.Label = null;

    @property({
        tooltip: "局数",
        type: cc.Label
    })
    inningsLabel: cc.Label = null;

    @property({
        tooltip: "底注",
        type: cc.Label
    })
    anteLabel: cc.Label = null;

    @property({
        tooltip: "人数",
        type: cc.Label
    })
    personNumLabel: cc.Label = null;

    @property({
        tooltip: "房间类型",
        type: cc.Sprite
    })
    spRoomType: cc.Sprite = null;

    @property({
        tooltip: "房间类型Frame",
        type: cc.SpriteFrame
    })
    spRoomTypeFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "房间类型背景",
        type: cc.Sprite
    })
    spRoomTypeBg: cc.Sprite = null;

    @property({
        tooltip: "房间类型背景Frame",
        type: cc.SpriteFrame
    })
    spRoomTypeBgFrame: cc.SpriteFrame[] = [];

    agantData: MahjongCommon.AgentRoomInfo = null;

    init(data: MahjongCommon.AgentRoomInfo) {
        this.agantData = data;
        this.roomNameLabel.string = data.roomName.substring(0, 8);
        this.roomNumberLabel.string = data.roomId.toString();
        this.inningsLabel.string = data.roundNum + "/" + data.maxRoundNum;
        this.anteLabel.string = data.baseScore + "/" + data.fanPoint;
        this.personNumLabel.string = data.playerNum + "/" + data.maxPlayerNum;
        if (data.createType == 3) {
            if (data.gameStatus >= 2) {
                this.spRoomType.spriteFrame = this.spRoomTypeFrame[1];
                this.spRoomTypeBg.spriteFrame = this.spRoomTypeBgFrame[0];
            } else {
                this.spRoomType.spriteFrame = this.spRoomTypeFrame[0];
                this.spRoomTypeBg.spriteFrame = this.spRoomTypeBgFrame[0];
            }
        } else if (data.createType == 2) {
            this.spRoomType.spriteFrame = this.spRoomTypeFrame[2];
            this.spRoomTypeBg.spriteFrame = this.spRoomTypeBgFrame[1];
        } 
    }

    /**
     * 加入代开房
     */
    joinClicked() {
        if (App.globalStatus == GAME_PRESERVE.LIMIT) {
            App.showToast("globaling");
            return;
        }
        let joinData = { gameId: platform_game_id.mahjong_table, roomId: this.agantData.roomId, password: "", step: 1 };
        MahjongRoomMgr.getInstance().joinMahjongTable(joinData, (data: MahjongServerToClient.JoinRoom) => {
            if (data.hasPassword) {
                App.loadGamePopul({ 
                    prefabName: "mahjongJoinRoom", 
                    prefabPath: "prefab", 
                    prefabComponent: "mahjongJoinRoom", 
                    data: {
                        inputType: InputType.password,
                        roomId: parseInt(this.roomNumberLabel.string) 
                    }
                })
            } else {
                let requestInfo = { gameId: platform_game_id.mahjong_table, roomId: data.roomId, password: "", step: 3 };
                if (data.roomConfig.gameStatus <= 2 && data.roomConfig.isShareEquallyRoom) {
                    let opts = {
                        confirmCallback: () => {
                            if (PlayerMgr.getInstance().money >= data.costMoney) {
                                MahjongRoomMgr.getInstance().joinMahjongTable(requestInfo, () => {
                                    PlayerMgr.getInstance().money -= data.costMoney;
                                    let mahjongRoom = cc.find("Canvas");
                                    if (mahjongRoom && mahjongRoom.getComponent(MahjongRoomScene)) {
                                        mahjongRoom.getComponent(MahjongRoomScene).refreshMoneyLabel();
                                    }
                                    App.refreshPlatformScore(); 
                                })
                            } else {
                                Utils.showSDKOpenBroken();
                            }
                        },
                        money: data.costMoney,
                        isCreate: false
                    }
                    App.loadGamePopul({
                        prefabName: "mahjongSureTipNode",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongSureTipNode",
                        data: opts
                    })
                } else {
                    MahjongRoomMgr.getInstance().joinMahjongTable(requestInfo)
                }
            }
        });
    }

    /**
     * 分享按钮点击
     */
    shareClicked() {
        MahjongRoomMgr.getInstance().copyRoomInfo(
            this.agantData, 
            MAHJONG_CONST.shareText, 
            this.agantData.roomId, 
            this.agantData.roomName,
            MAHJONG_CONST.shareRoomInfo,
        );
    }

    /**
     * 观战点击
     */
    watchFightClicked() {
        let requestInfo = { gameId: platform_game_id.mahjong_table, roomId: this.agantData.roomId, password: "" };
        MahjongRoomMgr.getInstance().watchMajongTable(requestInfo, () => { });
    }

}
