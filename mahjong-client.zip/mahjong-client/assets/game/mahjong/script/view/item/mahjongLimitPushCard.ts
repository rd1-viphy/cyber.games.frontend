
const {ccclass, property} = cc._decorator;

@ccclass
export default class MahjongLimitPushCard extends cc.Component {

    
    @property({
        tooltip: "行牌禁止Sprite",
        type: cc.Sprite
    })
    spPushCardTip: cc.Sprite = null;

    @property({
        tooltip: "行牌禁制Frame",
        type: cc.SpriteFrame
    })
    spPushCardTipsFrame: cc.SpriteFrame[] = [];

    showItem(limitType) {
        this.spPushCardTip.spriteFrame = this.spPushCardTipsFrame[limitType - 1];
    }
 
}
