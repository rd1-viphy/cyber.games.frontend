import PlayerMgr from "../../../../../script/model/PlayerMgr";
import { Utils } from "../../../../../script/model/Utils";
import { Mahjong_SettleCardType } from "../../model/mahjongEnum";
import MahjongCard from "../mahjongCard";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongSmallResultItem extends cc.Component {

    @property({
        tooltip: "庄家标志",
        type: cc.Sprite
    })
    spBank: cc.Sprite = null;

    @property({
        tooltip: "玩家头像",
        type: cc.Sprite
    })
    spHead: cc.Sprite = null;

    @property({
        tooltip: "玩家名称",
        type: cc.Label
    })
    lbName: cc.Label = null;

    @property({
        tooltip: "碰牌节点",
        type: cc.Node
    })
    nodePengCard: cc.Node = null;

    @property({
        tooltip: "手牌节点",
        type: cc.Node
    })
    nodeHandCard: cc.Node = null;

    @property({
        tooltip: "花牌节点",
        type: cc.Node
    })
    nodeFlowerCard: cc.Node = null;

    @property({
        tooltip: "加番类型",
        type: cc.Label
    })
    lbTypeFan: cc.Label = null;

    @property({
        tooltip: "番数节点",
        type: cc.Node
    })
    nodeFan: cc.Node = null;

    @property({
        tooltip: "加番数量",
        type: cc.Label
    })
    lbFanCount: cc.Label = null;

    @property({
        tooltip: "赢分",
        type: cc.Label
    })
    lbWinScore: cc.Label = null;

    @property({
        tooltip: "输分",
        type: cc.Label
    })
    lbLoseScore: cc.Label = null;

    @property({
        tooltip: "胡",
        type: cc.Sprite
    })
    spHu: cc.Sprite = null;

    @property({
        tooltip: "自摸",
        type: cc.Sprite
    })
    spZiMo: cc.Sprite = null;

    @property({
        tooltip: "放炮",
        type: cc.Sprite
    })
    spFangPao: cc.Sprite = null;

    @property({
        tooltip: "吃碰牌",
        type: cc.Prefab
    })
    resultPengItem: cc.Prefab = null;

    @property({
        tooltip: "明杠牌",
        type: cc.Prefab
    })
    resultMingGangItem: cc.Prefab = null;

    @property({
        tooltip: "暗杠牌",
        type: cc.Prefab
    })
    resultAnGangItem: cc.Prefab = null;

    @property({
        tooltip: "花牌",
        type: cc.Prefab
    })
    resultFlowerItem: cc.Prefab = null;

    @property({
        tooltip: "手牌",
        type: cc.Prefab
    })
    resultHandItem: cc.Prefab = null;

    @property({
        tooltip: "风位",
        type: cc.Sprite
    })
    spWind: cc.Sprite = null;

    @property({
        tooltip: "风圈Frame",
        type: cc.SpriteFrame
    })
    spWindFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "小结算背景",
        type: cc.Sprite
    })
    spItemBg: cc.Sprite = null;

    @property({
        tooltip: "小结算背景Frame",
        type: cc.SpriteFrame
    })
    spItemBgFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "胡的哪张牌",
        type: cc.Node
    })
    nodeWinCard: cc.Node = null;

    protected winCardType = [
        "", "天胡", "地胡", "大四喜", "人胡", "天聽", "五暗刻", "大三元", "小四喜", "八枝花", "字一色",
        "清一色", "四槓牌", "七搶一", "四暗刻", "地聽", "小三元", "混一色", "碰碰胡", "門清自摸", "全求人",
        "平胡", "三暗刻", "花槓", "莊家", "連莊", "自摸", "門清", "獨聽", "海底撈月", "槓上開花", "河底撈魚",
        "三元台", "搶槓", "花牌", "門風刻", "圈風刻", "報聽", "見花見台", "見風見台", "無字無花", "槓牌", "暗槓",
    ]

    initItem(data, isZiMo) {
        this.nodeFlowerCard.removeAllChildren();
        this.nodePengCard.removeAllChildren();
        this.nodeWinCard.removeAllChildren();
        this.nodeHandCard.removeAllChildren();
        this.nodePengCard.width = 0;
        this.nodeHandCard.width = 0;
        this.spFangPao.node.active = false;
        this.spHu.node.active = false;
        this.spZiMo.node.active = false;

        if (data.playerId == PlayerMgr.getInstance().uid) {
            this.lbName.node.color = new cc.Color(255, 255, 0);
        }
        this.lbName.string = Utils.tailoringNickName(data.nickname);
        Utils.setRemoteSpriteFrame(this.spHead, data.avatar);

        if (data.isDealer == 1) {
            this.spBank.node.active = true;
        } else {
            this.spBank.node.active = false;
        }

        if (data.isShot == 1) {
            this.spFangPao.node.active = true;
        } else {
            this.spFangPao.node.active = false;
        }

        if (data.wind) {
            this.spWind.spriteFrame = this.spWindFrame[data.wind - 1];
        }

        if (data.settleScore >= 0) {
            this.lbWinScore.node.active = true;
            this.lbLoseScore.node.active = false;
            if (data.settleScore == 0) {
                this.lbWinScore.string = data.settleScore;
                this.spItemBg.spriteFrame = this.spItemBgFrame[1];
            } else {
                this.lbWinScore.string = "+" + data.settleScore;
                this.spHu.node.active = true;
                this.spItemBg.spriteFrame = this.spItemBgFrame[0];
                let idx = this.onGetWinCardIdx(data);
                if (idx > -1) {
                    data.handCards.splice(idx, 1);
                }
                if (isZiMo) {
                    this.spZiMo.node.active = true;
                } else {
                    this.spHu.node.active = true;
                }
            }
        } else {
            this.spItemBg.spriteFrame = this.spItemBgFrame[1];
            this.lbWinScore.node.active = false;
            this.lbLoseScore.node.active = true;
            this.lbLoseScore.string = data.settleScore;
        }

        this.lbTypeFan.string = "";
        this.lbFanCount.string = data.totalFan;
        if (data.fanList) {
            data.fanList.forEach(fan => {
                this.lbTypeFan.string = this.lbTypeFan.string + this.winCardType[fan] + " ";
            })
        }
        
        this.onSortCardList(data.handCards);
        for (let i = 0; i < data.handCards.length; i++) {
            const card = data.handCards[i];
            const handItem = cc.instantiate(this.resultHandItem);
            handItem.getComponent(MahjongCard).setCardNum(card);
            this.nodeHandCard.addChild(handItem);
        }

        if (data.otherCards.length != 0) {
            this.nodePengCard.active = true;
            data.otherCards.forEach((cardData) => {
                if (cardData.cardType == Mahjong_SettleCardType.chow) {
                    const eatList = [cardData.cards[0], cardData.chowCard, cardData.cards[1]];
                    const eatItem = cc.instantiate(this.resultPengItem);
                    eatItem.getComponent(MahjongCard).setEatCardNum(eatList);
                    this.nodePengCard.addChild(eatItem);
                } else if (cardData.cardType == Mahjong_SettleCardType.pong) {
                    const pengItem = cc.instantiate(this.resultPengItem);
                    pengItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                    this.nodePengCard.addChild(pengItem);
                } else if (cardData.cardType == Mahjong_SettleCardType.exposedKong ||
                    cardData.cardType == Mahjong_SettleCardType.pongKong) {
                    const mingGangItem = cc.instantiate(this.resultMingGangItem);
                    mingGangItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                    this.nodePengCard.addChild(mingGangItem);
                } else if (cardData.cardType == Mahjong_SettleCardType.concealedKong) {
                    const anGangItem = cc.instantiate(this.resultAnGangItem);
                    anGangItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                    this.nodePengCard.addChild(anGangItem);
                }
            })
        }

        if (data.flowerCards.length != 0) {
            data.flowerCards.forEach((flowerCard, idx) => {
                const flowerItem = cc.instantiate(this.resultFlowerItem);
                flowerItem.getComponent(MahjongCard).setCardNum(flowerCard);
                this.nodeFlowerCard.addChild(flowerItem);
                if (idx == 7) {
                    flowerItem.getChildByName("spHu").active = true;
                }
            })
        }

        if (data.settleScore > 0 && data.winCards.length != 0) {
            data.winCards.forEach((winCard) => {
                const huCardItem = cc.instantiate(this.resultHandItem);
                huCardItem.getComponent(MahjongCard).setCardNum(winCard);
                huCardItem.getChildByName("spHu").active = true;
                this.nodeWinCard.addChild(huCardItem);
            })
        }
    }

    onGetWinCardIdx(data) {
        for (let i = 0; i < data.handCards.length; i++) {
            const handData = data.handCards[i];
            if (handData == data.winCards[0]) {
                return i;
            }
        }
        return -1;
    }

    onSortCardList(list) {
        if (list) {
            for (let i = 0; i < list.length; i++) {
                for (let j = 0; j < list.length - i; j++) {
                    if (list[j] > list[j + 1]) {
                        let temp = list[j];
                        list[j] = list[j + 1];
                        list[j + 1] = temp;
                    }
                }
            }
        }
    }

}
