
const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongDisCardItem extends cc.Component {

    @property({
        tooltip: "上下弃牌4种牌背",
        type: [cc.SpriteFrame]
    })
    spCardBgFrame1: cc.SpriteFrame[] = [];

    @property({
        tooltip: "上下弃牌4种遮罩",
        type: [cc.SpriteFrame]
    })
    spCardMaskFrame1: cc.SpriteFrame[] = [];

    @property({
        tooltip: "左右弃牌的牌背",
        type: [cc.SpriteFrame]
    })
    spCardBgFrame2: cc.SpriteFrame[] = [];

    @property({
        tooltip: "左右弃牌的牌背",
        type: [cc.SpriteFrame]
    })
    spCardMaskFrame2: cc.SpriteFrame[] = [];

    @property({
        tooltip: "牌背",
        type: cc.Sprite
    })
    spCardBg: cc.Sprite = null;

    @property({
        tooltip: "遮罩",
        type: cc.Sprite
    })
    spCardMask: cc.Sprite = null;

    @property({
        tooltip: "牌花",
        type: cc.Sprite
    })
    spCard: cc.Sprite = null;

    @property({
        tooltip: "麻将牌",
        type: cc.SpriteAtlas
    })
    spCardRes: cc.SpriteAtlas = null;

    private readonly disCardScale = [
        [0.3579, 0.4781],
        [0.3579, 0.4781],
        [0.3579, 0.4781],
        [0.3579, 0.4781],
        [0.3520, 0.4702],
        [0.3520, 0.4702],
        [0.3520, 0.4702],
        [0.3077, 0.4678]
    ]

    private readonly disCard_path = "mj_0_";

    /**
     * 第几号座位玩家、该玩家的第多少张弃牌
     * @param seatId 
     * @param idx 
     */
    showDisCard(seatId: number, idx: number, cardData: number) {
        let num = idx % 8;
        if (seatId == 0 || seatId == 2) {
            switch (num) {
                case 0:
                case 1:
                case 2:
                    this.spCardBg.spriteFrame = this.spCardBgFrame1[3 - num];
                    this.spCardMask.spriteFrame = this.spCardMaskFrame1[3 - num];
                    if (seatId == 0) {
                        this.spCardBg.node.scaleX = -this.spCardBg.node.scaleX;
                        this.spCard.node.scaleX = -this.spCard.node.scaleX;
                    }
                    break;
                case 3:
                    this.spCardBg.spriteFrame = this.spCardBgFrame1[0];
                    this.spCardMask.spriteFrame = this.spCardMaskFrame1[0];
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                    if (seatId == 0) {
                        this.spCardBg.spriteFrame = this.spCardBgFrame1[num - 4];
                        this.spCardMask.spriteFrame = this.spCardMaskFrame1[num - 4];
                    } else if (seatId == 2) {
                        this.spCardBg.spriteFrame = this.spCardBgFrame1[7 - num];
                        this.spCardMask.spriteFrame = this.spCardMaskFrame1[7 - num];
                    }
                    break;
                default:
                    break;
            }
            if (seatId == 2) {
                this.spCard.node.angle = -180;
            }
        } else if (seatId == 1 || seatId == 3) {
            this.spCard.node.scaleX = this.disCardScale[num][0];
            this.spCard.node.scaleY = this.disCardScale[num][1];
            if (seatId == 1) {
                this.spCardBg.spriteFrame = this.spCardBgFrame2[num];
                this.spCardMask.spriteFrame = this.spCardMaskFrame2[num];
                this.spCard.node.angle = -264.8;
                this.spCard.node.skewX = 8;
                this.spCard.node.skewY = 2;
            } else if (seatId == 3) {
                this.spCardBg.spriteFrame = this.spCardBgFrame2[7 - num];
                this.spCardMask.spriteFrame = this.spCardMaskFrame2[7 - num];
                this.spCard.node.angle = 90;
                this.spCardBg.node.scaleX = -this.spCardBg.node.scaleX;
                this.spCard.node.scaleX = -this.spCard.node.scaleX;
                this.spCard.node.angle = -264.8;
                this.spCard.node.skewX = -8;
                this.spCard.node.skewY = -2;
            }
        }
        const spPath = this.disCard_path + cardData;
        this.spCard.spriteFrame = this.spCardRes.getSpriteFrame(spPath);
    }

}
