import App from "../../../../../script/model/App";
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";

import MahjongModel from "../../model/mahjongModel";
import MahjongProxy from "../../model/mahjongProxy";


const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPrepsItem extends cc.Component {

    @property({
        tooltip: "道具图片",
        type: cc.Sprite
    })
    prepsSprite: cc.Sprite = null;

    @property({
        tooltip: "金币标识",
        type: cc.Node
    })
    coin: cc.Node = null;

    @property({
        tooltip: "金币数目",
        type: cc.Label
    })
    coinLabel: cc.Label = null;

    @property({
        tooltip: "免费金币",
        type: cc.Label
    })
    freeLabel: cc.Label = null;

    @property({
        tooltip: "道具锁",
        type: cc.Node
    })
    nodeLock: cc.Node = null;

    @property({
        tooltip: "道具图片集",
        type: cc.SpriteFrame
    })
    prepsSpriteFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "正常节点",
        type: cc.Node
    })
    nodeNormal: cc.Node = null;

    @property({
        tooltip: "限免节点",
        type: cc.Node
    })
    nodeFree: cc.Node = null;

    @property({
        tooltip: "限免金币数",
        type: cc.Label
    })
    lbFreeCost: cc.Label = null;

    prepsIndex: number = 0;
    coustomMoney: number = 0;
    chairId: number = 0;
    gameProxy: MahjongProxy = null;
    gameModel: MahjongModel = MahjongModel.getInstance();
    userId: string = "";

    init(prepsIndex: number, coustomMoney: number, chaidId: number, gameProxy: MahjongProxy, userId: string) {
        this.prepsIndex = prepsIndex;
        this.coustomMoney = coustomMoney;
        this.chairId = chaidId;
        this.gameProxy = gameProxy;
        this.prepsSprite.spriteFrame = this.prepsSpriteFrame[prepsIndex - 1];

        if (coustomMoney > 0 && MahjongRoomMgr.getInstance().isFreeEmoji && MahjongRoomMgr.getInstance().getIsIncludeActivities(MahjongRoomMgr.getInstance().startTime, MahjongRoomMgr.getInstance().endTime)) {
            this.nodeNormal.active = false;
            this.nodeFree.active = true;
            this.lbFreeCost.string = coustomMoney.toString();
        } else {
            this.nodeNormal.active = true;
            this.nodeFree.active = false;
            this.freeLabel.node.active = coustomMoney <= 0;
            this.coinLabel.node.active = coustomMoney > 0;
            this.coin.active = coustomMoney > 0;
            this.coinLabel.string = coustomMoney.toString();
        }

        this.userId = userId;
        if (userId == PlayerMgr.getInstance().uid || this.gameModel.getIsWatchTheBattle()) {
            this.nodeLock.active = true;
        }
    }

    prepsClicked() {
        if (!MahjongModel.getInstance().getIsWatchTheBattle()) {
            if (this.userId != PlayerMgr.getInstance().uid) {
                const free = (MahjongRoomMgr.getInstance().isFreeEmoji && MahjongRoomMgr.getInstance().getIsIncludeActivities(MahjongRoomMgr.getInstance().startTime, MahjongRoomMgr.getInstance().endTime));
                if (this.coustomMoney > 0 && !free) {
                    if (PlayerMgr.getInstance().money > this.coustomMoney) {
                        const isShowTips = JSON.parse(cc.sys.localStorage.getItem("mahjongPropBuyHint"));
                        if (isShowTips || isShowTips == null) {
                            let opts = {
                                confirmCallback: () => {
                                    this.gameProxy.sendEmoij({ id: this.prepsIndex, targetId: this.userId }, () => {
                                        PlayerMgr.getInstance().money -= this.coustomMoney;
                                        this.node.parent.parent.parent.destroy();
                                    })
                                },
                                money: this.coustomMoney
                            }
                            App.loadGamePopul({
                                prefabName: "mahjongPropsTipNode",
                                prefabPath: "prefab",
                                prefabComponent: "mahjongPropsTipsView",
                                data: opts
                            })
                        } else {
                            this.gameProxy.sendEmoij({ id: this.prepsIndex, targetId: this.userId }, () => {
                                PlayerMgr.getInstance().money -= this.coustomMoney;
                                App.refreshPlatformScore();
                                this.node.parent.parent.parent.destroy();
                            })
                        }
                    } else {
                        Utils.showSDKOpenBroken();
                    }
                } else {
                    this.gameProxy.sendEmoij({ id: this.prepsIndex, targetId: this.userId }, () => {
                        this.node.parent.parent.parent.destroy();
                    })
                }
            } else {
                App.showToast("772", 1);
            }
        } else {
            App.showToast("scp_not_allow_send_preps", 1);
        }
    }

}
