import { platform_game_id } from "../../../../../script/common/ClientEnum";
import App from "../../../../../script/model/App";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";
import { MAHJONG_ROOM_TYPE } from "../../model/mahjongEnum";
import mahjongPersonGradePlayer from "./mahjongPersonGradePlayer";


const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPersonGradeItem extends cc.Component {

    @property({
        tooltip: "房间名称",
        type: cc.Label
    })
    roomNumLabel: cc.Label = null;

    @property({
        tooltip: "对战时间",
        type: cc.Label
    })
    timeNumLabel: cc.Label = null;

    @property({
        tooltip: "玩家信息",
        type: cc.Node
    })
    personNode: cc.Node[] = [];

    @property({
        tooltip: "公开桌",
        type: cc.Node
    })
    publicRoom: cc.Node = null;

    protected tableData = null;

    protected roomId = null;

    protected roomUniqueID = null;

    /**
     * 初始化数据
     * @param data 
     * @param gameProxy 
     */
    init(data) {
        this.tableData = data;
        this.roomId = data.roomId;
        this.roomUniqueID = data.roomUniqueID;
        this.roomNumLabel.string = data.roomId + "號牌桌";
        this.timeNumLabel.string = Utils.formatTimestamp(data.createTime, "Y-M-D h:m:s");
        if (data.createType == MAHJONG_ROOM_TYPE.PUBLIC) {
            this.publicRoom.active = true;
        } else {
            this.publicRoom.active = false;
        }

        data.totalDetails.forEach((element, index) => {
            let person = this.personNode[index];
            person.getComponent(mahjongPersonGradePlayer).init(element);
        });
    }

    /**
     * 详情按钮的点击
     */
    detailsBtnClicked() {
        MahjongRoomMgr.getInstance().getGameInfo({
            gameId: platform_game_id.mahjong_table,
            roomId: this.roomId,
            roomUniqueID: this.roomUniqueID,
            pageStart: 1,
            pageNum: 1
        }, (data) => {
            App.loadGamePopul({
                prefabName: "mahjongRecordInfoView",
                prefabPath: "prefab",
                prefabComponent: "mahjongRecordInfoView",
                data: {
                    roomId: this.roomId,
                    roomUniqueID: this.roomUniqueID,
                    records: data.records,
                    pageStart: data.pageStart,
                    pageEnd: data.pageEnd,
                    isInfo: true,
                }
            })
        })
    }

}
