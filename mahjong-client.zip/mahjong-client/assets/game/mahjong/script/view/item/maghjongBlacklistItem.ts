import { Utils } from "../../../../../script/model/Utils";
import MahjongProxy from "../../model/mahjongProxy";
import mahjongBlacklistNode from "../mahjongBlacklistNode";

const { ccclass, property } = cc._decorator;

@ccclass
export default class maghjongBlacklistItem extends cc.Component {

    @property({
        tooltip: "玩家昵称",
        type: cc.Label
    })
    nameLabel: cc.Label = null;

    @property({
        tooltip: "玩家头像",
        type: cc.Node
    })
    photo: cc.Node = null;

    index: number = 0;
    mahjongBlacklist: mahjongBlacklistNode = null;
    gameProxy: MahjongProxy = null;
    uid: string = "";

    init(index: number, data: MahjongCommon.blacklistInfo, mahjongBlacklist: mahjongBlacklistNode, gameProxy: MahjongProxy) {
        this.index = index;
        this.mahjongBlacklist = mahjongBlacklist;
        this.gameProxy = gameProxy;
        this.nameLabel.string = Utils.tailoringNickName(data.nickname);
        this.uid = data.playerId;
        Utils.setRemoteSpriteFrame(this.photo, data.avatar);
    }

    /**
     * 移除按钮的点击
     */
    removeBtnClicked() {
        this.gameProxy.sendRemoveFromBlacklist({ playerId: this.uid }, () => {
            this.mahjongBlacklist.delectPerson(this.index);
        });
    }

}
