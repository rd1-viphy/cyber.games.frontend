import AudioMgr from "../../../../script/model/AudioMgr";
import { MAHJONG_CONST } from "../model/mahjongEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongButton extends cc.Component {

    start() {
        this.node.on(cc.Node.EventType.TOUCH_END, () => {
            if (this.node.getComponent(cc.Button) && this.node.getComponent(cc.Button).interactable) {
                AudioMgr.playSFX(MAHJONG_CONST.Sound.SoundBtn, true);
            }
            if (this.node.getComponent(cc.Toggle) && this.node.getComponent(cc.Toggle).interactable) {
                AudioMgr.playSFX(MAHJONG_CONST.Sound.SoundBtn, true);
            }
        })
    }

}
