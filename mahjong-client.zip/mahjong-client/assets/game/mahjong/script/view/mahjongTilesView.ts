import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../script/model/Utils";
import AppEmitter from "../../../../script/network/AppEmitter";
import MahjongClock from "../component/mahjongClock";
import MahjongLayout from "../component/mahjongLayout";
import MahjongCardPosiion = require("../model/mahjongCardPosition");
import { MAHJONG_ANIM, MAHJONG_CONST, MAHJONG_GAME_STAGE, MAHJONG_HAND_TYPE, MAHJONG_OPERATION_ANIM, MAHJONG_PLAYERS, MAHJONG_PLAYER_OPERATION, Mahjong_SettleCardType } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongDisCardItem from "./item/mahjongDisCardItem";
import MahjongHuCardItem from "./item/mahjongHuCardItem";
import MahjongCard from "./mahjongCard";
import MahjongCardPiles from "./mahjongCardPiles";
import MahjongOperation from "./mahjongOperation";
import MahjongView from "./mahjongView";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongTilesView extends cc.Component {

    @property({
        tooltip: "玩家牌组节点",
        type: [cc.Node]
    })
    nodeHandCardsLayout: cc.Node[] = [];

    @property({
        tooltip: "手牌节点",
        type: [cc.Node]
    })
    nodeHandCards: cc.Node[] = [];

    @property({
        tooltip: "弃牌节点",
        type: [cc.Node]
    })
    nodeDisCards: cc.Node[] = [];

    @property({
        tooltip: "牌堆",
        type: [cc.Node]
    })
    nodeCardPiles: cc.Node[] = [];

    @property({
        tooltip: "手牌Item",
        type: [cc.Prefab]
    })
    handCardItem: cc.Prefab[] = [];

    @property({
        tooltip: "碰牌节点",
        type: [cc.Node]
    })
    nodePengCards: cc.Node[] = [];

    @property({
        tooltip: "花牌节点",
        type: [cc.Node]
    })
    nodeFlowerCard: cc.Node[] = [];

    @property({
        tooltip: "展示出牌节点",
        type: [cc.Node]
    })
    nodeDisCardShow: cc.Node[] = [];

    @property({
        tooltip: "出牌背景",
        type: cc.Node
    })
    nodeDisCardsBg: cc.Node[] = [];

    @property({
        tooltip: "明杠Item",
        type: [cc.Prefab]
    })
    mingGangItem: cc.Prefab[] = [];

    @property({
        tooltip: "暗杠Item",
        type: [cc.Prefab]
    })
    anGangItem: cc.Prefab[] = [];

    @property({
        tooltip: "碰牌Item",
        type: [cc.Prefab]
    })
    pengItem: cc.Prefab[] = [];

    @property({
        tooltip: "弃牌Item",
        type: cc.Prefab
    })
    disCardItem: cc.Prefab = null;

    @property({
        tooltip: "花牌Item",
        type: [cc.Prefab]
    })
    flowerCardItem: cc.Prefab[] = [];

    @property({
        tooltip: "操作按钮节点",
        type: cc.Node
    })
    nodeOperation: cc.Node = null;

    @property({
        tooltip: "玩家操作标志",
        type: sp.Skeleton
    })
    spOperationSign: sp.Skeleton[] = []

    @property({
        tooltip: "放炮、抢杠胡",
        type: sp.Skeleton
    })
    spFangPaoGangHu: sp.Skeleton[] = [];

    @property({
        tooltip: "吃牌节点",
        type: cc.Node
    })
    nodeEatCards: cc.Node = null;

    @property({
        tooltip: "听牌节点",
        type: cc.Node
    })
    nodeTingCard: cc.Node = null;

    @property({
        tooltip: "听牌Item",
        type: cc.Prefab
    })
    tingItem: cc.Prefab = null;

    @property({
        tooltip: "出牌提示",
        type: sp.Skeleton
    })
    spDisCardTag: sp.Skeleton = null;

    @property({
        tooltip: "5张以上内胡牌提示",
        type: cc.Node
    })
    nodeHuCardView1: cc.Node = null;

    @property({
        tooltip: "5张以内胡牌提示",
        type: cc.Node
    })
    nodeHuCardView2: cc.Node = null;

    @property({
        tooltip: "听牌2个layout",
        type: cc.Node
    })
    nodeTing: cc.Node[] = [];

    @property({
        tooltip: "抓位动画",
        type: sp.Skeleton
    })
    spZhuaWeiAnim: sp.Skeleton = null;

    @property({
        tooltip: "补花动画",
        type: sp.Skeleton
    })
    spBuHuaAnim: sp.Skeleton[] = [];

    @property({
        tooltip: "听牌遮罩",
        type: cc.Node
    })
    spTingCardMask: cc.Node = null;

    @property({
        tooltip: "听牌小灯泡",
        type: cc.Node
    })
    spTingBulb: cc.Node = null;

    @property({
        tooltip: "摊牌Item",
        type: cc.Prefab
    })
    showCardItem: cc.Prefab[] = [];

    @property({
        tooltip: "摊牌暗杠item",
        type: cc.Prefab
    })
    showCardAnGangItem: cc.Prefab[] = [];

    @property({
        tooltip: "請出牌動畫",
        type: sp.Skeleton
    })
    spDisCardHintAnim: sp.Skeleton = null;

    private handCardsMap = new Map();

    private mySelfCards = [];

    protected gameView: MahjongView = null;

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    /** 每个座位玩家的弃牌数量 */
    protected disCardNum = [0, 0, 0, 0];

    /** 每个位置的碰杠数量 */
    protected pengGangCount = [0, 0, 0, 0];

    /** 发牌顺序 */
    protected dealCardOrder = [];

    /** 发牌数量 */
    protected dealCardCount = [0, 0, 0, 0];

    /** 手牌数量最大值 */
    protected readonly cardMaxCount: number = 17;

    /** 我的视角每张牌的宽度 */
    protected readonly cardWidth: number = 65;

    /** 花牌最大数量 */
    protected readonly maxFlowers: number = 8;

    /** 发牌的墩数 */
    protected readonly dealPiles: number = 17;

    /** 每次发牌数量 */
    protected readonly dealCardNumber: number = 4;

    protected selTouchCardPos = null;

    protected myHandCardData = null;

    protected dealCardTime = null;

    private readonly disCardShowPos = [cc.v2(0, -179), cc.v2(421, 0), cc.v2(0, 199), cc.v2(-409, 0)];

    onLoad() {
        AppEmitter.on(MAHJONG_CONST.MAHJONG_LOCAL_OPERATOR, this.onPlayerOperator, this);
    }

    initCardsView(gameView) {
        this.gameView = gameView;

        this.nodeOperation.active = false;

        this.nodeDisCards.forEach((nodeDisCard) => {
            nodeDisCard.destroyAllChildren();
        })

        this.spDisCardTag.node.active = false;
        this.spTingCardMask.active = false;
        this.spTingBulb.active = false;
        this.gameModel.otherHandCards = [[], [], [], []];
        this.dealCardCount = [0, 0, 0, 0];
        this.nodeTing[0].active = false;
        this.nodeTing[1].active = false;

        for (let i = 0; i < MAHJONG_CONST.PLAYERS_NUM; i++) {
            this.nodePengCards[i].destroyAllChildren();
            this.nodeHandCards[i].destroyAllChildren();
            this.nodeDisCards[i].destroyAllChildren();
            this.nodeCardPiles[i].active = false;
            this.nodeFlowerCard[i].destroyAllChildren();
            this.disCardNum[i] = 0;
            this.pengGangCount[i] = 0;

            if (i === 0 || i === 2) {
                this.nodePengCards[i].width = 0;
                this.nodeHandCards[i].width = 0;
            } else {
                this.nodePengCards[i].height = 0;
                this.nodeHandCards[i].height = 0;
            }
            this.nodePengCards[i].active = false;
        }
    }

    onStartGame() {
        this.mySelfCards = [];
        this.handCardsMap.clear();
    }

    /**
     * 显示牌堆
     */
    onDrawCardPiles() {
        this.nodeCardPiles.forEach((pile) => {
            pile.active = true;
            pile.getComponent(MahjongCardPiles).showCardPiles();
        })
    }

    /**
     * 断线重连牌堆显示
     */
    onRecPiles() {
        let cardTotalCount = 144;
        if (!this.gameModel.roomConfig.hasFlowerCard) {
            cardTotalCount = 136;
        }

        const number = this.gameModel.gameInfo.remainCardNum + this.gameModel.gameInfo.retainCardNum + this.gameModel.flowersGangCount;
        let hideCards = cardTotalCount - number;

        this.gameModel.getDealCardPos();

        this.gameModel.moCardSeat = this.gameModel.grabCardSeatId;
        this.gameModel.moCardPos = (this.gameModel.openCardPos - 1) * 2 - 1;

        cc.log("断线重连摸牌显示：" + this.gameModel.grabCardSeatId, this.gameModel.openCardPos);
        cc.log("花杠位置: " + this.gameModel.flowerGangSeat, this.gameModel.flowerGangPos);

        for (let i = 0; i < hideCards; i++) {
            const moCard = this.gameModel.onGetMoCardIdx(this.gameModel.moCardSeat, this.gameModel.moCardPos);
            this.nodeCardPiles[moCard.seat].getComponent(MahjongCardPiles).onHideMoCard(moCard.moCardPos);
            if (i != hideCards - 1) {
                this.gameModel.moCardPos += 1;
            }
        }

        for (let i = 0; i < this.gameModel.flowersGangCount; i++) {
            const flowerData = this.gameModel.onGetFlowerGangIdx(this.gameModel.flowerGangSeat, this.gameModel.flowerGangPos);
            this.nodeCardPiles[flowerData.seat].getComponent(MahjongCardPiles).onHideMoCard(flowerData.flowerGangPos);
        }
        this.onShowEightPileMask();
    }

    onShowEightPileMask() {
        this.gameModel.eightPileSeat = this.gameModel.flowerGangSeat;
        this.gameModel.eightPilePos = this.gameModel.flowerGangPos;
        let eightPileCount = 0;
        if (this.gameModel.roomConfig.maxPlayerNum == 4) {
            eightPileCount = 16;
        } else if (this.gameModel.roomConfig.maxPlayerNum == 3) {
            eightPileCount = 44;
        } else if (this.gameModel.roomConfig.maxPlayerNum == 2) {
            eightPileCount = 72;
        }
        for (let i = 0; i < eightPileCount; i++) {
            const eightPileCard = this.gameModel.onGetEightPileIdx(this.gameModel.eightPileSeat, this.gameModel.eightPilePos, i);
            this.nodeCardPiles[eightPileCard.seat].getComponent(MahjongCardPiles).onShowCardMask(eightPileCard.eightPilePos);
        }
    }

    /**
     * 发牌流程、一次性发4张牌
     * @param data 
     */
    onStartDealCard(data) {
        // 发牌数量
        let maxCardCount = this.gameModel.roomConfig.maxPlayerNum * 16;
        // 剩余牌张数
        this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
        let dealCardNumber = 0;
        // 开始从哪一摞抓牌s
        this.gameModel.onSetMoCardIdx();
        let openCardPos = this.gameModel.grabCardSeatId;
        // 从哪个位置开始抓牌
        let dealPos = this.gameModel.openCardPos;
        cc.log("牌摞: " + openCardPos, "抓牌位置: " + dealPos)
        let cardPies = this.gameModel.roomConfig.hasFlowerCard ? 18 : 17;
        // 开牌玩家还有多少摞牌可以发
        let remainderPies = cardPies - dealPos + 1;
        // 开牌玩家还有多少墩牌可以发(每次发两墩, 4张牌)
        let count = Math.floor(remainderPies / 2);
        // 发到第二摞的次数
        let seconedDealCount = 0;
        // 第二位抓牌玩家的墩数
        let secoenPiles = 0;
        if (remainderPies % 2 == 0) {
            // 第一摞可以发完
            if (cardPies == 18) {
                // 有花是18摞, 一次发两摞，9次可以整摞发完
                secoenPiles = 9;
                seconedDealCount = secoenPiles + count;
            } else {
                // 无花是17摞, 一次发两摞, 8次后还剩余一摞
                secoenPiles = 8;
                seconedDealCount = secoenPiles + count;
            }
        } else {
            // 第一摞没有全部发完,剩了一摞
            if (cardPies == 18) {
                // 有花18摞，一次发两摞只能发8次，还剩下一摞
                secoenPiles = 8;
                seconedDealCount = secoenPiles + count + 1;
            } else {
                // 无花17摞, 一次发两摞，8次整摞发完
                secoenPiles = 8;
                seconedDealCount = secoenPiles + count + 1;
            }
        }

        let tmp = maxCardCount / 4 + 1;
        for (let i = 0; i < tmp; i++) {
            cc.log(openCardPos + "号牌摞 " + " " + dealPos + "号位置 " + i + "数量: " + dealCardNumber)
            if (dealCardNumber >= maxCardCount) {
                cc.log("牌够了", dealCardNumber)
                break
            }
            if (!MahjongRoomMgr.getInstance().isBackView) {
                this.onDealLastCard(data, i, maxCardCount / 4);
            } 

            if (i < count) {
                // 先发第一位抓牌的牌摞
                this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                dealCardNumber += 4;
                dealPos += 2;
            } else if (i == count) {
                if (remainderPies % 2 == 0) {
                    // 第一摞可以整体发完, 则换下一牌摞
                    if (openCardPos == 0) {
                        openCardPos = 3
                    } else {
                        openCardPos -= 1;
                    }
                    dealPos = 1;
                    this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                    dealPos += 2;
                    dealCardNumber += 4;
                } else {
                    // 第一摞还剩一摞，则下一摞也发两张
                    if (dealPos <= cardPies) {
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                    }

                    if (openCardPos == 0) {
                        openCardPos = 3
                    } else {
                        openCardPos -= 1;
                    }
                    dealPos = 1;
                    this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                    dealPos += 1;
                    dealCardNumber += 4;
                }
            } else if (count < i && i < seconedDealCount) {
                // 发第二摞牌
                this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                dealPos += 2;
                dealCardNumber += 4;
            } else if (i == seconedDealCount) {
                if (dealCardNumber >= maxCardCount) { break }
                if (remainderPies % 2 == 0) {
                    // 第一摞可以发完
                    if (cardPies == 17) {
                        // 无花的时候第二摞会留下最后一墩牌
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                        if (dealCardNumber >= maxCardCount) { break }
                        if (openCardPos == 0) {
                            openCardPos = 3
                        } else {
                            openCardPos -= 1;
                        }
                        dealPos = 1;
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                        dealPos += 1;
                        dealCardNumber += 4;
                    } else {
                        if (openCardPos == 0) {
                            openCardPos = 3
                        } else {
                            openCardPos -= 1;
                        }
                        dealPos = 1;
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                        dealPos += 2;
                        dealCardNumber += 4;
                    }
                } else {
                    // 第一摞没有发完、有花的时候会留下最后一墩牌
                    if (cardPies == 17) {
                        if (openCardPos == 0) {
                            openCardPos = 3
                        } else {
                            openCardPos -= 1;
                        }
                        dealPos = 1;
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                        dealPos += 2;
                        dealCardNumber += 4;
                    } else {
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                        if (dealCardNumber >= maxCardCount) { break }
                        if (openCardPos == 0) {
                            openCardPos = 3
                        } else {
                            openCardPos -= 1;
                        }
                        dealPos = 1;
                        this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 1, i);
                        dealPos += 1;
                        dealCardNumber += 4;
                    }
                }
            } else if (i > seconedDealCount) {
                if (dealCardNumber >= maxCardCount) { break }
                this.nodeCardPiles[openCardPos].getComponent(MahjongCardPiles).onDealCardHideCards(dealPos, 3, i);
                dealPos += 2;
                dealCardNumber += 4;
            }

            if (!MahjongRoomMgr.getInstance().isBackView) {
                this.dealCardTime = setTimeout(() => {
                    this.onDealPlayerHandCard(i)
                }, 120 * i);
            }
        }

        if (MahjongRoomMgr.getInstance().isBackView) {
            this.gameModel.moCardPos = this.gameModel.moCardPos * 2 - 1;
            cc.log("最后一张牌: " + this.gameModel.moCardPos, " 牌摞 :" + this.gameModel.moCardSeat)
            let moCard = this.gameModel.onGetMoCardIdx(this.gameModel.moCardSeat, this.gameModel.moCardPos);
            this.nodeCardPiles[moCard.seat].getComponent(MahjongCardPiles).onHideMoCard(moCard.moCardPos);
        }
        this.onShowEightPileMask();
    }

    /**
     * 发送庄家的最后一张牌
     * @param data 
     * @param idx 
     * @param num 
     */
    onDealLastCard(data, idx, num) {
        if (idx == num - 1) {
            this.scheduleOnce(() => {
                this.gameModel.moCardPos = this.gameModel.moCardPos * 2 - 1;
                cc.log("最后一张牌: " + this.gameModel.moCardPos, " 牌摞 :" + this.gameModel.moCardSeat)
                let moCard = this.gameModel.onGetMoCardIdx(this.gameModel.moCardSeat, this.gameModel.moCardPos);
                this.nodeCardPiles[moCard.seat].getComponent(MahjongCardPiles).onHideMoCard(moCard.moCardPos);
                for (let m = 0; m < data.handCards.length; m++) {
                    const cardData = data.handCards[m];
                    const seatId = this.gameModel.changSeatId(cardData.chairId);
                    if (cardData.cards.length == 17) {
                        const handCard = cc.instantiate(this.handCardItem[seatId]);
                        if (seatId == MAHJONG_CONST.MY_SEATID) {
                            const isWatch = this.gameModel.getIsWatchTheBattle();
                            if (!isWatch) {
                                handCard.getComponent(MahjongCard).setMySelfCard(cardData.cards[16]);
                            } else {
                                handCard.getComponent(MahjongCard).setMySelfCardBg();
                            }
                            this.mySelfCards.push(cardData.cards[16]);
                            this.nodeHandCards[MAHJONG_CONST.MY_SEATID].getComponent(MahjongLayout).addMoCard(handCard);
                            handCard["card"] = cardData.cards[16];
                            if (cardData.cards[16]) {
                                this.gameModel.lastDrawData = JSON.parse("[" + cardData.cards[16] + "]");
                            }
                            this.onTouchCardListener(handCard);
                        } else if (seatId == 1) {
                            handCard.setPosition(MahjongCardPosiion.handCardPos2[16]);
                            handCard.zIndex = 0;
                        } else if (seatId == 2) {
                            this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handCard);
                        } else if (seatId == 3) {
                            handCard.setPosition(MahjongCardPosiion.handCardPos4[16]);
                        }
                        this.nodeHandCards[seatId].addChild(handCard);
                        this.gameModel.onSortCardList(this.mySelfCards);
                        this.updatePlayerHandCards(MAHJONG_CONST.MY_SEATID, this.mySelfCards.length, this.mySelfCards);
                    }
                }
            }, 2.2)
        }
    }

    /**
     * 发玩家手牌
     * @param idx 
     * @returns 
     */
    onDealPlayerHandCard(idx: number) {
        if (this.gameModel) {
            let order = idx % this.gameModel.roomConfig.maxPlayerNum;
            let seatId = this.dealCardOrder[order];

            if (this.dealCardCount[seatId] > 12) { return }

            for (let i = 0; i < this.dealCardNumber; i++) {
                const handCard = cc.instantiate(this.handCardItem[seatId]);
                if (seatId === MAHJONG_CONST.MY_SEATID) {
                    handCard.getComponent(MahjongCard).setMySelfCardBg();
                    if (i == this.cardMaxCount - 1) {
                        this.nodeHandCards[MAHJONG_CONST.MY_SEATID].getComponent(MahjongLayout).addMoCard(handCard);
                    } else {
                        this.nodeHandCards[MAHJONG_CONST.MY_SEATID].getComponent(MahjongLayout).addHandCard(handCard);
                    }
                    this.dealCardCount[seatId] += 1;
                    if (this.gameModel.getIsWatchTheBattle()) {
                        this.mySelfCards.push(0);
                    }
                } else if (seatId == 1) {
                    handCard.setPosition(MahjongCardPosiion.handCardPos2[this.dealCardCount[seatId]]);
                    handCard.zIndex = this.cardMaxCount - this.dealCardCount[seatId];
                    this.dealCardCount[seatId] += 1;
                } else if (seatId == 3) {
                    handCard.setPosition(MahjongCardPosiion.handCardPos4[this.dealCardCount[seatId]]);
                    this.dealCardCount[seatId] += 1;
                } else if (seatId == 2) {
                    if (i == this.cardMaxCount - 1) {
                        this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handCard);
                    } else {
                        this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handCard);
                    }
                    this.dealCardCount[seatId] += 1;
                }

                this.nodeHandCards[seatId].addChild(handCard);
            }

            if (seatId == MAHJONG_CONST.MY_SEATID) {
                if (!this.gameModel.getIsWatchTheBattle()) {
                    this.scheduleOnce(() => {
                        this.onDealMySelfCard(this.myHandCardData)
                    }, 0.3)
                }
            }
        }
    }

    /**
     * 发自己的牌
     * @param cardData 
     */
    onDealMySelfCard(cardData) {
        let startPos = this.mySelfCards.length;
        let endPos = startPos + 4;
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_DealCard, true);
        for (let i = startPos; i < endPos; i++) {
            const handCard = this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children[i];
            if (handCard) {
                handCard["id"] = i;
                handCard["card"] = cardData[i];
                handCard.getComponent(MahjongCard).setMySelfCard(cardData[i]);
                this.mySelfCards.push(cardData[i]);
                this.handCardsMap.set(handCard["id"], handCard["card"]);
                this.onTouchCardListener(handCard);
            }
        }
    }

    /**
     * 发牌
     * @param data 
     */
    onDealCard(data) {
        this.mySelfCards = [];
        this.myHandCardData = null;
        this.dealCardOrder[0] = this.gameModel.grabCardSeatId;
        if (this.gameModel.roomConfig.maxPlayerNum == MAHJONG_PLAYERS.FOUR) {
            if (this.gameModel.grabCardSeatId == 0) {
                this.dealCardOrder[1] = 3;
            } else {
                this.dealCardOrder[1] = this.gameModel.grabCardSeatId - 1;
            }

            if (this.dealCardOrder[1] == 0) {
                this.dealCardOrder[2] = 3;
            } else {
                this.dealCardOrder[2] = this.dealCardOrder[1] - 1;
            }

            if (this.dealCardOrder[2] == 0) {
                this.dealCardOrder[3] = 3;
            } else {
                this.dealCardOrder[3] = this.dealCardOrder[2] - 1;
            }
        } else if (this.gameModel.roomConfig.maxPlayerNum == MAHJONG_PLAYERS.TWO) {
            this.dealCardOrder = [0, 0];
            this.dealCardOrder[0] = this.gameModel.grabCardSeatId;
            if (this.gameModel.grabCardSeatId == 0) {
                this.dealCardOrder[1] = 2;
            } else if (this.gameModel.grabCardSeatId == 2) {
                this.dealCardOrder[1] = 0;
            }
        } else if (this.gameModel.roomConfig.maxPlayerNum == MAHJONG_PLAYERS.THREE) {
            this.dealCardOrder = [0, 0, 0];
            this.dealCardOrder[0] = this.gameModel.grabCardSeatId;
            if (this.gameModel.grabCardSeatId == 0) {
                this.dealCardOrder[1] = 3;
            } else if (this.gameModel.grabCardSeatId == 3) {
                this.dealCardOrder[1] = 1;
            } else if (this.gameModel.grabCardSeatId == 1) {
                this.dealCardOrder[1] = 0;
            }

            if (this.dealCardOrder[1] == 0) {
                this.dealCardOrder[2] = 3;
            } else if (this.dealCardOrder[1] == 3) {
                this.dealCardOrder[2] = 1;
            } else if (this.dealCardOrder[1] == 1) {
                this.dealCardOrder[2] = 0;
            }
        }

        this.onStartDealCard(data);

        for (let i = 0; i < data.handCards.length; i++) {
            const cardData = data.handCards[i];
            const seatId = this.gameModel.changSeatId(cardData.chairId);
            if (seatId == MAHJONG_CONST.MY_SEATID) {
                this.myHandCardData = cardData.cards;
            }
            this.gameModel.otherHandCards[seatId] = cardData.cards;
            this.gameModel.gameInfo.remainCardNum -= cardData.cards.length;
        }

        this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
    }

    /**
     * 断线重连发牌
     * @param data 
     */
    onReconnetDealCard(data) {
        const curOperatorSeatId = this.gameModel.changSeatId(this.gameModel.gameInfo.currActionSit);
        const lastOperatorSeatId = this.gameModel.getChariIdToPlayerId(this.gameModel.gameInfo.lastDiscardPlayerId);
        const curMoCardSeatId = this.gameModel.getChariIdToPlayerId(this.gameModel.gameInfo.currDrawCardPlayerId);
        const mySeatId = this.gameModel.changSeatId(this.gameModel.selfChairId);
        const isMoCard = (curOperatorSeatId != lastOperatorSeatId && curOperatorSeatId == mySeatId && curMoCardSeatId == curOperatorSeatId) ? true : false;
        data.handCards.forEach((cardData) => {
            const seatId = this.gameModel.changSeatId(cardData.chairId);
            if (seatId == MAHJONG_CONST.MY_SEATID && isMoCard && curOperatorSeatId == mySeatId) {
                const lastCard = cardData.cards[cardData.cards.length - 1];
                cardData.cards.pop();
                this.gameModel.onSortCardList(cardData.cards);
                cardData.cards.push(lastCard);
                this.updatePlayerHandCards(seatId, cardData.cards.length, cardData.cards, isMoCard);
                this.gameModel.otherHandCards[seatId] = cardData.cards;
                this.spDisCardHintAnim.node.active = true;
            } else {
                this.gameModel.onSortCardList(cardData.cards);
                this.updatePlayerHandCards(seatId, cardData.cards.length, cardData.cards, false);
                this.gameModel.otherHandCards[seatId] = cardData.cards;
            }
        })

        if (this.gameModel.gameInfo.lastDiscardPlayerId == "" && curOperatorSeatId == mySeatId) {
            this.spDisCardHintAnim.node.active = true;
        }

        this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
    }

    /**
     * 回放发牌
     * @param data 
     */
    onShowBackCard(data) {
        data.handCards.forEach((cardData) => {
            const seatId = this.gameModel.changSeatId(cardData.chairId);
            this.gameModel.onSortCardList(cardData.cards);
            this.updateBackHandCards(seatId, cardData.cards.length, cardData.cards, false);
        })
    }

    /**
     * 回放时刷新手中的明牌
     * @param seatId 
     * @param count 
     * @param cardData 
     * @param isMoCard 
     */
    updateBackHandCards(seatId, count, cardData, isMoCard = false) {
        this.nodeHandCards[seatId].removeAllChildren();
        this.gameModel.otherHandCards[seatId] = [];

        let maxCount = this.cardMaxCount;
        if (isMoCard) {
            maxCount = count;
        }

        for (let i = 0; i < count; i++) {
            const handItem = cc.instantiate(this.showCardItem[seatId]);
            handItem["id"] = i;
            handItem["card"] = cardData[i];
            this.gameModel.otherHandCards[seatId].push(cardData[i]);
            handItem.getComponent(MahjongCard).setShowCard(cardData[i]);
            if (seatId == 0) {
                if (i == maxCount - 1) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handItem);
                } else {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handItem);
                }
            } else if (seatId == 1) {
                if (i < 17) { 
                    handItem.setPosition(MahjongCardPosiion.showCardPos2[i]);
                    handItem.zIndex = 17 - i;
                }
            } else if (seatId == 2) {
                if (i == maxCount - 1) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handItem);
                } else {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handItem);
                }
            } else if (seatId == 3) {
                if (i < 17) {
                    handItem.setPosition(MahjongCardPosiion.showCardPos4[i]);
                }
            }
            this.nodeHandCards[seatId].addChild(handItem);
        }
    }

    /**
     * 自己换花
     * @param data 
     */
    onExchangeCard(data, seatId) {
        this.gameModel.onShowAnim(this.spBuHuaAnim[seatId], MAHJONG_ANIM.ReplaceFlower);
        this.gameModel.isDelyHuTime = true;
        this.scheduleOnce(() => {
            this.gameModel.isDelyHuTime = false;
        }, 2.5)
        if (data.flowerCards) {
            this.onShowFlowersCard(data, seatId);
            if (seatId == MAHJONG_CONST.MY_SEATID && !this.gameModel.getIsWatchTheBattle()) {
                // this.gameModel.curOperator = "";
                // this.gameView.nodeClock.getComponent(MahjongClock).onHidelbClock();
                if (data.exchangeCards && data.exchangeCards.length > 0) {
                    this.gameModel.isMoFlowerCard = true;
                    this.gameModel.isBuFlowerAnim = true;
                    this.scheduleOnce(() => {
                        this.gameModel.isMoFlowerCard = false;
                        this.gameModel.isBuFlowerAnim = false;
                    }, 3.0)

                    let idx = 0;
                    let isHaveCard = false;
                    for (let m = 0; m < data.flowerCards.length; m++) {
                        const flowerCard = data.flowerCards[m];
                        for (let k = 0; k < this.mySelfCards.length; k++) {
                            const card = this.mySelfCards[k];
                            if (flowerCard == card) {
                                this.mySelfCards.splice(k, 1);
                                if (data.exchangeCards[idx]) {
                                    const moData = JSON.parse("[" + data.exchangeCards[idx] + "]");
                                    this.onMoCardOperation(MAHJONG_CONST.MY_SEATID, moData, false);
                                    idx += 1;
                                    isHaveCard = true;
                                }
                                break;
                            }
                        }
                    }

                    if (!isHaveCard) {
                        for (let i = this.mySelfCards.length - 1; i >= 0; i--) {
                            const card = this.mySelfCards[i];
                            const isFlower = this.gameModel.isCheckFlowersCard(card);
                            if (isFlower) {
                                this.mySelfCards.splice(i, 1);
                            }
                        }
                        if (data.exchangeCards[0]) {
                            const moData = JSON.parse("[" + data.exchangeCards[0] + "]");
                            this.onMoCardOperation(MAHJONG_CONST.MY_SEATID, moData, false);
                        }
                    }

                    // 听牌后不排序
                    if (!this.gameModel.isMySelfTing && this.gameModel.gameInfo.phase == MAHJONG_GAME_STAGE.replaceFlowersCard) {
                        this.gameModel.onSortCardList(this.mySelfCards);
                        this.updatePlayerHandCards(MAHJONG_CONST.MY_SEATID, this.mySelfCards.length, this.mySelfCards);
                    }
                    cc.log("换花后: " + this.mySelfCards);
                } else {
                    this.gameModel.gameInfo.remainCardNum -= data.flowerCards.length;
                    this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
                }
            } else {
                this.gameModel.gameInfo.remainCardNum -= data.flowerCards.length;
                this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
            }
        }
    }

    /**
     * 回放补花
     * @param data 
     * @param seatId 
     */
    onPlayBackChangeFlowers(data, seatId) {
        this.gameModel.onShowAnim(this.spBuHuaAnim[seatId], MAHJONG_ANIM.ReplaceFlower);
        if (data.flowerCards) {
            this.onShowFlowersCard(data, seatId);
            if (data.exchangeCards && data.exchangeCards.length > 0) {
                let idx = 0;
                let isHaveCard = false;
                for (let m = 0; m < data.flowerCards.length; m++) {
                    const flowerCard = data.flowerCards[m];
                    for (let k = 0; k < this.gameModel.otherHandCards[seatId].length; k++) {
                        const card = this.gameModel.otherHandCards[seatId][k];
                        if (flowerCard == card) {
                            if (data.exchangeCards[idx]) {
                                this.gameModel.otherHandCards[seatId].splice(k, 1);
                                const moData = JSON.parse("[" + data.exchangeCards[idx] + "]");
                                this.updateBackHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
                                this.onPlayBackMoCard(seatId, moData, false);
                                idx += 1;
                                isHaveCard = true;
                                break;
                            }
                        }
                    }
                }

                if (!isHaveCard) {
                    for (let i = this.gameModel.otherHandCards[seatId].length - 1; i >= 0; i--) {
                        const card = this.gameModel.otherHandCards[seatId][i];
                        const isFlower = this.gameModel.isCheckFlowersCard(card);
                        if (isFlower) {
                            this.gameModel.otherHandCards[seatId].splice(i, 1);
                        }
                    }
                    if (data.exchangeCards[0]) {
                        const moData = JSON.parse("[" + data.exchangeCards[0] + "]");
                        this.onPlayBackMoCard(seatId, moData, false);
                    }
                }

                // 听牌后不排序
                if (!this.gameModel.isMySelfTing && this.gameModel.gameInfo.phase == MAHJONG_GAME_STAGE.replaceFlowersCard) {
                    this.gameModel.onSortCardList(this.gameModel.otherHandCards[seatId]);
                    this.updateBackHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
                }
            } else {
                this.gameModel.gameInfo.remainCardNum -= data.flowerCards.length;
                this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
            }
        }
    }

    /**
     * 展示花牌
     * @param data 
     * @param seatId 
     */
    onShowFlowersCard(data, seatId, isAgain = false) {
        for (let i = 0; i < data.flowerCards.length; i++) {
            if (!isAgain) {
                const moData = this.gameModel.onGetFlowerGangIdx(this.gameModel.flowerGangSeat, this.gameModel.flowerGangPos);
                this.nodeCardPiles[moData.seat].getComponent(MahjongCardPiles).onHideMoCard(moData.flowerGangPos);
                this.onShowEightPileMask();
            } else {
                this.gameModel.flowersGangCount += 1;
            }
            const flowerCard = data.flowerCards[i];
            const flowerItem = cc.instantiate(this.flowerCardItem[seatId]);
            flowerItem.getComponent(MahjongCard).setFlowerCardNum(flowerCard);
            flowerItem["card"] = flowerCard;
            let flowerCount = this.nodeFlowerCard[seatId].children.length;
            if (seatId == 1) {
                if (flowerCount < 8) {
                    flowerItem.setPosition(MahjongCardPosiion.flowersCardPos2[flowerCount]);
                    flowerItem.zIndex = this.maxFlowers - flowerCount;
                }
            } else if (seatId == 3) {
                if (flowerCount < 8) {
                    flowerItem.setPosition(MahjongCardPosiion.flowersCardPos4[flowerCount]);
                }
            }
            this.nodeFlowerCard[seatId].addChild(flowerItem);
        }
    }

    /**
     * 刷新玩家手牌
     * @param seatId 
     * @param count 
     * @param cardData 
     */
    updatePlayerHandCards(seatId, count, cardData, isMoCard = false) {
        this.nodeHandCards[seatId].removeAllChildren();
        if (seatId === MAHJONG_CONST.MY_SEATID) {
            this.mySelfCards = [];
        }
        let maxCount = this.cardMaxCount;
        if (isMoCard) {
            maxCount = count;
        }

        for (let i = 0; i < count; i++) {
            const handCard = cc.instantiate(this.handCardItem[seatId]);
            handCard["id"] = i;
            handCard["card"] = cardData[i];
            if (seatId === MAHJONG_CONST.MY_SEATID) {
                if (this.gameModel.getIsWatchTheBattle()) {
                    handCard.getComponent(MahjongCard).setMySelfCardBg();
                } else {
                    handCard.getComponent(MahjongCard).setMySelfCard(cardData[i]);
                    this.onTouchCardListener(handCard);
                }

                this.mySelfCards.push(cardData[i]);
                this.handCardsMap.set(handCard["id"], handCard["card"]);
                if (i == maxCount - 1) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handCard);
                } else {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handCard);
                }
                if (cardData[count - 1]) {
                    this.gameModel.lastDrawData = JSON.parse("[" + cardData[count - 1] + "]");
                }
            } else if (seatId == 1) {
                if (i < 17) {
                    handCard.setPosition(MahjongCardPosiion.handCardPos2[i]);
                    handCard.zIndex = count - i;
                }
            } else if (seatId == 3) {
                if (i < 17) {
                    handCard.setPosition(MahjongCardPosiion.handCardPos4[i]);
                }
            } else if (seatId == 2) {
                if (i == maxCount - 1) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handCard);
                } else {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handCard);
                }
            }
            this.nodeHandCards[seatId].addChild(handCard);
        }
    }

    /**
     * 抓位动画
     */
    onShowRandomWind() {
        this.gameModel.onShowAnim(this.spZhuaWeiAnim, MAHJONG_ANIM.RandomWind);
    }

    /**
     * 其他玩家操作
     * @param data 
     */
    onShowOtherOpaction(actionType, seatId, cards) {
        this.nodeOperation.active = false;
        this.nodeEatCards.active = false;
        this.gameModel.isHaveOperation = false;
        switch (actionType) {
            case MAHJONG_PLAYER_OPERATION.discard:          // 出牌
                if (MahjongRoomMgr.getInstance().isBackView) {
                    this.onPlayBackDisCard(seatId, cards)
                } else {
                    this.onPlayDisCard(seatId, cards)
                }
                break;
            case MAHJONG_PLAYER_OPERATION.eatCard:          // 吃
                this.onEatCardOperation(seatId, cards);
                break;
            case MAHJONG_PLAYER_OPERATION.pengCard:         // 碰
                this.onPengCardOperation(seatId, cards);
                break;
            case MAHJONG_PLAYER_OPERATION.mingGangCard:     // 明杠
            case MAHJONG_PLAYER_OPERATION.pongKongCard:
                this.onMingGangOperation(seatId, cards, true, actionType)
                break;
            case MAHJONG_PLAYER_OPERATION.anGangCard:       // 暗杠
                this.onAnGangOperation(seatId, cards)
                break;
            case MAHJONG_PLAYER_OPERATION.huCard:           // 胡
            case MAHJONG_PLAYER_OPERATION.ziMo:             // 自摸
            case MAHJONG_PLAYER_OPERATION.flowerWin:        // 自摸花胡
            case MAHJONG_PLAYER_OPERATION.robFlowerWin:     // 七抢一花胡
                const time = this.gameModel.isDelyHuTime ? 3.5 : 0;
                this.scheduleOnce(() => {
                    this.gameModel.onPengGangHuAnim(actionType, this.spOperationSign[seatId]);
                    //this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.HuCard, seatId);
                }, time)
                break;
            case MAHJONG_PLAYER_OPERATION.robKongHu:        // 抢杠胡
                this.gameModel.onPengGangHuAnim(actionType, this.spFangPaoGangHu[seatId]);
                break;
            case MAHJONG_PLAYER_OPERATION.readyHand:        // 听牌
                this.onPlayerTing(seatId);
            default:
                break;
        }
    }

    onTouchCardListener(node) {
        node.on(cc.Node.EventType.TOUCH_START, this.onTouchCardStart, this);
        node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchCardMove, this);
        node.on(cc.Node.EventType.TOUCH_END, this.onTouchCardEnd, this);
        node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCardEnd, this);
    }

    onTouchCardStart(event) {
        const touchCard = event.target;
        this.selTouchCardPos = cc.v2(touchCard.x, touchCard.y)
    }

    onTouchCardMove(event) {
        if (this.gameModel.curOperator == PlayerMgr.getInstance().uid && !this.gameModel.winPlayerId && !this.gameModel.isMoFlowerCard &&
            parseInt(this.gameView.nodeClock.getComponent(MahjongClock).lbClock.string) >= 1 && this.gameModel.isDisCard) {
            let delta = event.getDelta();
            let touchCard = event.target;
            touchCard.y += delta.y;

            if (touchCard.y > 0) {
                touchCard.x += delta.x;
                touchCard.isMove = true;
            }
        }
    }

    onTouchCardEnd(event) {
        const touchCard = event.target;
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_PickCard, true);
        if (touchCard.y >= 30) {
            if (this.gameModel.curOperator == PlayerMgr.getInstance().uid && !this.gameModel.winPlayerId && !this.gameModel.isMoFlowerCard && this.gameModel.isDisCard) {
                if (parseInt(this.gameView.nodeClock.getComponent(MahjongClock).lbClock.string) >= 1) {
                    this.sendDisCard(touchCard);
                }
            } else {
                touchCard.y = 0;
            }
        } else {
            touchCard.setPosition(this.selTouchCardPos);
            this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.forEach(element => {
                element.y = 0;
            })
            if (!touchCard.isMove) {
                touchCard.y = 30;
                if (this.gameModel.curPlayerTingCards.length > 0) {
                    if (touchCard.children) {
                        const spTingArrow = touchCard.getChildByName("spTing");
                        if (spTingArrow && spTingArrow.active) {
                            this.gameModel.curPlayerTingCards.forEach((tingCard) => {
                                if (tingCard.cards[0] == touchCard["card"]) {
                                    this.gameModel.curPlayerWinCards = tingCard.winCards;
                                }
                            })
                            this.onShowPlayerHuCards();
                        }
                    }

                } else {
                    this.showSameCard(touchCard["card"]);
                }
            } else {
                touchCard.isMove = false;
            }
        }
    }

    /**
     * 发送出牌
     * @param touchCard 
     */
    sendDisCard(touchCard) {
        this.isCheckCard();
        let type = null;
        const spTingArrow = touchCard.getChildByName("spTing");
        if (spTingArrow && spTingArrow.active && this.gameModel.isTingPush) {
            type = MAHJONG_PLAYER_OPERATION.readyHand;
        } else {
            type = MAHJONG_PLAYER_OPERATION.discard;
        }

        const card = [];
        card.push(touchCard.card);
        this.spDisCardHintAnim.node.active = false;
        this.gameView.onSendOperation(card, type, () => {
            cc.log("打出牌：" + card);
            this.gameModel.curOperator = "";
            this.gameModel.isDisCard = false;
            this.nodeTingCard.active = false;
            if (touchCard) {
                touchCard.destroy();
            }
            if (type == MAHJONG_PLAYER_OPERATION.readyHand) {
                this.spTingBulb.active = true;
                this.gameModel.curPlayerDisTingCard = card;
                this.gameModel.curPlayerTingCards.forEach((tingCard) => {
                    if (tingCard.cards[0] == card) {
                        this.gameModel.curPlayerWinCards = tingCard.winCards;
                    }
                })
            } else {
                if (this.gameModel.curPlayerTingCards.length > 0) {
                    this.gameModel.curPlayerTingCards.forEach((tingCard) => {
                        if (tingCard.cards[0] == card) {
                            this.gameModel.curPlayerWinCards = tingCard.winCards;
                            this.spTingBulb.active = true;
                            this.gameModel.curPlayerDisTingCard = card;
                        }
                    })
                } else {
                    if (!this.gameModel.isMySelfTing) {
                        this.spTingBulb.active = false;
                    }
                }
            }
        })
    }

    /**
     * 出牌
     * @param seatId 
     * @param cardData 
     */
    onPlayDisCard(seatId, cardData, isDelete = true) {
        const disCard = cc.instantiate(this.disCardItem);
        const card = cardData[0];
        disCard.getComponent(MahjongDisCardItem).showDisCard(seatId, this.disCardNum[seatId], card);
        if (this.disCardNum[seatId] < 24) {
            disCard.setPosition(MahjongCardPosiion.disCardPos[seatId][this.disCardNum[seatId]]);
        }
        disCard["card"] = card;
        this.gameModel.AllDisCardPongGangCardItem.push(disCard);
        if (seatId == MAHJONG_CONST.MY_SEATID) {
            if ((4 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 7) ||
                (12 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 15) ||
                (20 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 23)) {
                disCard.zIndex = 24 - this.disCardNum[MAHJONG_CONST.MY_SEATID];
            }
        } else {
            this.onReleseLimitCard();
            if (seatId == 1) {
                disCard.zIndex = 24 - this.disCardNum[seatId];
            } else if (seatId == 2) {
                if ((4 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 7) ||
                    (12 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 15) ||
                    (20 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 23)) {
                    disCard.zIndex = this.disCardNum[seatId] - 24;
                } else {
                    disCard.zIndex = this.disCardNum[seatId];
                }
            }
        }

        if (this.disCardNum[seatId] < 8) {
            this.nodeDisCards[seatId * 3].addChild(disCard);
        } else if (this.disCardNum[seatId] >= 8 && this.disCardNum[seatId] < 16) {
            this.nodeDisCards[seatId * 3 + 1].addChild(disCard);
        } else {
            this.nodeDisCards[seatId * 3 + 2].addChild(disCard);
        }

        this.gameModel.allDisCards.push(card);

        if (isDelete) {
            this.gameModel.isWaterHu = false;
            this.nodeOperation.active = false;
            this.gameModel.isHaveOperation = false;
            this.nodeEatCards.active = false;
            this.spDisCardHintAnim.node.active = false;
            this.gameModel.lastSeatId = seatId;
            this.gameModel.lastCardData = cardData;
            this.gameModel.lastCard = disCard;
            const voiceName = this.gameModel.getCardVoice(card);
            AudioMgr.playSFX(voiceName, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.sound_RowOfCards, true, false)
            if (seatId == MAHJONG_CONST.MY_SEATID) {
                this.onDeleteHandCard(seatId, card, true);
                this.gameModel.onSortCardList(this.mySelfCards);
                this.updatePlayerHandCards(seatId, this.mySelfCards.length, this.mySelfCards);
                this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.DisCard, seatId, this.selTouchCardPos, MahjongCardPosiion.disCardPos[seatId][this.disCardNum[seatId]], this.disCardNum[seatId]);
            } else {
                let haveCards = this.nodeHandCards[seatId].children.length;
                let disCardIdx = Math.floor(haveCards / 2);
                let disCardStarPos: cc.Vec2 = this.nodeHandCards[seatId].children[disCardIdx].getPosition();
                let disCardEndPos: cc.Vec2 = MahjongCardPosiion.disCardPos[seatId][this.disCardNum[seatId]];
                let liCardStartPos: cc.Vec2 = this.nodeHandCards[seatId].children[haveCards - 1].getPosition();
                this.nodeHandCards[seatId].children[disCardIdx].active = false;
                this.onPutCardAnim(seatId, card);
                this.gameModel.otherHandCards[seatId].splice(0, 1);
                this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.DisCard, seatId, disCardStarPos, disCardEndPos);
                let delayTime = this.gameModel.getIsWatchTheBattle() ? 0 : 1.5;
                this.scheduleOnce(() => {
                    this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.LiCard, seatId, liCardStartPos, disCardStarPos);
                }, delayTime)
                this.scheduleOnce(() => {
                    if (MahjongRoomMgr.getInstance().isBackView) {
                        this.updateBackHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
                    } else {
                        this.updatePlayerHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
                    }
                }, delayTime + 0.3)
            }
            this.spDisCardTag.node.active = true;
            if (this.gameModel.lastCard) {
                this.spDisCardTag.node.setPosition(this.gameModel.onGetLastDiaCardPos());
            }
        } else {
            const lastSeatId = this.gameModel.getChariIdToPlayerId(this.gameModel.gameInfo.lastDiscardPlayerId);
            if (lastSeatId == seatId) {
                this.gameModel.lastSeatId = seatId;
                cc.log("上一个操作玩家: " + lastSeatId);
                this.gameModel.lastCardData = cardData;
                this.gameModel.lastCard = disCard;
                this.spDisCardTag.node.active = true;
                if (this.gameModel.lastCard) {
                    this.spDisCardTag.node.setPosition(this.gameModel.onGetLastDiaCardPos());
                }
            }
        }
        this.disCardNum[seatId] += 1;
    }

    /**
     * 回放出牌
     * @param seatId 
     * @param cardData 
     * @param isDelete 
     */
    onPlayBackDisCard(seatId, cardData, isDelete = true) {
        const disCard = cc.instantiate(this.disCardItem);
        const card = cardData[0];
        disCard.getComponent(MahjongDisCardItem).showDisCard(seatId, this.disCardNum[seatId], card);

        if (this.disCardNum[seatId] < 24) {
            disCard.setPosition(MahjongCardPosiion.disCardPos[seatId][this.disCardNum[seatId]]);
        }

        disCard["card"] = card;
        this.gameModel.AllDisCardPongGangCardItem.push(disCard);
        if (seatId == MAHJONG_CONST.MY_SEATID) {
            if ((4 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 7) ||
                (12 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 15) ||
                (20 <= this.disCardNum[MAHJONG_CONST.MY_SEATID] && this.disCardNum[MAHJONG_CONST.MY_SEATID] <= 23)) {
                disCard.zIndex = 24 - this.disCardNum[MAHJONG_CONST.MY_SEATID];
            }
        } else {
            this.onReleseLimitCard();
            if (seatId == 1) {
                disCard.zIndex = 24 - this.disCardNum[seatId];
            } else if (seatId == 2) {
                if ((4 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 7) ||
                    (12 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 15) ||
                    (20 <= this.disCardNum[seatId] && this.disCardNum[seatId] <= 23)) {
                    disCard.zIndex = this.disCardNum[seatId] - 24;
                } else {
                    disCard.zIndex = this.disCardNum[seatId];
                }
            }
        }

        if (this.disCardNum[seatId] < 8) {
            this.nodeDisCards[seatId * 3].addChild(disCard);
        } else if (this.disCardNum[seatId] >= 8 && this.disCardNum[seatId] < 16) {
            this.nodeDisCards[seatId * 3 + 1].addChild(disCard);
        } else {
            this.nodeDisCards[seatId * 3 + 2].addChild(disCard);
        }

        this.gameModel.allDisCards.push(card);

        if (isDelete) {
            this.nodeOperation.active = false;
            this.gameModel.isHaveOperation = false;
            this.nodeEatCards.active = false;
            this.spDisCardHintAnim.node.active = false;
            this.gameModel.lastSeatId = seatId;
            this.gameModel.lastCardData = cardData;
            this.gameModel.lastCard = disCard;
            const voiceName = this.gameModel.getCardVoice(card);
            AudioMgr.playSFX(voiceName, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.sound_RowOfCards, true, false)
            this.gameModel.onSortCardList(this.gameModel.otherHandCards[seatId]);
            this.onDelPlayBackHandCard(seatId, card);
            this.spDisCardTag.node.active = true;
            this.spDisCardTag.node.setPosition(this.gameModel.onGetLastDiaCardPos());
        }
        this.disCardNum[seatId] += 1;
    }

    /**
     * 出牌动画
     * @param seatId 
     * @param cardData 
     */
    onPutCardAnim(seatId, cardData) {
        const card = this.nodeDisCardShow[seatId];
        this.scheduleOnce(() => {
            this.nodeDisCardsBg[seatId].active = true;
        }, 0.2)
        this.scheduleOnce(() => {
            this.nodeDisCardsBg[seatId].active = false;
        }, 0.6)
        card.getComponent(MahjongCard).setCardNum(cardData);
        card.setPosition(this.disCardShowPos[seatId]);
        card.active = true;
        card.setScale(0.5);
        cc.tween(card)
            .to(0.2, { scale: 2.0 })
            .delay(0.4)
            .to(0.2, { scale: 0.1 })
            .call(() => {
                card.active = false;
            })
            .start()
    }

    /**
     * 摸牌操作
     * @param seatId 
     * @param cardData 
     */
    onMoCardOperation(seatId, cardData, isHide = true) {
        cc.log("摸牌: " + cardData);
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_LiCard, true)
        this.nodeOperation.active = false;
        this.gameModel.isHaveOperation = false;
        let count = this.nodeHandCards[seatId].children.length;
        const moCard = cc.instantiate(this.handCardItem[seatId]);
        this.gameModel.gameInfo.remainCardNum -= 1;
        this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
        if (this.gameModel.isHaveGang) {
            this.gameModel.isHaveGang = false;
            let moData = this.gameModel.onGetFlowerGangIdx(this.gameModel.flowerGangSeat, this.gameModel.flowerGangPos);
            this.nodeCardPiles[moData.seat].getComponent(MahjongCardPiles).onHideMoCard(moData.flowerGangPos);
            this.onShowEightPileMask();
        } else {
            if (isHide) {
                this.gameModel.moCardPos += 1;
                let moData = this.gameModel.onGetMoCardIdx(this.gameModel.moCardSeat, this.gameModel.moCardPos);
                this.nodeCardPiles[moData.seat].getComponent(MahjongCardPiles).onHideMoCard(moData.moCardPos);
            }
        }

        if (seatId == MAHJONG_CONST.MY_SEATID) {
            this.spDisCardTag.node.active = false;
            this.gameModel.isDisCard = false;
            this.nodeEatCards.active = false;
            if (this.gameModel.getIsWatchTheBattle()) {
                moCard.getComponent(MahjongCard).setMySelfCardBg();
            } else {
                moCard.getComponent(MahjongCard).setMySelfCard(cardData[0]);
                this.gameModel.isMoFlowerCard = this.gameModel.isCheckFlowersCard(cardData[0]);
                if (this.gameModel.isMoFlowerCard) {
                    this.scheduleOnce(() => {
                        this.gameModel.isMoFlowerCard = false;
                    }, 2.0)
                }
            }
            this.gameModel.lastDrawData = cardData;
            this.mySelfCards.push(cardData[0]);
            moCard["card"] = cardData[0];
            this.onTouchCardListener(moCard);
            if (this.gameModel.isMySelfTing && !this.gameModel.getIsWatchTheBattle()) {
                const isFlower = this.gameModel.isCheckFlowersCard(cardData[0]);
                if (!isFlower) {
                    this.gameModel.isDelyHuTime = true;
                    this.scheduleOnce(() => {
                        const isHu = this.gameModel.isCheckHuCard(cardData[0]);
                        App.loadGamePopul({
                            prefabName: "miCardAnim",
                            prefabPath: "prefab/mahjongCard/miCardAnim",
                            prefabComponent: "mahjongMiCardAnim",
                            data: { cardData: cardData[0], hu: isHu },
                        })
                        this.gameModel.isDelyHuTime = true;
                        this.scheduleOnce(() => {
                            this.gameModel.isDelyHuTime = false;
                        }, 2.5)
                        this.scheduleOnce(() => {
                            if (isHu) {
                                this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                                this.nodeHandCards[seatId].addChild(moCard);
                            } else {
                                if (!this.gameModel.isBuGang) {
                                    this.sendDisCard(moCard);
                                } else {
                                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                                    this.nodeHandCards[seatId].addChild(moCard);
                                }
                            }
                        }, 1.6)
                    }, 0.3)
                } else {
                    if (moCard) {
                        moCard.destroy();
                    }
                }
            } else {
                this.spTingBulb.active = false;
                const isFlower = this.gameModel.isCheckFlowersCard(cardData[0]);
                if (!isFlower) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                    this.nodeHandCards[seatId].addChild(moCard);
                } else {
                    if (moCard) {
                        moCard.destroy();
                    }
                }
            }
        } else {
            if (seatId == 1) {
                cc.log("下家: " + count);
                if (count <= 16) {
                    const pos = cc.v2(MahjongCardPosiion.handCardPos2[count].x - 5, MahjongCardPosiion.handCardPos2[count].y + 10);
                    moCard.setPosition(pos);
                }
                this.gameModel.otherHandCards[seatId].push(cardData[0]);
            } else if (seatId == 3) {
                cc.log("上家: " + count);
                if (count <= 16) {
                    const pos = cc.v2(MahjongCardPosiion.handCardPos4[count].x - 4, MahjongCardPosiion.handCardPos4[count].y - 8);
                    moCard.setPosition(pos);
                }
                this.gameModel.otherHandCards[seatId].push(cardData[0]);
            } else if (seatId == 2) {
                cc.log("对家: " + count)
                this.gameModel.otherHandCards[seatId].push(cardData[0]);
                this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
            }
            this.nodeHandCards[seatId].addChild(moCard);
        }
    }

    /**
     * 回放摸牌
     * @param seatId 
     * @param cardData 
     * @param isHide 
     */
    onPlayBackMoCard(seatId, cardData, isHide = true) {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_LiCard, true)
        this.nodeOperation.active = false;
        this.gameModel.isHaveOperation = false;
        let count = this.nodeHandCards[seatId].children.length;
        const moCard = cc.instantiate(this.showCardItem[seatId]);
        this.gameModel.gameInfo.remainCardNum -= 1;
        this.gameView.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
        if (this.gameModel.isHaveGang) {
            this.gameModel.isHaveGang = false;
            let moData = this.gameModel.onGetFlowerGangIdx(this.gameModel.flowerGangSeat, this.gameModel.flowerGangPos);
            this.nodeCardPiles[moData.seat].getComponent(MahjongCardPiles).onHideMoCard(moData.flowerGangPos);
            this.onShowEightPileMask();
        } else {
            if (isHide) {
                this.gameModel.moCardPos += 1;
                let moData = this.gameModel.onGetMoCardIdx(this.gameModel.moCardSeat, this.gameModel.moCardPos);
                this.nodeCardPiles[moData.seat].getComponent(MahjongCardPiles).onHideMoCard(moData.moCardPos);
            }
        }

        moCard.getComponent(MahjongCard).setShowCard(cardData[0]);
        this.gameModel.lastDrawData = cardData;
        this.gameModel.otherHandCards[seatId].push(cardData[0]);
        moCard["card"] = cardData[0];

        if (seatId == MAHJONG_CONST.MY_SEATID) {
            this.gameModel.isDisCard = false;
            this.nodeEatCards.active = false;
            this.gameModel.isMoFlowerCard = this.gameModel.isCheckFlowersCard(cardData[0]);
            if (this.gameModel.isMoFlowerCard) {
                this.scheduleOnce(() => {
                    this.gameModel.isMoFlowerCard = false;
                }, 2.0)
            }
            if (this.gameModel.isMySelfTing && !this.gameModel.getIsWatchTheBattle()) {
                const isFlower = this.gameModel.isCheckFlowersCard(cardData[0]);
                if (!isFlower) {
                    const isHu = this.gameModel.isCheckHuCard(cardData[0]);
                    this.gameModel.isDelyHuTime = true;
                    this.scheduleOnce(() => {
                        this.gameModel.isDelyHuTime = false;
                    }, 2.5)
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                    this.nodeHandCards[seatId].addChild(moCard);
                } else {
                    moCard.destroy();
                }
            } else {
                this.spTingBulb.active = false;
                const isFlower = this.gameModel.isCheckFlowersCard(cardData[0]);
                if (!isFlower) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                    this.nodeHandCards[seatId].addChild(moCard);
                } else {
                    if (moCard) {
                        moCard.destroy();
                    }
                }
            }
        } else {
            if (seatId == 1) {
                cc.log("右侧玩家: " + count);
                if (count <= 16) {
                    let pos = cc.v2(MahjongCardPosiion.handCardPos2[count].x + 5, MahjongCardPosiion.handCardPos2[count].y + 10);
                    moCard.setPosition(pos);
                }
            } else if (seatId == 3) {
                cc.log("左侧玩家: " + count);
                if (count <= 16) {
                    let pos = cc.v2(MahjongCardPosiion.handCardPos4[count].x - 4, MahjongCardPosiion.handCardPos4[count].y - 8);
                    moCard.setPosition(pos);
                }
            }
            const isFlower = this.gameModel.isCheckFlowersCard(cardData[0]);
            if (!isFlower) {
                if (seatId == 2) {
                    this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(moCard);
                }
                this.nodeHandCards[seatId].addChild(moCard);
            } else {
                moCard.destroy();
            }
        }
    }

    /**
     * 吃牌操作
     * @param seatId 
     * @param cardData 
     */
    onEatCardOperation(seatId, cardData, isDelete = true) {
        const eatCard = cc.instantiate(this.pengItem[seatId]);
        let eatData = null;
        if (isDelete) {
            if (this.gameModel.lastCardData) {
                eatData = this.gameModel.getEatCardList(this.gameModel.lastCardData[0], cardData);
            } else {
                eatData = cardData;
            }
        } else {
            eatData = cardData;
        }

        eatCard.getComponent(MahjongCard).setEatCardNum(eatData);
        this.nodePengCards[seatId].active = true;
        this.nodeEatCards.active = false;
        if (seatId == 1 || seatId == 3) {
            this.onSetLeftRightPengGangPos(seatId, eatCard);
        }

        this.pengGangCount[seatId] += 1;
        this.nodePengCards[seatId].addChild(eatCard);
        this.gameModel.onManageMingCard(eatCard, eatData, seatId);
        if (isDelete) {
            this.spDisCardTag.node.active = false;
            this.onDeleteLastCard(cardData);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Chow, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_DisplayBoards, true)
            const pos = Utils.changToNodePoint(eatCard, this.gameView.spLightWuAnim.node);
            this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.wu_chipanggang, pos);
            this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.PongKongChi, seatId, this.pengGangCount[seatId]);
            this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.eatCard, this.spOperationSign[seatId]);
            this.gameModel.onSortCardList(this.mySelfCards);
            cardData.forEach((card) => {
                if (card != this.gameModel.lastCardData[0]) {
                    this.gameModel.allDisCards.push(card);
                    if (seatId == MAHJONG_CONST.MY_SEATID) {
                        this.onDeleteHandCard(seatId, card, true, true);
                        cc.log("吃牌: " + cardData);
                    } else {
                        this.onDeleteHandCard(seatId, card, false, true);
                    }
                }
            })

            if (seatId != MAHJONG_CONST.MY_SEATID && !MahjongRoomMgr.getInstance().isBackView) {
                this.updatePlayerHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
            }
        }
    }

    /**
     * 碰牌操作
     * @param seatId 
     * @param cardData 
     */
    onPengCardOperation(seatId, cardData, isDelete = true) {
        const pengCard = cc.instantiate(this.pengItem[seatId]);
        pengCard.getComponent(MahjongCard).setCardNum(cardData[0]);
        pengCard["card"] = cardData[0];
        pengCard["type"] = MAHJONG_PLAYER_OPERATION.pengCard;
        this.nodePengCards[seatId].active = true;
        if (seatId == 1 || seatId == 3) {
            this.onSetLeftRightPengGangPos(seatId, pengCard);
        }
        this.pengGangCount[seatId] += 1;
        this.nodePengCards[seatId].addChild(pengCard);
        this.gameModel.onManageMingCard(pengCard, cardData, seatId);

        if (isDelete) {
            this.spDisCardTag.node.active = false;
            this.onDeleteLastCard(cardData);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Peng, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_DisplayBoards, true)
            const pos = Utils.changToNodePoint(pengCard, this.gameView.spLightWuAnim.node);
            this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.wu_chipanggang, pos);
            this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.PongKongChi, seatId, this.pengGangCount[seatId]);
            this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.pengCard, this.spOperationSign[seatId]);
            this.gameModel.onSortCardList(this.mySelfCards);
            for (let i = 0; i < 2; i++) {
                this.gameModel.allDisCards.push(cardData[0]);
                if (seatId == MAHJONG_CONST.MY_SEATID) {
                    this.onDeleteHandCard(seatId, cardData[0], true, true);
                    cc.log("碰牌: " + cardData);
                } else {
                    this.onDeleteHandCard(seatId, cardData[0], false, true);
                }
            }

            if (seatId != MAHJONG_CONST.MY_SEATID && !MahjongRoomMgr.getInstance().isBackView) {
                this.updatePlayerHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
            }
        }
    }

    /**
     * 明杠牌操作
     * @param seatId 
     * @param cardData 
     */
    onMingGangOperation(seatId, cardData, isDelete = true, actionType?) {
        const mingGangCard = cc.instantiate(this.mingGangItem[seatId]);
        mingGangCard.getComponent(MahjongCard).setCardNum(cardData[0]);
        this.nodePengCards[seatId].active = true;
        this.onGangAfterPeng(seatId, cardData[0], isDelete);
        this.onSetLeftRightPengGangPos(seatId, mingGangCard);
        this.pengGangCount[seatId] += 1;
        this.nodePengCards[seatId].addChild(mingGangCard);
        this.gameModel.isHaveGang = true;

        if (isDelete) {
            this.spDisCardTag.node.active = false;
            this.onDeleteLastCard(cardData);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Kong, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_DisplayBoards, true)
            if (this.gameView.spLightWuAnim) {
                const pos = Utils.changToNodePoint(mingGangCard, this.gameView.spLightWuAnim.node);
                this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.wu_chipanggang, pos);
            }
            this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.PongKongChi, seatId, this.pengGangCount[seatId]);
            this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.mingGangCard, this.spOperationSign[seatId]);
            this.gameModel.onSortCardList(this.mySelfCards);
            const isPengGnag = this.isCheckPengGang(seatId, cardData[0]);
            let deleteCount = isPengGnag ? 1 : 3;
            if (actionType) {
                if (actionType == MAHJONG_PLAYER_OPERATION.mingGangCard) {
                    deleteCount = 3;
                } else if (actionType == MAHJONG_PLAYER_OPERATION.pongKongCard) {
                    deleteCount = 1;
                }
            }
            cc.log("杠牌数量: " + deleteCount)
            for (let i = 0; i < deleteCount; i++) {
                this.gameModel.allDisCards.push(cardData[0]);
                if (seatId == MAHJONG_CONST.MY_SEATID) {
                    cc.log("明杠: " + cardData);
                    this.onDeleteHandCard(seatId, cardData[0], true, true);
                } else {
                    this.onDeleteHandCard(seatId, cardData[0], false, true);
                }
            }
            if (seatId != MAHJONG_CONST.MY_SEATID && !MahjongRoomMgr.getInstance().isBackView) {
                this.updatePlayerHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
            }
        }
    }

    /**
     * 暗杠牌操作
     * @param curSeatId 
     * @param cardData 
     */
    onAnGangOperation(seatId, cardData, isDelete = true) {
        const anGangCard = cc.instantiate(this.anGangItem[seatId]);
        if (seatId == MAHJONG_CONST.MY_SEATID) {
            if (this.gameModel.getIsWatchTheBattle()) {
                anGangCard.getComponent(MahjongCard).setAnGangCardBg();
            } else {
                anGangCard.getComponent(MahjongCard).setCardNum(cardData[0]);
            }
            this.spTingCardMask.width = this.spTingCardMask.width - 3 * this.cardWidth;
        }
        if (seatId == 1 || seatId == 3) {
            this.onSetLeftRightPengGangPos(seatId, anGangCard);
        }
        this.pengGangCount[seatId] += 1;
        this.nodePengCards[seatId].active = true;
        this.nodePengCards[seatId].addChild(anGangCard);
        this.gameModel.isHaveGang = true;

        if (isDelete) {
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Kong, true, true);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_DisplayBoards, true)
            const pos = Utils.changToNodePoint(anGangCard, this.gameView.spLightWuAnim.node);
            this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.wu_chipanggang, pos);
            this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.PongKongChi, seatId, this.pengGangCount[seatId]);
            this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.mingGangCard, this.spOperationSign[seatId]);
            this.onGangAfterPeng(seatId, cardData[0]);
            this.gameModel.onSortCardList(this.mySelfCards);
            for (let i = 0; i < 4; i++) {
                if (seatId == MAHJONG_CONST.MY_SEATID) {
                    this.gameModel.allDisCards.push(cardData[0]);
                    cc.log("暗杠: " + cardData);
                    this.onDeleteHandCard(seatId, cardData[0], true, true);
                } else {
                    this.onDeleteHandCard(seatId, cardData[0], false, true);
                }
            }
            if (seatId != MAHJONG_CONST.MY_SEATID && !MahjongRoomMgr.getInstance().isBackView) {
                this.updatePlayerHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
            }
        }
    }

    /**
     * 碰牌后摸到杠牌
     * @param seatId 
     * @param gangCardVal 
     */
    onGangAfterPeng(seatId, gangCardVal, isDelete = true) {
        if (!isDelete) { return }
        const gangCards = this.nodePengCards[seatId].children;
        if (gangCards) {
            gangCards.forEach((gangItem) => {
                if (gangItem["type"]) {
                    if (gangItem["card"] == gangCardVal) {
                        this.pengGangCount[seatId] -= 1;
                        this.nodePengCards[seatId].removeChild(gangItem);
                        if (gangItem) {
                            gangItem.destroy();
                        }
                        this.updatePengGangPos(seatId);
                    }
                }
            })
        }
    }

    updatePengGangPos(seatId) {
        for (let i = 0; i < this.nodePengCards[seatId].children.length; i++) {
            const item = this.nodePengCards[seatId].children[i];
            if (i < 5) {
                if (seatId == 1) {
                    item.setPosition(MahjongCardPosiion.pengGangCardPos2[i]);
                } else if (seatId == 3) {
                    item.setPosition(MahjongCardPosiion.pengGangCardPos4[i]);
                }
            }
        }
    }

    /**
     * 检测是否是碰杠
     * @param seatId 
     * @param gangCardVal 
     * @returns 
     */
    isCheckPengGang(seatId, gangCardVal) {
        let isPengGang = false;
        const gangCards = this.nodePengCards[seatId].children;
        if (gangCards) {
            gangCards.forEach((gangItem) => {
                if (gangItem["type"]) {
                    if (gangItem["card"] == gangCardVal) {
                        isPengGang = true
                    }
                }
            })
        }
        return isPengGang;
    }

    /**
     * 玩家听牌
     * @param seatId 
     */
    onPlayerTing(seatId, isAgain = false) {
        this.gameView.players[seatId].showTing(true);
        if (!isAgain) {
            this.gameModel.onPengGangHuAnim(MAHJONG_PLAYER_OPERATION.readyHand, this.spOperationSign[seatId]);
            AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_WaitOne, true, true);
        }
        if (seatId == MAHJONG_CONST.MY_SEATID && !this.gameModel.getIsWatchTheBattle()) {
            this.gameModel.isMySelfTing = true;
            this.spTingBulb.active = true;
            let cardCount = this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.length;
            const maskWidth = cardCount * this.cardWidth;
            this.spTingCardMask.width = maskWidth;
            this.spTingCardMask.active = true;
        }
    }

    /**
     * 删除最后一张牌
     * @param cardDatas 
     */
    onDeleteLastCard(cardDatas) {
        for (let i = 0; i < cardDatas.length; i++) {
            const card = cardDatas[i];
            if (this.gameModel.lastCardData) {
                if (this.gameModel.lastCardData[0] == card) {
                    if (this.gameModel.lastCard) {
                        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_TakeAwayCards, true);
                        this.gameModel.lastCard.destroy();
                        this.gameModel.lastCard = null;
                        this.disCardNum[this.gameModel.lastSeatId] -= 1;
                    }
                }
            }
        }
    }

    /**
     * 删除手中的牌并刷新
     * @param seatId 
     * @param card 
     */
    onDeleteHandCard(seatId, disCard, isMyself, isPengGang = false) {
        if (isMyself) {
            if (!MahjongRoomMgr.getInstance().isBackView) {
                if (!this.gameModel.getIsWatchTheBattle()) {
                    for (let i = 0; i < this.mySelfCards.length; i++) {
                        let myCard = this.mySelfCards[i];
                        if (myCard == disCard) {
                            this.mySelfCards.splice(i, 1);
                            break;
                        }
                    }
                    this.updatePlayerHandCards(seatId, this.mySelfCards.length, this.mySelfCards);
                    cc.log("我的剩余牌张: " + this.mySelfCards);
                } else {
                    this.mySelfCards.splice(0, 1);
                    this.updatePlayerHandCards(seatId, this.mySelfCards.length, this.mySelfCards);
                }
            } else {
                this.onDelPlayBackHandCard(seatId, disCard);
            }
        } else {
            if (isPengGang) {
                if (!MahjongRoomMgr.getInstance().isBackView) {
                    this.gameModel.otherHandCards[seatId].splice(0, 1);
                } else {
                    this.onDelPlayBackHandCard(seatId, disCard);
                }
            }
        }
    }

    onDelPlayBackHandCard(seatId, disCard) {
        for (let i = this.gameModel.otherHandCards[seatId].length - 1; i >= 0; i--) {
            const card = this.gameModel.otherHandCards[seatId][i];
            if (card == disCard) {
                this.gameModel.otherHandCards[seatId].splice(i, 1);
                break;
            }
        }
        this.updateBackHandCards(seatId, this.gameModel.otherHandCards[seatId].length, this.gameModel.otherHandCards[seatId]);
    }

    /**
     * 玩家点击操作
     * @param actionType 
     */
    onPlayerOperator(actionType) {
        this.gameModel.isHaveOperation = false;
        if (actionType == MAHJONG_PLAYER_OPERATION.eatCard) {
            if (this.gameModel.curPlayerEatCards.length == 1) {
                const eatData = JSON.parse("[" + this.gameModel.curPlayerEatCards + "]");
                this.gameView.onSendOperation(eatData, actionType, () => {
                    if (!this.gameModel.isHaveOperation) {
                        this.nodeOperation.active = false;
                    }
                });
            } else {
                this.onShowPlayerEatCards();
            }
        } else if (actionType == MAHJONG_PLAYER_OPERATION.readyHand) {
            this.gameModel.isTingPush = true;
            this.nodeOperation.active = false;
        } else if (actionType == MAHJONG_PLAYER_OPERATION.overLeap) {
            this.gameView.onSendOperation([], actionType)
            this.nodeOperation.active = false;
        } else {
            let operationCard = null;
            operationCard = this.gameModel.lastCardData;

            if (actionType == MAHJONG_CONST.GANG_CARD) {
                if (this.gameModel.curAnPongGangCards.length && (this.gameModel.curAnPongGangCards[0].cards.length > 1 ||
                    this.gameModel.curAnPongGangCards.length > 1)) {
                    this.onShowPlayerGangCards();
                } else {
                    for (let i = 0; i < this.gameModel.curPlayerOptions.length; i++) {
                        const option = this.gameModel.curPlayerOptions[i];
                        if (option == MAHJONG_PLAYER_OPERATION.anGangCard) {
                            actionType = MAHJONG_PLAYER_OPERATION.anGangCard;
                            if (this.gameModel.curAnPongGangCards[0].cards[0]) {
                                operationCard = JSON.parse("[" + this.gameModel.curAnPongGangCards[0].cards[0] + "]");
                            }
                        } else if (option == MAHJONG_PLAYER_OPERATION.mingGangCard) {
                            actionType = MAHJONG_PLAYER_OPERATION.mingGangCard;
                        } else if (option == MAHJONG_PLAYER_OPERATION.pongKongCard) {
                            actionType = MAHJONG_PLAYER_OPERATION.pongKongCard;
                            if (this.gameModel.curAnPongGangCards[0].cards[0]) {
                                operationCard = JSON.parse("[" + this.gameModel.curAnPongGangCards[0].cards[0] + "]");
                            }
                        }
                    }
                    this.gameView.onSendOperation(operationCard, actionType);
                }
            } else if (actionType == MAHJONG_CONST.HU_CARD) {
                for (let i = 0; i < this.gameModel.curPlayerOptions.length; i++) {
                    const option = this.gameModel.curPlayerOptions[i];
                    if (option == MAHJONG_PLAYER_OPERATION.ziMo) {
                        operationCard = this.gameModel.lastDrawData;
                        actionType = MAHJONG_PLAYER_OPERATION.ziMo;
                    } else if (option == MAHJONG_PLAYER_OPERATION.huCard) {
                        actionType = MAHJONG_PLAYER_OPERATION.huCard;
                    } else if (option == MAHJONG_PLAYER_OPERATION.robKongHu) {
                        actionType = MAHJONG_PLAYER_OPERATION.robKongHu;
                    } else if (option == MAHJONG_PLAYER_OPERATION.robFlowerWin) {
                        actionType = MAHJONG_PLAYER_OPERATION.robFlowerWin;
                    } else if (option == MAHJONG_PLAYER_OPERATION.flowerWin) {
                        actionType = MAHJONG_PLAYER_OPERATION.flowerWin;
                    }
                }
                this.gameView.onSendOperation(operationCard, actionType, () => {
                    this.nodeOperation.active = false;
                })
                this.spDisCardHintAnim.node.active = false;
            } else if (actionType == MAHJONG_PLAYER_OPERATION.pengCard) {
                this.gameView.onSendOperation(operationCard, actionType, () => {
                    if (!this.gameModel.isHaveOperation) {
                        this.nodeOperation.active = false;
                    }
                })
            }
        }
    }

    /**
     * 展示玩家吃牌
     * @param actionType 
     */
    onShowPlayerEatCards() {
        this.nodeOperation.active = false;
        this.nodeEatCards.active = true;
        this.nodeEatCards.destroyAllChildren();
        this.gameModel.onSortEatList(this.gameModel.curPlayerEatCards);
        for (let i = 0; i < this.gameModel.curPlayerEatCards.length; i++) {
            const eatCard = this.gameModel.curPlayerEatCards[i];
            const eatItem = cc.instantiate(this.pengItem[MAHJONG_CONST.MY_SEATID]);
            eatItem.getComponent(MahjongCard).setEatCardNum(eatCard);
            this.nodeEatCards.addChild(eatItem);

            const handler = new cc.Component.EventHandler();
            handler.component = "mahjongTilesView";
            handler.customEventData = `${eatCard}`;
            handler.target = this.node;
            handler.handler = "onSelTouchEatCard";
            eatItem.getComponent(cc.Button).clickEvents.push(handler);
        }
    }

    /**
     * 展示玩家杠牌
     */
    onShowPlayerGangCards() {
        this.nodeOperation.active = false;
        this.nodeEatCards.active = true;
        this.nodeEatCards.destroyAllChildren();

        for (let i = 0; i < this.gameModel.curAnPongGangCards.length; i++) {
            const gangData = this.gameModel.curAnPongGangCards[i];
            for (let m = 0; m < gangData.cards.length; m++) {
                const gangCard = gangData.cards[m];
                const gangItem = cc.instantiate(this.mingGangItem[MAHJONG_CONST.MY_SEATID]);
                gangItem.getComponent(MahjongCard).setCardNum(gangCard);
                this.nodeEatCards.addChild(gangItem);

                const handler = new cc.Component.EventHandler();
                handler.component = "mahjongTilesView";
                const obj = { data: gangCard, actionType: gangData.reqType };
                handler.customEventData = `${JSON.stringify(obj)}`;
                handler.target = this.node;
                handler.handler = "onSelTouchGangCard";
                gangItem.getComponent(cc.Button).clickEvents.push(handler);
            }
        }
    }

    onSelTouchEatCard(event, data) {
        if (data) {
            const eatData = JSON.parse("[" + data + "]");
            this.gameView.onSendOperation(eatData, MAHJONG_PLAYER_OPERATION.eatCard, () => {
                this.nodeEatCards.active = false;
            })
        }
    }

    onSelTouchGangCard(event, data) {
        if (data) {
            const str = JSON.parse(data);
            const card = str.data;
            const actionType = str.actionType;
            const gangData = JSON.parse("[" + card + "]");
            this.gameView.onSendOperation(gangData, actionType);
        }
    }

    /**
     * 听牌小箭头
     * @param data 
     */
    onShowTingArrow() {
        for (let i = 0; i < this.gameModel.curPlayerTingCards.length; i++) {
            const tingData = this.gameModel.curPlayerTingCards[i];
            for (let m = 0; m < this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.length; m++) {
                const handCard = this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children[m];
                if (tingData.cards[0] == handCard["card"]) {
                    if (handCard.children) {
                        if (handCard.getChildByName("spTing")) {
                            handCard.getChildByName("spTing").active = true;
                        }
                    }
                }
            }
        }
    }

    /**
     * 听牌状态下断线且我可以出牌，打出最后一张牌
     */
    onReconnectDisCard() {
        if (this.gameModel.curOperator == PlayerMgr.getInstance().uid && this.gameModel.gameInfo.phase != MAHJONG_GAME_STAGE.Settle) {
            if (this.gameModel.curPlayerDisCards.length > 0) {
                const card = this.gameModel.curPlayerDisCards[this.gameModel.curPlayerDisCards.length - 1];
                for (let m = 0; m < this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.length; m++) {
                    const handCard = this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children[m];
                    if (handCard && card == handCard["card"]) {
                        this.sendDisCard(handCard);
                        this.gameModel.isMySelfTing = true;
                        this.spTingBulb.active = true;
                        let cardCount = this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.length;
                        const maskWidth = cardCount * this.cardWidth;
                        this.spTingCardMask.width = maskWidth;
                        this.spTingCardMask.active = true;
                    }
                }
            }
        }
    }

    /**
     * 玩家胡牌列表
     */
    onShowPlayerHuCards() {
        if (this.gameModel.curPlayerWinCards && this.gameModel.curPlayerWinCards.length > 0) {
            this.nodeTingCard.active = true;
            this.nodeHuCardView2.destroyAllChildren();
            this.nodeHuCardView1.destroyAllChildren();
            let nodeHu = null;

            if (this.gameModel.curPlayerWinCards.length <= 5) {
                this.nodeTing[0].active = false;
                this.nodeTing[1].active = true;
                nodeHu = this.nodeHuCardView2;
            } else {
                this.nodeTing[0].active = true;
                this.nodeTing[1].active = false;
                nodeHu = this.nodeHuCardView1;
            }

            for (let i = 0; i < this.gameModel.curPlayerWinCards.length; i++) {
                const winCard = this.gameModel.curPlayerWinCards[i];
                const huCardItem = cc.instantiate(this.tingItem);
                huCardItem.getComponent(MahjongCard).setCardNum(winCard.winCard);
                let cardCount = this.getCardSurplusCount(winCard.winCard);
                huCardItem.getComponent(MahjongHuCardItem).initItem({ point: winCard.totalPoint, count: cardCount })
                nodeHu.addChild(huCardItem);
            }
        }
    }

    /**
     * 点击听牌小灯泡
     */
    onTouchTingBulb() {
        if (!this.nodeTingCard.active) {
            this.onShowPlayerHuCards();
        } else {
            this.nodeTingCard.active = false;
        }

    }

    onCloseTingView() {
        this.nodeTingCard.active = false;
    }

    /**
     * 显示相同的牌
     * @param card 
     */
    showSameCard(card) {
        if (this.gameModel.AllDisCardPongGangCardItem && this.gameModel.AllDisCardPongGangCardItem.length > 0) {
            for (let i = 0; i < this.gameModel.AllDisCardPongGangCardItem.length; i++) {
                const item = this.gameModel.AllDisCardPongGangCardItem[i];
                if (item && item.active) {
                    if (item.children) {
                        if (item.getChildByName("spMask")) {
                            const spMask = item.getChildByName("spMask");
                            if (spMask) {
                                if (item["card"] == card) {
                                    spMask.active = true;
                                } else {
                                    spMask.active = false;
                                }
                            }
                        }
                    }
                }
            }

            this.scheduleOnce(() => {
                for (let i = 0; i < this.gameModel.AllDisCardPongGangCardItem.length; i++) {
                    const item = this.gameModel.AllDisCardPongGangCardItem[i];
                    if (item && item.active) {
                        if (item.children) {
                            if (item.getChildByName("spMask")) {
                                item.getChildByName("spMask").active = false;
                            }
                        }
                    }
                }
            }, 3.0)
        }
    }

    /**
     * 玩家可以操作的类型
     */
    onShowOperationNode(data) {
        data.options.forEach(option => {
            if (option.reqType != MAHJONG_PLAYER_OPERATION.discard) {
                this.nodeOperation.active = true;
                this.gameModel.isHaveOperation = true;
                this.nodeTingCard.active = false;
                if (this.spOperationSign[MAHJONG_CONST.MY_SEATID].node.active) {
                    cc.Tween.stopAllByTarget(this.spOperationSign[MAHJONG_CONST.MY_SEATID].node);
                    this.spOperationSign[MAHJONG_CONST.MY_SEATID].node.active = false;
                }
                this.nodeOperation.getComponent(MahjongOperation).setButtonData(option.reqType);
            }
        })

        if (this.gameModel.curPlayerTingCards.length > 0) {
            this.onShowTingArrow();
        } else {
            if (!this.gameModel.isMySelfTing && this.gameModel.curOperator == PlayerMgr.getInstance().uid) {
                this.spTingBulb.active = false;
            }
        }
    }

    /**
     * 获取左右玩家碰杠位置
     * @param seatId 
     * @param nodeCard 
     */
    onSetLeftRightPengGangPos(seatId, nodeCard) {
        let count = this.pengGangCount[seatId];
        if (count < 5) {
            if (seatId == 1) {
                nodeCard.setPosition(MahjongCardPosiion.pengGangCardPos2[count])
            } else if (seatId == 3) {
                nodeCard.setPosition(MahjongCardPosiion.pengGangCardPos4[count])
            }
        }
    }

    isCheckCard() {
        if (this.gameModel.curPlayerDisCards) {
            if (this.gameModel.curPlayerDisCards.sort()) {
                if (this.gameModel.curPlayerDisCards.sort().toString() == this.mySelfCards.sort().toString()) {
                    return true;
                } else {
                    cc.warn("麻将牌错误", "后端: " + this.gameModel.curPlayerDisCards, "前端: " + this.mySelfCards)
                }
            }
        }
    }

    /**
     * 获取这张牌的剩余数量
     * @param card 
     */
    getCardSurplusCount(card) {
        let count = 0;
        for (let i = 0; i < this.gameModel.allDisCards.length; i++) {
            if (card == this.gameModel.allDisCards[i]) {
                count++;
            }
        }
        for (let i = 0; i < this.mySelfCards.length; i++) {
            if (card == this.mySelfCards[i]) {
                count++;
            }
        }
        if (count >= 4) {
            count = 4;
        }
        return 4 - count;
    }

    /**
     * 摊牌
     * @param data 
     */
    onShowDownCard(data) {
        if (MahjongRoomMgr.getInstance().isBackView) { return }
        this.spTingCardMask.active = false;
        this.nodeTing[0].active = false;
        this.nodeTing[1].active = false;
        this.gameView.nodeClock.getComponent(MahjongClock).onHideClock();
        for (let i = 0; i < MAHJONG_CONST.PLAYERS_NUM; i++) {
            this.nodePengCards[i].removeAllChildren();
            this.nodeHandCards[i].removeAllChildren();
            this.nodePengCards[i].width = 0;
            this.nodeHandCards[i].width = 0;
        }

        let cardCount = this.cardMaxCount;

        let winSeatId = null;
        for (let i = 0; i < data.length; i++) {
            const playerData = data[i];
            if (playerData.playerId) {
                let seatId = this.gameModel.getChariIdToPlayerId(playerData.playerId);
                this.gameView.onShowHandAnim(MAHJONG_HAND_TYPE.TanCard, seatId);
                this.gameModel.onSortCardList(playerData.handCards);
                if (playerData.settleScore > 0) {
                    let idx = this.gameModel.onGetWinCardIdx(playerData);
                    if (idx > -1) {
                        playerData.handCards.splice(idx, 1);
                        playerData.handCards.push(playerData.winCards[0]);
                        cardCount = playerData.handCards.length;
                    }
                    winSeatId = seatId;
                }

                playerData.handCards.forEach((card, idx) => {
                    if (this.showCardItem[seatId]) {
                        const handItem = cc.instantiate(this.showCardItem[seatId]);
                        handItem.getComponent(MahjongCard).setShowCard(card);
                        if (seatId == 0) {
                            if (idx == cardCount - 1 && playerData.settleScore > 0) {
                                this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handItem);
                            } else {
                                this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handItem);
                            }
                        } else if (seatId == 1) {
                            if (idx < 17) {
                                handItem.setPosition(MahjongCardPosiion.showCardPos2[idx]);
                                handItem.zIndex = 17 - idx;
                            }
                        } else if (seatId == 2) {
                            if (idx == cardCount - 1 && playerData.settleScore > 0) {
                                this.nodeHandCards[seatId].getComponent(MahjongLayout).addMoCard(handItem);
                            } else {
                                this.nodeHandCards[seatId].getComponent(MahjongLayout).addHandCard(handItem);
                            }
                        } else if (seatId == 3) {
                            if (idx < 17) {
                                handItem.setPosition(MahjongCardPosiion.showCardPos4[idx]);
                            }
                        }
                        this.nodeHandCards[seatId].addChild(handItem);

                        if (winSeatId == seatId) {
                            if (idx == cardCount - 1) {
                                let pos = Utils.changToNodePoint(handItem, this.gameView.spLightWuAnim.node);
                                pos.y += 150;
                                this.gameView.showLightFogAnim(MAHJONG_OPERATION_ANIM.light_shoupai, pos);
                                AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Cardeffects, true);
                            }
                        }
                    }
                })
                playerData.otherCards.forEach((cardData, idx) => {
                    if (cardData.cardType == Mahjong_SettleCardType.chow) {
                        const eatList = [cardData.cards[0], cardData.chowCard, cardData.cards[1]];
                        const eatItem = cc.instantiate(this.pengItem[seatId]);
                        eatItem.getComponent(MahjongCard).setEatCardNum(eatList);
                        this.onSetItemPos(eatItem, idx, seatId);
                        this.nodePengCards[seatId].addChild(eatItem);
                    } else if (cardData.cardType == Mahjong_SettleCardType.pong) {
                        const pengItem = cc.instantiate(this.pengItem[seatId]);
                        pengItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                        this.onSetItemPos(pengItem, idx, seatId);
                        this.nodePengCards[seatId].addChild(pengItem);
                    } else if (cardData.cardType == Mahjong_SettleCardType.exposedKong ||
                        cardData.cardType == Mahjong_SettleCardType.pongKong) {
                        const mingGangItem = cc.instantiate(this.mingGangItem[seatId]);
                        mingGangItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                        this.onSetItemPos(mingGangItem, idx, seatId);
                        this.nodePengCards[seatId].addChild(mingGangItem);
                    } else if (cardData.cardType == Mahjong_SettleCardType.concealedKong) {
                        const anGangItem = cc.instantiate(this.showCardAnGangItem[seatId]);
                        anGangItem.getComponent(MahjongCard).setCardNum(cardData.cards[0]);
                        this.onSetItemPos(anGangItem, idx, seatId);
                        this.nodePengCards[seatId].addChild(anGangItem);
                    }
                })
            }
        }
    }

    /**
     * 行牌禁止
     * @param data 
     */
    onLimitCardPush(data) {
        this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.forEach((nodeCard) => {
            const card = nodeCard["card"];
            if (card == data[0]) {
                if (nodeCard && nodeCard.children) {
                    if (nodeCard.getChildByName("spMask")) {
                        nodeCard.getChildByName("spMask").active = true;
                        nodeCard.off(cc.Node.EventType.TOUCH_START, this.onTouchCardStart, this);
                        nodeCard.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchCardMove, this);
                        nodeCard.off(cc.Node.EventType.TOUCH_END, this.onTouchCardEnd, this);
                        nodeCard.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCardEnd, this);
                    }
                }
            }
        })
    }

    /**
     * 七抢一删除花牌
     * @param card 
     */
    onDeleteQiQiangYiFlower(card) {
        for (let i = 0; i < MAHJONG_CONST.PLAYERS_NUM; i++) {
            const items = this.nodeFlowerCard[i];
            for (let m = 0; m < items.children.length; m++) {
                const flower = items.children[m];
                if (flower["card"] == card) {
                    if (flower) {
                        flower.destroy();
                    }
                }
            }
        }
    }

    /**
     * 取消行牌禁止
     */
    onReleseLimitCard() {
        this.nodeHandCards[MAHJONG_CONST.MY_SEATID].children.forEach((nodeCard) => {
            if (nodeCard && nodeCard.children) {
                if (nodeCard.getChildByName("spMask")) {
                    nodeCard.getChildByName("spMask").active = false;
                }
            }
        })
    }

    onSetItemPos(item, idx, seatId) {
        if (seatId == 1) {
            item.setPosition(MahjongCardPosiion.pengGangCardPos2[idx])
        } else if (seatId == 3) {
            item.setPosition(MahjongCardPosiion.pengGangCardPos4[idx])
        }
    }

    onDisable() {
        for (let i = 0; i < MAHJONG_CONST.PLAYERS_NUM; i++) {
            this.nodePengCards[i].destroyAllChildren();
            this.nodeHandCards[i].destroyAllChildren();
            this.nodeDisCards[i].destroyAllChildren();
            this.nodeCardPiles[i].active = false;
            this.nodeFlowerCard[i].destroyAllChildren();
        }
    }

    onDestroy() {
        if (this.dealCardTime) {
            clearTimeout(this.dealCardTime);
        }
        AppEmitter.off(MAHJONG_CONST.MAHJONG_LOCAL_OPERATOR, this.onPlayerOperator);
    }

}
