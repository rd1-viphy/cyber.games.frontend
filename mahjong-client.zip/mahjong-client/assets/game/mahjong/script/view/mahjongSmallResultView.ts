import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import AppEmitter from "../../../../script/network/AppEmitter";
import { MAHJONG_REQUEST_ROUTE, MAHJONG_SETTLE_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongSmallResultItem from "./item/mahjongSmallResultItem";
import mahjongApplyClock from "./mghjongApplyClock";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongSmallResultView extends cc.Component {

    @property({
        tooltip: "风圈位",
        type: cc.Sprite
    })
    spWind: cc.Sprite = null;

    @property({
        tooltip: "风圈Frame",
        type: cc.SpriteFrame
    })
    spWindFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "玩家信息节点",
        type: cc.Node
    })
    nodeResultItem: cc.Node[] = [];

    @property({
        tooltip: "合计台数",
        type: cc.Label
    })
    lbTotalPoint: cc.Label = null;

    @property({
        tooltip: "台数Layout",
        type: cc.Node
    })
    nodeFanList: cc.Node = null;

    @property({
        tooltip: "台数Item",
        type: cc.Node
    })
    fanItem: cc.Node = null;

    @property({
        tooltip: "倒計時",
        type: mahjongApplyClock
    })
    clock: mahjongApplyClock = null;

    @property({
        tooltip: "继续游戏按钮",
        type: cc.Node
    })
    nodeContiue: cc.Node = null;

    @property({
        tooltip: "等待其他玩家确认",
        type: cc.Node
    })
    nodeHint: cc.Node = null;

    @property({
        tooltip: "流局",
        type: cc.Node
    })
    nodeFlow: cc.Node = null;

    @property({
        tooltip: "和局",
        type: cc.Node
    })
    nodePlace: cc.Node = null;

    protected currentPage: number = 0;
    protected maxPage: number = 0;
    protected gameProxy: MahjongProxy = null;
    protected gameModel: MahjongModel = null;
    protected roomId: number = 0;
    protected roomUniqueID: string = null;

    protected winCardType = [
        "", "天胡", "地胡", "大四喜", "人胡", "天聽", "五暗刻", "大三元", "小四喜", "八枝花", "字一色",
        "清一色", "四槓牌", "七搶一", "四暗刻", "地聽", "小三元", "混一色", "碰碰胡", "門清自摸", "全求人",
        "平胡", "三暗刻", "花槓", "莊家", "連莊", "自摸", "門清", "獨聽", "海底撈月", "槓上開花", "河底撈魚",
        "三元台", "搶槓", "花牌", "門風刻", "圈風刻", "報聽", "見花見台", "見風見台", "無字無花", "槓牌", "暗槓",
    ]

    onLoad() {
        AppEmitter.on(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame, this);
    }

    init(data) {
        if (data.gameProxy) {
            this.gameProxy = data.gameProxy;
        }

        if (data.roomId) {
            this.roomId = data.roomId;
        }

        if (data.roomUniqueID) {
            this.roomUniqueID = data.roomUniqueID;
        }

        if (data.gameModel) {
            this.gameModel = data.gameModel;
        }

        if (this.gameModel.getIsWatchTheBattle()) {
            this.nodeContiue.active = false;
            this.nodeHint.active = true;
        }

        this.nodePlace.active = false;
        this.nodeFlow.active = false;
        if (data.gameEndType) {
            if (data.gameEndType == MAHJONG_SETTLE_TYPE.Flow) {
                this.nodeFlow.active = true;
            } else if (data.gameEndType == MAHJONG_SETTLE_TYPE.Peace) {
                this.nodePlace.active = true;
            }
        }

        const waitTime = data.delayTime;
        if (waitTime) {
            this.clock.startClock(waitTime, waitTime, () => {
                if (this.node) {
                    this.node.destroy();
                }
            })
        }
        this.refreshList(data);
    }

    refreshList(data) {
        this.spWind.spriteFrame = this.spWindFrame[data.roundWind - 1];

        this.gameModel.onSortSettleWind(data.settle);

        if (!this.gameModel.getIsWatchTheBattle()) {
            let obj = {};
            data.settle.forEach((item, idx) => {
                if (item.playerId == PlayerMgr.getInstance().uid) {
                    obj = item;
                    data.settle.splice(idx, 1);
                    return;
                }
            })
            data.settle.unshift(obj);
        }

        let isZiMo = this.gameModel.isCheckZiMo(data.settle);
        this.lbTotalPoint.string = "0";
        this.nodeFanList.destroyAllChildren();

        for (let i = 0; i < data.settle.length; i++) {
            const playerSettle = data.settle[i];
            if (playerSettle.playerId) {
                this.nodeResultItem[i].active = true;
                this.nodeResultItem[i].getComponent(MahjongSmallResultItem).initItem(playerSettle, isZiMo);
            }

            if (playerSettle.settleScore > 0) {
                this.lbTotalPoint.string = playerSettle.totalFan;
                if (playerSettle.fanList && playerSettle.fanList.length > 0) {
                    playerSettle.fanList.forEach((fanPoint) => {
                        const fanItem = cc.instantiate(this.fanItem);
                        fanItem.getChildByName("lbFanName").getComponent(cc.Label).string = this.winCardType[fanPoint.pointType];
                        fanItem.getChildByName("lbTanShu").getComponent(cc.Label).string = "+" + fanPoint.point + "台";
                        fanItem.active = true;
                        this.nodeFanList.addChild(fanItem);
                    })
                }
            }
        }
    }

    onContinueGame() {
        this.gameModel.isSmallSettle = false;
        this.gameProxy.sendContinueGame(() => {
            if (this.nodeContiue) {
                this.nodeContiue.active = false;
                this.nodeHint.active = true;
            }
        })
    }

    /**
     * 有邀请
     * @param data 
     */
    onInviteToContinueGame(data) {
        App.showLog("onInviteJoinRoomPush", data);
        if (data) {
            this.clock.stopClock()
            App.loadGamePopul({
                prefabName: "mahjongInviteToRoom",
                prefabPath: "prefab",
                prefabComponent: "mahjongInviteToRoom",
                data: data,
                zIndex: 1300,
            })
        }
    }

    onDestroy() {
        AppEmitter.off(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame);
    }

}
