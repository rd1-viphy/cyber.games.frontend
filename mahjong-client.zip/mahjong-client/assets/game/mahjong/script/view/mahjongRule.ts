
const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongRule extends cc.Component {

    @property({
        tooltip: "规则滑动列表",
        type: cc.ScrollView
    })
    scrollview: cc.ScrollView = null;

    @property({
        tooltip: "内容节点",
        type: cc.Node
    })
    content: cc.Node = null;

    @property({
        tooltip: "基本流程",
        type: cc.SpriteFrame
    })
    basicProcessFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "计分方式",
        type: cc.SpriteFrame
    })
    scoreFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "麻将术语",
        type: cc.SpriteFrame
    })
    mahjongYuFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "台数简表",
        type: cc.SpriteFrame
    })
    taiFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "游戏规则",
        type: cc.SpriteFrame
    })
    rulesFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "规则Item",
        type: cc.Node
    })
    ruleItem: cc.Node = null;

    protected selTogFrames = null;

    start() {
        this.toggleClicked(cc.Event, "0");
    }

    toggleClicked(event, data: string) {
        this.content.removeAllChildren();
        const idx = +data;
        this.scrollview.scrollToTop(0.2, false);
        switch (idx) {
            case 0:
                this.selTogFrames = this.rulesFrames;
                break;
            case 1:
                this.selTogFrames = this.basicProcessFrames;
                break;
            case 2:
                this.selTogFrames = this.mahjongYuFrames;
                break;
            case 3:
                this.selTogFrames = this.taiFrames;
                break;
            case 4:
                this.selTogFrames = this.scoreFrames;
            default:
                break;
        }
        for (let i = 0; i < this.selTogFrames.length; i++) {
            const frame = this.selTogFrames[i];
            const ruleItem = cc.instantiate(this.ruleItem);
            ruleItem.active = true;
            ruleItem.getComponent(cc.Sprite).spriteFrame = frame;
            this.content.addChild(ruleItem);
        }
    }

}
