import MahjongProxy from "../model/mahjongProxy";
import maghjongBlacklistItem from "./item/maghjongBlacklistItem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongBlacklistNode extends cc.Component {

    @property({
        tooltip: "人数",
        type: cc.Label
    })
    persoNumLabel: cc.Label = null;

    @property({
        tooltip: "黑名单滑动列表",
        type: cc.ScrollView
    })
    blackScrollView: cc.ScrollView = null;

    @property({
        tooltip: "没有人数的节点",
        type: cc.Node
    })
    noCustomerNode: cc.Node = null;

    @property({
        tooltip: "有人数的节点",
        type: cc.Node
    })
    customerNode: cc.Node = null;

    @property({
        tooltip: "黑名单人物的item",
        type: cc.Prefab
    })

    blacklistItem: cc.Prefab = null;

    blacklistInfo: MahjongServerToClient.getBlacklist = null;

    gameProxy: MahjongProxy = null;

    init(data) {
        this.gameProxy = data.gameProxy;
        let blacklistInfo: MahjongServerToClient.getBlacklist = data.blacklistInfo;
        this.blacklistInfo = blacklistInfo;
        this.refreshList();
    }

    /**
     * 刷新列表
     */
    refreshList() {
        this.persoNumLabel.string = this.blacklistInfo.blackList.length.toString();
        this.noCustomerNode.active = this.blacklistInfo.blackList.length == 0;
        this.customerNode.active = this.blacklistInfo.blackList.length > 0;
        if (this.blacklistInfo.blackList.length > 0) {
            let content = this.blackScrollView.content;
            content.removeAllChildren();
            let list = this.blacklistInfo.blackList;
            list.forEach((element, index) => {
                let item = cc.instantiate(this.blacklistItem);
                content.addChild(item);
                item.getComponent(maghjongBlacklistItem).init(index, element, this, this.gameProxy);
            });
        }
    }

    /**
     * 删除玩家
     */
    delectPerson(index: number) {
        this.blacklistInfo.blackList.splice(index, 1);
        this.refreshList();
    }

}
