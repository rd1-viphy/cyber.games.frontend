import AgoraClient from "../../../../script/agora/AgoraClient";
import { AgoraUserInfo } from "../../../../script/agora/AgoraDeclare";
import { PermissionCode, platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import AudioMgr from "../../../../script/model/AudioMgr";
import consts = require("../../../../script/model/Consts");
import MahjongBackModel from "../../../../script/model/mahjongBackModel";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../script/model/Utils";

import MahjongClock from "../component/mahjongClock";
import MahjongEmoji from "../component/mahjongEmoji";
import MahjongControl from "../control/mahjongControl";
import { MAHJONG_CONST, MAHJONG_HAND_ANIM, MAHJONG_HAND_TYPE, MAHJONG_LIMIT_TIPS, MAHJONG_OPERATION_ANIM, MAHJONG_PLAYERS, MAHJONG_ROOM_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongLimitPushCard from "./item/mahjongLimitPushCard";

import MahjongCardPiles from "./mahjongCardPiles";
import mahjongDissolutionRoomNode from "./mahjongDissolutionRoomNode";
import MahjongPlayer from "./mahjongPlayer";
import MahjongTilesView from "./mahjongTilesView";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongView extends cc.Component {

    @property({
        type: MahjongTilesView,
        visible: true
    })
    public gameCardsView: MahjongTilesView = null;

    @property({
        tooltip: "游戏玩家",
        type: MahjongPlayer
    })
    players: MahjongPlayer[] = [];

    @property({
        tooltip: "房间号",
        type: cc.Label
    })
    lbRoomId: cc.Label = null;

    @property({
        tooltip: "圈数",
        type: cc.Label
    })
    lbRound: cc.Label = null;

    @property({
        tooltip: "底注/台分",
        type: cc.Label
    })
    lbBaseScore: cc.Label = null;

    @property({
        tooltip: "风圈",
        type: cc.Sprite
    })
    spWind: cc.Sprite = null;

    @property({
        tooltip: "风圈Frame",
        type: cc.SpriteFrame
    })
    spWinFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "剩余张数",
        type: cc.Label
    })
    lbCardCount: cc.Label = null;

    @property({
        tooltip: "准备按钮",
        type: cc.Node
    })
    nodeReadyStart: cc.Node = null;

    @property({
        tooltip: "开始游戏按钮",
        type: cc.Node
    })
    nodeStartGame: cc.Node = null;

    @property({
        tooltip: "邀请按钮",
        type: cc.Node
    })
    nodeInvite: cc.Node = null;

    @property({
        tooltip: "上桌按钮",
        type: cc.Node
    })
    nodeSitDown: cc.Node = null;

    @property({
        tooltip: "观战中",
        type: cc.Node
    })
    nodeWatchGame: cc.Node = null;

    @property({
        tooltip: "操作风盘",
        type: cc.Node
    })
    nodeClock: cc.Node = null;

    @property({
        tooltip: "结局动画",
        type: sp.Skeleton
    })
    spSettleAnim: sp.Skeleton = null;

    @property({
        tooltip: "骰子动画",
        type: sp.Skeleton
    })
    spDiceAnims: sp.Skeleton[] = [];

    @property({
        tooltip: "庄家图片",
        type: cc.Node
    })
    nodeSpBank: cc.Node = null;

    @property({
        tooltip: "有花",
        type: cc.Node
    })
    nodeHaveFlowers: cc.Node = null;

    @property({
        tooltip: "无花",
        type: cc.Node
    })
    nodeNoFlowers: cc.Node = null;

    @property({
        tooltip: "封顶无限",
        type: cc.Node
    })
    nodeFengDingWuXian: cc.Node = null;

    @property({
        tooltip: "封顶台",
        type: cc.Node
    })
    nodeFengDingTai: cc.Node = null;

    @property({
        tooltip: "封顶台数",
        type: cc.Label
    })
    lbFengDingNumber: cc.Label = null;

    @property({
        tooltip: "行牌禁止",
        type: cc.Node
    })
    nodePushCardBg: cc.Node = null;

    @property({
        tooltip: "行牌提示",
        type: cc.Prefab
    })
    pushCardTipItem: cc.Prefab = null;

    @property({
        tooltip: "开始游戏动画",
        type: sp.Skeleton
    })
    spStartGameAnim: sp.Skeleton = null;

    @property({
        tooltip: "互动道具",
        type: MahjongEmoji
    })
    nodeEmojiProp: MahjongEmoji = null;

    @property({
        tooltip: "手的动画",
        type: sp.Skeleton
    })
    spHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "右手摊牌动画",
        type: sp.Skeleton
    })
    spRightHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "上家摊牌动画",
        type: sp.Skeleton
    })
    spShangJiaHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "下家摊牌动画",
        type: sp.Skeleton
    })
    spXiaJiaHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "对家摊牌动画",
        type: sp.Skeleton
    })
    spDuiJiaHandAnim: sp.Skeleton = null;

    @property({
        tooltip: "声网",
        type: AgoraClient
    })
    agoraClient: AgoraClient = null;

    @property({
        tooltip: "聊天按钮",
        type: cc.Node
    })
    nodeChatBtn: cc.Node = null;

    @property({
        tooltip: "闪电云雾动画",
        type: sp.Skeleton
    })
    spLightWuAnim: sp.Skeleton = null;

    @property({
        tooltip: "Ace快顯節點",
        type: cc.Node
    })
    nodeAceSdkMsg: cc.Node = null;

    @property({
        tooltip: "按钮组",
        type: cc.Node
    })
    nodeButtonGroups: cc.Node = null;

    @property({
        tooltip: "回放节点",
        type: cc.Node
    })
    nodePlayBack: cc.Node = null;

    @property({
        tooltip: "房间解散倒计时",
        type: cc.Node
    })
    nodeCountTimerDown: cc.Node = null;

    @property({
        tooltip: "topBox",
        type: cc.Node
    })
    nodeTopBox: cc.Node = null;

    protected gameProxy: MahjongProxy = null;

    public control: MahjongControl = null;

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    protected timeFlag: number = 0;

    protected curRemainTime: number = 0;

    protected diceAnimName = ["dice1", "dice2", "dice3", "dice4", "dice5", "dice6"];

    onLoad() {
        AudioMgr.playBGM(MAHJONG_CONST.Sound.GameBGM, true);
    }

    start() {
        //if (MahjongRoomMgr.getInstance().isBackView) {
        this.agoraClient = null;
        //}

        this.scheduleOnce(() => {
            if (!this.gameModel.getIsWatchTheBattle() && CC_BUILD && this.agoraClient) {
                this.startAccessAgora();
            }
        }, 0.5);


        this.nodeTopBox.zIndex = 1900;
        this.nodeAceSdkMsg.zIndex = 2000;
        cc.sys.localStorage.setItem("mahjongMianZe", false);
        //this.agoraClient = null;
    }

    init(control: MahjongControl, gameProxy: MahjongProxy) {
        this.control = control;
        this.gameProxy = gameProxy;
        let self = this;
        this.players.forEach((player) => {
            player.init(gameProxy, self);
        })
    }

    initGameView() {
        this.gameModel.hideCount = 0;
        this.gameModel.isSmallSettle = false;
        this.gameModel.allDisCards = [];
        this.gameModel.curPlayerWinCards = [];
        this.gameModel.AllDisCardPongGangCardItem = [];
        this.gameModel.isMySelfTing = false;
        this.gameModel.flowersGangCount = 0;
        this.gameModel.winPlayerId = null;
        this.gameModel.curPlayerDisTingCard = null;

        if (this.gameModel.roomConfig.maxPlayerNum == MAHJONG_PLAYERS.TWO) {
            this.players[1].node.active = false;
            this.players[3].node.active = false;
        } else if (this.gameModel.roomConfig.maxPlayerNum == MAHJONG_PLAYERS.THREE) {
            this.players[2].node.active = false;
        }

        this.players.forEach((player) => {
            player.initView();
            player.closeCountDown();
        })
        this.gameCardsView.initCardsView(this);

        const result = cc.find('Canvas').getChildByName("smallResultView");
        if (result) {
            result.destroy();
        }
        this.nodeClock.getComponent(MahjongClock).onHideClock();

        this.lbRound.string = this.gameModel.gameInfo.currRound + "/" + this.gameModel.roomConfig.maxRoundNum;
        this.spWind.spriteFrame = this.spWinFrame[this.gameModel.gameInfo.windRound - 1];
        this.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();

        if (MahjongRoomMgr.getInstance().isBackView) {
            this.nodePlayBack.active = true;
            this.nodeButtonGroups.active = false;
            this.nodePlayBack.zIndex = 1300;
        }
    }

    /**
     * 设置房间信息
     */
    setRoomInfo() {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_EnterRoom, true);
        this.lbRoomId.string = this.gameModel.tableId.toString();
        let num1 = this.gameModel.formatCoinNum(this.gameModel.roomConfig.baseScore);
        let num2 = this.gameModel.formatCoinNum(this.gameModel.roomConfig.fanPoint)
        this.lbBaseScore.string = num1 + "/" + num2;
        this.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
        this.nodeHaveFlowers.active = false;
        this.nodeNoFlowers.active = false;
        if (this.gameModel.roomConfig.hasFlowerCard == 1) {
            this.nodeHaveFlowers.active = true;
        } else if (this.gameModel.roomConfig.hasFlowerCard == 0) {
            this.nodeNoFlowers.active = true;
        }

        this.nodeFengDingWuXian.active = false;
        this.nodeFengDingTai.active = false;
        if (this.gameModel.roomConfig.maxFan == 0) {
            this.nodeFengDingWuXian.active = true;
        } else {
            this.nodeFengDingTai.active = true;
            this.lbFengDingNumber.string = this.gameModel.roomConfig.maxFan.toString();
        }

        if (this.gameModel.getIsWatchTheBattle()) {
            this.nodeChatBtn.active = false;
        } else {
            this.nodeChatBtn.active = true;
        }
    }

    /**
     * 准备
     */
    onReadyGame() {
        if (this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
            if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                this.gameProxy.sendPlayerReady(() => {
                    this.nodeReadyStart.active = false;
                    this.nodeStartGame.active = false;
                    this.nodeInvite.active = false;
                })
            } else {
                this.gameProxy.sendPlayerReady(() => {
                    this.nodeReadyStart.active = false;
                    this.nodeStartGame.active = false;
                })
            }
        } else {
            this.gameProxy.sendPlayerReady(() => {
                this.nodeReadyStart.active = false;
                this.nodeStartGame.active = false;
            })
        }
    }

    /**
     * 邀请
     */
    onInvite() {
        MahjongRoomMgr.getInstance().copyRoomInfo(
            this.gameModel.roomConfig,
            MAHJONG_CONST.shareText,
            this.gameModel.tableId,
            this.gameModel.roomName,
            MAHJONG_CONST.shareRoomInfo,
        )
    }

    /**
     * 开始游戏
     */
    onStartGame() {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_StartGame, true);
        this.nodeReadyStart.active = false;
        this.nodeStartGame.active = false;
        this.nodeInvite.active = false;
        this.nodeSitDown.active = false;
        this.gameCardsView.onStartGame();
        this.spStartGameAnim.node.active = true;
        this.nodeCountTimerDown.active = false;
        this.lbCardCount.string = this.gameModel.gameInfo.remainCardNum.toString();
        this.spStartGameAnim.setAnimation(0, "animation", false);
        if (this.gameModel.getIsWatchTheBattle()) {
            this.nodeWatchGame.active = true;
        } else {
            this.nodeWatchGame.active = false;
        }
        this.spStartGameAnim.setCompleteListener(() => {
            this.spStartGameAnim.node.active = false;
        })
    }

    /**
     * 摇骰子动画
     * @param data 
     */
    onShowDiceAnim(data) {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_RollTheDice, true);
        for (let i = 0; i < data.length; i++) {
            const dice = data[i];
            this.spDiceAnims[i].node.active = true;
            this.spDiceAnims[i].setAnimation(0, this.diceAnimName[dice - 1], false);
            this.spDiceAnims[i].setCompleteListener(() => {
                this.scheduleOnce(() => {
                    this.spDiceAnims[i].node.active = false;
                }, 1.0)
            })
        }
    }

    /**
     * 抓位动画
     */
    onShowZhuaWeiAnim() {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Catchingposition, true, true);
        this.gameCardsView.onShowRandomWind();
    }

    /**
     * 定庄动画
     * @param seatId 
     */
    onSureBank(seatId, isShow) {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_SureBank, true);
        this.lbRound.string = this.gameModel.gameInfo.currRound + "/" + this.gameModel.roomConfig.maxRoundNum;
        this.spWind.spriteFrame = this.spWinFrame[this.gameModel.gameInfo.windRound - 1];

        if (isShow) {
            this.nodeSpBank.active = true;
            this.nodeSpBank.scale = 1.0;
            this.nodeSpBank.setPosition(cc.v2(0, 60));
            const pos = Utils.changToNodePoint(this.players[seatId].nodeBank, this.node);
            cc.tween(this.nodeSpBank)
                .parallel(
                    cc.tween().to(1.0, { position: pos }, { easing: "smooth" }),
                    cc.tween().to(1.0, { scale: 0.2 }, { easing: "smooth" })
                )
                .call(() => this.nodeSpBank.active = false)
                .start()
        }
    }

    /**
     * 发牌
     * @param data 
     */
    onGameDealCards(data) {
        if (!MahjongRoomMgr.getInstance().isBackView) {
            this.gameCardsView.onDealCard(data);
        } else {
            this.gameCardsView.onDealCard(data);
            this.gameCardsView.onShowBackCard(data);
        }
    }

    /**
     * 换花
     * @param data 
     */
    onExChangeFlowerCard(data, seatId) {
        AudioMgr.playSFX(MAHJONG_CONST.Sound.Sound_Mulligan, true, true);
        if (MahjongRoomMgr.getInstance().isBackView) {
            this.gameCardsView.onPlayBackChangeFlowers(data, seatId);
        } else {
            this.gameCardsView.onExchangeCard(data, seatId);
        }
    }

    /**
     * 摸牌
     * @param data 
     */
    onGameAddCard(seatId, cardData) {
        if (MahjongRoomMgr.getInstance().isBackView) {
            this.gameCardsView.onPlayBackMoCard(seatId, cardData);
        } else {
            this.gameCardsView.onMoCardOperation(seatId, cardData);
        }
    }

    /**
     * 展示牌堆
     */
    onShowCardPiles() {
        this.gameCardsView.onDrawCardPiles();
    }

    /**
     * 断线显示牌堆
     */
    onRecShowCardPiles() {
        this.gameCardsView.onRecPiles();
    }

    /**
     * 发送操作请求
     * @param card 
     * @param type 
     */
    onSendOperation(card, type, cb?: Function) {
        this.gameProxy.sendPlayerOperationType(card, type, cb);
    }

    /**
     * 操作列表
     * @param data 
     */
    onShowOperation(data) {
        if (!this.gameModel.getIsWatchTheBattle()) {
            this.gameCardsView.onShowOperationNode(data);
        }
    }

    /**
     * 其他玩家操作
     * @param data 
     */
    onShowOtherOperation(seatId, type, cards) {
        this.gameCardsView.onShowOtherOpaction(type, seatId, cards);
    }

    /**
     * 观战玩家坐下
     */
    onSendSitDown() {
        if (!this.gameModel.isGameStart) {
            const isFull = this.gameModel.isCheckRoomFull();
            if (!isFull) {
                this.gameProxy.sendPlayerSitDown(() => {
                    this.nodeWatchGame.active = false;
                    this.nodeSitDown.active = true;
                    this.nodeReadyStart.active = true;
                    this.nodeChatBtn.active = true;
                    App.isWatchGame = false;
                    App.showToast("mahjong_intend_hint", 1);
                })
            } else {
                App.showToast("917")
            }
        } else {
            App.showToast("")
        }
    }

    /**
     * 座位玩家站起观战
     */
    onSendPlayerWatchGame() {
        if (!this.gameModel.isGameStart) {
            this.gameProxy.sendPlayerSitUpWatch(() => {
                this.gameModel.playersInfo.forEach((player, idx) => {
                    if (player.playerId == PlayerMgr.getInstance().uid) {
                        const seatId = this.gameModel.changSeatId(player.chairId);
                        this.players[seatId].onStandUp();
                        this.gameModel.playersInfo.splice(idx, 1);
                        this.nodeReadyStart.active = false;
                        this.nodeWatchGame.active = true;
                        this.nodeSitDown.active = true;
                        this.nodeChatBtn.active = false;
                        if (this.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                            this.agoraClient.leaveCall();
                        }
                        this.gameModel.selfChairId = -1;
                        this.isRefshPlayerHead();
                        App.isWatchGame = true;
                    }
                })
            })
        } else {
            App.showToast("mahjong_watchGameStart", 1);
        }
    }

    /**
     * 观战后刷新牌桌头像
     */
    public isRefshPlayerHead() {
        this.players.forEach((player) => {
            player.onStandUp();
        })
        this.gameModel.playersInfo.forEach((player) => {
            const seatId = this.gameModel.changSeatId(player.chairId);
            this.players[seatId].setPlayerInfo(player);
            if (player.isReady) {
                this.players[seatId].setPlayerReady(true);
            } else {
                this.players[seatId].setPlayerReady(false);
            }
        })
    }

    /**
     * 行牌禁制提示
     */
    onShowLimitTips(data) {
        if (data.limits && data.limits.length > 0) {
            this.nodePushCardBg.destroyAllChildren();
            if (!this.gameModel.isMySelfTing) {
                this.nodePushCardBg.active = true;
                const tipItem = cc.instantiate(this.pushCardTipItem);
                tipItem.getComponent(MahjongLimitPushCard).showItem(data.limits[0].limitType);
                this.nodePushCardBg.addChild(tipItem);

                data.limits.forEach((limit) => {
                    if (limit.limitType == MAHJONG_LIMIT_TIPS.Limit_Chow_Not_Discard) {
                        this.gameCardsView.onLimitCardPush(limit.cards)
                    } else if (limit.limitType == MAHJONG_LIMIT_TIPS.Limit_Pong_Not_Discard) {
                        this.gameCardsView.onLimitCardPush(limit.cards)
                    } else if (limit.limitType == MAHJONG_LIMIT_TIPS.Limit_OverWater_Win) {
                        this.gameModel.isWaterHu = true;
                    }
                })

                this.scheduleOnce(() => {
                    this.nodePushCardBg.active = false;
                }, 1.5)
            } else {
                if (data.limits[0].limitType == MAHJONG_LIMIT_TIPS.Limit_OverWater_Win) {
                    this.nodePushCardBg.active = true;
                    const tipItem = cc.instantiate(this.pushCardTipItem);
                    tipItem.getComponent(MahjongLimitPushCard).showItem(data.limits[0].limitType);
                    this.nodePushCardBg.addChild(tipItem);
                    this.scheduleOnce(() => {
                        this.nodePushCardBg.active = false;
                    }, 1.5)
                }
            }
        }
    }

    /**
     * 手的动画
     * @param operationType 
     * @param seatId 
     */
    onShowHandAnim(operationType, seatId, startPos?, endPos?, curCount?) {
        if (MahjongRoomMgr.getInstance().isBackView) { return };
        if (this.gameModel.getIsWatchTheBattle()) { return };
        let x = 0;
        let y = 0;
        this.spHandAnim.node.setPosition(cc.v2(0, 0));
        this.spHandAnim.node.x = 0;
        if (operationType == MAHJONG_HAND_TYPE.LiCard) {
            this.spHandAnim.node.setPosition(startPos);
            if (seatId == 1) {
                this.spHandAnim.node.y = this.spHandAnim.node.y + 600;
                this.spHandAnim.node.x = this.spHandAnim.node.x + 200;
                x = endPos.x - 350;
                y = endPos.y + 120;
            } else if (seatId == 2) {
                this.spHandAnim.node.y += 200;
                x = endPos.x + 100;
                y = endPos.y - 10;
            } else if (seatId == 3) {
                x = endPos.x + 400;
                y = endPos.y - 160;
            }

            cc.tween(this.spHandAnim.node)
                .to(0.2, { position: cc.v3(x, y) })
                .start()
        }

        if (operationType == MAHJONG_HAND_TYPE.DisCard && startPos) {
            this.spHandAnim.node.setPosition(startPos);
            if (seatId == MAHJONG_CONST.MY_SEATID) {
                if (curCount) {
                    if (curCount <= 7) {
                        y = endPos.y + 100;
                    } else if (curCount > 7 && curCount <= 15) {
                        y = endPos.y + 70;
                    } else if (curCount > 15) {
                        y = endPos.y + 40;
                    }
                }
                x = endPos.x;
                this.spHandAnim.node.x = this.spHandAnim.node.x - 500;
            } else if (seatId == 1) {
                this.spHandAnim.node.x = this.spHandAnim.node.x - 50;
                x = endPos.x - 200;
                y = endPos.y + 50;
            } else if (seatId == 2) {

            } else if (seatId == 3) {
                x = endPos.x + 120;
                y = endPos.y - 150;
            }

            cc.tween(this.spHandAnim.node)
                .to(0.2, { position: cc.v3(x, y) })
                .start()
        }

        if (operationType == MAHJONG_HAND_TYPE.PongKongChi) {
            if (seatId == MAHJONG_CONST.MY_SEATID) {
                this.spHandAnim.node.x = this.spHandAnim.node.x - startPos * 160 + 300;
            } else if (seatId == 1) {
                this.spHandAnim.node.y = this.spHandAnim.node.y - startPos * 160 + 300;
            } else if (seatId == 2) {
                this.spHandAnim.node.x = this.spHandAnim.node.x + startPos * 160 + 300;
            } else if (seatId == 3) {
                this.spHandAnim.node.y = this.spHandAnim.node.y + startPos * 160 + 300;
            }
        }

        if (operationType == MAHJONG_HAND_TYPE.TanCard) {
            if (seatId == MAHJONG_CONST.MY_SEATID) {
                this.spRightHandAnim.node.active = true;
                this.spRightHandAnim.setAnimation(0, MAHJONG_HAND_ANIM.MySelf_TanCard_Right, false);
                this.spRightHandAnim.setCompleteListener(() => {
                    this.spRightHandAnim.node.active = false;
                })
                let animName = this.onGetHandAnimName(operationType, seatId).toString();
                this.spHandAnim.node.active = true;
                this.spHandAnim.setAnimation(0, animName, false);
                this.spHandAnim.setCompleteListener(() => {
                    this.spHandAnim.node.active = false;
                })
            } else if (seatId == 1) {
                this.spXiaJiaHandAnim.node.active = true;
                this.spXiaJiaHandAnim.setAnimation(0, MAHJONG_HAND_ANIM.XiaJia_TanCard, false);
                this.spXiaJiaHandAnim.setCompleteListener(() => {
                    this.spXiaJiaHandAnim.node.active = false;
                })
            } else if (seatId == 2) {
                this.spDuiJiaHandAnim.node.active = true;
                this.spDuiJiaHandAnim.setAnimation(0, MAHJONG_HAND_ANIM.DuiJia_TanCard, false);
                this.spDuiJiaHandAnim.setCompleteListener(() => {
                    this.spDuiJiaHandAnim.node.active = false;
                })
            } else if (seatId == 3) {
                this.spShangJiaHandAnim.node.active = true;
                this.spShangJiaHandAnim.setAnimation(0, MAHJONG_HAND_ANIM.ShangJia_TanCard, false);
                this.spShangJiaHandAnim.setCompleteListener(() => {
                    this.spShangJiaHandAnim.node.active = false;
                })
            }
        } else {
            let animName = this.onGetHandAnimName(operationType, seatId).toString();
            if (animName && this.spHandAnim) {
                this.spHandAnim.node.active = true;
                this.spHandAnim.setAnimation(0, animName, false);
                this.spHandAnim.setCompleteListener(() => {
                    this.spHandAnim.node.active = false;
                })
            }
        }
    }

    /**
     * 获取手的动画名称
     * @param operationType 
     * @param seatId 
     * @returns 
     */
    onGetHandAnimName(operationType, seatId) {
        const handAnimName = [
            [MAHJONG_HAND_ANIM.MySelf_DisCard, MAHJONG_HAND_ANIM.MySelf_PengGangChi, 0,
            MAHJONG_HAND_ANIM.MySelf_HuCard, MAHJONG_HAND_ANIM.MySelf_TanCard_Left],
            [MAHJONG_HAND_ANIM.XiaJia_DisCard, MAHJONG_HAND_ANIM.XiaJia_PengGangChi, MAHJONG_HAND_ANIM.XiaJia_LiCard,
            MAHJONG_HAND_ANIM.XiaJia_HuCard, MAHJONG_HAND_ANIM.XiaJia_TanCard],
            [MAHJONG_HAND_ANIM.DuiJia_DisCard, MAHJONG_HAND_ANIM.DuiJia_PengGangChi, MAHJONG_HAND_ANIM.DuiJia_LiCard,
            MAHJONG_HAND_ANIM.DuiJia_HuCard, MAHJONG_HAND_ANIM.DuiJia_TanCard],
            [MAHJONG_HAND_ANIM.ShangJia_DisCard, MAHJONG_HAND_ANIM.ShangJia_PengGangChi, MAHJONG_HAND_ANIM.ShangJia_LiCard,
            MAHJONG_HAND_ANIM.ShangJia_HuCard, MAHJONG_HAND_ANIM.ShangJia_TanCard]
        ]
        return handAnimName[seatId][operationType - 1];
    }

    /**
     * 流局、和局动画
     * @param animName 
     */
    onShowGameSettleAnim(animName) {
        this.spSettleAnim.node.active = true;
        this.spSettleAnim.setAnimation(0, animName, false);
        this.spSettleAnim.setCompleteListener(() => {
            this.spSettleAnim.node.active = false;
        })
    }

    /**
     * 互动道具
     * @param data 
     */
    onShowEmojiProps(data) {
        this.nodeEmojiProp.setPropsAnimation(data);
    }

    /**
     * 房主解散房间
     * @param cb 
     */
    onGameMasterDissRoom() {
        let opts = {
            contentLabel: "mahjong_notStartDissRoom",
            confirmCallback: () => {
                this.gameProxy.sendGameMasterDissRoom(() => {
                    if (this.agoraClient && !this.gameModel.getIsWatchTheBattle()) {
                        this.agoraClient.leaveCall();
                    }
                    App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
                })
            }
        }
        this.gameModel.onShowDialog(opts)
    }

    onExit() {
        if (this.gameModel.getIsWatchTheBattle()) {
            this.gameProxy.sendPlayerLeaveRoom(() => { })
            App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
        } else {
            this.gameProxy.sendPlayerLeaveRoom(() => {
                if (this.agoraClient) {
                    this.agoraClient.leaveCall();
                }
                App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
            })
        }
    }

    /**
     * 退出游戏
     */
    public applyExitRoom() {
        let lbHint = null;
        if (this.gameModel.getIsWatchTheBattle()) {
            lbHint = "mahjong_watchLeaveRoom";
        } else {
            if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                lbHint = "exit_game";
            } else {
                lbHint = "mahjong_leaveRoom";
            }
        }

        let opts = {
            contentLabel: lbHint,
            confirmCallback: () => {
                this.onExit()
            }
        }
        this.gameModel.onShowDialog(opts);
    }

    /**
     * 申请解散房间
     */
    public applyDissolveTabel() {
        if (this.gameModel.isDissRoom) {
            App.showToast("mahjong_dissrooming", 1);
            return
        }
        let opts = {
            contentLabel: "mahjong_startGameDissRoom",
            confirmCallback: () => {
                this.gameModel.isDissRoom = true;
                this.gameProxy.sendEndGameVote({ vote: 1 }, () => { }, () => {
                    this.gameModel.isDissRoom = false;
                });
            }
        }
        this.gameModel.onShowDialog(opts);
    }

    /**
     * 游戏未开始点APP离开
     */
    public appLeaveDissRoom() {
        if (this.gameModel.getIsWatchTheBattle()) {
            const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
            if (!tipView) {
                this.applyExitRoom();
            }
        } else {
            if (!this.gameModel.isGameStart) {
                if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                    if (this.gameModel.roomConfig.createType != MAHJONG_ROOM_TYPE.AGENT) {
                        const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
                        if (!tipView) {
                            this.onGameMasterDissRoom();
                        }
                    } else {
                        const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
                        if (!tipView) {
                            this.applyExitRoom();
                        }
                    }
                } else {
                    const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
                    if (!tipView) {
                        this.applyExitRoom();
                    }
                }
            } else {
                const result = cc.find('Canvas').getChildByName("totalResultView");
                if (result) {
                    const tipView = cc.find('Canvas').getChildByName("mahjongContinueRoom");
                    if (tipView) {
                        MahjongRoomMgr.getInstance().renewRoom({
                            gameId: platform_game_id.mahjong_table,
                            roomId: MahjongModel.getInstance().tableId,
                            step: 2,
                            confirmRes: 1
                        }, () => {
                            tipView.destroy();
                        }, () => {
                            tipView.destroy();
                        });
                    } else {
                        if (PlayerMgr.getInstance().uid == this.gameModel.masterUid &&
                            this.gameModel.roomConfig.createType == MAHJONG_ROOM_TYPE.COMMON) {
                            if (!this.gameModel.isCancleXuWan) {
                                MahjongRoomMgr.getInstance().renewRoom({
                                    gameId: platform_game_id.mahjong_table,
                                    roomId: MahjongModel.getInstance().tableId,
                                    step: 2,
                                    confirmRes: 1
                                }, () => { },
                                    () => { })
                            }
                        }

                        App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
                    }
                } else {
                    const tipView = cc.find('Canvas').getChildByName("mahjongTipNode");
                    if (!tipView) {
                        this.applyDissolveTabel();
                    }
                }
            }
        }
    }

    /**
     * 开始解散
     */
    public startDissolveRoom(dissoulteInfo: MahjongServerToClient.onVoteDisbandStartPush) {
        if (!this.gameModel.getIsWatchTheBattle()) {
            App.loadGamePopul({
                prefabName: "mahjongDissolutionRoomNode",
                prefabPath: "prefab",
                prefabComponent: "mahjongDissolutionRoomNode",
                notAction: true,
                data: {
                    gameView: this,
                    gameProxy: this.gameProxy,
                    dissoulteInfo: dissoulteInfo
                }
            })
        }
        this.gameModel.isDissRoom = true;
        this.gameModel.recordOperationTime = 0;
        this.gameModel.recordOperationTime = parseInt(this.nodeClock.getComponent(MahjongClock).lbClock.string)
        this.nodeClock.getComponent(MahjongClock).onHidelbClock();
    }

    /**
     * 玩家解散
     * @param dissolveResult 
     */
    public playerDissolve(dissolveResult: MahjongServerToClient.onVotePlayerActionPush) {
        let dissolutionRoomNode = cc.find("Canvas/mahjongDissolutionRoomNode");
        if (dissolutionRoomNode) {
            let dissolutionComponent = dissolutionRoomNode.getComponent(mahjongDissolutionRoomNode);
            if (dissolutionComponent) {
                dissolutionComponent.refreshPlayerOpreate(dissolveResult);
            }
        }
    }

    /**
     * 打开聊天界面
     */
    public onShowChatView() {
        if (!this.gameModel.getIsWatchTheBattle()) {
            App.loadGamePopul({
                prefabName: "mahjongChatNode",
                prefabPath: "prefab",
                notAction: false,
                prefabComponent: "mahjongChat",
                data: {
                    gameProxy: this.gameProxy,
                }
            })
        }
    }

    /**
     * 吃碰杠烟雾动画
     * @param animName 
     * @param pos 
     */
    showLightFogAnim(animName, pos) {
        if (pos && !MahjongRoomMgr.getInstance().isBackView) {
            this.spLightWuAnim.node.active = true;
            this.spLightWuAnim.node.setPosition(pos);
            this.spLightWuAnim.setAnimation(0, animName, false);
            this.spLightWuAnim.setCompleteListener(() => {
                this.spLightWuAnim.node.setPosition(cc.v3(0, 0));
                this.spLightWuAnim.node.active = false;
            })
        }
    }

    /**
     * 關閉回放返回大厅
     */
    public backToHall() {
        MahjongBackModel.destoryTimer();
        MahjongRoomMgr.getInstance().isBackView = false;
        cc.director.resume();
        App.changeScene({ sceneName: consts.MAHJONG_ROOM_LIST_SCENE });
    }

    /**
     * 打开菜单栏
     */
    public menuBtnClicked() {
        App.loadGamePopul({
            prefabName: "mahjongMenuNode",
            prefabPath: "prefab",
            notAction: false,
            prefabComponent: "mahjongMenu",
            data: {
                gameModel: this.gameModel,
                gameProxy: this.gameProxy,
                gameView: this
            }
        })
    }

    /**
     * 展示创房信息
     */
    public onShowCreateRoomInfo() {
        App.loadGamePopul({
            prefabName: "mahjongCreateRoomInfo",
            prefabPath: "prefab",
            notAction: false,
            prefabComponent: "mahjongRoomInfo",
            data: { gameInfo: this.gameModel }
        })
    }

    /**
    * 加入声网
    */
    startAccessAgora() {
        const joinAgora = () => {
            if (this.gameModel.videoCallInfo && this.gameModel.videoCallInfo.token && this.gameModel.videoCallInfo.channelName) {
                const token = this.gameModel.videoCallInfo.token;
                const channel = this.gameModel.videoCallInfo.channelName;

                let userInfo: AgoraUserInfo[] = [];
                this.gameModel.playersInfo.forEach((element) => {
                    if (element.playerId) {
                        let palyerSeatId = this.gameModel.changSeatId(element.chairId);
                        let agoraView = this.players[palyerSeatId].node.getChildByName("agoraView");
                        if (agoraView) {
                            userInfo.push({ userId: element.playerId, agoraView: agoraView, videoTrack: null, audioTrack: null, interval: null });
                        }
                    }
                });
                //this.agoraClient = new AgoraClient();
                if (this.agoraClient) {
                    this.agoraClient.init(token, channel, userInfo);
                }
            }
        }
        joinAgora();
    }

    /**
     * 换视频位置
     */
    changeSeatAgoraView() {
        if (this.agoraClient && CC_BUILD && !this.gameModel.getIsWatchTheBattle()) {
            if (this.gameModel.getIsWatchTheBattle()) { return }
            this.gameModel.playersInfo.forEach((element) => {
                if (element.playerId) {
                    this.agoraClient.removeVideo(element.playerId);
                    this.agoraClient.removeAudio(element.playerId);
                }
            })

            this.scheduleOnce(() => {
                this.gameModel.playersInfo.forEach((element) => {
                    if (element.playerId) {
                        const palyerSeatId = this.gameModel.changSeatId(element.chairId);
                        const agoraView = this.players[palyerSeatId].node.getChildByName("agoraView");
                        this.agoraClient.changeAgoraView(element.playerId, agoraView);
                    }
                })
            }, 0.3)

            this.scheduleOnce(() => {
                this.gameModel.playersInfo.forEach((element) => {
                    if (element.playerId) {
                        this.agoraClient.changeShowVideo(element.playerId);
                    }
                })
            }, 0.6)
        }
    }

    showDissRoomCountDown(waitTime) {
        this.curRemainTime = waitTime;
        this.nodeCountTimerDown.active = true;
        let timer = this.nodeCountTimerDown.getChildByName("lbTime").getComponent(cc.Label);
        timer.string = this.curRemainTime + "秒";
        let lbHint = this.nodeCountTimerDown.getChildByName("lbHint").getComponent(cc.Label);

        lbHint.string = "後未開始遊戲將解散牌桌";

    }

    updateDissRoomtTimer() {
        let timer = this.nodeCountTimerDown.getChildByName("lbTime").getComponent(cc.Label);
        timer.string = this.curRemainTime + "秒";
    }

    update(dt) {
        if (this.nodeCountTimerDown.active) {
            this.timeFlag += dt;
            if (this.timeFlag >= 1) {
                this.timeFlag = 0;
                this.curRemainTime -= 1;
                this.updateDissRoomtTimer();
                if (this.curRemainTime <= 0) {
                    this.nodeCountTimerDown.active = false;
                }
            }
        }
    }

}


