
import { platform_game_id } from "../../../../script/common/ClientEnum";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { MAHJONG_RECORD_TYPE } from "../model/mahjongEnum";
import MahjongProxy from "../model/mahjongProxy";
import mahjongPersonGradeItem from "./item/mahjongPersonGradeItem";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongPersonGrade extends cc.Component {

    @property({
        tooltip: "个人战绩的滑动列表",
        type: cc.ScrollView
    })
    personRecordScrollView: cc.ScrollView = null;

    @property({
        tooltip: "个人战绩的item",
        type: cc.Prefab
    })
    personRecordItem: cc.Prefab = null;

    @property({
        tooltip: "显示当前页数的label",
        type: cc.Label
    })
    pageLabel: cc.Label = null;

    @property({
        tooltip: "沒有記錄的",
        type: cc.Node
    })
    noRecordNode: cc.Node = null;

    @property({
        tooltip: "左边箭头",
        type: cc.Button
    })
    leftBtn: cc.Button = null;

    @property({
        tooltip: "右边箭头",
        type: cc.Button
    })
    rightBtn: cc.Button = null;

    currentPage: number = 0;
    maxPage: number = 0;
    gameProxy: MahjongProxy = null;
    tableId: number = 0;

    /**
     * 初始化数据
     * @param gradeData 
     */
    init(gradeData) {
        this.tableId = MAHJONG_RECORD_TYPE.PERSONAL;
        this.refreshList(gradeData);
    }

    /**
     * 刷新列表
     * @param data 
     */
    refreshList(data) {
        this.currentPage = data.pageStart;
        this.maxPage = data.pageEnd;
        this.pageLabel.string = this.currentPage + "/" + this.maxPage;
        this.refreshBtnClick();
        let content = this.personRecordScrollView.content;
        content.removeAllChildren();
        data.rooms.forEach((element) => {
            let item = cc.instantiate(this.personRecordItem);
            content.addChild(item);
            item.getComponent(mahjongPersonGradeItem).init(element);
        });
        this.noRecordNode.active = data.rooms.length <= 0;
    }

    /**
     * 个人战绩和代开战绩切换
     * @param event 
     * @param data 
     */
    toggleClicked(event: cc.Event, data: string) {
        this.tableId = parseInt(data);
        MahjongRoomMgr.getInstance().getGameRecords({
            gameId: platform_game_id.mahjong_table,
            recordType: parseInt(data),
            pageStart: 1, pageNum: 4
        }, (data) => {
            this.refreshList(data);
        });
    }

    /**
     * 翻页按钮的点击
     * @param event 
     * @param data 
     */
    pageBtnClicked(event: cc.Event, data: string) {
        const roomType = this.tableId;
        switch (data) {
            case "left":
                if (this.currentPage > 1) {
                    MahjongRoomMgr.getInstance().getGameRecords({
                        gameId: platform_game_id.mahjong_table,
                        recordType: roomType,
                        pageStart: this.currentPage - 1,
                        pageNum: 4
                    }, (data) => {
                        this.refreshList(data);
                    });
                }
                break;
            case "right":
                if (this.currentPage < this.maxPage) {
                    MahjongRoomMgr.getInstance().getGameRecords({
                        gameId: platform_game_id.mahjong_table,
                        recordType: roomType,
                        pageStart: this.currentPage + 1,
                        pageNum: 4
                    }, (data) => {
                        this.refreshList(data);
                    });
                }
                break;
        }
    }

    refreshBtnClick() {
        this.leftBtn.interactable = this.currentPage > 1;
        this.rightBtn.interactable = this.currentPage < this.maxPage;
    }

}
