import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import MahjongModel from "../model/mahjongModel";


const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongCardPiles extends cc.Component {

    @property({
        tooltip: "每一张牌",
        type: cc.Node
    })
    nodeCard: cc.Node[] = [];

    protected onDealHideCount: number = 4;

    protected gameModel: MahjongModel = MahjongModel.getInstance();

    /**
     * 展示牌堆
     */
    showCardPiles() {
        let cardPiles = 0;
        if (this.gameModel.roomConfig.hasFlowerCard == 0) {
            cardPiles = 33;
        } else if (this.gameModel.roomConfig.hasFlowerCard == 1) {
            cardPiles = 35;
        }

        this.nodeCard.forEach((item, idx) => {
            if (idx > cardPiles) {
                item.active = false;
            } else {
                if (item.children) {
                    if (item.getChildByName("spMask")) {
                        item.getChildByName("spMask").active = false;
                    }
                    item.active = true;
                }
            }
        })
    }

    /**
     * 发牌时一次隐藏4张牌
     */
    onDealCardHideCards(pos, hideCount, idx) {
        let dealyDealCard = MahjongRoomMgr.getInstance().isBackView ? 0 : 0.12;
        this.scheduleOnce(() => {
            let min = (pos - 1) * 2;
            let max = min + hideCount;
            cc.log("min: " + min, "max: " + max)
            this.nodeCard.forEach((item, idx) => {
                if (idx >= min && idx <= max) {
                    item.active = false;
                }
            })
        }, dealyDealCard * idx)
    }

    /**
     * 隐藏摸牌
     * @param idx 
     */
    onHideMoCard(idx) {
        if (this.nodeCard && this.nodeCard.length > 0) {
            if (this.nodeCard[idx]) {
                this.nodeCard[idx].active = false;
                this.gameModel.hideCount += 1;
            }
        }
    }

    /**
     * 显示牌墩遮罩
     * @param idx 
     */
    onShowCardMask(idx) {
        if (this.nodeCard && this.nodeCard.length > 0) {
            if (this.nodeCard[idx] && this.nodeCard[idx].children) {
                if (this.nodeCard[idx].getChildByName("spMask")) {
                    this.nodeCard[idx].getChildByName("spMask").active = true;
                }
            }
        }
    }

}
