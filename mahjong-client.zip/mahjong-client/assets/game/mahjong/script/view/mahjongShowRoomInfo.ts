

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongShowRoomInfo extends cc.Component {

    @property({
        tooltip: "房间名称",
        type: cc.Label
    })
    roomNameLabel: cc.Label = null;

    @property({
        tooltip: "房間人數",
        type: cc.Label
    })
    personNumLabel: cc.Label = null;

    @property({
        tooltip: "底分",
        type: cc.Label
    })
    anteLabel: cc.Label = null;

    @property({
        tooltip: "台分",
        type: cc.Label
    })
    pointLabel: cc.Label = null;

    @property({
        tooltip: "出牌时间",
        type: cc.Label
    })
    timeLabel: cc.Label = null;

    @property({
        tooltip: "圈数",
        type: cc.Label
    })
    inningsNumLabel: cc.Label = null;

    @property({
        tooltip: "封顶",
        type: cc.Label
    })
    topLabel: cc.Label = null;

    @property({
        tooltip: "花牌",
        type: cc.Label
    })
    flowerLabel: cc.Label = null;

    @property({
        tooltip: "特殊玩法",
        type: cc.Label
    })
    specialPlayLabel: cc.Label = null;

    @property({
        tooltip: "特殊类型",
        type: cc.Label
    })
    specialTypeLabel: cc.Label = null;

    @property({
        tooltip: "房间设置",
        type: cc.Label
    })
    roomSetLabel: cc.Label = null;

    @property({
        tooltip: "创房类型",
        type: cc.Label
    })
    lbRoomType: cc.Label = null;

    @property({
        tooltip: "房间密码",
        type: cc.Label
    })
    lbPassWord: cc.Label = null;

    @property({
        tooltip: "支付方式",
        type: cc.Label
    })
    lbPayType: cc.Label = null;

    roomInfo: MahjongServerToClient.JoinRoom = null;

    /**
    * 设置房间信息
    */
    setRoomInfo(roomInfo: MahjongServerToClient.JoinRoom) {
        this.roomInfo = roomInfo;
        const roomConfig = this.roomInfo.roomConfig;
        this.roomNameLabel.string = this.roomInfo.roomName;
        if (roomConfig) {
            this.anteLabel.string = roomConfig.baseScore.toString();
            this.personNumLabel.string = roomConfig.maxPlayerNum.toString();
            this.pointLabel.string = roomConfig.fanPoint.toString();
            this.timeLabel.string = roomConfig.thinkTime + "秒";
            this.inningsNumLabel.string = roomConfig.maxRoundNum + "圈";
            if (roomConfig.maxFan == 0) {
                this.topLabel.string = "無限台";
            } else {
                this.topLabel.string = roomConfig.maxFan + "台";
            }
            this.flowerLabel.string = roomConfig.hasFlowerCard ? "有花" : "無花";
            this.roomSetLabel.string = roomConfig.isWatchGame ? "允許觀戰" : "不允許觀戰";

            if (this.lbRoomType) {
                if (roomConfig.createType == 1) {
                    this.lbRoomType.string = "普通牌桌"
                } else if (roomConfig.createType == 2) {
                    this.lbRoomType.string = "代開牌桌"
                } else if ((roomConfig.createType == 3)) {
                    this.lbRoomType.string = "公開牌桌"
                }
            }

            if (roomConfig.password) {
                this.lbPassWord.string = roomConfig.password;
            } else {
                this.lbPassWord.string = "無";
            }

            if (roomConfig.isReadyHand) {
                this.specialPlayLabel.string += " 限聽";
            }
            if (roomConfig.isLimitSelfDraw) {
                this.specialPlayLabel.string += " 限自摸";
            }
            if (roomConfig.isAutoHu) {
                this.specialPlayLabel.string += " 強制胡牌";
            }
            if (roomConfig.isDealerNoPoint) {
                this.specialPlayLabel.string += " 莊家無台";
            }
            if (roomConfig.hasFlowerWord) {
                this.specialPlayLabel.string += " 見花見字";
            }
            if (roomConfig.costType == 1) {
                this.lbPayType.string = "主揪支付";
            } else if (roomConfig.costType == 2) {
                this.lbPayType.string = "AA支付";
            }
            this.repliceEmptyStr(this.specialPlayLabel);

            if (roomConfig.hasTianDi) {
                this.specialTypeLabel.string += " 天胡、地胡";
            }
            if (roomConfig.hasRobFlower) {
                this.specialTypeLabel.string += " 七搶一";
            }
            if (roomConfig.hasEightFlower) {
                this.specialTypeLabel.string += " 八枝花";
            }
            this.repliceEmptyStr(this.specialTypeLabel);
        }
    }

    /**
     * @param str 
     * @returns 
     */
    repliceEmptyStr(label: cc.Label) {
        let str = label.string;
        let newStr = str;
        if (str.length > 2) {
            newStr = str.replace("暫無 ", "");
        }
        label.string = newStr;
    }

}
