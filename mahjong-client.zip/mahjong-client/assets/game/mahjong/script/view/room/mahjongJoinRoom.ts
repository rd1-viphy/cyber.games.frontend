
import { GAME_PRESERVE, platform_game_id } from "../../../../../script/common/ClientEnum";
import App from "../../../../../script/model/App";
import consts = require("../../../../../script/model/Consts");
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { InputType } from "../../model/mahjongEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongJoinRoom extends cc.Component {

    @property({
        tooltip: "输入房号",
        type: cc.Label
    })
    inputLabel: cc.Label = null;

    @property({
        tooltip: "输入的最大长度",
        type: cc.Integer
    })
    maxInputlength: number = 0;

    @property({
        tooltip: "标题精灵",
        type: cc.Node
    })
    inPutSign: cc.Node[] = [];

    /** 输入类型 */
    protected inputType: number = InputType.roomName;

    protected roomId: number = 0;

    protected tableData = null;

    init(data) {
        if (data.inputType) {
            this.refreshInputStatus(data.inputType);
        }

        if (data.roomId) {
            this.roomId = data.roomId;
        }
       
        MahjongRoomMgr.getInstance().isBackView = false;
    }

    /**
     * 数字键的点击
     * @param event 
     * @param data 
     */
    keyBoardBtnCliecked(event: cc.Event, data: string) {
        if (this.inputLabel.string.length < this.maxInputlength) {
            this.inputLabel.string += data;
            if (this.inputLabel.string.length == this.maxInputlength) {
                if (App.globalStatus == GAME_PRESERVE.LIMIT) {
                    App.showToast("globaling");
                } else {
                    if (this.inputType == InputType.roomName) { //输入房号
                        this.roomId = parseInt(this.inputLabel.string);
                        if (this.roomId != 0) {
                            let joinData = { gameId: platform_game_id.mahjong_table, roomId: this.roomId, password: "", step: 1 }
                            MahjongRoomMgr.getInstance().joinMahjongTable(joinData, (data: MahjongServerToClient.JoinRoom) => {
                                this.tableData = data;
                                if (data.hasPassword) {
                                    this.refreshInputStatus(InputType.password);
                                    App.showToast("mahjong_please_input_room_password", 1);
                                } else {
                                    this.node.destroy();
                                    App.loadGamePopul({
                                        prefabName: "mahjongRoomInfo",
                                        prefabPath: "prefab",
                                        prefabComponent: "mahjongRoomInfo",
                                        data: { gameInfo: data, joinTableInfo: joinData }
                                    });
                                }
                            })
                        } else {
                            App.showToast("916", 1);
                        }
                    } else {
                        let requestInfo = { gameId: platform_game_id.mahjong_table, roomId: this.roomId, password: this.inputLabel.string, step: 2 };
                        MahjongRoomMgr.getInstance().joinMahjongTable(requestInfo, (data: MahjongServerToClient.JoinRoom) => {
                            this.node.destroy();
                            if (!this.tableData) {
                                this.tableData = data;
                            }
                            App.loadGamePopul({
                                prefabName: "mahjongRoomInfo",
                                prefabPath: "prefab",
                                prefabComponent: "mahjongRoomInfo",
                                data: { gameInfo: this.tableData, joinTableInfo: requestInfo }
                            });
                        });
                    }
                }
            }
        }
    }

    /**
     * 删除
     */
    delectClicked() {
        if (this.inputLabel.string.length > 0) {
            this.inputLabel.string = this.inputLabel.string.substring(0, this.inputLabel.string.length - 1);
        }
    }

    /**
     * 清除
     */
    clearClicked() {
        this.inputLabel.string = "";
    }

    /**
     * 刷新输入状态
     */
    refreshInputStatus(status: number) {
        this.inputLabel.string = "";
        this.inputType = status;
        this.inPutSign[0].active = status == InputType.roomName;
        this.inPutSign[1].active = status == InputType.password;
        if (status == InputType.roomName) {
            this.maxInputlength = 6;
            this.inputLabel.getComponent(cc.Label).spacingX = 30.5;
            this.inputLabel.node.x = -416.266;
        } else if (status == InputType.password) {
            this.inputLabel.node.x = -400;
            this.inputLabel.getComponent(cc.Label).spacingX = 66;
            this.maxInputlength = 4;
        }
    }

}
