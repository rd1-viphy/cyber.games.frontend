
import App from "../../../../../script/model/App";
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";

import { InputType } from "../../model/mahjongEnum";
import mahjongShowRoomInfo from "../mahjongShowRoomInfo";
import MahjongRoomScene from "./mahjongRoomScene";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongRoomInfo extends cc.Component {

    @property({
        tooltip: "房間信息",
        type: mahjongShowRoomInfo
    })
    mahjongRoomInfo: mahjongShowRoomInfo = null;

    roomInfo: MahjongServerToClient.JoinRoom = null;
    joinTableInfo = null;

    /**
     * 设置房间消息
     */
    init(data) {
        this.roomInfo = data.gameInfo;
        if (data.joinTableInfo) {
            this.joinTableInfo = data.joinTableInfo;
            this.joinTableInfo.step = 3;
        }
        this.mahjongRoomInfo.setRoomInfo(this.roomInfo);
    }

    /**
     * 按钮的点击
     * @param event 
     * @param data 
     */
    btnClicked(event: cc.Event, data: string) {
        switch (data) {
            case 'sure':    //确定加入
                let isFree = (MahjongRoomMgr.getInstance().isFreeTable && MahjongRoomMgr.getInstance().getIsIncludeActivities(MahjongRoomMgr.getInstance().startTime, MahjongRoomMgr.getInstance().endTime)) ? true : false;
                if (this.roomInfo.roomConfig.gameStatus <= 2 && this.roomInfo.roomConfig.isShareEquallyRoom && !isFree) {
                    let opts = {
                        confirmCallback: () => {
                            if (PlayerMgr.getInstance().money >= this.roomInfo.costMoney) {
                                MahjongRoomMgr.getInstance().joinMahjongTable(this.joinTableInfo, () => {
                                    PlayerMgr.getInstance().money -= this.roomInfo.costMoney;
                                    let mahjongRoom = cc.find("Canvas");
                                    if (mahjongRoom && mahjongRoom.getComponent(MahjongRoomScene)) {
                                        mahjongRoom.getComponent(MahjongRoomScene).refreshMoneyLabel();
                                    }
                                    App.refreshPlatformScore();
                                })
                            } else {
                                Utils.showSDKOpenBroken();
                            }
                        },
                        money: this.roomInfo.costMoney,
                        isCreate: false
                    }
                    App.loadGamePopul({
                        prefabName: "mahjongSureTipNode",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongSureTipNode",
                        data: opts
                    });
                } else {
                    MahjongRoomMgr.getInstance().joinMahjongTable(this.joinTableInfo)
                }

                break;
            case 'cancle':  //取消
                this.node.destroy();
                App.loadGamePopul({
                    prefabName: "mahjongJoinRoom",
                    prefabPath: "prefab",
                    prefabComponent: "mahjongJoinRoom",
                    data: InputType.roomName
                })
                break;
            default:
                break;
        }
    }


}
