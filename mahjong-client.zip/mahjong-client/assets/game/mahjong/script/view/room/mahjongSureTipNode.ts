
import consts = require("../../../../../script/model/Consts");
import { Utils } from "../../../../../script/model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongSureTipNode extends cc.Component {

  confirmCallback: Function = null;
  cancleCallback: Function = null;

  @property({
    tooltip: "花费金币数",
    type: cc.Label,
  })
  goldCoinLabel: cc.Label = null;

  @property({
    tooltip: "提示是加入还是创建",
    type: cc.Label,
  })
  tipLabel: cc.Label = null;

  @property({
    tooltip: "红色提示",
    type: cc.Label,
  })
  lbTipHint: cc.Label = null;

  @property({
    tooltip: "好运金币显示",
    type: cc.Label
  })
  lbWangPaiCost: cc.Label = null;

  @property({
    tooltip: "金币节点",
    type: cc.Node
  })
  nodeLaoZiCost: cc.Node = null;

  @property({
    tooltip: "提示节点",
    type: cc.Node
  })
  nodeNormal: cc.Node = null;

  @property({
    tooltip: "免费提示",
    type: cc.Label
  })
  nodeFreeHint: cc.Label = null;

  init(opts) {
    opts = opts || {};
    this.confirmCallback = opts["confirmCallback"];
    this.cancleCallback = opts["cancleCallback"];

    this.lbWangPaiCost.node.active = false;
    this.nodeLaoZiCost.active = true;
    this.goldCoinLabel.string = Utils.formatCoinNum(opts.money);


    this.tipLabel.string = opts.isCreate ? "創建牌桌？" : "加入牌桌？";
    this.lbTipHint.string = opts.isCreate
      ? "若牌桌未進行遊戲，牌桌解散後返還全部費用？"
      : "若您未進行遊戲，牌桌解散後返還全部費用？";

    if (opts.isFree) {
      this.nodeNormal.active = false;
      this.nodeFreeHint.node.active = true;
    }
  }

  btnClicked(event: any, data: string) {
    switch (data) {
      case "confirm":
        this.confirmCallback && this.confirmCallback();
        break;
      case "cancle":
        this.cancleCallback && this.cancleCallback();
        break;
    }
    this.node.removeFromParent();
    //this.node.destroy();
  }
}
