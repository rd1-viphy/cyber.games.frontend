import mahjongCreateRoom from "./mahjongCreateRoom";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongCreateRoomSelectNode extends cc.Component {

    @property({
        tooltip: "显示的文字",
        type: cc.Label
    })
    label: cc.Label = null;

    @property({
        tooltip: "单位"
    })
    unit: string = "";

    @property({
        tooltip: "是否是圈數"
    })
    isInnings: boolean = false;

    @property({
        tooltip: "加的按钮",
        type: cc.Button
    })
    addBtn: cc.Button = null;

    @property({
        tooltip: "减的按钮",
        type: cc.Button
    })
    minusBtn: cc.Button = null;

    /**当前值 */
    value: number = 0;

    /**限制值 */
    limitValue: number[] = [];

    createView: mahjongCreateRoom = null;

    init(data: number[], createView: mahjongCreateRoom) {
        this.createView = createView;
        this.limitValue = data;
        this.setLabel(data[0]);
    }

    /**
     * 设置当前数值
     * @param value 
     */
    setLabel(value: number) {
        this.value = value;
        this.label.string = value.toString() + this.unit;
        this.refreshBtn();
        if (this.isInnings) {
            this.createView.refreshCreateFree();
        }
    }

    /**
     * 刷新按钮状态
     */
    refreshBtn() {
        this.addBtn.interactable = this.value < this.limitValue[this.limitValue.length - 1];
        this.minusBtn.interactable = this.value > this.limitValue[0];
    }

    /**
     * 加号点击
     */
    addClicked() {
        let idx = this.getRoomConfigArryIdx(this.limitValue, this.value);
        if (idx < this.limitValue.length - 1) {
            this.setLabel(this.limitValue[idx + 1]);
        }
    }

    /**
     * 减号的点击
     */
    minusClicked() {
        let idx = this.getRoomConfigArryIdx(this.limitValue, this.value);
        if (idx > 0) {
            this.setLabel(this.limitValue[0]);
        }
    }

    private getRoomConfigArryIdx(array, idx) {
        for (let i = 0; i < array.length; i++) {
            const element = array[i];
            if (element == idx) {
                return i;
            }
        }
    }

}
