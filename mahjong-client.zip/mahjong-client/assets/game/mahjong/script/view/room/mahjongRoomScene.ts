import { GAME_PRESERVE, platform_game_id } from "../../../../../script/common/ClientEnum";
import App from "../../../../../script/model/App";
import AudioMgr from "../../../../../script/model/AudioMgr";
import consts = require("../../../../../script/model/Consts");
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";
import AppEmitter from "../../../../../script/network/AppEmitter";

import { InputType, MAHJONG_CONST, MAHJONG_REQUEST_ROUTE } from "../../model/mahjongEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongRoomScene extends cc.Component {

    @property({
        tooltip: "玩家钱数",
        type: cc.Label
    })
    moneyLabel: cc.Label = null;

    @property(cc.Prefab)
    createRoomPrefab: cc.Prefab = null;

    @property(cc.Prefab)
    joinRoomPrefab: cc.Prefab = null;

    @property({
        tooltip: "储值节点",
        type: cc.Node
    })
    nodeStore: cc.Node = null;

    @property({
        tooltip: "Ace快顯節點",
        type: cc.Node
    })
    nodeAceSdkMsg: cc.Node = null;

    @property({
        tooltip: "跑马灯节点",
        type: cc.Node
    })
    nodeMarquee: cc.Node = null;

    @property({
        tooltip: "新手引导节点",
        type: cc.Node
    })
    guideAniNode: cc.Node = null;

    @property({
        tooltip: "引导按钮",
        type: cc.Node
    })
    guideBtn: cc.Node = null;

    @property({
        tooltip: "topBox",
        type: cc.Node
    })
    nodeTopBox: cc.Node = null;

    @property(({
        tooltip: "限时免费",
        type: cc.Node
    }))
    nodeFree: cc.Node = null;

    onLoad() {
        this.refreshMoneyLabel();
        AppEmitter.on(consts.LOCAL_EVENT_UPDATEPLAYERGOLD, this.refreshMoneyLabel, this);
        AppEmitter.on(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame, this);
        AppEmitter.on(consts.LOCAL_CURRECT_SCENE_JUMP_SCHEDULE, this.startCheckSceneJump, this);

        const isOpenTeachView = JSON.parse(cc.sys.localStorage.getItem("mahjongLookTeachView"));
        if (!isOpenTeachView) {
            this.guideAniNode.active = true;
            const ani = this.guideAniNode.getComponent(cc.Animation);
            ani.play();
        } else {
            this.guideAniNode.active = false;
        }

        //获取房间配置
        let roomMgr: MahjongRoomMgr = MahjongRoomMgr.getInstance();
        roomMgr.queryCreateRoomConfig((data: MahjongServerToClient.CreateRoomConfig) => {
            MahjongRoomMgr.getInstance().isFreeTable = data.freeTableSwitch == 1 ? true : false;
            MahjongRoomMgr.getInstance().isFreeEmoji = data.freeEmotionSwitch == 1 ? true : false;
            MahjongRoomMgr.getInstance().startTime = data.startFreeTime;
            MahjongRoomMgr.getInstance().endTime = data.endFreeTime;
            this.nodeFree.active = (data.freeTableSwitch && MahjongRoomMgr.getInstance().getIsIncludeActivities(data.startFreeTime, data.endFreeTime)) ? true : false;
        })
        App.clearAgoraCache();
    }

    start() {
        AudioMgr.playBGM(MAHJONG_CONST.Sound.NewYearBGM, true);

        const isShowTips = JSON.parse(cc.sys.localStorage.getItem("mahjongMianZe"));
        if (isShowTips) {
            App.loadGamePopul({ prefabName: "mahjongDisclaimersView", prefabPath: "prefab" });
        }

        MahjongRoomMgr.getInstance().getRenewRoom({ gameId: platform_game_id.mahjong_table }, (data) => {
            //是否续房
            if (data.confirmRenewData) {
                App.loadGamePopul({ prefabName: "mahjongContinueRoom", prefabPath: "prefab", prefabComponent: "mahjongContinueRoom", data: data.confirmRenewData });
            } else {
                //是否接受邀请
                if (data.confirmJoinRoomData) {
                    App.loadGamePopul({ prefabName: "mahjongInviteToRoom", prefabPath: "prefab", prefabComponent: "mahjongInviteToRoom", data: data.confirmJoinRoomData });
                }
            }
        }, () => { })

        this.nodeTopBox.zIndex = 1900;
        this.nodeAceSdkMsg.zIndex = 2000;

        Utils.showSDKMarquee(this.nodeMarquee);
    }

    /**
     * 好运点击显示小银行
     */
    openSDKMiniBank() {

    }

    /**
     * 房间界面的按钮点击
     */
    btnClicked(event: cc.Event, btnName: string) {
        switch (btnName) {
            case "creatRoom":
                if (App.globalStatus == GAME_PRESERVE.LIMIT) {
                    App.showToast("globaling");
                } else {
                    let roomMgr: MahjongRoomMgr = MahjongRoomMgr.getInstance();
                    roomMgr.queryCreateRoomConfig((data: MahjongServerToClient.CreateRoomConfig) => {
                        App.loadGamePopul({
                            prefabName: "mahjongCreateRoom",
                            prefabPath: "prefab",
                            prefabComponent: "mahjongCreateRoom",
                            notAction: true,
                            data: data
                        });
                    });
                }
                break;
            case "joinRoom":
                if (App.globalStatus == GAME_PRESERVE.LIMIT) {
                    App.showToast("globaling");
                } else {
                    App.loadGamePopul({
                        prefabName: "mahjongJoinRoom",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongJoinRoom",
                        data: {
                            inputType: InputType.roomName
                        }
                    })
                }
                break;
            case "back":
                // if (cc.sys.isNative) {
                //     nativeAcePlatfromSdk.leaveGame();
                //     event.target.getComponent(cc.Button).interactable = false;
                // } else {
                //     if (consts.isAccessPlatform) {
                //         App.exitGame();
                //     } else {
                //         App.changeScene({ "sceneName": consts.LOBBY_SCENE });
                //     }
                // }
                break;
            case "menu":
                App.loadGamePopul({
                    prefabName: "mahjongMenuNode",
                    prefabPath: "prefab",
                    notAction: false,
                    prefabComponent: "mahjongMenu"
                })
                break;
            case "guide":
                this.guideAniNode.active = false;
                this.guideAniNode.getComponent(cc.Animation).stop();
                App.loadGamePopul({ prefabName: "mahjongGuideTeachView", prefabPath: "prefab", notAction: false });
                break;
            case "close":
                this.node.destroy();
                break;
        }
    }

    refreshMoneyLabel() {
        //显示金币
        let currectMoney = PlayerMgr.getInstance().money;
        if (currectMoney > consts.MAX_COIN) {
            this.moneyLabel.string = consts.MAX_COIN.toString();
        } else {

            this.moneyLabel.string = Utils.formatNumDistance(currectMoney.toFixed(2));

        }
    }

    /**
     * 有邀请
     * @param data 
     */
    onInviteToContinueGame(data) {
        App.showLog("onInviteJoinRoomPush", data);
        if (data) {
            App.loadGamePopul({ prefabName: "mahjongInviteToRoom", prefabPath: "prefab", prefabComponent: "mahjongInviteToRoom", data: data });
        }
    }

    /**
     * 开始检测场景跳转
     */
    startCheckSceneJump() {
        this.unschedule(this.gameOutTip);
        this.scheduleOnce(() => {
            this.gameOutTip();
        }, 5);
    }

    /**
     * 检测跳转游戏场景
     */
    gameOutTip() {
        let opts = {
            contentLabel: "net_err_again_enter",
            okCallback: () => {
                App.exitGame();
            }
        }
        App.loadDialogBox(opts);
    }

    onDestroy() {
        this.unscheduleAllCallbacks();
        AppEmitter.off(MAHJONG_REQUEST_ROUTE.GAME_INVITE_PLAYER, this.onInviteToContinueGame);
        AppEmitter.off(consts.LOCAL_EVENT_UPDATEPLAYERGOLD, this.refreshMoneyLabel);
        AppEmitter.off(consts.LOCAL_CURRECT_SCENE_JUMP_SCHEDULE, this.startCheckSceneJump);
    }

}
