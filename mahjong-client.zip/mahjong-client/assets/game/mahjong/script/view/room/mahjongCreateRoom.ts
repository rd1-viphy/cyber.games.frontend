import { GAME_PRESERVE, platform_game_id } from "../../../../../script/common/ClientEnum";
import App from "../../../../../script/model/App";
import consts = require("../../../../../script/model/Consts");
import PlayerMgr from "../../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../../script/model/roomMgr/mahjongRoomMgr";
import { Utils } from "../../../../../script/model/Utils";
import AppEmitter from "../../../../../script/network/AppEmitter";
import HttpUtils from "../../../../../script/network/HttpUtils";

import { MAHJONG_ROOM_TYPE } from "../../model/mahjongEnum";
import mahjongCreateRoomSelectNode from "./mahjongCreateRoomSelectNode";

const { ccclass, property } = cc._decorator;
@ccclass
export default class mahjongCreateRoom extends cc.Component {
    @property({
        tooltip: "创建房间的费用",
        type: cc.Label
    })
    createFreeNum: cc.Label = null;

    @property({
        tooltip: "房间名输入框",
        type: cc.EditBox
    })
    roomNameEditBox: cc.EditBox = null;

    @property({
        tooltip: "设置密码开关",
        type: cc.Sprite
    })
    setPasswordSprite: cc.Sprite = null;

    @property({
        tooltip: "密码开关的精灵集",
        type: cc.SpriteFrame
    })
    passwordBtnSpriteFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "密码输入框",
        type: cc.EditBox
    })
    passwordEditBox: cc.EditBox = null;

    @property({
        tooltip: "人數",
        type: cc.ToggleContainer
    })
    personNumToggleContainer: cc.ToggleContainer = null;

    @property({
        tooltip: "支付方式",
        type: cc.ToggleContainer
    })
    payToggleContainer: cc.ToggleContainer = null;

    @property({
        tooltip: "創房方式",
        type: cc.ToggleContainer
    })
    createTypeContainer: cc.ToggleContainer = null;

    @property({
        tooltip: "是否带花",
        type: cc.ToggleContainer
    })
    flowerToggleContainer: cc.ToggleContainer = null;

    @property({
        tooltip: "封顶",
        type: cc.ToggleContainer
    })
    topToggleContainer: cc.ToggleContainer = null;

    @property({
        tooltip: "特殊玩法的复选框 [限听，限自摸，强制胡牌，庄家无台，见花见字]",
        type: cc.Toggle
    })
    specialPlayToggles: cc.Toggle[] = [];

    @property({
        tooltip: "特殊牌型的复选框 [七抢一，天胡、地胡， 八枝花]",
        type: cc.Toggle
    })
    specialTypeToggles: cc.Toggle[] = [];

    @property({
        tooltip: "开桌方式",
        type: cc.Toggle
    })
    spCreatePayType: cc.Toggle[] = [];

    @property({
        tooltip: "支付方式",
        type: cc.Toggle
    })
    spPayType: cc.Toggle[] = [];

    @property({
        tooltip: "观战",
        type: cc.Toggle
    })
    isWatchGameToggle: cc.Toggle = null;

    @property({
        tooltip: "底分滑动",
        type: cc.Slider
    })
    diFenSlider: cc.Slider = null;

    @property({
        tooltip: "底分",
        type: cc.Node
    })
    diFenCountLayer: cc.Node = null;

    @property({
        tooltip: "底分Hander",
        type: cc.Node
    })
    diFenHander: cc.Node = null;

    @property({
        tooltip: "台分滑动",
        type: cc.Slider
    })
    taiFenSlider: cc.Slider = null;

    @property({
        tooltip: "台分",
        type: cc.Node
    })
    taiFenCountLayer: cc.Node = null;

    @property({
        tooltip: "台分Hander",
        type: cc.Node
    })
    taiFenHander: cc.Node = null;

    @property({
        tooltip: "思考时间滑动",
        type: cc.Slider
    })
    thinkTimeSlider: cc.Slider = null;

    @property({
        tooltip: "思考时间",
        type: cc.Node
    })
    thinkTimeLayer: cc.Node = null;

    @property({
        tooltip: "思考时间Hander",
        type: cc.Node
    })
    thinkTimeHander: cc.Node = null;

    @property({
        tooltip: "圈数滑动",
        type: cc.Slider
    })
    lapCountSlider: cc.Slider = null;

    @property({
        tooltip: "圈数",
        type: cc.Node
    })
    lapCountLayer: cc.Node = null;

    @property({
        tooltip: "圈数Hander",
        type: cc.Node
    })
    lapCountHander: cc.Node = null;

    @property({
        tooltip: "slider档位标记",
        type: cc.Node
    })
    posItem: cc.Node = null;

    @property({
        tooltip: "圈数打折节点",
        type: cc.Node
    })
    nodeLapZhe: cc.Node = null;

    @property({
        tooltip: "圈数打几折",
        type: cc.Label
    })
    lbLapZheCount: cc.Label = null;

    @property({
        tooltip: "费用特价节点",
        type: cc.Node
    })
    nodeCostTeJia: cc.Node = null;

    @property({
        tooltip: "特价费用数",
        type: cc.Label
    })
    lbCostTeJia: cc.Label = null;

    @property({
        tooltip: "金币显示",
        type: cc.Node
    })
    nodeLaoZiCost: cc.Node = null;

    @property({
        tooltip: "好运金币显示",
        type: cc.Label
    })
    lbWangPaiCost: cc.Label = null;

    @property({
        tooltip: "春节优惠节点",
        type: cc.Node
    })
    nodeNewYear: cc.Node = null;

    @property({
        tooltip: "春节优惠时间",
        type: cc.Label
    })
    lbNewYearOffersTime: cc.Label = null;

    @property({
        tooltip: "创建费用限时免费",
        type: cc.Node
    })
    nodeCostFree: cc.Node = null;

    @property({
        tooltip: "自定义底分",
        type: cc.EditBox
    })
    diFenEditBox: cc.EditBox = null;

    @property({
        tooltip: "自定义台分",
        type: cc.EditBox
    })
    taiFenEdiBox: cc.EditBox = null;

    @property({
        tooltip: "底分输入范围",
        type: cc.Label
    })
    lbBaseFree: cc.Label = null;

    @property({
        tooltip: "台分输入范围",
        type: cc.Label
    })
    lbFanPointFree: cc.Label = null;

    protected setPasswordStatus: number = 0;
    protected roundCost: number = 0;
    protected roundCostDisCount: number[] = [];
    protected createConfig: MahjongServerToClient.CreateRoomConfig = null;
    protected personNumConfig: number[] = [2, 3, 4];
    protected payMethods: number[] = [0, 1];
    protected createType: number[] = [1, 2, 3];
    protected costType: number[] = [1, 2];
    protected whileColor: cc.Color = cc.color(255, 255, 255);
    protected yellowColor: cc.Color = cc.color(255, 242, 41);
    protected purpleColor: cc.Color = cc.color(133, 123, 175);
    /** 底分每个档位的slider间距 */
    protected diFenCountSpace: number = 0;
    /** 底分档位 */
    protected diFenCountPos: number = 0;
    /** 台分每个档位的slider间距 */
    protected taiFenCountSpace: number = 0;
    /** 台分档位 */
    protected taiFenCountPos: number = 0;
    /** 思考时间每个档位的slider间距 */
    protected thinkTimeCountSpace: number = 0;
    /** 思考时间档位 */
    protected thinkTimeCountPos: number = 0;
    /** 圈数每个档位的slider间距 */
    protected lapCountSpace: number = 0;
    /** 圈数档位 */
    protected lapCountPos: number = 0;
    /** 真實消耗費用 */
    protected realCreateCost: number = 0;
    /** 是否自定义底分 */
    protected isInputDifen: boolean = false;
    /** 是否自定义台分 */
    protected isInputTaiFen: boolean = false;
    /** 底分 */
    protected baseCount: number = 0;
    /** 台分 */
    protected taiCount: number = 0;

    onLoad() {
        this.diFenSlider.node.on(cc.Node.EventType.TOUCH_END, this.onDiFenCountTouchEnd, this);
        this.diFenSlider.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onDiFenCountTouchEnd, this);
        this.diFenHander.on(cc.Node.EventType.TOUCH_END, this.onDiFenCountTouchEnd, this);
        this.diFenHander.on(cc.Node.EventType.TOUCH_CANCEL, this.onDiFenCountTouchEnd, this);

        this.taiFenSlider.node.on(cc.Node.EventType.TOUCH_END, this.onTaiFenCountTouchEnd, this);
        this.taiFenSlider.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTaiFenCountTouchEnd, this);
        this.taiFenHander.on(cc.Node.EventType.TOUCH_END, this.onTaiFenCountTouchEnd, this);
        this.taiFenHander.on(cc.Node.EventType.TOUCH_CANCEL, this.onTaiFenCountTouchEnd, this);

        this.thinkTimeSlider.node.on(cc.Node.EventType.TOUCH_END, this.onThinkTimeCountTouchEnd, this);
        this.thinkTimeSlider.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onThinkTimeCountTouchEnd, this);
        this.thinkTimeHander.on(cc.Node.EventType.TOUCH_END, this.onThinkTimeCountTouchEnd, this);
        this.thinkTimeHander.on(cc.Node.EventType.TOUCH_CANCEL, this.onThinkTimeCountTouchEnd, this);

        this.lapCountSlider.node.on(cc.Node.EventType.TOUCH_END, this.onLapCountTouchEnd, this);
        this.lapCountSlider.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onLapCountTouchEnd, this);
        this.lapCountHander.on(cc.Node.EventType.TOUCH_END, this.onLapCountTouchEnd, this);
        this.lapCountHander.on(cc.Node.EventType.TOUCH_CANCEL, this.onLapCountTouchEnd, this);
    }

    /**
     * 初始化房间信息
     */
    init(createConfig: MahjongServerToClient.CreateRoomConfig) {
        this.nodeNewYear.active = createConfig.festivalSwitch == 1 ? true : false;
        this.passwordEditBox.enabled = false;
        MahjongRoomMgr.getInstance().isBackView = false;
        this.refreshPassworrdLabelColor();
        //获取敏感字
        if (App.shieldDatas == undefined || App.shieldDatas.length < 1) {
            // HttpUtils.httpGet(consts.chessReqUrl.sensitiveWordsAdress, consts.HTTP_ROUTE.GET_SHIELDED_WORD, {}, (data) => {
            //     App.shieldDatas = JSON.parse(data);
            // });
        }
        this.roundCost = createConfig.roundCost;
        this.createConfig = createConfig;

        MahjongRoomMgr.getInstance().isFreeTable = this.createConfig.freeTableSwitch == 1 ? true : false;
        MahjongRoomMgr.getInstance().isFreeEmoji = this.createConfig.freeEmotionSwitch == 1 ? true : false;
        MahjongRoomMgr.getInstance().startTime = this.createConfig.startFreeTime;
        MahjongRoomMgr.getInstance().endTime = this.createConfig.endFreeTime;

        if (this.createConfig.freeTableSwitch && MahjongRoomMgr.getInstance().getIsIncludeActivities(this.createConfig.startFreeTime, this.createConfig.endFreeTime)) {
            this.nodeNewYear.active = true;
            this.nodeCostFree.active = true;
            this.nodeCostTeJia.active = false;
            this.nodeLaoZiCost.active = false;
            this.createFreeNum.node.parent.active = false;
            let startTime = Utils.formatTimestamp2(this.createConfig.startFreeTime);
            let endTime = Utils.formatTimestamp2(this.createConfig.endFreeTime);
            //this.lbNewYearOffersTime.string = startTime + "~" + endTime;
            this.lbNewYearOffersTime.string = "";
        } else {
            this.createFreeNum.node.parent.active = true;
            this.nodeNewYear.active = false;
            this.nodeCostFree.active = false;
        }

        //初始化界面
        this.showView(createConfig);
        //记录创房信息
        this.showCreateRecord();
        this.popShowAnim(this.node);
    }

    showView(createConfig: MahjongServerToClient.CreateRoomConfig) {
        //底分
        const diFenCount = createConfig.baseScore.length - 1;
        this.diFenCountLayer.children.forEach(item => item.active = false);
        this.diFenCountLayer.getComponent(cc.Layout).spacingX = 590 / (diFenCount);
        for (let i = 0; i <= diFenCount; i++) {
            let item = this.diFenCountLayer.children[i];
            if (item) {
                item.active = true;
            } else {
                item = cc.instantiate(this.posItem);
                item.active = true;
                this.diFenCountLayer.addChild(item);
            }
            item.getComponentInChildren(cc.Label).string = `${createConfig.baseScore[i]}`;
        }
        this.diFenCountSpace = 1 / (diFenCount);
        this.diFenSlider.progress = 0;
        this.updateDiFenLable(this.diFenSlider.progress);
        this.lbBaseFree.string = "(限：" + this.createConfig.baseScoreRange[0] + "~" + this.createConfig.baseScoreRange[1] + ")";
        this.lbFanPointFree.string = "(限：" + this.createConfig.fanPointRange[0] + "~" + this.createConfig.fanPointRange[1] + ")";
        //台分
        const taiFenCount = createConfig.pointScore.length - 1;
        this.taiFenCountLayer.children.forEach(item => item.active = false);
        this.taiFenCountLayer.getComponent(cc.Layout).spacingX = 590 / (taiFenCount);
        for (let i = 0; i <= taiFenCount; i++) {
            let item = this.taiFenCountLayer.children[i];
            if (item) {
                item.active = true;
            } else {
                item = cc.instantiate(this.posItem);
                item.active = true;
                this.taiFenCountLayer.addChild(item);
            }
            item.getComponentInChildren(cc.Label).string = `${createConfig.pointScore[i]}`;
        }
        this.taiFenCountSpace = 1 / (taiFenCount);
        this.taiFenSlider.progress = 0;
        this.updateTaiFenLable(this.taiFenSlider.progress);
        //出牌时间
        const thinkTimeFenCount = createConfig.thinkTime.length - 1;
        this.thinkTimeLayer.children.forEach(item => item.active = false);
        this.thinkTimeLayer.getComponent(cc.Layout).spacingX = 590 / (thinkTimeFenCount);
        for (let i = 0; i <= thinkTimeFenCount; i++) {
            let item = this.thinkTimeLayer.children[i];
            if (item) {
                item.active = true;
            } else {
                item = cc.instantiate(this.posItem);
                item.active = true;
                this.thinkTimeLayer.addChild(item);
            }
            item.getComponentInChildren(cc.Label).string = `${createConfig.thinkTime[i]}`;
        }
        this.thinkTimeCountSpace = 1 / (thinkTimeFenCount);
        this.thinkTimeSlider.progress = 2 * this.thinkTimeCountSpace;
        this.updateThinkTimeLable(this.thinkTimeSlider.progress);
        //圈数
        const lapCount = Math.floor((createConfig.roundLimit.length - 1) / 2);
        this.lapCountLayer.children.forEach(item => item.active = false);
        this.lapCountLayer.getComponent(cc.Layout).spacingX = 590 / (lapCount);
        for (let i = 0; i <= lapCount; i++) {
            let item = this.lapCountLayer.children[i];
            if (item) {
                item.active = true;
            } else {
                item = cc.instantiate(this.posItem);
                item.active = true;
                this.lapCountLayer.addChild(item);
            }
            item.getComponentInChildren(cc.Label).string = `${createConfig.roundLimit[i * 2]}`;
        }
        this.lapCountSpace = 1 / (lapCount);
        this.lapCountSlider.progress = 0;
        this.updateLapCountLable(this.lapCountSlider.progress);

        //人数
        this.personNumConfig[this.getToggleContainerSelectIndex(this.personNumToggleContainer)];
        //封顶
        this.topToggleContainer.toggleItems.forEach((item: cc.Toggle, index) => {
            let label1 = item.node.getChildByName("Background").getChildByName("label").getComponent(cc.Label);
            let label2 = item.node.getChildByName("checkmark").getChildByName("label").getComponent(cc.Label);
            let str = "";
            if (createConfig.pointLimit[index] == 0) {
                str = "無限台";
            } else {
                str = createConfig.pointLimit[index] + "台";
            }
            label1.string = str;
            label2.string = str;
        });

        this.refreshCreateFree();
    }

    showCreateRecord() {
        const recordData = this.getCreateRoomRecord();
        if (recordData) {
            // 底注
            if (this.createConfig.baseScoreRange[0] < recordData.roomConfig.baseScore && recordData.roomConfig.baseScore <= this.createConfig.baseScoreRange[1]) {
                if (recordData.isInputAnte) {
                    this.diFenEditBox.string = recordData.roomConfig.baseScore.toString();
                    this.diFenEditBox.textLabel.node.color = this.yellowColor;
                    this.isInputDifen = true;
                    this.diFenHander.getChildByName("spMask").active = true;
                    this.onClearSliderSel(this.diFenCountLayer);
                } else {
                    const diFenIdx = this.getRoomConfigArryIdx(this.createConfig.baseScore, recordData.roomConfig.baseScore);
                    if (diFenIdx) {
                        this.diFenSlider.progress = diFenIdx * this.diFenCountSpace;
                        this.diFenCountPos = diFenIdx;
                        this.setSliderSelectLabel(this.diFenCountLayer, diFenIdx);
                    }
                }
            }
            //台分
            if (this.createConfig.fanPointRange[0] < recordData.roomConfig.fanPoint && recordData.roomConfig.fanPoint <= this.createConfig.fanPointRange[1]) {
                if (recordData.isInputFanPoint) {
                    this.taiFenEdiBox.string = recordData.roomConfig.fanPoint.toString();
                    this.taiFenEdiBox.textLabel.node.color = this.yellowColor;
                    this.isInputTaiFen = true;
                    this.taiFenHander.getChildByName("spMask").active = true;
                    this.onClearSliderSel(this.taiFenCountLayer);
                } else {
                    const taiFenIdx = this.getRoomConfigArryIdx(this.createConfig.pointScore, recordData.roomConfig.fanPoint);
                    if (taiFenIdx) {
                        this.taiFenSlider.progress = taiFenIdx * this.taiFenCountSpace;
                        this.taiFenCountPos = taiFenIdx;
                        this.setSliderSelectLabel(this.taiFenCountLayer, taiFenIdx);
                    }
                }
            }

            //出牌时间
            const thinkTimeIdx = this.getRoomConfigArryIdx(this.createConfig.thinkTime, recordData.roomConfig.thinkTime);
            this.thinkTimeSlider.progress = thinkTimeIdx * this.thinkTimeCountSpace;
            this.thinkTimeCountPos = thinkTimeIdx;
            this.setSliderSelectLabel(this.thinkTimeLayer, thinkTimeIdx);
            //圈数
            const lapCountIdx = this.getRoomConfigArryIdx(this.createConfig.roundLimit, recordData.roomConfig.maxRoundNum);
            this.lapCountSlider.progress = lapCountIdx / 2 * this.lapCountSpace;
            this.lapCountPos = lapCountIdx / 2;
            this.setSliderSelectLabel(this.lapCountLayer, lapCountIdx / 2);
            // 人数
            this.setToggleContainerSelIdx(this.personNumToggleContainer, recordData.roomConfig.maxPlayerNum - 2);
            // 限听
            this.specialPlayToggles[0].isChecked = recordData.roomConfig.isReadyHand ? true : false;
            // 限自摸
            this.specialPlayToggles[1].isChecked = recordData.roomConfig.isLimitSelfDraw ? true : false;
            // 强制胡
            this.specialPlayToggles[2].isChecked = recordData.roomConfig.isAutoHu ? true : false;
            // 庄家無台
            this.specialPlayToggles[3].isChecked = recordData.roomConfig.isDealerNoPoint ? true : false;
            // 天胡、地胡
            this.specialTypeToggles[0].isChecked = recordData.roomConfig.hasTianDi ? true : false;
            // 是否代开
            this.spCreatePayType[1].isChecked = recordData.roomConfig.isAgent ? true : false;
            // 是否观战
            this.isWatchGameToggle.isChecked = recordData.roomConfig.isWatchGame ? true : false;
            //封頂
            let topIdx = this.getRoomConfigArryIdx(this.createConfig.pointLimit, recordData.roomConfig.maxFan);
            this.setToggleContainerSelIdx(this.topToggleContainer, topIdx);
            // 花牌
            let flowerValue = recordData.roomConfig.hasFlowerCard;
            let selFlowerToggle = recordData.roomConfig.hasFlowerCard == 0 ? 1 : 0;
            this.setToggleContainerSelIdx(this.flowerToggleContainer, selFlowerToggle);

            if (flowerValue) {
                //見花見字
                this.specialPlayToggles[4].isChecked = recordData.roomConfig.hasFlowerWord;
                // 七抢一
                this.specialTypeToggles[1].isChecked = recordData.roomConfig.hasRobFlower;
                // 八枝花
                this.specialTypeToggles[2].isChecked = recordData.roomConfig.hasEightFlower;
            } else {
                this.specialPlayToggles[4].node.active = false;
                // 七抢一
                this.specialTypeToggles[1].node.active = false;
                // 八枝花
                this.specialTypeToggles[2].node.active = false;
            }

            this.setToggleContainerSelIdx(this.createTypeContainer, recordData.roomConfig.createType - 1);
            //支付方式
            this.setToggleContainerSelIdx(this.payToggleContainer, recordData.roomConfig.isShareEquallyRoom);
            if (recordData.roomConfig.isShareEquallyRoom) {
                this.spCreatePayType[1].node.active = false;
                this.spCreatePayType[2].node.active = false;
            }
            this.refreshCreateFree();
        }
    }

    /**
    * 设置密码开关
    */
    setPasswordClicked() {
        if (this.setPasswordStatus == 1) {
            this.setPasswordStatus = 0;
            this.passwordEditBox.enabled = false;
        } else {
            this.setPasswordStatus = 1;
            this.passwordEditBox.enabled = true;
        }
        this.setPasswordSprite.spriteFrame = this.passwordBtnSpriteFrames[this.setPasswordStatus];
        this.refreshPassworrdLabelColor();
    }

    /**
     * 创建房间按钮的点击
     */
    createClicked(event, data) {
        if (App.globalStatus == GAME_PRESERVE.LIMIT) {
            App.showToast("globaling");
            return;
        }

        //设置密码  开启时判断是否输入了密码
        if (this.setPasswordStatus == 1 && this.passwordEditBox.string.length != 4) {
            App.showToast("mahjong_please_input_room_password");
            return;
        }

        //房間名稱
        let roomName = Utils.onFilterEmoji(this.roomNameEditBox.string);
        if (roomName == "") {
            roomName = this.generateRoomName();
        }

        //密碼
        let isSetPassword = this.setPasswordStatus;
        let password = isSetPassword ? this.passwordEditBox.string : "";
        //底註
        if (this.isInputDifen) {
            this.baseCount = parseInt(this.diFenEditBox.string);
        } else {
            this.baseCount = this.createConfig.baseScore[this.diFenCountPos];
        }

        //人數
        let personNum = this.personNumConfig[this.getToggleContainerSelectIndex(this.personNumToggleContainer)];
        //台分
        if (this.isInputTaiFen) {
            this.taiCount = parseInt(this.taiFenEdiBox.string);
        } else {
            this.taiCount = this.createConfig.pointScore[this.taiFenCountPos];
        }
        //時間
        let timeValue = this.createConfig.thinkTime[this.thinkTimeCountPos];
        //圈數
        let inningsValue = this.createConfig.roundLimit[this.lapCountPos * 2];
        //花牌
        let flowerValue = this.getToggleContainerSelectIndex(this.flowerToggleContainer) == 0 ? 1 : 0;
        //封頂
        let topValue = this.createConfig.pointLimit[this.getToggleContainerSelectIndex(this.topToggleContainer)];
        //限聽
        let isReadyHand = this.specialPlayToggles[0].isChecked ? 1 : 0;
        //限自摸
        let isLimitSelfDraw = this.specialPlayToggles[1].isChecked ? 1 : 0;
        //強制胡牌
        let isAutoHu = this.specialPlayToggles[2].isChecked ? 1 : 0;
        //莊家無台
        let isDealerNoPoint = this.specialPlayToggles[3].isChecked ? 1 : 0;
        //見花見字
        let hasFlowerWord: number = (this.specialPlayToggles[4].isChecked && flowerValue == 1) ? 1 : 0;
        //天胡，地胡
        let hasTianDi: number = this.specialTypeToggles[0].isChecked ? 1 : 0;
        //七搶一
        let hasRobFlower: number = (this.specialTypeToggles[1].isChecked && flowerValue == 1) ? 1 : 0;
        //八枝花
        let hasEightFlower: number = (this.specialTypeToggles[2].isChecked && flowerValue == 1) ? 1 : 0;
        //創建類型
        let createType: number = this.createType[this.getToggleContainerSelectIndex(this.createTypeContainer)];
        //是否是代开
        let isAgent: number = this.spCreatePayType[1].isChecked ? 1 : 0;
        //創建費用
        let createMoney: number = this.realCreateCost;
        //观战
        let isWatchGame: number = this.isWatchGameToggle.isChecked ? 1 : 0;
        //是否AA创房
        let isShareEquallyRoom: number = this.payMethods[this.getToggleContainerSelectIndex(this.payToggleContainer)];
        //支付方式
        let costType: number = this.costType[this.getToggleContainerSelectIndex(this.payToggleContainer)];

        let free = (this.createConfig.freeTableSwitch &&
            MahjongRoomMgr.getInstance().getIsIncludeActivities(this.createConfig.startFreeTime, this.createConfig.endFreeTime)) ? true : false;

        let createInfo: MahjongClientToServer.CreateRoom = {
            gameId: platform_game_id.mahjong_table,
            roomName: roomName,
            password: password,
            maxPlayerNum: personNum,
            maxRoundNum: inningsValue,
            baseScore: this.baseCount,
            thinkTime: timeValue,
            maxFan: topValue,
            hasFlowerCard: flowerValue,
            isAgent: isAgent,
            fanPoint: this.taiCount,
            isAutoHu: isAutoHu,
            hasFlowerWord: hasFlowerWord,
            isReadyHand: isReadyHand,
            isLimitSelfDraw: isLimitSelfDraw,
            hasRobFlower: hasRobFlower,
            hasTianDi: hasTianDi,
            hasEightFlower: hasEightFlower,
            isDealerNoPoint: isDealerNoPoint,
            isWatchGame: isWatchGame,
            isShareEquallyRoom: isShareEquallyRoom,
            createType: createType,
            costType: costType
        }

        let opts = {
            confirmCallback: () => {
                if (createInfo.createType == MAHJONG_ROOM_TYPE.PUBLIC) {
                    createInfo.password = "";
                }

                if (PlayerMgr.getInstance().money >= createMoney) {
                    //确认创建
                    MahjongRoomMgr.getInstance().createMahjongTable(createInfo, (data) => {
                        data.isInputAnte = this.isInputDifen;
                        data.isInputFanPoint = this.isInputTaiFen;
                        cc.sys.localStorage.setItem("mahjongCreateRoom", JSON.stringify(data));
                        if (createType == MAHJONG_ROOM_TYPE.AGENT) {
                            //创建成功，代开房间刷新列表
                            AppEmitter.emit(consts.SANSHUI_REFRESH_PRIVITE_ROOM);
                        } else {
                            //公桌和普通桌5秒监测是否进入游戏
                            AppEmitter.emit(consts.LOCAL_CURRECT_SCENE_JUMP_SCHEDULE);
                        }
                        App.refreshPlatformScore();
                        this.node.destroy();
                        PlayerMgr.getInstance().money = data.currMoney;
                        AppEmitter.emit(consts.LOCAL_EVENT_UPDATEPLAYERGOLD);
                    })
                } else {
                    Utils.showSDKOpenBroken();
                }
            },
            money: createMoney,
            createType: createType,
            isShareEquallyRoom: isShareEquallyRoom,
            isFree: free,
            isCreate: true
        }

        App.loadGamePopul({
            prefabName: "mahjongSureTipNode",
            prefabPath: "prefab",
            prefabComponent: "mahjongSureTipNode",
            data: opts
        });
    }

    /** 有花无花
     * @param event 
     * @param data 
     */
    haveFlowerToggleClicked(event, data) {
        let isSelect = data == "have";
        this.specialPlayToggles[4].node.active = isSelect;
        this.specialTypeToggles[1].node.active = isSelect;
        this.specialTypeToggles[2].node.active = isSelect;
    }

    /**
     * AA支付的时候关掉代开牌桌
     * @param event 
     * @param data 
     */
    isCreatePayTypeClicked(event, data) {
        let isAASelect = data == "AA";
        this.spCreatePayType[1].node.active = !isAASelect;
        this.spCreatePayType[2].node.active = !isAASelect;
        if (isAASelect) {
            this.spCreatePayType[0].isChecked = true;
        }
        this.refreshCreateFree();
    }

    /**
     * 创房方式
     * @param event 
     * @param data 
     */
    isCreateTypeClicked(event, data) {
        let isAASelect = data == "common";
        this.spPayType[1].node.active = isAASelect;
        this.refreshCreateFree();
    }

    /**
     * 生成房间名称
     */
    private generateRoomName(): string {
        let name = PlayerMgr.getInstance().nickName;
        if (name.length > 5) {
            return name.substring(0, 5) + "的牌桌";
        } else {
            return name + "的牌桌";
        }
    }

    /**
     * 刷新输入框输入字的颜色
     */
    private refreshPassworrdLabelColor() {
        let label = this.passwordEditBox.textLabel;
        let colors = [[125, 125, 125], [255, 255, 255]];
        label.node.color = new cc.Color(...colors[this.setPasswordStatus]);
    }

    /**
     * 房间号输入结束
     */
    private roomNameEditingEnd() {
        if (App.shieldDatas && App.shieldDatas.length > 0) {
            let inputTxt = Utils.checkInputTxtIsRight(this.roomNameEditBox.string, App.shieldDatas);
            this.roomNameEditBox.string = inputTxt;
        }
    }

    private inPutPassWord() {
        if (this.passwordEditBox.string) {
            this.passwordEditBox.string = this.passwordEditBox.string.replace("-", "");
            this.passwordEditBox.string = this.passwordEditBox.string.replace(".", "");
        }
    }

    /**
     * 自定义输入底分
     */
    private onInputBaseScore() {
        if (this.diFenEditBox.string) {
            let difen = parseInt(this.diFenEditBox.string);
            if (difen > this.createConfig.baseScoreRange[1]) {
                this.diFenEditBox.string = this.createConfig.baseScoreRange[1].toString();
            } else if (difen < this.createConfig.baseScoreRange[0]) {
                this.diFenEditBox.string = this.createConfig.baseScoreRange[0].toString();
            } else {
                this.diFenEditBox.string = difen.toString();
            }

            if (difen >= this.createConfig.baseScoreRange[0]) {
                this.diFenEditBox.textLabel.node.color = this.yellowColor;
                this.isInputDifen = true;
                this.diFenHander.getChildByName("spMask").active = true;
                this.onClearSliderSel(this.diFenCountLayer);
            }
        } else {
            this.setSliderSelectLabel(this.diFenCountLayer, this.diFenCountPos);
            this.isInputDifen = false;
            this.diFenHander.getChildByName("spMask").active = false;
            if (this.diFenEditBox.string) {
                this.diFenEditBox.textLabel.node.color = this.purpleColor;
            }
        }
    }

    /**
     * 自定义输入底分
     */
    private onInputTaiScore() {
        if (this.taiFenEdiBox.string) {
            let taifen = parseInt(this.taiFenEdiBox.string);
            if (taifen > this.createConfig.fanPointRange[1]) {
                this.taiFenEdiBox.string = this.createConfig.fanPointRange[1].toString();
            } else if (taifen < this.createConfig.fanPointRange[0]) {
                this.taiFenEdiBox.string = "1";
            } else {
                this.taiFenEdiBox.string = taifen.toString();
            }

            if (taifen >= this.createConfig.fanPointRange[0]) {
                this.taiFenEdiBox.textLabel.node.color = this.yellowColor;
                this.isInputTaiFen = true;
                this.taiFenHander.getChildByName("spMask").active = true;
                this.onClearSliderSel(this.taiFenCountLayer);
            }
        } else {
            this.setSliderSelectLabel(this.taiFenCountLayer, this.taiFenCountPos);
            this.isInputTaiFen = false;
            this.taiFenHander.getChildByName("spMask").active = false;
            if (this.taiFenEdiBox.string) {
                this.taiFenEdiBox.textLabel.node.color = this.purpleColor;
            }
        }
    }

    /**
     * 刷新創建費用
     */
    public refreshCreateFree() {
        if (this.createConfig.freeTableSwitch && MahjongRoomMgr.getInstance().getIsIncludeActivities(this.createConfig.startFreeTime, this.createConfig.endFreeTime)) { return }
        let inningsNum = this.createConfig.roundLimit[this.lapCountPos * 2];
        let rebates = this.createConfig.roundLimit[this.lapCountPos * 2 + 1] / 100;
        let person = this.personNumConfig[this.getToggleContainerSelectIndex(this.personNumToggleContainer)];
        let payType = this.payMethods[this.getToggleContainerSelectIndex(this.payToggleContainer)];
        let cost = inningsNum * this.roundCost * rebates * person;
        let originCost = inningsNum * this.roundCost * person;
        if (payType) {
            originCost = originCost / person;
            cost = cost / person;
        }
        this.realCreateCost = cost;
        let line = this.createFreeNum.node.getChildByName("line");
        let wangPaiLine = this.lbWangPaiCost.node.getChildByName("line");


        if (rebates != 1) {
            this.nodeCostTeJia.active = true;
            this.nodeLapZhe.active = true;
            this.lbLapZheCount.string = rebates * 10 + "折";
            this.lbCostTeJia.string = "特價" + cost;
            this.nodeLaoZiCost.active = true;
            this.lbWangPaiCost.node.parent.active = false;
            this.createFreeNum.string = originCost.toString();
            line.width = this.createFreeNum.node.width + 10;
            line.active = true;
            this.nodeCostTeJia.x = -78;
        } else {
            line.active = false;
            wangPaiLine.active = false;
            this.nodeCostTeJia.active = false;
            this.nodeLapZhe.active = false;

            this.nodeLaoZiCost.active = true;
            this.lbWangPaiCost.node.parent.active = false;
            this.createFreeNum.string = cost.toString();
            this.nodeCostTeJia.x = -78;
        }

        if (this.createType[this.getToggleContainerSelectIndex(this.createTypeContainer)] == MAHJONG_ROOM_TYPE.PUBLIC) {
            this.setPasswordStatus = 1;
            this.passwordEditBox.string = "";
            this.setPasswordClicked();
        }
    }

    /**
     * 获取单选组的选中下标
     */
    private getToggleContainerSelectIndex(toggleContainer: cc.ToggleContainer): number {
        let toggleItems = toggleContainer.toggleItems;
        let selectIndex: number = 0;
        toggleItems.forEach((toggle, index: number) => {
            if (toggle.isChecked) {
                selectIndex = index;
            }
        });
        return selectIndex;
    }

    /**
     * 设置单选组选中指定下标
     * @param toggleContainer 
     * @param selIdx 
     */
    private setToggleContainerSelIdx(toggleContainer: cc.ToggleContainer, selIdx: number) {
        let toggleItems = toggleContainer.toggleItems;
        toggleItems.forEach((toggle, index: number) => {
            if (selIdx == index) {
                toggle.isChecked = true;
            }
        })
    }

    /**
     * 获取配置表中元素的id
     * @param array 
     * @param idx 
     * @returns 
     */
    private getRoomConfigArryIdx(array, idx) {
        for (let i = 0; i < array.length; i++) {
            const element = array[i];
            if (element == idx) {
                return i;
            }
        }
    }

    onDiFenCountTouchEnd(event: cc.Event) {
        this.diFenSlider.progress = this.diFenCountPos * this.diFenCountSpace;
        this.updateDiFenLable(this.diFenSlider.progress);
    }

    /**
     * 更新底分显示
     * @param progress 
     */
    updateDiFenLable(progress: number) {
        this.diFenCountPos = Math.round(progress / this.diFenCountSpace);
        this.setSliderSelectLabel(this.diFenCountLayer, this.diFenCountPos);
        this.isInputDifen = false;
        this.diFenHander.getChildByName("spMask").active = false;
        if (this.diFenEditBox.string) {
            this.diFenEditBox.textLabel.node.color = this.purpleColor;
        }
    }

    onTaiFenCountTouchEnd(event: cc.Event) {
        this.taiFenSlider.progress = this.taiFenCountPos * this.taiFenCountSpace;
        this.updateTaiFenLable(this.taiFenSlider.progress);
    }

    /**
     * 更新台分显示
     * @param progress 
     */
    updateTaiFenLable(progress: number) {
        this.taiFenCountPos = Math.round(progress / this.taiFenCountSpace);
        this.setSliderSelectLabel(this.taiFenCountLayer, this.taiFenCountPos);
        this.isInputTaiFen = false;
        this.taiFenHander.getChildByName("spMask").active = false;
        if (this.taiFenEdiBox.string) {
            this.taiFenEdiBox.textLabel.node.color = this.purpleColor;
        }
    }

    onThinkTimeCountTouchEnd(event: cc.Event) {
        this.thinkTimeSlider.progress = this.thinkTimeCountPos * this.thinkTimeCountSpace;
        this.updateThinkTimeLable(this.thinkTimeSlider.progress);
    }

    /**
     * 更新思考时间显示
     * @param progress 
     */
    updateThinkTimeLable(progress: number) {
        this.thinkTimeCountPos = Math.round(progress / this.thinkTimeCountSpace);
        this.setSliderSelectLabel(this.thinkTimeLayer, this.thinkTimeCountPos);
    }

    onLapCountTouchEnd(event: cc.Event) {
        this.lapCountSlider.progress = this.lapCountPos * this.lapCountSpace;
        this.updateLapCountLable(this.lapCountSlider.progress);
    }

    /**
     * 更新圈数显示
     * @param progress 
     */
    updateLapCountLable(progress: number) {
        this.lapCountPos = Math.round(progress / this.lapCountSpace);
        this.setSliderSelectLabel(this.lapCountLayer, this.lapCountPos);
        this.refreshCreateFree();
    }

    onSlider(slider: cc.Slider, data: string) {
        let progress = slider.progress;
        switch (data) {
            case "diFen":
                this.updateDiFenLable(progress);
                break;
            case "taiFen":
                this.updateTaiFenLable(progress);
                break;
            case "thinkTime":
                this.updateThinkTimeLable(progress);
                break;
            case "lapCount":
                this.updateLapCountLable(progress);
                break;
            default:
                break;
        }
    }

    /**
     * 设定slider选中档位label显示 
     */
    setSliderSelectLabel(parentNode: cc.Node, pos: number) {
        parentNode.children.forEach((item, index) => {
            let node = item.children[0];
            if (index == pos) {
                if (node) {
                    node.color = this.yellowColor;
                    node.y = 5;
                }
            } else {
                if (node) {
                    node.color = this.whileColor;
                    node.y = 0;
                }
            }
        })
    }

    /**
     * 清除滑动选中
     * @param parentNode 
     */
    onClearSliderSel(parentNode: cc.Node) {
        parentNode.children.forEach((item) => {
            let node = item.children[0];
            if (node) {
                node.color = this.whileColor;
                node.y = 0;
            }
        })
    }

    /**
     * 获取创房选项缓存
     * @returns 
     */
    private getCreateRoomRecord() {
        const createRoomRecord = JSON.parse(cc.sys.localStorage.getItem("mahjongCreateRoom"));
        return createRoomRecord;
    }

    private popShowAnim(node: cc.Node) {
        let bgNode = node.getChildByName("bg");
        if (bgNode) {
            bgNode.stopAllActions();
            bgNode.setScale(0);
            cc.tween(bgNode)
                .to(0.2, { "scale": 1.2 })
                .to(0.1, { "scale": 1.0 })
                .start()
        }
    }

}
