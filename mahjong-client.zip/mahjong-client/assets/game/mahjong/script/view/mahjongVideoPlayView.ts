
import AudioMgr from "../../../../script/model/AudioMgr";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MahjongVideoPlayView extends cc.Component {

    @property(cc.VideoPlayer)
    videoPlayer: cc.VideoPlayer = null;

    @property(cc.Node)
    playVideoArea: cc.Node = null;

    public divBtn = null;
    private isMove = false;

    init(data) {
        const url:string =data.url;
        this.node.active = true;
        this.createDivBtn();
        this.videoPlayer.volume = AudioMgr.bgmVolume;
        this.videoPlayer.remoteURL = url;
        this.videoPlayer.play();
      
    }

    onVideoPlayerEvent(sender, event) {
        if (event === cc.VideoPlayer.EventType.CLICKED) {
          
        } else if (event === cc.VideoPlayer.EventType.READY_TO_PLAY || event === cc.VideoPlayer.EventType.META_LOADED) {
            this.playVideoArea.active = true;
        } else if (event === cc.VideoPlayer.EventType.PLAYING) {
            this.playVideoArea.active = false;
        } else if (event === cc.VideoPlayer.EventType.COMPLETED) {
            this.close();
        }
    }

    toggleFullscreen() {
        if (
            cc.sys.isBrowser &&
            cc.sys.browserType === cc.sys.BROWSER_TYPE_MOBILE_QQ &&
            Number(cc.sys.browserVersion) <= 7.2 &&
            /Nexus 6/.test(navigator.userAgent)
        ) {
            return cc.log('May be crash, so prohibit full screen');
        }
        cc.audioEngine.pauseAll();
        AudioMgr.setSFXVolume(0);

        this.videoPlayer.isFullscreen = true;
    }

    play() {
        this.videoPlayer.volume = AudioMgr.bgmVolume;
        this.videoPlayer.play();
        this.playVideoArea.active = false;
    }

    pause() {
        this.videoPlayer.pause();
    }

    stop() {
        this.videoPlayer.stop();
    }

    close() {
        AudioMgr.init();
        AudioMgr.resumeAll();
        this.divBtn.style.visibility = "hidden";
        this.videoPlayer.stop();
        this.node.destroy();
    }

    createDivBtn() {
        let cocos2dContainer = document.getElementById("Cocos2dGameContainer");
        let button = document.createElement("button");
        button.setAttribute("id", "webButton");
        button.style.position = "fixed"
        button.style.right = `2px`;
        button.style.top = `2px`;
        let imageUrl = null;
        button.style.visibility = "visible"
        let localResUrl = cc.url.raw("resources/image/button_gb.png");

        cc.loader.load(localResUrl, (error, res) => {
            if (!error) {
                imageUrl = res.nativeUrl;
                button.style.backgroundImage = `url(${imageUrl})`;
                button.style.width = res.width + "px";
                button.style.height = res.height + "px";
                button.style.backgroundColor = "transparent";
                button.style.borderColor = "transparent";

                // button.onmousedown = (event) => {
                //     let ev = window.event;  //兼容ie浏览器
                //     //鼠标点击物体那一刻相对于物体左侧边框的距离=点击时的位置相对于浏览器最左边的距离-物体左边框相对于浏览器最左边的距离  
                //     let distanceX = event.clientX - button.offsetLeft;
                //     let distanceY = event.clientX - button.offsetTop;
                //     document.onmousemove = (event) => {
                //         var ev = window.event;  //兼容ie浏览器
                //         if ((event.clientX - distanceX) > 0) {
                //             this.isMove = true;
                //             button.style.left = event.clientX - distanceX + 'px';
                //         }
                //         if ((event.clientY - distanceY) > 0) {
                //             this.isMove = true;
                //             button.style.top = event.clientY - distanceY + 'px';
                //         }
                //     };
                //     document.onmouseup = () => {
                //         document.onmousemove = null;
                //         document.onmouseup = null;
                //     };
                // };

                button.onclick = (() => {
                    if (!this.isMove) {
                        this.close();
                    } else {
                        this.isMove = false;
                    }
                   
                });
                this.divBtn = button;
                cocos2dContainer.appendChild(button);
            }
        });
    }

    onDestroy() {
        this.divBtn.style.visibility = "hidden"
    }
}
