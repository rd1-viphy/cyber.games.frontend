import { platform_game_id, platform_game_name } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import consts = require("../../../../script/model/Consts");
import MahjongBackModel from "../../../../script/model/mahjongBackModel";
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import HttpUtils from "../../../../script/network/HttpUtils";
import { MAHJONG_SETTLE_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongSmallResultItem from "./item/mahjongSmallResultItem";



const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongRecordInfoView extends cc.Component {

    @property({
        tooltip: "风圈位",
        type: cc.Sprite
    })
    spWind: cc.Sprite = null;

    @property({
        tooltip: "风圈Frame",
        type: cc.SpriteFrame
    })
    spWindFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "玩家信息节点",
        type: cc.Node
    })
    nodeResultItem: cc.Node[] = [];

    @property({
        tooltip: "合计台数",
        type: cc.Label
    })
    lbTotalPoint: cc.Label = null;

    @property({
        tooltip: "台数Layout",
        type: cc.Node
    })
    nodeFanList: cc.Node = null;

    @property({
        tooltip: "台数Item",
        type: cc.Node
    })
    fanItem: cc.Node = null;

    @property({
        tooltip: "左边箭头",
        type: cc.Button
    })
    leftBtn: cc.Button = null;

    @property({
        tooltip: "右边箭头",
        type: cc.Button
    })
    rightBtn: cc.Button = null;

    @property({
        tooltip: "显示当前页数的label",
        type: cc.Label
    })
    pageLabel: cc.Label = null;

    @property({
        tooltip: "有数据",
        type: cc.Node
    })
    nodeHaveData: cc.Node = null;

    @property({
        tooltip: "没数据",
        type: cc.Node
    })
    nodeNoData: cc.Node = null;

    @property({
        tooltip: "详情",
        type: cc.Node
    })
    nodeInfo: cc.Node = null;

    @property({
        tooltip: "战绩",
        type: cc.Node
    })
    nodeRecord: cc.Node = null;

    @property({
        tooltip: "流局",
        type: cc.Node
    })
    nodeFlow: cc.Node = null;

    @property({
        tooltip: "和局",
        type: cc.Node
    })
    nodePlace: cc.Node = null;

    protected currentPage: number = 0;
    protected maxPage: number = 0;
    protected gameProxy: MahjongProxy = null;
    protected gameModel: MahjongModel = null;
    protected roomId: number = 0;
    protected roomUniqueID: string = null;

    protected winCardType = [
        "", "天胡", "地胡", "大四喜", "人胡", "天聽", "五暗刻", "大三元", "小四喜", "八枝花", "字一色",
        "清一色", "四槓牌", "七搶一", "四暗刻", "地聽", "小三元", "混一色", "碰碰胡", "門清自摸", "全求人",
        "平胡", "三暗刻", "花槓", "莊家", "連莊", "自摸", "門清", "獨聽", "海底撈月", "槓上開花", "河底撈魚",
        "三元台", "搶槓", "花牌", "門風刻", "圈風刻", "報聽", "見花見台", "見風見台", "無字無花", "槓牌", "暗槓",
    ]

    init(data) {
        if (data.gameProxy) {
            this.gameProxy = data.gameProxy;
        }

        if (data.roomId) {
            this.roomId = data.roomId;
        }

        if (data.roomUniqueID) {
            this.roomUniqueID = data.roomUniqueID;
        }

        if (data.gameModel) {
            this.gameModel = data.gameModel;
        }

        if (data.isInfo) {
            this.nodeRecord.active = false;
            this.nodeInfo.active = true;
        } else {
            this.nodeRecord.active = true;
            this.nodeInfo.active = false;
        }

        if (data.records.length != 0) {
            this.refreshList(data);
        } else {
            this.nodeHaveData.active = false;
            this.nodeNoData.active = true;
        }
    }

    refreshList(data) {
        if (data.pageStart) {
            this.currentPage = data.pageStart;
            this.maxPage = data.pageEnd;
            this.pageLabel.string = this.currentPage + "/" + this.maxPage;
            this.refreshBtnClick();
        }

        this.spWind.spriteFrame = this.spWindFrame[data.records[0].roundWind - 1];
        this.showGameInfoList(data.records[0]);
    }

    showGameInfoList(data) {
        this.onSortCardList(data.details);

        if (this.nodeInfo.active || (this.gameModel && !this.gameModel.getIsWatchTheBattle())) {
            let obj = {};
            data.details.forEach((item, idx) => {
                if (item.playerId == PlayerMgr.getInstance().uid) {
                    obj = item;
                    data.details.splice(idx, 1);
                    return;
                }
            })
            data.details.unshift(obj);
        }

        this.nodePlace.active = false;
        this.nodeFlow.active = false;
        if (data.gameEndType == MAHJONG_SETTLE_TYPE.Flow) {
            this.nodeFlow.active = true;
        } else if (data.gameEndType == MAHJONG_SETTLE_TYPE.Peace) {
            this.nodePlace.active = true;
        }

        let isZiMo = this.isCheckZiMo(data.details);
        this.lbTotalPoint.string = "0";
        this.nodeFanList.destroyAllChildren();

        for (let i = 0; i < data.details.length; i++) {
            const playerSettle = data.details[i];
            if (playerSettle.playerId) {
                this.nodeResultItem[i].getComponent(MahjongSmallResultItem).initItem(playerSettle, isZiMo);
                this.nodeResultItem[i].active = true;
            }

            if (playerSettle.settleScore > 0) {
                this.lbTotalPoint.string = playerSettle.totalFan;
                if (playerSettle.fanList && playerSettle.fanList.length > 0) {
                    playerSettle.fanList.forEach((fanPoint) => {
                        const fanItem = cc.instantiate(this.fanItem);
                        fanItem.getChildByName("lbFanName").getComponent(cc.Label).string = this.winCardType[fanPoint.pointType];
                        fanItem.getChildByName("lbTanShu").getComponent(cc.Label).string = "+" + fanPoint.point + "台";
                        fanItem.active = true;
                        this.nodeFanList.addChild(fanItem);
                    })
                }
            }
        }
    }

    isCheckZiMo(data) {
        let isFangPao = true;
        data.forEach(player => {
            if (player.isShot) {
                isFangPao = false;
            }
        })
        return isFangPao;
    }

    /**
     * 翻页按钮的点击
     * @param event 
     * @param data 
     */
    pageBtnClicked(event: cc.Event, data: string) {
        switch (data) {
            case "left":
                if (this.currentPage > 1) {
                    if (App.currentScene == consts.MAHJONG_SCENE) {
                        this.gameProxy.getGameDetail({
                            gameId: platform_game_id.mahjong_table,
                            roomId: this.gameModel.tableId,
                            roomUniqueID: this.gameModel.roomUniqueID,
                            pageStart: this.currentPage - 1,
                            pageNum: 1,
                        }, (data) => {
                            this.refreshList({
                                records: data.records,
                                pageStart: data.pageStart,
                                pageEnd: data.pageEnd
                            })
                        })
                    } else {
                        MahjongRoomMgr.getInstance().getGameInfo({
                            gameId: platform_game_id.mahjong_table,
                            roomId: this.roomId,
                            roomUniqueID: this.roomUniqueID,
                            pageStart: this.currentPage - 1,
                            pageNum: 1
                        }, (data) => {
                            this.refreshList({
                                records: data.records,
                                pageStart: data.pageStart,
                                pageEnd: data.pageEnd
                            })
                        })
                    }
                }
                break;
            case "right":
                if (App.currentScene == consts.MAHJONG_SCENE) {
                    this.gameProxy.getGameDetail({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.gameModel.tableId,
                        roomUniqueID: this.gameModel.roomUniqueID,
                        pageStart: this.currentPage + 1,
                        pageNum: 1,
                    }, (data) => {
                        this.refreshList({
                            records: data.records,
                            pageStart: data.pageStart,
                            pageEnd: data.pageEnd
                        })
                    })
                } else {
                    MahjongRoomMgr.getInstance().getGameInfo({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.roomId,
                        roomUniqueID: this.roomUniqueID,
                        pageStart: this.currentPage + 1,
                        pageNum: 1
                    }, (data) => {
                        this.refreshList({
                            records: data.records,
                            pageStart: data.pageStart,
                            pageEnd: data.pageEnd
                        })
                    })
                }
                break;
        }
    }

    onSortCardList(list) {
        if (list) {
            for (let i = 0; i < list.length - 1; i++) {
                for (let j = 0; j < list.length - i - 1; j++) {
                    if (list[j].wind > list[j + 1].wind) {
                        let temp = list[j];
                        list[j] = list[j + 1];
                        list[j + 1] = temp;
                    }
                }
            }
        }
    }

    onTouchBackView() {
        const obj = {
            apiGameId: platform_game_name.Mahjong,
            tableUuid: this.roomUniqueID,
            roundLimit: this.currentPage,
        }
        HttpUtils.httpGet(consts.chessReqUrl.HttpAdress,consts.HTTP_ROUTE.FIND_PALYER_BACK, obj, (data) => {
            const backData = JSON.parse(data);
            if (backData.code == 0) {
                if (!MahjongRoomMgr.getInstance().isBackView) {
                    MahjongRoomMgr.getInstance().isBackView = true;
                    MahjongBackModel.initData(backData.data);
                }
            }
        })
    }

    refreshBtnClick() {
        this.leftBtn.interactable = this.currentPage > 1;
        this.rightBtn.interactable = this.currentPage < this.maxPage;
    }

    onClose() {
        for (let i = 0; i < 4; i++) {
            this.nodeResultItem[i].getComponent(MahjongSmallResultItem).nodeHandCard.destroyAllChildren();
            this.nodeResultItem[i].getComponent(MahjongSmallResultItem).nodeFlowerCard.destroyAllChildren();
            this.nodeResultItem[i].getComponent(MahjongSmallResultItem).nodePengCard.destroyAllChildren();
            this.nodeResultItem[i].getComponent(MahjongSmallResultItem).nodeWinCard.destroyAllChildren();
        }
        this.node.destroy();
    }

}
