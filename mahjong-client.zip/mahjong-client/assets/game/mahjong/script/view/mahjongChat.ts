
import consts = require("../../../../script/model/Consts");
import { MAHJONG_CONST } from "../model/mahjongEnum";
import MahjongProxy from "../model/mahjongProxy";
const { ccclass, property } = cc._decorator;
@ccclass
export default class mahjongChat extends cc.Component {

    gameProxy: MahjongProxy = null;

    @property({
        tooltip: "聊天文字label",
        type: cc.Node
    })
    nodeMsgLabel: cc.Node = null;

    @property({
        tooltip: "聊天节点",
        type: cc.Node
    })
    nodeMsgContent: cc.Node = null;

    init(data) {
        this.gameProxy = data.gameProxy;
        this.showMsgLabels(MAHJONG_CONST.msgLabels)

    }

    showMsgLabels(data) {
        for (let i = 0; i < data.length; i++) {
            const msgLabel = cc.instantiate(this.nodeMsgLabel);
            msgLabel.getChildByName("msgLabel").getComponent(cc.Label).string = data[i];
            const handler = new cc.Component.EventHandler();
            handler.component = "mahjongChat";
            handler.customEventData = `${100 + i}`;
            handler.target = this.node;
            handler.handler = "msgItemClicked";
            msgLabel.getComponent(cc.Button).clickEvents.push(handler);
            msgLabel.active = true;
            this.nodeMsgContent.addChild(msgLabel);
        }
    }

    /**
     * 消息的点击
     * @param event 
     * @param data 
     */
    msgItemClicked(event: cc.Event, data: string) {
        this.gameProxy.sendMessage({ "id": parseInt(data) }, () => {
            this.nodeMsgContent.destroyAllChildren();
            if (this.node) {
                this.node.destroy();
            }
        });
    }

    /**
     * 表情是点击
     * @param event 
     * @param data 
     */
    expressClicked(event: cc.Event, data: string) {
        this.gameProxy.sendMessage({ "id": parseInt(data) }, () => {
            this.node.destroy();
        });
    }

    nodeClicked() {
        this.node.destroy();
    }

}
