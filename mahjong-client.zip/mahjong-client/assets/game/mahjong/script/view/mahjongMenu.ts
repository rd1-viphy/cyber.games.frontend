import { platform_game_id } from "../../../../script/common/ClientEnum";
import App from "../../../../script/model/App";
import consts = require("../../../../script/model/Consts");
import PlayerMgr from "../../../../script/model/PlayerMgr";
import MahjongRoomMgr from "../../../../script/model/roomMgr/mahjongRoomMgr";
import { MAHJONG_CONST, MAHJONG_RECORD_TYPE, MAHJONG_ROOM_TYPE } from "../model/mahjongEnum";
import MahjongModel from "../model/mahjongModel";
import MahjongProxy from "../model/mahjongProxy";
import MahjongView from "./mahjongView";

const { ccclass, property } = cc._decorator;

@ccclass
export default class mahjongMenu extends cc.Component {

    @property({
        tooltip: "菜单按钮",
        type: cc.Node
    })
    menuBtns: cc.Node[] = [];

    @property({
        tooltip: "菜单背景",
        type: cc.Node
    })
    menuBg: cc.Node = null;

    gameModel: MahjongModel = null;
    gameView: MahjongView = null;
    gameProxy: MahjongProxy = null;

    init(data) {
        if (data) {
            this.gameModel = data.gameModel;
            this.gameView = data.gameView;
            this.gameProxy = data.gameProxy;
        }

        if (App.currentScene == consts.MAHJONG_ROOM_LIST_SCENE) {
            this.refreshBtnsShow([0, 3, 5, 9]);
            this.menuBg.x = 494.5;
        } else {
            if (this.gameModel.roomConfig.createType == MAHJONG_ROOM_TYPE.AGENT) {
                if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                    if (this.gameModel.getIsWatchTheBattle()) {
                        if (this.gameModel.isGameStart) {
                            this.refreshBtnsShow([0, 1, 2, 3, 4, 5, 8]);
                        } else {
                            this.refreshBtnsShow([0, 1, 2, 3, 4, 5, 7, 8]);
                        }
                    } else {
                        if (this.gameModel.isGameStart) {
                            this.refreshBtnsShow([0, 1, 2, 3, 4, 5, 7, 8]);
                        } else {
                            this.refreshBtnsShow([0, 1, 2, 3, 4, 5, 6, 7, 8]);
                        }
                    }
                } else {
                    if (this.gameModel.getIsWatchTheBattle()) {
                        this.refreshBtnsShow([0, 1, 3, 4, 5, 8]);
                    } else {
                        if (this.gameModel.isGameStart) {
                            this.refreshBtnsShow([0, 1, 3, 4, 5, 8]);
                        } else {
                            this.refreshBtnsShow([0, 1, 3, 4, 5, 6, 8]);
                        }
                    }
                }
            } else {
                if (PlayerMgr.getInstance().uid == this.gameModel.masterUid) {
                    this.refreshBtnsShow([0, 1, 2, 3, 4, 5, 7]);
                } else {
                    if (this.gameModel.getIsWatchTheBattle()) {
                        this.refreshBtnsShow([0, 1, 3, 4, 5, 8]);
                    } else {
                        if (this.gameModel.isGameStart) {
                            this.refreshBtnsShow([0, 1, 3, 4, 5, 8]);
                        } else {
                            this.refreshBtnsShow([0, 1, 3, 4, 5, 6, 8]);
                        }
                    }
                }
            } 
            this.menuBg.x = -494.5;
        }
    }

    /**
     * 菜单栏按钮的点击
     */
    btnClicked(event: cc.Event, data: string) {
        const gameProxy = this.gameProxy;
        const gameModel = this.gameModel;
        switch (data) {
            case "rule":
                App.loadGamePopul({ prefabName: "mahjongRule", prefabPath: "prefab" });
                break;
            case "share":
                MahjongRoomMgr.getInstance().copyRoomInfo(
                    this.gameModel.roomConfig,
                    MAHJONG_CONST.shareText,
                    this.gameModel.tableId,
                    this.gameModel.roomName,
                    MAHJONG_CONST.shareRoomInfo,
                );
                break;
            case "blacklist":
                this.gameProxy.getGameBlackList((data) => {
                    App.loadGamePopul({
                        prefabName: "mahjongBlacklistNode",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongBlacklistNode",
                        data: {
                            blacklistInfo: data,
                            gameProxy: gameProxy
                        }
                    });
                })
                break;
            case "grade":
                if (App.currentScene == consts.MAHJONG_ROOM_LIST_SCENE) {
                    MahjongRoomMgr.getInstance().getGameRecords({
                        gameId: platform_game_id.mahjong_table,
                        pageStart: 1,
                        pageNum: 4,
                        recordType: MAHJONG_RECORD_TYPE.PERSONAL
                    }, (data) => {
                        App.loadGamePopul({
                            prefabName: "mahjongPersonGradeNode",
                            prefabPath: "prefab",
                            prefabComponent: "mahjongPersonGrade",
                            data: data
                        });
                    })
                } else if (App.currentScene == consts.MAHJONG_SCENE) {
                    this.gameProxy.getGameDetail({
                        gameId: platform_game_id.mahjong_table,
                        roomId: this.gameModel.tableId,
                        roomUniqueID: this.gameModel.roomUniqueID,
                        pageStart: 1,
                        pageNum: 1,
                    }, (data) => {
                        App.loadGamePopul({
                            prefabName: "mahjongRecordInfoView",
                            prefabPath: "prefab",
                            prefabComponent: "mahjongRecordInfoView",
                            data: {
                                records: data.records,
                                pageStart: data.pageStart,
                                pageEnd: data.pageEnd,
                                gameProxy: gameProxy,
                                gameModel: gameModel,
                                isInfo: false,
                            }
                        })
                    })
                }
                break;
            case "record":
                this.gameProxy.getGameScoreRecords({
                    gameId: platform_game_id.mahjong_table,
                    roomId: this.gameModel.tableId,
                    roomUniqueID: this.gameModel.roomUniqueID,
                    pageStart: 1,
                    pageNum: 1,
                }, (data) => {
                    App.loadGamePopul({
                        prefabName: "mahjongRecordNode",
                        prefabPath: "prefab",
                        prefabComponent: "mahjongRecordNode",
                        data: {
                            playerDetails: data.playerDetails,
                            totalDetails: data.totalDetails,
                        }
                    })
                })
                break;
            case "sound":
                App.loadGamePopul({ prefabName: "mahjongSoundNode", prefabPath: "prefab" });
                break;
            case "watchGame":
                this.gameView.onSendPlayerWatchGame();
                break;
            case "dissolution":
                if (!this.gameModel.isGameStart) {
                    this.gameView.onGameMasterDissRoom();
                } else {
                    this.gameView.applyDissolveTabel();
                }
                break;
            case "exit":
                //游戏未开始 房主创房房主退出解散，普通玩家直接退出  代开创房都可以退出
                //游戏开始  申请解散
                if (this.gameModel.getIsWatchTheBattle()) {
                    this.gameView.applyExitRoom();
                } else {
                    if (!this.gameModel.isGameStart) {
                        this.gameView.applyExitRoom();
                    } else {
                        this.gameView.applyDissolveTabel();
                    }
                }
                break;
            case "disclaimers":
                App.loadGamePopul({ prefabName: "mahjongDisclaimersView", prefabPath: "prefab" });
                break;
            default:
                break;
        }
        this.node.destroy();
    }

    refreshBtnsShow(showArr: number[]) {
        this.menuBtns.forEach((element, index) => {
            element.active = showArr.indexOf(index) > -1;
        });
    }

}
