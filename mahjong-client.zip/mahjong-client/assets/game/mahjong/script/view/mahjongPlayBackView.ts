import backPlayNode from "../../../../script/common/backPlayNode";
import MahjongBackModel from "../../../../script/model/mahjongBackModel";
import MahjongPlayBackNode from "../component/mahjongPlayBackNode";
import MahjongControl from "../control/mahjongControl";
import MahjongModel from "../model/mahjongModel";

import MahjongView from "./mahjongView";

const { ccclass, property } = cc._decorator;

@ccclass
export default class MahjongPlayBackView extends cc.Component {

    @property({
        tooltip: "回放控制节点",
        type: cc.Node
    })
    nodePlayBack: cc.Node = null;

    gameView: MahjongView = null;
    gameControl: MahjongControl = null;
    gameModel: MahjongModel = MahjongModel.getInstance();

    init(view: MahjongView, gameControl: MahjongControl) {
        this.gameView = view;
        this.gameControl = gameControl;
        this.gameView.agoraClient = null;
        this.gameView.lbCardCount.string = "0";
        this.gameView.initGameView();
        const time = MahjongBackModel.backData.length * MahjongBackModel.timeInterval / 1000;
        this.nodePlayBack.getComponent(MahjongPlayBackNode).init(this, time, () => {
            this.nodePlayBack.getComponent(MahjongPlayBackNode).playBtn.active = true;
            this.nodePlayBack.getComponent(MahjongPlayBackNode).stopBtn.active = false;
        })
    }

    onFastWord() {
        MahjongBackModel.fastForward();
        this.nodePlayBack.getComponent(MahjongPlayBackNode).isPlay = false;;
        let curTime = MahjongBackModel.curMsgCout * MahjongBackModel.timeInterval / 1000;
        let totalTime = MahjongBackModel.backData.length * MahjongBackModel.timeInterval / 1000;
        this.nodePlayBack.getComponent(MahjongPlayBackNode).clockTime = curTime;
        this.nodePlayBack.getComponent(MahjongPlayBackNode).totalTime = totalTime;
        this.nodePlayBack.getComponent(MahjongPlayBackNode).setProgress();
        this.nodePlayBack.getComponent(MahjongPlayBackNode).isPlay = true;;
    }
}
