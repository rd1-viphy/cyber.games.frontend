
/**
 * 计算牌的点数
 */
const SrcPokerList:number[] = [
    0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D,	//方块 A - K
    0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D,	//梅花 A - K
    0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D,	//红桃 A - K
    0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D,   //黑桃 A - K
];



let CardID2PointMap:Map<number,number> = new Map<number, number>();

function createCardID2PointMap(){
    SrcPokerList.forEach((val,index)=>{
        SrcPokerList.forEach((val,index)=>{
            var position = index%13;
            if(position >8){
                CardID2PointMap.set(val,10);
            }else{
                CardID2PointMap.set(val,position+1);
            }
        })
    })
}

createCardID2PointMap();

export function getPointByCardID(cardID:number):number{
    return CardID2PointMap.get(cardID);
}

export function getPointOfCards(cards) {
    let point = 0;
    if(cards.length == 0){
        point = 0;
    }
    var isIncoundA = false;
    let pointNum = 0;
    //判断是否包含A，并且计算总点数
    for(let i=0;i<cards.length;i++){
        let value = getPointByCardID(cards[i]);
        if(value == 1){
            isIncoundA = true;
        }
        if(value){
           pointNum += value;
        }
    }
    if(isIncoundA&&(pointNum+10)<=21){
        point=pointNum+10;
    }else{
        point = pointNum;
    }
    return point;
}

export function getTotalPointOfCards(cards) {
    let pointStr = "";
    if(cards.length == 0){
        pointStr = "";
    }
    var isIncoundA = false;
    let pointNum = 0;
    //判断是否包含A，并且计算总点数
    for(let i=0;i<cards.length;i++){
        let value = getPointByCardID(cards[i]);
        if(value == 1){
            isIncoundA = true;
        }
        if(value){
           pointNum += value;
        }
    }
    if(isIncoundA&&(pointNum+10)<=21){
        
        if((pointNum+10)==21){
            pointStr = "21";
        }else{
            pointStr = pointNum+"/"+(pointNum+10);
        }
    }else{
        pointStr = ""+pointNum;
    }
    return pointStr;
}

