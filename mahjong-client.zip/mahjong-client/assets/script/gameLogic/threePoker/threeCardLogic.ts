import CardLogic from "./cardLogic";
import ArrayHelper from "./arrayHelper";
import { CardType, CompareType, PACK_COUNT, SettleWinOrLose, SixCardType, SIX_COUNT } from "./config";

/**
 * 三张扑克逻辑类
 */
export class ThreeCardLogic extends CardLogic {
    constructor() {
        super();
    }

    /**
     * 对比两个牌组
     * @param mType 庄家的牌型
     * @param pType 玩家的牌型
     * @param masterCard 庄家的牌
     * @param playerCard 玩家的牌
     * @param checkInvalid 是否检查无效局
     */
    public compareCard(mType: CardType, pType: CardType, masterCard: number[], playerCard: number[], checkInvalid: Boolean = true): CompareType {
        let isInvalid = this.isInvalid(mType, masterCard);
        if (isInvalid && checkInvalid) {
            return CompareType.INVALID;//无效局
        }
        //都是同花大顺 平局
        if (mType >= CardType.CT_BIG_STRAIGHT_FLUSH && pType >= CardType.CT_BIG_STRAIGHT_FLUSH) {
            return CompareType.DRAW;
        } else if (mType > pType) {
            return CompareType.LOSE;
        } else if (mType < pType) {
            return CompareType.WIN;
        }
        //牌型相同的 比较
        if (mType == CardType.CT_SINGLE || mType == CardType.CT_FLUSH) {//如果是单牌 按照最大依次比较
            return this.single(masterCard, playerCard);
        } else if (mType == CardType.CT_DOUBLE) {//如果是对子 按照对子比较 相同按照单牌比较
            return this.dobleCompare(masterCard, playerCard);
        } else if (mType == CardType.CT_STRAIGHT || mType == CardType.CT_STRAIGHT_FLUSH) {//顺子或者同花顺
            return this.straighCompare(masterCard, playerCard);
        }
        //其他类型 拿着纸牌的分数总和比较就行
        return this.cardCompare(masterCard, playerCard);
    }

    /**
     * 判断是否为无效局
     */
    public isInvalid(mType: CardType, masterCard: number[]): Boolean {
        if (mType == CardType.CT_SINGLE) {
            let mCard: number[] = this.getScoreArr(masterCard);
            mCard = ArrayHelper.sortDesc(mCard);
            if (mCard[0] < 12) {//如果庄家最大的牌在Q以下 算无效局 玩家赢底注
                return true;
            }
        }
        return false;
    }

    /**
     * 一般牌型的比较
     * 计算牌型总分数对比
     * @param masterCard
     * @param playerCard
     */
    private cardCompare(masterCard: number[], playerCard: number[]) {
        let mNum: number = ArrayHelper.sumArray(this.getScoreArr(masterCard));
        let pNum: number = ArrayHelper.sumArray(this.getScoreArr(playerCard));
        if (mNum > pNum) {
            return CompareType.LOSE;
        } else if (mNum == pNum) {
            return CompareType.DRAW;
        }
        return CompareType.WIN;
    }

    /**
     * 顺子或者同花顺进行比较
     * @param masterCard
     * @param playerCard
     */
    private straighCompare(masterCard: number[], playerCard: number[]) {
        let mScoreArr = this.getScoreArr(masterCard);
        let pScoreArr = this.getScoreArr(playerCard);
        if (this.isMinstraigh(mScoreArr) && this.isMinstraigh(pScoreArr)) {
            return CompareType.DRAW;//都是A23牌型 平局
        } else if (this.isMinstraigh(mScoreArr) && !this.isMinstraigh(pScoreArr)) {
            return CompareType.WIN;
        } else if (!this.isMinstraigh(mScoreArr) && this.isMinstraigh(pScoreArr)) {
            return CompareType.LOSE;
        }
        //如果都不是A23 计算总分
        return this.cardCompare(masterCard, playerCard);
    }

    /**
     * 根据牌分数组判断是否为顺子的最小牌 A23
     * @param scoreArr
     */
    private isMinstraigh(scoreArr: number[]): Boolean {
        let ascArr = ArrayHelper.sortAsc(scoreArr);
        if (ascArr[0] == 2 && ascArr[1] == 3 && ascArr[2] == 14) {
            return true;
        }
        return false;
    }

    /**
     * 对子进行比较
     * @param masterCard
     * @param playerCard
     */
    private dobleCompare(masterCard: number[], playerCard: number[]) {
        let mScoreArr = this.getDobleScore(masterCard);
        let pScoreArr = this.getDobleScore(playerCard);
        if (mScoreArr == 0 || pScoreArr == 0) {
            throw new Error("[ThreeCard.dobleCompare]庄家与玩家都出对子时才能进行比较");
        }
        if (mScoreArr[0] > pScoreArr[0]) {
            return CompareType.LOSE;
        } else if (mScoreArr[0] < pScoreArr[0]) {
            return CompareType.WIN;
        } else if (mScoreArr[1] > pScoreArr[1]) {
            return CompareType.LOSE;
        } else if (mScoreArr[1] < pScoreArr[1]) {
            return CompareType.WIN;
        }
        return CompareType.DRAW;
    }

    /**
     * 单牌比较
     * @param masterCard
     * @param playerCard
     */
    private single(masterCard: number[], playerCard: number[]) {
        let mCard: number[] = this.getScoreArr(masterCard);
        let pCard: number[] = this.getScoreArr(playerCard);
        mCard = ArrayHelper.sortDesc(mCard);
        pCard = ArrayHelper.sortDesc(pCard);
        for (let i = 0; i < 3; i++) {
            if (mCard[i] > pCard[i]) {
                return CompareType.LOSE;
            } else if (mCard[i] < pCard[i]) {
                return CompareType.WIN;
            }
        }
        return CompareType.DRAW;
    }

    /**
     * 判断3张牌里是否有对子
     * 如果没有对子 返回0  如果包含对子 返回数组 [对子分数,单牌分数] 进一步判断
     * @param cardArr 需要判断的牌组
     */
    private getDobleScore(cardArr: number[]): number | number[] {
        let cardScoreArr: number[] = this.getScoreArr(cardArr);
        let uniqueArr = ArrayHelper.unique(cardScoreArr);//进行一次去重
        if (uniqueArr.length != 2) {//3张牌里如果有对子 那么去重后应该有2个元素
            return 0;
        }
        let countObj: Object = ArrayHelper.countTimes(cardScoreArr);//包含重复元素的
        let cardData: number[] = [];//要返回的分数 数组
        Object.keys(countObj).forEach(item => {
            if (countObj[item] == 2) {
                cardData[0] = ArrayHelper.sumArray([Number(item), Number(item)]);
            } else {
                cardData[1] = Number(item);
            }
        });
        return cardData;
    }

    /**
     * 获取牌组分数
     * @param cardList
     */
    private getScoreArr(cardArr: number[]): number[] {
        let cardScoreArr: number[] = [];
        cardArr.forEach(card => {
            cardScoreArr.push(this.getCardValue(card, 14));
        });
        return cardScoreArr;
    }
    /**
     * 获取六张牌玩法的牌型
     * @param cardList 
     */
    public getSixCardType(cardList: number[]): SixCardType {
        if (cardList.length !== SIX_COUNT) {
            throw new Error("[CardLogic.getSixCardType]扑克数目有误");
        }
        this.setPokerBucket(cardList);
        let oneCnt = 0;         //单张数目
        let twoCnt = 0;         //对子数目
        let threeCnt = 0;       //三条数目
        let fourCnt = 0;        //四条数目
        let isFlush = false;      //同花
        let isStraight = false;   //顺子
        for (let i = 1; i < 14; i++) {
            if (this.PokerBucket.ValueCountMap[i] === 1) {
                oneCnt++;
            } else if (this.PokerBucket.ValueCountMap[i] === 2) {
                twoCnt++;
            } else if (this.PokerBucket.ValueCountMap[i] === 3) {
                threeCnt++;
            } else if (this.PokerBucket.ValueCountMap[i] === 4) {
                fourCnt++;
            }
        }
        if (fourCnt > 0) {
            return SixCardType.CT_FOUR;//四条
        }
        if (threeCnt > 0 && twoCnt > 0) {
            return SixCardType.CT_FULL_HOUSE;//葫芦
        }
        if (threeCnt > 0) {
            return SixCardType.CT_THREE;//三条
        }

        for (let i = 0; i < 4; i++) {
            if (this.PokerBucket.ColorCountMap[i] === cardList.length) {
                isFlush = true;
                break;
            }
        }
        // 判断是否是顺子, 必须全是单牌
        if (oneCnt === cardList.length) {
            for (let i = 1, shunCnt = 0; i <= 14; i++) {
                if (this.PokerBucket.ValueCountMap[i] > 0) {
                    shunCnt++;
                    if (shunCnt === cardList.length) {
                        isStraight = true;
                    }
                } else {
                    shunCnt = 0;
                }
            }
        }
        if (isFlush && isStraight) {//同花同顺 继续判断是否是皇家同花顺
            let scoreArr = this.getScoreArr(cardList);
            scoreArr = ArrayHelper.sortAsc(scoreArr);
            if (
                scoreArr[0] == 10 &&
                scoreArr[1] == 11 &&
                scoreArr[2] == 12 &&
                scoreArr[3] == 13 &&
                scoreArr[4] == 14
            ) {
                return SixCardType.CT_BIG_STRAIGHT_FLUSH;
            }
            return SixCardType.CT_STRAIGHT_FLUSH;
        } else if (!isFlush && isStraight) {
            return SixCardType.CT_STRAIGHT;
        } else if (isFlush && !isStraight) {
            return SixCardType.CT_FLUSH;
        }
        if (twoCnt > 1) {
            return SixCardType.CT_DOUBLE_TWO;
        } else if (twoCnt > 0) {
            return SixCardType.CT_DOUBLE;
        }
        return SixCardType.CT_SINGLE;
    }

    /**
     * 获取6张扑克组合的5张扑克中最大的牌型
     */
    public getFiveMaxCardType(cardList: number[]): SixCardType {
        if (cardList.length !== 6) {
            throw new Error("[CardLogic.getFiveMaxCardType]扑克数目有误");
        }
        let cardArr = this.getSixCardFiveArr(cardList);
        let typeArr: SixCardType[] = [];
        cardArr.forEach(item => {
            let cardType: SixCardType = this.getSixCardType(item);
            typeArr.push(cardType);
        });
        typeArr = ArrayHelper.sortDesc(typeArr);
        return typeArr[0];
    }

    /**
     * 获取6张牌里面所有由5张牌组成的组合
     */
    public getSixCardFiveArr(cardList: number[]): Array<Array<number>> {
        if (cardList.length !== 6) {
            throw new Error("[CardLogic.getSixCardFiveArr]扑克数目有误");
        }
        let outArr = [];
        for (let i = 0; i < cardList.length; i++) {
            let item = cardList.slice(0, 5);
            outArr.push(item)
            let number = cardList.pop();
            cardList.unshift(number);
        }
        return outArr;
    }

    /**
     * 获取牌组类型
     * @param cardList
     */
    public getCardType(cardList: number[]): CardType {
        if (cardList.length !== PACK_COUNT) {
            throw new Error("[CardLogic.getCardType]扑克数目有误");
        }
        this.setPokerBucket(cardList);

        let oneCnt = 0;         //单张数目
        let twoCnt = 0;         //对子数目
        let threeCnt = 0;       //三条数目
        let isFlush = false;      //同花
        let isStraight = false;   //顺子

        for (let i = 1; i < 14; i++) {
            if (this.PokerBucket.ValueCountMap[i] === 1) {
                oneCnt++;
            } else if (this.PokerBucket.ValueCountMap[i] === 2) {
                twoCnt++;
            } else if (this.PokerBucket.ValueCountMap[i] === 3) {
                threeCnt++;
            }
        }

        if (threeCnt > 0) {
            return CardType.CT_THREE;//三条
        }

        for (let i = 0; i < 4; i++) {
            if (this.PokerBucket.ColorCountMap[i] === cardList.length) {
                isFlush = true;
                break;
            }
        }
        // 判断是否是顺子, 必须全是单牌
        if (oneCnt === cardList.length) {
            for (let i = 1, shunCnt = 0; i <= 14; i++) {
                if (this.PokerBucket.ValueCountMap[i] > 0) {
                    shunCnt++;
                    if (shunCnt === cardList.length) {
                        isStraight = true;
                    }
                } else {
                    shunCnt = 0;
                }
            }
        }
        if (isFlush && isStraight) {
            let scoreArr = this.getScoreArr(cardList);
            scoreArr = ArrayHelper.sortAsc(scoreArr);
            if (scoreArr[0] == 12 && scoreArr[1] == 13 && scoreArr[2] == 14 && this.getCardColor(cardList[0]) == 3) {
                return CardType.CT_BIG_SPADE_STRAIGHT_FLUSH;
            }
            if (scoreArr[0] == 12 && scoreArr[1] == 13 && scoreArr[2] == 14) {
                return CardType.CT_BIG_STRAIGHT_FLUSH;
            }
            return CardType.CT_STRAIGHT_FLUSH;
        } else if (!isFlush && isStraight) {
            return CardType.CT_STRAIGHT;
        } else if (isFlush && !isStraight) {
            return CardType.CT_FLUSH;
        }
        if (twoCnt > 0) {
            return CardType.CT_DOUBLE;
        }

        return CardType.CT_SINGLE;
    }

    /**
     * 获取比牌结果
     */
    public getGameCompare(compareType: CompareType) {
        switch (compareType) {
            case CompareType.WIN:
                return "玩家赢";
            case CompareType.LOSE:
                return "玩家输";
            case CompareType.DRAW:
                return "平局";
            case CompareType.INVALID:
                return "无效";
            case CompareType.FOLD:
                return "弃牌";
        }
    }

    /**
     * 获取该游戏的牌型
     * @param cardType
     */
    public getCardTypeName(cardType: CardType): string {
        return "game_card_type_" + cardType;
    }

    /**
     * 根据传入牌返回牌型与花色(字符串)
     */
    public getCardData(cardList: Array<number>): string {
        let data = [];
        cardList.forEach(card => {
            data.push(this.getCardName(card));
        })
        return data.join('   ');
    }

    /**
     * 获取扑克牌的详细信息
     * 返回格式为
     * 牌型数字 如 1
     * 牌型名称 如 同花顺
     * 牌型详情 如 同花顺A
     * @param cardArr
     */
    public getCardInfo(cardArr: number[]): any {
        let cardInfo: any = {
            cardType: 0,
            cardTypeName: '',
            cardTypeDetails: '',
            cardTag: '',
            cardValue: 0
        };
        let cardType: CardType = this.getCardType(cardArr);
        cardInfo.cardType = cardType;
        cardInfo.cardTypeName = this.getCardTypeName(cardType);
        
        let cardTag: string = '';
        let cardValue: number = 0;
        if (cardType == CardType.CT_DOUBLE) {
            let scoreArr = this.getDobleScore(cardArr);
            let cardScore: number = scoreArr[0] / 2;
            cardScore = cardScore == 14 ? 1 : cardScore;
            cardTag = this.getCardTagName(cardScore);
            cardValue = cardScore;
        } else if (cardType == CardType.CT_STRAIGHT || cardType == CardType.CT_STRAIGHT_FLUSH) {
            let scoreArr = this.getScoreArr(cardArr);
            let descArr = ArrayHelper.sortDesc(scoreArr);
            if (descArr[0] == 14 && descArr[1] == 3 && descArr[2] == 2) {
                cardTag = '3';
                cardValue = 3;
            } else {
                cardTag = this.getCardTagName(descArr[0] == 14 ? 1 : descArr[0]);
                cardValue = descArr[0] == 14 ? 1 : descArr[0];
            }
        } else {
            let scoreArr = this.getScoreArr(cardArr);
            let descArr = ArrayHelper.sortDesc(scoreArr);
            cardTag = this.getCardTagName(descArr[0] == 14 ? 1 : descArr[0]);
            cardValue = descArr[0] == 14 ? 1 : descArr[0];
        }
        cardInfo.cardValue = cardValue;
        cardInfo.cardTag = cardTag;
        cardInfo.cardTypeDetails = cardInfo.cardTypeName + cardTag;
        return cardInfo;
    }

    /**
     * 判断哪一副扑克更大 返回最大的扑克
     * 如果相同,返回第二副牌
     * @param oneCardArr
     * @param twoCardArr
     */
    public getMaxCard(oneCardArr: number[], twoCardArr: number[]): any {
        let oType = this.getCardType(oneCardArr);
        let tType = this.getCardType(twoCardArr);
        let compareData = this.compareCard(oType, tType, oneCardArr, twoCardArr, false);
        if (compareData != CompareType.WIN) {
            return oneCardArr;
        }
        return twoCardArr;
    }

    /**
     * 获取输赢名称
     * @param winLose
     */
    getSettleWinOrLoseName(winLose: number) {
        switch (winLose) {
            case SettleWinOrLose.NONE:
                return "未分胜负";
            case SettleWinOrLose.WIN:
                return "玩家赢";
            case SettleWinOrLose.LOSE:
                return "玩家输";
            case SettleWinOrLose.DRAW:
                return "平局";
        }
    }

    /**
    * 判断扑克牌是否大于Q 6 4
    * @param cards
    */
    isBigerThanQ64(cards) {
        if (this.getCardType(cards) > CardType.CT_SINGLE) {
            return true;
        } else {
            let scoreArr = this.getScoreArr(cards);
            let cardsValue = ArrayHelper.sortDesc(scoreArr);
            if (cardsValue[0] > 12) {
                return true;
            } else {
                if (cardsValue[0] === 12) {
                    if (cardsValue[1] > 6) {
                        return true;
                    } else {
                        if (cardsValue[1] === 6) {
                            if (cardsValue[2] >= 4) {
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    }
                } else {
                    return false;
                }
            }
        }
    }

    /**
     * 获取被遮掩的一张牌的出现牌型的可能性
     */
    getShadowCardInfo(cards) {
        let cardTypeData = {};
        ThreeCardLogic.SrcPokerList.forEach(card => {
            if (card == 0x4e || card == 0x4f)
                return;
            if (cards.indexOf(card) != -1)
                return;
            let newCard = [cards[0], cards[1], card];
            let maxCardType = CardType.CT_SINGLE;
            if(this.getCardValue(newCard[0])==this.getCardValue(newCard[1])){
                maxCardType = CardType.CT_DOUBLE;
            }
            let cardType = this.getCardType(newCard)
            if (cardType > maxCardType) {
                if (!cardTypeData[cardType]) {
                    cardTypeData[cardType] = [];
                }
                cardTypeData[cardType].push(card);
            }
        });
        return cardTypeData;
    }
}