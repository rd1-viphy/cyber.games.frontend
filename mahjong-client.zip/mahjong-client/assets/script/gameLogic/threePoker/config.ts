export const GAME_STAGE_FREE = 0;

//  服务端发送给客户端消息类型定义
export enum SERVER_MESSAGE_TYPE {
    PLAYER_PLAY = 1,             //玩家博注 | 弃牌
    PLAYER_BET = 2               //玩家下注
}

// 允许下注的区域定义
export enum BET_AREA {
    ANTE = 0,       //底注
    PAIR_PLUS = 1,   //边注
    SIX_PLUS =2      //6张牌玩法下注
}

// 游戏阶段定义
export enum GAME_STAGE {
    FREE = GAME_STAGE_FREE,         //游戏没有开始
    BET = 1,                        //下注， 单人模式桌子一初始化  就进入第一个阶段
    SHADOW = 2,                     //眯牌阶段
    PLAY = 3,                       //博注  | 弃牌
    SETTLE = 4,                     //结算
    FLOW = 5                        //流局
}

//  系统扑克区域
export enum SYS_CARD_AREA {
    BANKER = 0,     //庄家
}

//玩家手牌的扑克数目
export const PACK_COUNT = 3;

//6牌玩法数量
export const SIX_COUNT = 5;

export enum CardType {
    CT_ERR = 0,            //错误牌型
    CT_SINGLE = 1,			//单牌类型
    CT_DOUBLE = 2,			//对子类型
    CT_FLUSH = 3,			//同花类型
    CT_STRAIGHT = 4,		//顺子类型
    CT_THREE = 5,           //三条
    CT_STRAIGHT_FLUSH = 6,	//同花顺类型
    CT_BIG_STRAIGHT_FLUSH = 7 ,//同花大顺
    CT_BIG_SPADE_STRAIGHT_FLUSH = 8  //黑桃同花大顺
}

/**
 * 六张牌玩法的牌型
 */
export enum SixCardType{
    CT_ERR = 0,                 //错误牌型
    CT_SINGLE = 1,			    //单牌类型
    CT_DOUBLE = 2,			    //对子类型
    CT_DOUBLE_TWO = 3,			//两个对子类型
    CT_THREE = 4,               //三条
    CT_STRAIGHT = 5,		    //顺子类型
    CT_FLUSH = 6,	            //同花
    CT_FULL_HOUSE = 7,          //葫芦
    CT_FOUR = 8,                //四条
    CT_STRAIGHT_FLUSH = 9 ,     //同花顺
    CT_BIG_STRAIGHT_FLUSH = 10   //同花大顺
}

export enum CompareType {
    WIN = 0, //玩家赢
    LOSE = 1, //玩家输
    DRAW = 2, //平局
    INVALID = 3, //无效局（庄家单牌Q以下,玩家赢得底注）
    FOLD = 4//玩家弃牌
}

export enum SettleWinOrLose {
    NONE = 0,//未分胜负
    WIN = 1, //玩家赢
    LOSE = 2, //玩家输
    DRAW = 3 //平局
}