/**
 * 针对数组的辅助类
 */
export default class ArrayHelper {

    /**
     * 打乱一个数组
     * 使用洗牌算法(Fisher–Yates shuffle) 也叫knuth算法
     * @param array
     */
    static shuffle(array: any[]): any[] {
        let i, j, temp;
        for (i = array.length - 1; i > 0; i--) {
            j = Math.floor(Math.random() * (i + 1));
            temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return array;
    }

    /**
     * 返回数组中元素出现的次数
     * 如  [3,0,1,2,1] 返回 {0: 1, 1: 2, 2: 1, 3: 1}
     * @param array 要处理的数组
     */
    static countTimes(array: Array<any>): Object {
        return array.reduce(function (allNames, name) {
            if (name in allNames) {
                allNames[name]++;
            } else {
                allNames[name] = 1;
            }
            return allNames;
        }, {});
    }

    /**
     * 对数组进行去重
     * @param array 要去重的数组
     */
    static unique(array: Array<number | string>): Array<number | string> {
        return Array.from(new Set(array))
    }

    /**
     * 计算一个数组的总和
     * @param array
     */
    static sumArray(array: Array<number>): number {
        return array.reduce(function (prev, cur, index, array) {
            return prev + cur;
        });
    }

    /**
     * 检查一个数组的元素是否是连续递增的
     * @param array
     */
    static isSerial(array: Array<number>): Boolean {
        for (let i = 0; i < array.length - 1; i++) {
            if (array[i] + 1 != array[i + 1]) {
                //不连续的
                return false;
            }
        }
        return true;
    }

    /**
     * 判断数组A是否位数组B的子集
     * @param subset 数组A
     * @param array 数组B
     */
    static isSubset(subset: Array<any>, array: Array<any>): Boolean {
        let Intersection = subset.filter(val => array.indexOf(val) > -1);//获取交集
        if (Intersection.length == subset.length) {
            return true;
        }
        return false;
    }

    /**
     * 对数组进行正序排列
     * @param array
     */
    static sortAsc(array: Array<number>): Array<number> {
        array.sort((a, b) => a - b);
        return array;
    }

    /**
     * 对数组进行倒序排列
     * @param array
     */
    static sortDesc(array: Array<number>): Array<number> {
        array.sort((a, b) => b - a);
        return array;
    }

}