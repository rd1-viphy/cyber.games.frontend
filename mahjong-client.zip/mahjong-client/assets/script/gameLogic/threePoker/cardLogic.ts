import ArrayHelper from "./arrayHelper";


/**
 * 扑克类游戏逻辑基类
 */
export default abstract class CardLogic {

    static readonly LOGIC_MASK_COLOR = 0xF0;            //花色掩码
    static readonly LOGIC_MASK_VALUE = 0x0F;            //数值掩码
    static readonly SrcPokerList: number[] = [
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D,	//方块 A - K
        0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D,	//梅花 A - K
        0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D,	//红桃 A - K
        0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 	//黑桃 A - K
        0x4e, 0x4f //小王 大王
    ];

    /**
     * PokerBucket扑克桶 空间换时间 加速计算
     * 优点1 不需要排序, 判断牌型非常方便, 即使是计算A23或者QKA都非常方便
     * 优点2 空间占用小, 计算迅速
     *
     * PokerBucket.ColorValueMap 二维数组
     * 第一维的索引是颜色 0号索引代表0x00方块 1号索引代表0x01梅花...
     * 第二维的索引是逻辑值, 值代表个数 一共15个桶, 把每张放到对应的桶里, 特殊的地方是有0号 1号 14号

     * PokerBucket.ValueCountMap 一维数组 不计花色 只统计逻辑值相同的扑克个数
     * 索引是逻辑值 值代表个数 1号索引代表A, 2号索引代表2... 13号索引代表K

     * PokerBucket.ColorCountMap 一维数组 统计各个花色的扑克个数
     * 索引是颜色 值代表个数 0号索引代表0x00方块 1号索引代表0x01梅花...
     */
    public PokerBucket: any = {
        ColorValueMap: [
            [0/*0*/, 0/*1*/, 0/*2*/, 0/*3*/, 0/*4*/, 0/*5*/, 0/*6*/, 0/*7*/, 0/*8*/, 0/*9*/, 0/*10*/, 0/*11*/, 0/*12*/, 0/*13*/, 0/*14*/], /*方块*/
            [0/*0*/, 0/*1*/, 0/*2*/, 0/*3*/, 0/*4*/, 0/*5*/, 0/*6*/, 0/*7*/, 0/*8*/, 0/*9*/, 0/*10*/, 0/*11*/, 0/*12*/, 0/*13*/, 0/*14*/], /*梅花*/
            [0/*0*/, 0/*1*/, 0/*2*/, 0/*3*/, 0/*4*/, 0/*5*/, 0/*6*/, 0/*7*/, 0/*8*/, 0/*9*/, 0/*10*/, 0/*11*/, 0/*12*/, 0/*13*/, 0/*14*/], /*红桃*/
            [0/*0*/, 0/*1*/, 0/*2*/, 0/*3*/, 0/*4*/, 0/*5*/, 0/*6*/, 0/*7*/, 0/*8*/, 0/*9*/, 0/*10*/, 0/*11*/, 0/*12*/, 0/*13*/, 0/*14*/], /*黑桃*/
        ],
        ValueCountMap: [
            [0], /*0*/
            [0], /*1*/
            [0], /*2*/
            [0], /*3*/
            [0], /*4*/
            [0], /*5*/
            [0], /*6*/
            [0], /*7*/
            [0], /*8*/
            [0], /*9*/
            [0], /*10*/
            [0], /*11*/
            [0], /*12*/
            [0], /*13*/
            [0], /*14*/
        ],
        ValueCardMap: [
            [0, 0, 0, 0], /*0*/
            [0, 0, 0, 0], /*1*/
            [0, 0, 0, 0], /*2*/
            [0, 0, 0, 0], /*3*/
            [0, 0, 0, 0], /*4*/
            [0, 0, 0, 0], /*5*/
            [0, 0, 0, 0], /*6*/
            [0, 0, 0, 0], /*7*/
            [0, 0, 0, 0], /*8*/
            [0, 0, 0, 0], /*9*/
            [0, 0, 0, 0], /*10*/
            [0, 0, 0, 0], /*11*/
            [0, 0, 0, 0], /*12*/
            [0, 0, 0, 0], /*13*/
            [0, 0, 0, 0], /*14*/
        ],
        ColorCountMap: [0/*方块*/, 0/*梅花*/, 0/*红桃*/, 0/*黑桃*/]
    };

    //洗牌池
    public dealBucket: number[];

    constructor() {
        //进行一次初始洗牌
        this.shuffle();
    }

    /**
     * 重置扑克桶
     */
    public resetPokerBucket(): void {
        for (let c = 0; c < 4; c++) {
            for (let v = 0; v < 15; v++) {
                this.PokerBucket.ColorValueMap[c][v] = 0;
            }
        }
        for (let v = 0; v < 15; v++) {
            for (let i = 0; i < 4; i++) {
                this.PokerBucket.ValueCardMap[v][i] = 0;
            }
        }
        for (let v = 0; v < 15; v++) {
            this.PokerBucket.ValueCountMap[v] = 0;
        }
        for (let c = 0; c < 4; c++) {
            this.PokerBucket.ColorCountMap[c] = 0;
        }
    }

    /**
     * 获取扑克花色
     * @param card
     */
    public getCardColor(card: number): number {
        return (card & CardLogic.LOGIC_MASK_COLOR) >> 4;
    }

    /**
     * 获取扑克分
     * @param card 扑克
     * @param cardOneVal 特殊扑克A的分数
     * @param cardTwoVal 特殊扑克2的分数
     */
    public getCardValue(card: number, cardOneVal: number = 1, cardTwoVal = 2): number {
        let value = card & CardLogic.LOGIC_MASK_VALUE;
        switch (value) {
            case 1:
                value = cardOneVal;
                break;
            case 2:
                value = cardTwoVal;
                break;
        }
        return value;
    }

    /**
     * 通过牌型返回指派花色与名
     * @param card
     */
    public getCardName(card: number) {
        return this.getCardColorName(card) + this.getCardTagName(card);
    }

    /**
     * 获取扑克花色名
     * @param card
     */
    protected getCardColorName(card: number): string {
        const cardColor = this.getCardColor(card);
        switch (cardColor) {
            case 0:
                return '♦';
            case 1:
                return '♣';
            case 2:
                return '♥';
            case 3:
                return '♠';
        }
        return '';
    }

    /**
     * 获取扑克标签名
     * @param card
     */
    public getCardTagName(card: number): string {
        const cardValue = this.getCardValue(card);
        let value = '';
        if (cardValue > 1 && cardValue <= 10) {
            value = cardValue.toString();
        } else if (cardValue === 1) {
            value = 'A';
        } else if (cardValue === 11) {
            value = 'J';
        } else if (cardValue === 12) {
            value = 'Q';
        } else if (cardValue === 13) {
            value = 'K';
        }
        return value;
    }

    /**
     * 将扑克牌组填充到扑克桶
     * @param cardList
     */
    protected setPokerBucket(cardList: number[]): void {
        this.resetPokerBucket();//清零桶
        for (let i = 0; i < cardList.length; i++) {
            const color = this.getCardColor(cardList[i]);
            const value = this.getCardValue(cardList[i]);
            if (value === 0) {
                // 允许数组中有空的值
                continue;
            }
            if (this.PokerBucket.ColorValueMap[color][value] > 0) {
                throw new Error('[CardLogic.setPokerBucket] 牌值重复');
            }
            this.PokerBucket.ColorValueMap[color][value] = 1;//防止重复
            this.PokerBucket.ColorCountMap[color]++;//统计花色数量
            this.PokerBucket.ValueCountMap[value]++;//统计扑克值数数量
        }
        this.PokerBucket.ValueCountMap[14] = this.PokerBucket.ValueCountMap[1];
        this.PokerBucket.ColorValueMap[0][14] = this.PokerBucket.ColorValueMap[0][1];
        this.PokerBucket.ColorValueMap[1][14] = this.PokerBucket.ColorValueMap[1][1];
        this.PokerBucket.ColorValueMap[2][14] = this.PokerBucket.ColorValueMap[2][1];
        this.PokerBucket.ColorValueMap[3][14] = this.PokerBucket.ColorValueMap[3][1];
    }

    /**
     * 按数值排序一副牌
     * @param cardList 要排序的牌
     * @param sortDesc 是否倒序排列
     */
    public sortCardArr(cardList: number[], sortDesc: Boolean = true): number[] {
        let data = cardList.sort((a, b) => {
            let c = this.getCardValue(a);
            let d = this.getCardValue(b);
            if (sortDesc) {
                return d - c;
            } else {
                return c - d;
            }
        })
        return data;
    }

    /**
     * 洗出一付乱序牌
     * @param ghost 是否加入大王小王  默认不加入
     */
    public shuffle(ghost: boolean = false): void {
        this.dealBucket = [];
        CardLogic.SrcPokerList.forEach(card => {
            if (ghost == false && (card == 0x4e || card == 0x4f)) return;
            this.dealBucket.push(card);
        })
        this.dealBucket = ArrayHelper.shuffle(this.dealBucket);
    }

    /**
     * 发牌,使用一副打乱的扑克牌 抽取若干张牌发给若干个玩家
     * 返回值一般为数组  发牌数量 * 玩家数量不可超过扑克牌的上限 否则返回false
     * @param cardNum 发牌数量
     */
    public deal(cardNum: number): number[] {
        let dealArray = [];
        for (let i = 0; i < cardNum; i++) {
            if (this.dealBucket.length == 0) {//如果牌发完了 停止发牌
                break;
            }
            let card = this.dealBucket.pop();
            dealArray.push(card);
        }
        return dealArray;
    }

}