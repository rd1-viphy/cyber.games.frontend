// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { CardType } from "./config";

const { ccclass, property } = cc._decorator;

@ccclass
export default class cardSort {
    public cardsNumSort(cardType, cardList) {
        let newList = [];
        if (cardType == CardType.CT_SINGLE || cardType == CardType.CT_FLUSH) {
            newList = this.cardSortSingle(cardList);
        } else if (cardType == CardType.CT_DOUBLE) {
            newList = this.cardSortDouble(cardList);
        } else if (cardType == CardType.CT_STRAIGHT || cardType == CardType.CT_STRAIGHT_FLUSH || cardType == CardType.CT_BIG_STRAIGHT_FLUSH || cardType == CardType.CT_BIG_SPADE_STRAIGHT_FLUSH) {
            newList = this.cardSortStraight(cardList);
        } else if (cardType == CardType.CT_THREE) {
            newList = this.cardSortThree(cardList);
        }
        return newList;
    }
    /**
     * 单牌排序
     * @param cardlist 
     */
    public cardSortSingle(cardList) {
        let newList = cardList.sort((a, b) => {
            return b % 16 - a % 16;
        });
        let includeIndex = this.getIncludeIndex(1, cardList);
        let includeNum = newList[includeIndex];
        if (includeIndex > -1) {
            newList.splice(includeIndex, 1);
            newList.unshift(includeNum);
        }
        return newList;
    }
    /**
     * 对子的排序
     * @param cardList 
     */
    public cardSortDouble(cardList) {
        let newList = cardList.sort((a, b) => {
            return b % 16 - a % 16;
        });
        if (newList[0] % 16 != newList[1] % 16) {
            let lastNum = newList[0];
            newList.shift()
            newList.push(lastNum);
        }
        return newList;
    }
    /**
     * 顺子排序
     * @param cardList 
     */
    public cardSortStraight(cardList) {
        let newList = cardList.sort((a, b) => {
            return b % 16 - a % 16;
        });
        if (newList[0] % 16 == 13 && newList[1] % 16 == 12 && newList[2] % 16 == 1) {
            let firstNum = newList[2];
            newList.splice(2);
            newList.unshift(firstNum);
        }
        return newList;
    }
    /**
     * 三条排序
     * @param cardList 
     */
    public cardSortThree(cardList) {
        let newList = cardList.sort((a, b) => {
            return b / 16 - a / 16;
        });
        return newList;
    }

    public getIncludeIndex(num, cardList) {
        let includeIndex = -1;
        cardList.forEach((element, index) => {
            if (num == element % 16) {
                includeIndex = index;
            }
        });
        return includeIndex;
    }
}
