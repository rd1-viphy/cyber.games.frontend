
import consts = require("../model/Consts");

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

   @property(cc.SpriteFrame)
   twNormalSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   twPressedSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   twDisableSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   enNormalSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   enPressedSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   enDisableSpriteFrame: cc.SpriteFrame = null;


   @property(cc.SpriteFrame)
   zhNormalSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   zhPressedSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   zhDisableSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   jpNormalSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   jpPressedSpriteFrame: cc.SpriteFrame = null;

   @property(cc.SpriteFrame)
   jpDisableSpriteFrame: cc.SpriteFrame = null;

   onLoad() {
      let btn = this.node.getComponent(cc.Button);
      if (consts.language == "tw") {
         btn.normalSprite = this.twNormalSpriteFrame;
         btn.pressedSprite = this.twPressedSpriteFrame;
         btn.hoverSprite = this.twNormalSpriteFrame;
         if(this.twDisableSpriteFrame){
            btn.disabledSprite = this.twDisableSpriteFrame;
         }
      } else if (consts.language == "en") {
         btn.normalSprite = this.enNormalSpriteFrame;
         btn.pressedSprite = this.enPressedSpriteFrame;
         btn.hoverSprite = this.enNormalSpriteFrame;
         if(this.enDisableSpriteFrame){
            btn.disabledSprite = this.enDisableSpriteFrame;
         }
      } else if (consts.language == "zh") {
         btn.normalSprite = this.zhNormalSpriteFrame;
         btn.pressedSprite = this.zhPressedSpriteFrame;
         btn.hoverSprite = this.zhNormalSpriteFrame;
         if(this.zhDisableSpriteFrame){
            btn.disabledSprite = this.zhDisableSpriteFrame;
         }
      } else if (consts.language == "jp") {
         btn.normalSprite = this.jpNormalSpriteFrame;
         btn.pressedSprite = this.jpPressedSpriteFrame;
         btn.hoverSprite = this.jpNormalSpriteFrame;
         if(this.jpDisableSpriteFrame){
            btn.disabledSprite = this.jpDisableSpriteFrame;
         }
      }
   }
}
