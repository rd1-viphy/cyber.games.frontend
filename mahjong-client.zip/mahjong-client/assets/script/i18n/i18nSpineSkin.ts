import consts = require("../model/Consts");

const { ccclass, property } = cc._decorator;

@ccclass
export default class i18nSpineSkin extends cc.Component {

    onLoad() {
        if (consts.language == "zh") {
            this.node.getComponent(sp.Skeleton).setSkin("cn");
            this.node.getComponent(sp.Skeleton).defaultSkin = "cn";
        } else {
            this.node.getComponent(sp.Skeleton).setSkin(consts.language);
            this.node.getComponent(sp.Skeleton).defaultSkin = consts.language;
        }
    }

}
