import App from "../model/App";
import * as i18nLabel from "./i18nLabel";
import * as i18nRichText from "./i18nRichText";
import * as i18nSpine from "./i18nSpine";
import * as i18nSprite from "./i18nSprite";
import * as i18nFont from "./i18nFont";

export class i18nMgr {
    private static language = "";     // 当前语言
    private static labelArr: i18nLabel.i18nLabel[] = [];        // i18nLabel 列表
    private static labelData: { [key: string]: string } = {};   // 文字配置
    private static spriteArr: i18nSprite.i18nSprite[] = [];     // i18nSprite 列表
    private static spineArr: i18nSpine.i18nSpine[] = [];        // i18nSpine  列表
    private static richTextArr: i18nRichText.i18nRichText[] = [];// i18nRichText 列表
    private static fontArr: i18nFont.i18nFont[] = [];// i18nRichText 列表

    // private static checkInit() {
    //     if (!this.language) {
    //         this.setLanguage("tw");
    //     }
    // }

    /**
     * 设置语言
     */
    public static setLanguage(language: string) {
        if (this.language === language) {
            return;
        }
        this.language = language;
        this.reloadLabel();
        this.reloadSprite();
        this.reloadSpine();
    }

    /**
     * 添加或移除 i18nLabel
     */
    public static _addOrDelLabel(label: i18nLabel.i18nLabel, isAdd: boolean) {
        if (isAdd) {
            this.labelArr.push(label);
        } else {
            let index = this.labelArr.indexOf(label);
            if (index !== -1) {
                this.labelArr.splice(index, 1);
            }
        }
    }

    public static _getLabel(opt: string, params: string[]): string {
        //this.checkInit();
        if (params.length === 0) {
            return this.labelData[opt] || opt;
        }
        let str = this.labelData[opt] || opt;
        for (let i = 0; i < params.length; i++) {
            let reg = new RegExp("#" + i, "g")
            str = str.replace(reg, params[i]);
        }
        return str;
    }


    /**
     * 添加或移除 i18nSprite
     */
    public static _addOrDelSprite(sprite: i18nSprite.i18nSprite, isAdd: boolean) {
        if (isAdd) {
            this.spriteArr.push(sprite);
        } else {
            let index = this.spriteArr.indexOf(sprite);
            if (index !== -1) {
                this.spriteArr.splice(index, 1);
            }
        }
    }

    public static _getSprite(path: string, isBundle: boolean, cb: (spriteFrame: cc.SpriteFrame) => void) {
        //this.checkInit();
        if (App.spriteCache.get(path)) {
            cb(App.spriteCache.get(path));
        } else {
            let bundle: cc.AssetManager.Bundle;
            if (isBundle && App.gameBundle) {
                bundle = App.gameBundle;
            } else {
                bundle = cc.resources;
            }

            bundle.load("i18n/sprite/" + this.language + "/" + path, cc.SpriteFrame, (err, spriteFrame) => {
                if (err) {
                    return cb(null);
                }
                App.spriteCache.set(path,spriteFrame);
                cb(<cc.SpriteFrame>spriteFrame);
            });
        }
    }

    private static reloadLabel() {
        let url = "i18n/label/" + this.language;
        cc.resources.load(url, cc.JsonAsset, (err: Error, data: cc.JsonAsset) => {
            if (err) {
                console.error("load Json error");
                this.labelData = {};
            } else {
                let jsonData = data.json;
                for (let key in jsonData) {
                    if (Object.prototype.hasOwnProperty.call(jsonData, key)) {
                        let element = jsonData[key];
                        for (let keyValue in element) {
                            if (Object.prototype.hasOwnProperty.call(element, keyValue)) {
                                let element1 = element[keyValue];
                                this.labelData[keyValue] = element1;
                            }
                        }
                    }
                }
            }
            for (let one of this.labelArr) {
                one._resetValue();
            }
            for (let one of this.richTextArr) {
                one._resetValue();
            }
        });
    }

    /**
     * 添加或移除 i18nSpine
     */
    public static _addOrDelSpine(spine: i18nSpine.i18nSpine, isAdd: boolean) {
        if (isAdd) {
            this.spineArr.push(spine);
        } else {
            let index = this.spineArr.indexOf(spine);
            if (index !== -1) {
                this.spineArr.splice(index, 1);
            }
        }
    }

    public static _getSpine(path: string, isBundle: boolean, cb: (skeleton: sp.SkeletonData) => void) {
        //this.checkInit();
        if (App.spineCache.get(path)) {
            cb(App.spineCache.get(path));
        }else{
            let bundle: cc.AssetManager.Bundle;
            if (isBundle && App.gameBundle) {
                bundle = App.gameBundle;
            } else {
                bundle = cc.resources;
            }
            bundle.load("i18n/spine/" + this.language + "/" + path, sp.SkeletonData, (err, skeletonData) => {
                if (err) {
                    return cb(null);
                }
                App.spineCache.set(path,skeletonData);
                cb(<sp.SkeletonData>skeletonData);
            });
        }
    }

    private static reloadSprite() {
        for (let one of this.spriteArr) {
            one._resetValue();
        }
    }

    private static reloadSpine() {
        for (let one of this.spineArr) {
            one._resetValue();
        }
    }

    /**
     * 添加或移除 i18nRichText
     */
     public static _addOrDelRichText(richText: i18nRichText.i18nRichText, isAdd: boolean) {
        if (isAdd) {
            this.richTextArr.push(richText);
        } else {
            let index = this.richTextArr.indexOf(richText);
            if (index !== -1) {
                this.richTextArr.splice(index, 1);
            }
        }
    }

    public static _getRichText(opt: string, params: string[]): string {
        //this.checkInit();
        if (params.length === 0) {
            return this.labelData[opt] || opt;
        }
        let str = this.labelData[opt] || opt;
        for (let i = 0; i < params.length; i++) {
            let reg = new RegExp("#" + i, "g")
            str = str.replace(reg, params[i]);
        }
        return str;
    }


     /**
     * 添加或移除 i18nFont
     */
     public static _addOrDelFont(font: i18nFont.i18nFont, isAdd: boolean) {
        if (isAdd) {
            this.fontArr.push(font);
        } else {
            let index = this.fontArr.indexOf(font);
            if (index !== -1) {
                this.spriteArr.splice(index, 1);
            }
        }
    }

    public static _getFont(path: string, isBundle: boolean, cb: (font: cc.Font) => void) {
        //this.checkInit();
        if (App.fontCache.get(path)) {
            cb(App.fontCache.get(path));
        }else{
            let bundle: cc.AssetManager.Bundle;
            if (isBundle && App.gameBundle) {
                bundle = App.gameBundle;
            } else {
                bundle = cc.resources;
            }
            cc.log("font load path ","i18n/font/" + this.language + "/" + path);
            bundle.load("i18n/font/" + this.language + "/" + path , cc.Font, (err, font) => {
                if (err) {
                    return cb(null);
                }
                cb(<cc.Font>font);
            });
        }
    }

}
