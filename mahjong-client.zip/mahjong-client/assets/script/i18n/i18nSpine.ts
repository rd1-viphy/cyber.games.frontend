import consts = require("../model/Consts");
import { i18nMgr } from "./i18nMgr";
const { ccclass, property, executeInEditMode, disallowMultiple, requireComponent, menu } = cc._decorator;

@ccclass
@executeInEditMode
@requireComponent(sp.Skeleton)
@disallowMultiple
@menu("多语言/i18nSpine")
export class i18nSpine extends cc.Component {

    @property({ visible: false })
    private i18n_string: string = "";

    start() {
        i18nMgr._addOrDelSpine(this, true);
        this._resetValue();
    }
    @property
    isBundle:boolean = false;

    @property
    isLoop:boolean = false;

    @property
    isSetSkin:boolean = false;

    @property
    aniName:string = "";

    @property({ type: cc.String })
    get string() {
        return this.i18n_string;
    }
    set string(value: string) {
        if(value){
            this.i18n_string = value;
            let skeleton = this.getComponent(sp.Skeleton);
            if (cc.isValid(skeleton)) {
                if(this.isSetSkin){
                    skeleton.setAnimation(0,this.aniName,this.isLoop);
                    let skinName = consts.language;
                    if(skinName == "zh"){
                        skinName = "cn"
                    }
                    skeleton.setSkin(skinName);
                }else{
                    i18nMgr._getSpine(value,this.isBundle,(skeletonData) => {
                        if (cc.isValid(skeletonData)) {
                            skeleton.skeletonData = skeletonData;
                            skeleton.setAnimation(0,this.aniName,this.isLoop);
                        }
                    });
                }
                
            }
        }
    }
 
    init(value:string,aniName:string){
        this.aniName = aniName;
        this.string = value;
    } 
    _resetValue() {
        this.string = this.i18n_string;
    }

    onDestroy() {
        i18nMgr._addOrDelSpine(this, false);
    }
}
