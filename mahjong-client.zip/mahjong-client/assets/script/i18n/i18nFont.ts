import { i18nMgr } from "./i18nMgr";
const { ccclass, property, executeInEditMode, disallowMultiple, requireComponent, menu } = cc._decorator;

@ccclass
@executeInEditMode
@requireComponent(cc.Label)
@disallowMultiple
@menu("多语言/i18nFont")
export class i18nFont extends cc.Component {

    @property({ visible: false })
    private i18n_string: string = "";

    @property
    isBundle: boolean = true;

    @property({ type: cc.String })
    get string() {
        return this.i18n_string;
    }
    set string(value: string) {
        this.i18n_string = value;

        // let sprite = this.getComponent(cc.Sprite);
        // if (cc.isValid(sprite)) {
        //     i18nMgr._getSprite(value,this.isBundle,(spriteFrame) => {
        //         if (spriteFrame) {
        //             //sprite.spriteFrame = spriteFrame;
        //         }
        //     });
        // }
    }
    onLoad() {
        i18nMgr._addOrDelFont(this, true);
        this._resetValue();
    }
    _resetValue() {
        //this.string = this.i18n_string;
        if (this.string) {
            this.refreshFont(this.string);
        }
    }

    refreshFont(str) {
        if (str) {
            let label = this.getComponent(cc.Label);
            if (cc.isValid(label)) {
                i18nMgr._getFont(str, this.isBundle, (font) => {
                    if (font) {
                        label.font = font;
                    }
                });
            }
        }
    }

    onDestroy() {
        i18nMgr._addOrDelFont(this, false);
    }
}
