import { GAME_TYPE } from "../common/ClientEnum";
import PlayerMgr from "../model/PlayerMgr";
import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    clock_btn: cc.Node = null;

    @property(cc.Prefab)                    //item
    myrecord_blackJack_list: cc.Prefab = null;

    @property(cc.Prefab)                    //item
    myrecord_threePoker_list: cc.Prefab = null;

    @property(cc.Prefab)                    //item
    date_item: cc.Prefab = null;


    @property(cc.Node)
    no_record: cc.Node = null;
    @property(cc.Node)
    layout0: cc.Node = null;


    @property(cc.Label)
    date_label0: cc.Label = null;
    @property(cc.Label)
    date_label1: cc.Label = null;
    @property(cc.Label)
    game_label: cc.Label = null;


    @property(cc.Node)
    select0: cc.Node = null;
    @property(cc.Node)
    layout1: cc.Node = null;

    @property(cc.Node)
    select1: cc.Node = null;
    @property(cc.Node)
    layout2: cc.Node = null;

    @property(cc.Node)
    select2: cc.Node = null;
    @property(cc.Node)
    layout3: cc.Node = null;

    @property(cc.Node)
    sel_icon0: cc.Node = null;
    @property(cc.Node)
    sel_icon1: cc.Node = null;
    @property(cc.Node)
    sel_icon2: cc.Node = null;

    @property({ type: cc.SpriteFrame })
    dengjiimg: cc.SpriteFrame[] = [];
    // tou_0 = false;
    // tou_1 = false;

    @property(cc.Node)
    jia: cc.Node = null;
    @property(cc.Node)
    jian: cc.Node = null;
    @property(cc.Node)
    current_page: cc.Node = null;
    @property(cc.Node)
    max_page: cc.Node = null;
    @property(cc.Label)
    putAllLabel: cc.Label = null;
    @property(cc.Label)
    resultAllLabel: cc.Label = null;

    @property(cc.ToggleContainer)
    startToggleContainer: cc.ToggleContainer = null;

    @property(cc.ToggleContainer)
    endToggleContainer: cc.ToggleContainer = null;


    @property(cc.ToggleContainer)
    gameToggleContainer: cc.ToggleContainer = null;

    @property(cc.Node)
    toggleItem: cc.Node = null;

    @property(cc.Node)
    gameSelectFrame: cc.Node = null;

    @property(cc.Node)
    gameSelectDown: cc.Node = null;

    @property(cc.ScrollView)
    recordScrollview:cc.ScrollView = null;
    page = 1;
    maxpage = 0;
    // startTime = 0;
    // endTime = 0;
    count = 4;
    gameId = 0;

    putAll = 0;
    resultAll = 0;
    currectTime = 0;
    startIndex = 0;
    endIndex = 0;
    maxNum = 7;
    start() {
        this.clock_btn.on(cc.Node.EventType.TOUCH_END, () => {
            this.node.destroy()
        });

        this.select0.active = false;
        this.select1.active = false;


        this.currectTime = Date.parse(new Date().toString()) / 1000;
        this.startIndex = this.maxNum;
        this.getRecord();
        this.refreshSelectDate();
        this.refreSelectGame();
        this.refreshGameToggleCount();
    }

    getRecord() {
        let requestData = { "startTime": this.currectTime - 24 * 3600 * this.startIndex, "endTime": this.currectTime - 24 * 3600 * this.endIndex, "gameId": this.gameId, "page": this.page, "size": this.count };
        PlayerMgr.getInstance().getGameRecord(requestData, (data) => {
            this.maxpage = data.maxPage;
            if(data.maxPage>99){
                this.maxpage = 99;
            }
            this.refreshData(data);
            this.refreshTurnBtn();
        });
    }
    refreshData(data) {
        let msg = data.recordLog;
        this.putAll = 0;
        this.resultAll = 0;
        this.recordScrollview.scrollToTop();
        this.layout0.removeAllChildren();
        this.current_page.getComponent(cc.Label).string = String(this.page);
        this.max_page.getComponent(cc.Label).string = String(this.maxpage);
        //msg = [{ juhao: 2020061800001, time: "06-18 18:20", game: "21点", device: { xian: 18, zhuang: 19 }, bet: 999999, send: 9999999 }, { juhao: 2020061800002, time: "06-18 18:20", game: "21点", device: { xian: 18, zhuang: 19 }, bet: 9999.99, send: 99999.99 }, { juhao: 2020061800003, time: "06-18 18:20", game: "21点", device: { xian: 18, zhuang: 19 }, bet: 9999.99, send: 99999.99 }, { juhao: 2020061800004, time: "06-18 18:20", game: "21点", device: { xian: 18, zhuang: 19 }, bet: 9999.99, send: 99999.99 }]
        this.no_record.active = (msg.length > 0) ? false : true;
        if (msg.length == 0) {
            this.current_page.getComponent(cc.Label).string = "0";
        }
        for (let i = 0; i < msg.length; i++) {
            let item;
            if (msg[i].gameId == GAME_TYPE.THREE_POKER) {
                item = cc.instantiate(this.myrecord_threePoker_list);
                item.getComponent("set_myrecord_threePoker_list").init(msg[i]);
            } else if (msg[i].gameId == GAME_TYPE.BLACK_JACK) {
                item = cc.instantiate(this.myrecord_blackJack_list);
                item.getComponent("set_myrecord_blackJack_list").init(msg[i]);
            }
            this.putAll += msg[i].betMoney;
            this.resultAll += msg[i].payment;
            this.layout0.addChild(item);
        }
        this.putAllLabel.string = Utils.formatNumDistance(data.betSum.toFixed(2));
        this.resultAllLabel.string = Utils.formatNumDistance(data.paymentSum.toFixed(2));
        this.setTotalColor(data.betSum, data.paymentSum, this.resultAllLabel);
    }

    date_touch(event, data) {
        switch (data) {
            case "0":
                if (this.select0.active) {
                    this.select0.active = false;
                    this.sel_icon0.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];
                } else {
                    this.select0.active = true;
                    this.refreshToggleContainer(this.endIndex + 1, this.maxNum, this.startToggleContainer, true);
                    this.sel_icon0.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[1];
                }
                break;
            case "1":
                if (this.select1.active) {
                    this.select1.active = false;
                    this.sel_icon1.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];

                } else {
                    this.select1.active = true;
                    this.refreshToggleContainer(0, this.startIndex - 1, this.endToggleContainer, false);
                    this.sel_icon1.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[1];
                }
                break;
            case "2":
                if (this.select2.active) {
                    this.select2.active = false;
                    this.sel_icon2.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];

                } else {
                    this.select2.active = true;
                    this.refreshGameToggleContainer();
                    this.sel_icon2.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[1];
                }
                break;
        }
    }

    nest_page(event, data) {
        if (this.maxpage > 0) {
            switch (data) {
                case "+":

                    if (this.page < this.maxpage) {
                        this.page++;
                        this.getRecord();
                    }
                    this.current_page.getComponent(cc.Label).string = String(this.page)

                    break;
                case "-":
                    if (this.page > 1) {
                        this.page--;
                        this.getRecord();
                    }
                    this.current_page.getComponent(cc.Label).string = String(this.page)
                    break;
            }
        }
    }

    refreshSelectDate() {
        this.date_label0.string = Utils.timestampToTime(this.currectTime - this.startIndex * 24 * 3600, 1);
        this.date_label1.string = Utils.timestampToTime(this.currectTime - this.endIndex * 24 * 3600, 1);
    }
    refreshGameToggleCount() {
        PlayerMgr.getInstance().getGameRecordCount({}, (data) => {
            let toggles = this.gameToggleContainer.toggleItems;
            let games = data.data;
            let isHaveRecord:boolean = false;
            let gameLength = 0;
            let havaRecordGameId = 0;
            games.forEach(element => {
                if (element.count > 0) {
                    isHaveRecord = true;
                    gameLength++;
                    havaRecordGameId = element.gameId;
                }
                if (element.gameId) {
                    toggles[element.gameId].node.active = element.count > 0;
                }
            });
            this.gameSelectDown.active = isHaveRecord;
            this.gameSelectFrame.active = isHaveRecord;
            toggles[0].node.active = gameLength > 1;
            if(gameLength == 1){
                this.gameId = havaRecordGameId;
                this.refreSelectGame();
                this.gameSelectDown.getComponent(cc.Button).interactable = false;
                this.gameSelectFrame.getComponent(cc.Button).interactable = false;
            }
        });
    }
    selectDateNodeClicked() {
        this.select0.active = false;
        this.select1.active = false;
        this.sel_icon0.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];
        this.sel_icon1.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];
    }


    refreshToggleContainer(start, end, toggleContainer, isStart) {
        toggleContainer.node.removeAllChildren();
        for (let i = start; i <= end; i++) {
            let item = cc.instantiate(this.toggleItem);
            let label1 = item.getChildByName("Background").getChildByName("New Label").getComponent(cc.Label);
            let label2 = item.getChildByName("checkmark").getChildByName("New Label").getComponent(cc.Label);
            let dateLabel = Utils.timestampToTime(this.currectTime - i * 24 * 3600, 1);
            label1.string = dateLabel;
            label2.string = dateLabel;
            if (isStart) {
                item.getComponent(cc.Toggle).isChecked = i == this.startIndex;
            } else {
                item.getComponent(cc.Toggle).isChecked = i == this.endIndex;
            }
            item.getComponent(cc.Toggle)["indexData"] = i;
            item.on("toggle", (event) => {
                let index = event["indexData"];
                if (isStart) {
                    this.startIndex = index;
                } else {
                    this.endIndex = index;
                }
                this.page = 1;
                this.refreshSelectDate();
                this.selectDateNodeClicked();
                this.getRecord();
            });
            toggleContainer.node.addChild(item);
            item.active = true;
        }
    }

    refreSelectGame() {
        if (this.gameId == GAME_TYPE.THREE_POKER) {
            //this.game_label.string = "富贵三宝";
            Utils.setLabelStrForLanguage(this.game_label, "game_three_poker");
        } else if (this.gameId == GAME_TYPE.BLACK_JACK) {
            //this.game_label.string = "21点";
            Utils.setLabelStrForLanguage(this.game_label, "game_black_jack");
        } else if (this.gameId == 0) {
            //this.game_label.string = "全部";
            Utils.setLabelStrForLanguage(this.game_label, "all_game");
        }
    }

    selectGameNodeClicked() {
        this.select2.active = false;
        this.sel_icon2.getComponent(cc.Sprite).spriteFrame = this.dengjiimg[0];
    }

    gameToggleClicked(event, data) {
        this.gameId = parseInt(data);
        this.page = 1;
        this.refreSelectGame();
        this.selectGameNodeClicked();
        this.getRecord();
    }

    refreshGameToggleContainer() {
        let toggles = this.gameToggleContainer.toggleItems;
        toggles.forEach((toggleItem, index) => {
            toggleItem.isChecked = index == this.gameId;
        });
    }

    setTotalColor(putValue, getValue, label) {
        if (getValue > putValue) {
            label.node.color = new cc.Color(80, 228, 0);
        } else if (getValue == putValue) {
            label.node.color = new cc.Color(255, 255, 255);
        } else {
            label.node.color = new cc.Color(249, 0, 0);
        }
    }
    refreshTurnBtn() {
        if (this.maxpage == 0) {
            this.jia.active = false;
            this.jian.active = false;
        } else {
            this.jian.active = this.page > 1;
            this.jia.active = this.page < this.maxpage;
        }
    }
}
