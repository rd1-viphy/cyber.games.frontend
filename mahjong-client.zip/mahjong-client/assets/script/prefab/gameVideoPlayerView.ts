import App from "../model/App";
import AudioMgr from "../model/AudioMgr";


const {ccclass, property} = cc._decorator;

@ccclass
export default class gameVideoPlayerView extends cc.Component {

    @property(cc.VideoPlayer)
    videoPlayer: cc.VideoPlayer = null;

    @property(cc.Node)
    playVideoArea: cc.Node = null;

    @property(cc.Label)
    multipleLabel:cc.Label = null;

    @property(cc.Node)
    multipleSprite:cc.Node = null;

    @property(cc.ToggleContainer)
    multipToggleContainer:cc.ToggleContainer = null;

    @property(cc.Node)
    stopBtn:cc.Node = null;

    @property(cc.Node)
    playBtn:cc.Node = null;

    @property(cc.Node)
    bottomNode:cc.Node = null;

    @property(cc.ProgressBar)
    progressBar:cc.ProgressBar = null;

    @property(cc.Node)
    loadingLabel:cc.Node = null;

    public divBtn = null;
    private isMove = false;
    protected onLoad(): void {
        App.isPlayVideo = true;
    }
    init(data) {
        let localResUrl = cc.url.raw("resources/image/btn_play.png");
        cc.loader.load(localResUrl, (error, res) => {
            if (!error) {
                const imageUrl = res.nativeUrl;
                let videos = document.getElementsByClassName("cocosVideo");
                if(videos && videos[0]){
                  //@ts-ignore
                  videos[0].poster = imageUrl;
                }
            }
        });
        const url:string =data.url;
        this.node.active = true;
        //this.createDivBtn();
        this.videoPlayer.volume = AudioMgr.bgmVolume;
        cc.log("load remote url=",url);
        this.videoPlayer.remoteURL = url;
     
    }

    onVideoPlayerEvent(sender, event) {
        if (event === cc.VideoPlayer.EventType.CLICKED) {
          
        } else if (event === cc.VideoPlayer.EventType.READY_TO_PLAY || event === cc.VideoPlayer.EventType.META_LOADED) {
            this.videoPlayer.play();
            this.playBtn.active = false;
            this.stopBtn.active = true;
            this.playVideoArea.active = true;
            this.bottomNode.active = true;
            //this.loadingLabel.active = true;
        } else if (event === cc.VideoPlayer.EventType.PLAYING) {
            //this.loadingLabel.active = false;
            this.playVideoArea.active = false;
        } else if (event === cc.VideoPlayer.EventType.COMPLETED) {
            this.close();
        }
    }

    toggleFullscreen() {
        if (
            cc.sys.isBrowser &&
            cc.sys.browserType === cc.sys.BROWSER_TYPE_MOBILE_QQ &&
            Number(cc.sys.browserVersion) <= 7.2 &&
            /Nexus 6/.test(navigator.userAgent)
        ) {
            return cc.log('May be crash, so prohibit full screen');
        }
        cc.audioEngine.pauseAll();
        AudioMgr.setSFXVolume(0);

        this.videoPlayer.isFullscreen = true;
    }

    play() {
        this.playBtn.active = false;
        this.stopBtn.active = true;
        this.videoPlayer.volume = AudioMgr.bgmVolume;
        this.videoPlayer.play();
        this.playVideoArea.active = false;
    }

    pause() {
        this.playBtn.active = true;
        this.stopBtn.active = false;
        this.videoPlayer.pause();
    }

    stop() {
        this.playBtn.active = true;
        this.stopBtn.active = false;
        this.videoPlayer.stop();
    }

    close() {
        AudioMgr.init();
        AudioMgr.resumeAll();
       // this.divBtn.style.visibility = "hidden";
        this.videoPlayer.stop();
        this.node.destroy();
    }

    createDivBtn() {
        let cocos2dContainer = document.getElementById("Cocos2dGameContainer");
        let button = document.createElement("button");
        button.setAttribute("id", "webButton");
        button.style.position = "fixed"
        button.style.right = `2px`;
        button.style.top = `2px`;
        let imageUrl = null;
        button.style.visibility = "visible";
        let localResUrl = cc.url.raw("resources/image/btn_video_close.png");

        cc.loader.load(localResUrl, (error, res) => {
            if (!error) {
                imageUrl = res.nativeUrl;
                button.style.backgroundImage = `url(${imageUrl})`;
                button.style.width = res.width + "px";
                button.style.height = res.height + "px";
                button.style.backgroundColor = "transparent";
                button.style.borderColor = "transparent";
                button.onclick = (() => {
                    if (!this.isMove) {
                        this.close();
                    } else {
                        this.isMove = false;
                    }
                   
                });
                this.divBtn = button;
                cocos2dContainer.appendChild(button);
            }
        });
    }

    toggleClicked(event,data:string){
       let multiple = parseFloat(data);
       this.multipToggleContainer.node.active = false;
       let videos = document.getElementsByClassName("cocosVideo");
       if(videos && videos[0]){
         //@ts-ignore
         videos[0].playbackRate = multiple;
       }
       if(multiple > 1){
          this.multipleLabel.node.active = true;
          this.multipleSprite.active = false;
          this.multipleLabel.string = multiple.toFixed(1) + "x";
       }else{
        this.multipleLabel.node.active = false;
        this.multipleSprite.active = true;
       }
    }
    onDestroy() {
        //this.divBtn.style.visibility = "hidden";
        App.isPlayVideo = false;
    }

    btnClieked(event,data:string){
        switch(data){
           case "again":
               this.videoPlayer.stop();
               this.scheduleOnce(()=>{
                 this.play();
               },0.5);
              
               break;
           case "multip":
               this.multipToggleContainer.node.active = !this.multipToggleContainer.node.active;
               break;    
        }
     
    }

    protected update(dt: number): void {
        this.progressBar.progress = this.videoPlayer.currentTime/this.videoPlayer.getDuration();
    }
}
