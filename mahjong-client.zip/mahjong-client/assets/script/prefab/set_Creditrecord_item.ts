import { GAME_TYPE } from "../common/ClientEnum";
import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    time: cc.Label = null;

    @property(cc.Label)
    game: cc.Label = null;

    @property(cc.Label)
    Balance_before: cc.Label = null;

    @property(cc.Label)
    winOrLose: cc.Label = null;

    @property(cc.Label)
    Balance_after: cc.Label = null;

    @property(cc.Node)
    infoNode:cc.Node = null;

    @property(cc.Node)
    infoBtn:cc.Node = null;

    @property(cc.Label)
    orderNumberLabel:cc.Label = null;

    @property(cc.Label)
    infoBeforeCoin:cc.Label = null;

    @property(cc.Label)
    infoWinOrLoseCoin:cc.Label = null;

    @property(cc.Label)
    infoAfterCoin:cc.Label = null;

    @property(cc.Label)
    roomNum:cc.Label = null;
    status = 0;
    start() {

    }
    init(msg) {
        this.time.string = Utils.timestampToTime(msg.addTime,2); ;
        if(msg.gameId == GAME_TYPE.THREE_POKER){
            //this.game.string = "富贵三宝";
            Utils.setLabelStrForLanguage(this.game,"game_three_poker");
        }else if(msg.gameId == GAME_TYPE.BLACK_JACK){
            //this.game.string = "21点";
            Utils.setLabelStrForLanguage(this.game,"game_black_jack");
        }
        this.Balance_before.string = Utils.formatMoneyNum(msg.beforeMoney);
        let type = msg.type;
        if(type == 3){
            this.winOrLose.string = Utils.formatMoneyNum(-msg.changeMoney);
            this.infoWinOrLoseCoin.string = Utils.formatNumDistance((-msg.changeMoney).toFixed(2));
            this.Balance_after.string =  Utils.formatMoneyNum(msg.beforeMoney - msg.changeMoney);
            this.infoAfterCoin.string = Utils.formatNumDistance((msg.beforeMoney - msg.changeMoney).toFixed(2));
            this.winOrLose.node.color = new cc.Color(249,0,0);
            this.infoWinOrLoseCoin.node.color = new cc.Color(249,0,0);
            Utils.setLabelStrForLanguage(this.roomNum, "sign_bet");
        }else{
            this.winOrLose.string = Utils.formatMoneyNum(msg.changeMoney);
            this.infoWinOrLoseCoin.string = Utils.formatNumDistance(msg.changeMoney.toFixed(2));
            this.Balance_after.string =  Utils.formatMoneyNum(msg.beforeMoney + msg.changeMoney);
            this.infoAfterCoin.string = Utils.formatNumDistance((msg.beforeMoney + msg.changeMoney).toFixed(2));
            if(msg.changeMoney == 0){
                this.winOrLose.node.color = new cc.Color(255,255,255);
                this.infoWinOrLoseCoin.node.color = new cc.Color(255,255,255);
            }else{
                this.winOrLose.node.color = new cc.Color(80,228,0);
                this.infoWinOrLoseCoin.node.color = new cc.Color(80,228,0);
            }
            
            Utils.setLabelStrForLanguage(this.roomNum, "sign_settle");
        }
        
        this.orderNumberLabel.string = msg.transactionid;
        this.infoBeforeCoin.string = Utils.formatNumDistance(msg.beforeMoney.toFixed(2));
        // this.infoAfterCoin.string = this.Balance_after.string;
        // this.infoWinOrLoseCoin.string = this.winOrLose.string;
    }
    
    infoBtnClicked(){
       if(this.status == 0){
         this.status = 1;
         this.infoNode.active = true;
         this.infoBtn.scaleY = -1;
       }else{
         this.status = 0;
         this.infoNode.active = false;
         this.infoBtn.scaleY = 1;
       }
    }
}
