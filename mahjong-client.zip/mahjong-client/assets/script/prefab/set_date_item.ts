

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    label: cc.Node = null;

    @property(cc.Node)
    bg: cc.Node = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}
    node0
    data
    d
    start() {
        this.node.on(cc.Node.EventType.TOUCH_START, () => {
            this.label.color = cc.color(0, 0, 0, 255);
            this.bg.active = true;
        });
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, () => {
            this.label.color = cc.color(255, 217, 115, 255);
            this.bg.active = false;
        });
        this.node.on(cc.Node.EventType.TOUCH_END, () => {
            this.bg.active = false;
            this.node0["date_label" + this.d].string = this.data.date;
            this.node0["select" + this.d].active = false;
            this.node0["sel_icon" + this.d].getComponent(cc.Sprite).spriteFrame = this.node0.dengjiimg[0];
            this.node0["tou_" + this.d] = false;
        });
    }
    /**msg:信息，node:父级，d:左右位置区分*/
    init(msg, node, d) {
        this.data = msg;
        this.label.getComponent(cc.Label).string = msg.date;
        this.node0 = node;
        this.d = d;
        this.bg.active = false;
    }

  
}
