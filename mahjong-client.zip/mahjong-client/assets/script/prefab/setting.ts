import App from "../../script/model/App";

import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import { Utils } from "../model/Utils";
import AppEmitter from "../network/AppEmitter";
const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {
    @property(cc.Label)
    id: cc.Label = null;

    @property(cc.Node)
    head_icon: cc.Node = null;

    @property(cc.Node)
    clock_btn: cc.Node = null;

    @property(cc.Node)
    touch_0: cc.Node = null;
    @property(cc.Node)
    touch_1: cc.Node = null;
    @property(cc.Node)
    touch_2: cc.Node = null;
    @property(cc.Node)
    touch_3: cc.Node = null;
    @property(cc.Node)
    touch_4: cc.Node = null;
    @property(cc.Node)
    touch_5: cc.Node = null;
    @property(cc.Node)
    touch_video: cc.Node = null;
    @property(cc.Node)
    touch_table_info: cc.Node = null;
    @property(cc.Node)
    head: cc.Node = null;

    panelZIndex = 1400;
    onLoad() {
        AppEmitter.on(consts.LOCAL_EVENT_NET_REFRESH_PHOTO, this.refreshPhoto, this);
    }
    start() {
        this.clock_btn.on(cc.Node.EventType.TOUCH_END, () => {
            //this.node.destroy()
        });
        if (PlayerMgr.getInstance().userID.length > 25) {
            this.id.string = PlayerMgr.getInstance().userID.substr(0, 24) + "...";
        } else {
            this.id.string = PlayerMgr.getInstance().userID;
        }

        if (App.currentScene == consts.MAGIC_BLACK_JACK_SCENE || App.currentScene == consts.GANE_THREE_POKER_SCENE || App.currentScene == consts.CLASSIC_BLACK_JACK_SCENE
        ) {
            this.touch_5.active = true;
        } else {
            this.touch_5.active = false;
        }


        this.touch_video.active = App.currentScene == consts.GANE_THREE_POKER_SCENE;


        if (consts.language != "tw") {
            this.touch_video.active = false;
        }

        this.touch_table_info.active = App.currentScene == consts.CLASSIC_BLACK_JACK_SCENE;
        this.refreshPhoto();
        this.touch_3.active = false;
    }
    onDestroy() {
        AppEmitter.off(consts.LOCAL_EVENT_NET_REFRESH_PHOTO, this.refreshPhoto);
    }
    refreshPhoto() {
        // Utils.setLoacalSpriteFrame(this.head_icon, "deafultPhoto/peo" + PlayerMgr.getInstance().avatar);
    }
    btnsClicked(event, data: string) {
        switch (data) {
            case "head":         //头像
                let opts = {
                    prefabName: "set_head",
                    opts: { "zIndex": this.panelZIndex }
                }
                App.loadPopalPanel(opts);
                break;
            case "personal":         //个人资料
                PlayerMgr.getInstance().getPersonData((data) => {
                    if (data) {
                        let opts0 = {
                            prefabName: "set_AboutMe",
                            opts: { "data": data, "zIndex": this.panelZIndex }
                        }
                        App.loadPopalPanel(opts0);
                    }
                });
                break;
            case "bet_record":      //下注记录
                let opts1 = {
                    prefabName: "set_myrecord",
                    opts: { "zIndex": this.panelZIndex }
                }
                App.loadPopalPanel(opts1);
                break;
            case "credit_record":      //额度记录
                let opts2 = {
                    prefabName: "set_Creditrecord",
                    opts: { "zIndex": this.panelZIndex }
                }
                App.loadPopalPanel(opts2);
                break;
            case "game_rule":    //游戏规则
                if (App.currentScene == consts.CLASSIC_JACK_ROOM_SCENE || App.currentScene == consts.CLASSIC_JACK_TABLE_SCENE || App.currentScene == consts.CLASSIC_BLACK_JACK_SCENE) {
                    App.loadGamePopul({ "prefabName": "gameHelpPop", "prefabPath": "prefab", "zIndex": this.panelZIndex });
                } else if (App.currentScene == consts.GANE_THREE_POKER_SCENE ||
                    App.currentScene == consts.THREE_POKER_ROOM_LIST_SCENE ||
                    App.currentScene == consts.THREE_POKER_TABLE_SCENE) {
                    AppEmitter.emit(consts.LOLAL_EVENT_SHOWGAMERULEVIEW)
                    this.closeNode();
                } else {
                    let opts3 = {
                        prefabName: "set_help",
                        opts: { "zIndex": this.panelZIndex }
                    }
                    App.loadPopalPanel(opts3);
                }

                break;
            case "sound_switch":    //音效开关
                if (App.currentScene == consts.CLASSIC_JACK_ROOM_SCENE || App.currentScene == consts.CLASSIC_JACK_TABLE_SCENE || App.currentScene == consts.CLASSIC_BLACK_JACK_SCENE) {
                    App.loadGamePopul({ "prefabName": "gameSetSoundPop", "prefabPath": "prefab", "zIndex": this.panelZIndex });
                } else if (App.currentScene == consts.MAGIC_JACK_ROOM_SCENE || App.currentScene == consts.MAGIC_JACK_TABLE_SCENE || App.currentScene == consts.MAGIC_BLACK_JACK_SCENE) {
                    App.loadGamePopul({ "prefabName": "magicSoundPanel", "prefabPath": "prefab", "zIndex": this.panelZIndex });
                } else {

                    let opts4 = {
                        prefabName: "set_Sound",
                        opts: { "zIndex": this.panelZIndex }
                    }
                    App.loadPopalPanel(opts4);
                }

                break;
            case "set_chip":       //筹码设置
                if (App.currentScene == consts.MAGIC_BLACK_JACK_SCENE) {
                    App.loadGamePopul({ "prefabName": "magicChipSetView", "prefabPath": "prefab", "prefabComponent": "magicBlackJackChipSettingView" });
                } else if (App.currentScene == consts.CLASSIC_BLACK_JACK_SCENE) {
                    App.loadGamePopul({ "prefabName": "chipSetView", "prefabPath": "prefab", "prefabComponent": "classicBlackJackChipSettingView" });
                } else {
                    AppEmitter.emit(consts.LOCAL_EVENT_SHOWCHIPSEIINGVIEW);
                }
                this.closeNode();
                break;
            case "set_video":
                AppEmitter.emit(consts.LOCAL_EVENT_SHOWTEACHVIDEO);
                this.closeNode();
                break;
            case "set_table_info":
                App.loadGamePopul({ "prefabName": "tableInfoPanel", "prefabPath": "prefab", "zIndex": this.panelZIndex });
                this.closeNode();
                break;
        }
    }
    // update (dt) {}
    closeNode() {
        this.node.destroy();
    }
}
