import { GAME_TYPE, RECORD_BET_TYPE } from "../common/ClientEnum";
import { ThreeCardLogic } from "../gameLogic/threePoker/threeCardLogic";
import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    juhao: cc.Label = null;

    @property(cc.Label)
    time: cc.Label = null;

    @property(cc.Label)
    game: cc.Label = null;

    @property(cc.Label)
    room: cc.Label = null;

    @property(cc.Label)
    putTotalLabel: cc.Label = null;

    @property(cc.Label)
    resultTotalLabel: cc.Label = null;

    @property(cc.Label)
    putAnteLabel: cc.Label = null;

    @property(cc.Label)
    resultAnteLabel: cc.Label = null;

    @property(cc.Label)
    putPairsLabel: cc.Label = null;

    @property(cc.Label)
    resultPairsLabel: cc.Label = null;

    @property(cc.Label)
    putPlayLabel: cc.Label = null;

    @property(cc.Label)
    resultPlayLabel: cc.Label = null;

    @property(cc.Node)
    poolNode: cc.Node = null;

    @property(cc.Label)
    poolGetLabel: cc.Label = null;

    @property(cc.Node)
    treasureNode: cc.Node = null;

    @property(cc.Label)
    treasureGetLabel: cc.Label = null;

    @property([cc.Sprite])
    zhuangColors: cc.Sprite[] = [];

    @property([cc.Label])
    zhuangValueLabels: cc.Label[] = [];

    @property([cc.Sprite])
    xianColors: cc.Sprite[] = [];

    @property([cc.Label])
    xianValueLabels: cc.Label[] = [];

    @property([cc.SpriteFrame])
    cardColors: cc.SpriteFrame[] = [];

    @property(cc.Label)
    xianLabel: cc.Label = null;

    @property(cc.Node)
    cardDetailsNode: cc.Node = null;

    @property(cc.Node)
    putSignLabel:cc.Node = null;

    @property(cc.Node)
    seatLabel:cc.Label = null;
    start() {

    }

    init(msg) {
        let threeCard = new ThreeCardLogic();
        Utils.setLabelStrForLanguage(this.xianLabel, "palyer", [msg.chairId + 1]);
        this.juhao.string = msg.roundId;
        this.time.string = Utils.timestampToTime(msg.addTime, 2);
        if (msg.gameId == GAME_TYPE.THREE_POKER) {
            Utils.setLabelStrForLanguage(this.game, "game_three_poker");
        } else if (msg.gameId == GAME_TYPE.BLACK_JACK) {
            Utils.setLabelStrForLanguage(this.game, "game_black_jack");
        }
        Utils.setLabelStrForLanguage(this.room, msg.roomId);
        this.putTotalLabel.string = Utils.formatMoneyNum(msg.betMoney);
        this.resultTotalLabel.string = Utils.formatMoneyNum(msg.payment);
        this.setTotalColor(msg.betMoney,msg.payment,this.resultTotalLabel);
        let gameInfo = JSON.parse(msg.gameInfo);
        if(gameInfo.sysCards){
            let sysCards = gameInfo.sysCards.sort(function (a, b) {
                return b % 16 - a % 16;
            });
            sysCards.forEach((card, index) => {
                this.zhuangColors[index].spriteFrame = this.cardColors[threeCard.getCardColor(card)];
                this.zhuangValueLabels[index].string = threeCard.getCardTagName(card);
                if (threeCard.getCardColor(card) == 0 || threeCard.getCardColor(card) == 2) {
                    this.zhuangValueLabels[index].node.color = new cc.Color(249, 0, 0);
                } else {
                    this.zhuangValueLabels[index].node.color = new cc.Color(255, 255, 255);
                }
            });
        }
        if(gameInfo.cards){
            let xianCards = gameInfo.cards.sort(function (a, b) {
                return b % 16 - a % 16;
            });
            xianCards.forEach((card, index) => {
                this.xianColors[index].spriteFrame = this.cardColors[threeCard.getCardColor(card)];
                this.xianValueLabels[index].string = threeCard.getCardTagName(card);
                if (threeCard.getCardColor(card) == 0 || threeCard.getCardColor(card) == 2) {
                    this.xianValueLabels[index].node.color = new cc.Color(249, 0, 0);
                } else {
                    this.xianValueLabels[index].node.color = new cc.Color(255, 255, 255);
                }
            });
        }
        
        this.putAnteLabel.string = Utils.formatMoneyNum(gameInfo.ante[0]);
        //this.resultAnteLabel.string = (gameInfo.ante[1]+gameInfo.poolMoney+gameInfo.treasureMoney));
        this.resultAnteLabel.string = Utils.formatMoneyNum(gameInfo.ante[1]);
        this.setTotalColor( gameInfo.ante[0],gameInfo.ante[1],this.resultAnteLabel);

        this.putPairsLabel.string = Utils.formatMoneyNum(gameInfo.pairPlus[0]);
        this.resultPairsLabel.string = Utils.formatMoneyNum(gameInfo.pairPlus[1]);
        this.setTotalColor( gameInfo.pairPlus[0],gameInfo.pairPlus[1],this.resultPairsLabel,);

        this.putPlayLabel.string = Utils.formatMoneyNum(gameInfo.play[0]);
        this.resultPlayLabel.string = Utils.formatMoneyNum(gameInfo.play[1]);
        this.setTotalColor(gameInfo.play[0], gameInfo.play[1],this.resultPlayLabel);

        this.poolNode.active = gameInfo.poolMoney > 0;
        this.treasureNode.active = gameInfo.treasureMoney > 0;
        this.poolGetLabel.string = Utils.formatMoneyNum(gameInfo.poolMoney);
        this.treasureGetLabel.string = Utils.formatMoneyNum(gameInfo.treasureMoney);
        if (msg.isTemp == RECORD_BET_TYPE.NORMAL_BET) {
            this.cardDetailsNode.active = true;
            this.putSignLabel.active = false;
        } else if (msg.isTemp == RECORD_BET_TYPE.ALREADY_BET) {
            this.cardDetailsNode.active = false;
            this.putSignLabel.active = true;
            Utils.setLabelStrForLanguage(this.putSignLabel, "puted_bet");
            Utils.setLabelStrForLanguage(this.seatLabel, "xian", [msg.chairId + 1]);
            this.setNoResult(); 
            //this.getValue.string = "--";
           //Utils.setLabelStrForLanguage(this.resultTotalLabel, "--");
        } else if (msg.isTemp == RECORD_BET_TYPE.NORMAL_BET) {
            this.cardDetailsNode.active = false;
            this.putSignLabel.active = true;
            Utils.setLabelStrForLanguage(this.putSignLabel, "canceled_bet");
            Utils.setLabelStrForLanguage(this.seatLabel, "xian", [msg.chairId + 1]);
            this.setNoResult();
            //Utils.setLabelStrForLanguage(this.resultTotalLabel, "--");
            //this.getValue.string = "--";
        }

    }
    setNoResult(){
        let labels = [this.resultTotalLabel,this.resultAnteLabel,this.resultPairsLabel,this.resultPlayLabel,this.treasureGetLabel,this.poolGetLabel];
        labels.forEach(element => {
            element.string = "--";
            element.node.color = new cc.Color(255, 255, 255);
        });
    }
    // setColor(label, coin) {
    //     if (coin > 0) {
    //         label.node.color = new cc.Color(80, 228, 0);
    //     } else {
    //         label.node.color = new cc.Color(249, 0, 0);
    //     }
    // }
    setTotalColor(putValue, getValue, label) {
        if (getValue > putValue) {
            label.node.color = new cc.Color(80, 228, 0);
        } else if (getValue == putValue) {
            label.node.color = new cc.Color(255, 255, 255);
        } else {
            label.node.color = new cc.Color(249, 0, 0);
        }
    }
}
