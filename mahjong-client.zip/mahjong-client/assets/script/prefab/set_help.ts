import { GAME_TYPE, platform_game_id } from "../common/ClientEnum";
import consts = require("../model/Consts");
import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    titleLabel: cc.Label = null;

    @property(cc.ScrollView)
    helpScrollView: cc.ScrollView = null;

    @property(cc.Sprite)
    helpSprite: cc.Sprite = null;

    @property(cc.Node)
    helpToggleLayout:cc.Node = null;

    @property(cc.Node)
    downLine:cc.Node = null;

    start() {
        if(consts.isAccessPlatform){
           this.helpToggleLayout.active = false;
           this.downLine.active = false; 
           let gameId = Utils.getUrlGameId()["gameid"];
           if(gameId){
             this.refreshContent(platform_game_id[gameId]);
           }
           this.helpScrollView.node.height = 650;
        }else{
            this.helpToggleLayout.active = true;
            this.downLine.active = true; 
            this.refreshContent(GAME_TYPE.BLACK_JACK);
            this.helpScrollView.node.height = 570;
        }
       
    }

    refreshContent(gameId) {
        this.helpScrollView.scrollToTop();
        if (gameId == GAME_TYPE.THREE_POKER) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_three_poker");
            Utils.setSpriteStrForLanguage(this.helpSprite, "three_help");
        } else if (gameId == GAME_TYPE.BLACK_JACK) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_black_jack");
            Utils.setSpriteStrForLanguage(this.helpSprite, "black_help");
        } else if (gameId == GAME_TYPE.CORNCUPIA) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_corncupia");
            Utils.setSpriteStrForLanguage(this.helpSprite, "jbp_help");
        } else if (gameId == GAME_TYPE.COLORFULGEMS) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_colorfulGems");
            Utils.setSpriteStrForLanguage(this.helpSprite, "jbp_help");
        } else if (gameId == GAME_TYPE.MAGIC_BLACK_JACK) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_rate_black_jack");
            Utils.setSpriteStrForLanguage(this.helpSprite, "magic21_help");
        } else if (gameId == GAME_TYPE.RUMMY) {
            Utils.setLabelStrForLanguage(this.titleLabel, "game_rummy");
            Utils.setSpriteStrForLanguage(this.helpSprite, "rummy_help");
        }
    }

    toggleClicked(event, data) {
        this.refreshContent(parseInt(data));
    }
}
