import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    juhao: cc.Label = null;

    @property(cc.Label)
    time: cc.Label = null;

    @property(cc.Label)
    game: cc.Label = null;

    @property(cc.Label)
    game0: cc.Label = null;

    @property(cc.Label)
    device: cc.Label = null;

    @property(cc.Label)
    bet: cc.Label = null;

    @property(cc.Label)
    send: cc.Label = null;
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start() {

    }
    init(msg) {
        this.juhao.string = msg.roundId;
        this.time.string = Utils.timestampToTime(msg.addTime,2);
        this.game.string = msg.gameId;
        this.game0.string = "B001";
        this.device.string = "闲" + msg.device.xian + "点   庄" + msg.device.zhuang + "点";
        this.bet.string = msg.bet;
        this.send.string = msg.send;
    }
    // update (dt) {}
}
