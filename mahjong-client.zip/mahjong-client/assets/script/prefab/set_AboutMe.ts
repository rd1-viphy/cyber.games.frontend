import App from "../../script/model/App";
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import { Utils } from "../model/Utils";
import AppEmitter from "../network/AppEmitter";
const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    clock_btn: cc.Node = null;

    @property(cc.Label)
    id: cc.Label = null;
    @property(cc.Label)
    name1: cc.Label = null;
    @property(cc.Label)
    ber_all: cc.Label = null;
    @property(cc.Label)
    blance: cc.Label = null;

    @property(cc.Label)
    Players_currency: cc.Label = null;
    @property(cc.Label)
    Bets_available_today: cc.Label = null;
    @property(cc.Label)
    Online_time: cc.Label = null;

    @property(cc.Sprite)
    photo: cc.Sprite = null;
    onLoad() {
        AppEmitter.on(consts.LOCAL_EVENT_NET_REFRESH_PHOTO, this.refreshPhoto, this);
    }
    start() {
        this.clock_btn.on(cc.Node.EventType.TOUCH_END, () => {
            this.node.destroy()
        });
    }
    init(msg) {
        if (PlayerMgr.getInstance().userID.length > 45) {
            this.id.string = "ID:" + PlayerMgr.getInstance().userID.substr(0, 44) + "...";
        } else {
            this.id.string = "ID:" + PlayerMgr.getInstance().userID;
        }
        //this.id.string = "ID:" + PlayerMgr.getInstance().userID;
        this.name1.string = msg.nickName;
        this.ber_all.string = Utils.formatMoneyNum( msg.allBetSum);
        this.blance.string = Utils.formatMoneyNum(msg.money);
        this.Players_currency.string = msg.currency;
        this.Bets_available_today.string = Utils.formatMoneyNum(msg.dayBetSum);
        //this.Online_time.string = Math.ceil(msg.onelineHours/3600).toString() ;
        this.Online_time.string =  msg.onlineHours.toString();
        Utils.setLoacalSpriteFrame(this.photo, "deafultPhoto/peo" + msg.avatar);
    }
    set_head() {
        let opts = {
            prefabName: "set_head",
            opts:{"zIndex":1400}
        }
        App.loadPopalPanel(opts);
    }
    onDestroy() {
        AppEmitter.off(consts.LOCAL_EVENT_NET_REFRESH_PHOTO, this.refreshPhoto);
    }
    refreshPhoto() {
        Utils.setLoacalSpriteFrame(this.photo, "deafultPhoto/peo" + PlayerMgr.getInstance().avatar);
    }
    // update (dt) {}
}
