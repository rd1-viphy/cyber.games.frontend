/**
 * 提示框
 */
import { Utils } from "../model/Utils";
const { ccclass, property } = cc._decorator;

@ccclass
export default class dialogBox extends cc.Component {

  @property(cc.Label)
  contentLabel: cc.Label = null;

  @property(cc.Node)
  okBtn: cc.Node = null;

  @property(cc.Node)
  confirmBtn: cc.Node = null;

  @property(cc.Node)
  concleBtn: cc.Node = null;

  @property(cc.Label)
  confirmLabel: cc.Label = null;

  @property(cc.Label)
  cancleLabel: cc.Label = null;

  confirmCallback: Function = null;
  cancleCallback: Function = null;
  okCallback: Function = null;

  init(opts: object) {
    opts = opts || {};
    if (opts["contentLabel"]) {
      if(opts["params"]){
        Utils.setLabelStrForLanguage(this.contentLabel, opts["contentLabel"],opts["params"]);
      }else{
        Utils.setLabelStrForLanguage(this.contentLabel, opts["contentLabel"]);
      }
    }
    if (opts["confirmLabel"]) {
      Utils.setLabelStrForLanguage(this.confirmLabel, opts["confirmLabel"]);
    }
    if (opts["cancleLabel"]) {
      Utils.setLabelStrForLanguage(this.cancleLabel, opts["cancleLabel"]);
    }

    this.confirmCallback = opts["confirmCallback"];
    this.cancleCallback = opts["cancleCallback"];
    this.okCallback = opts["okCallback"];
    this.okBtn.active = opts["okCallback"];
    this.confirmBtn.active = opts["confirmCallback"];
    this.concleBtn.active = opts["confirmCallback"];
    
  }

  btnClicked(event: any, data: string) {
    switch (data) {
      case "confirm":
        this.confirmCallback && this.confirmCallback();;
        break;
      case "cancle":
        this.cancleCallback && this.cancleCallback();
        break;
      case "ok":
        this.okCallback && this.okCallback();
        break;
    }
    this.node.removeFromParent();
    //this.node.destroy();
  }
}
