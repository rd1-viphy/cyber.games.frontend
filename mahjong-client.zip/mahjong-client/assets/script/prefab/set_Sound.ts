
import AudioMgr from "../../script/model/AudioMgr";

import consts = require("../model/Consts");
import { jaoziPlatfromSdk } from "../sdk/jiaoziPlatFormSdk";
const { ccclass, property } = cc._decorator;

@ccclass
export default class SetSound extends cc.Component {

    @property(cc.Node)
    clock_btn: cc.Node = null;

    @property(cc.Slider)
    soundSlider: cc.Slider = null;

    @property(cc.Slider)
    musicSlider: cc.Slider = null;

    @property(cc.ProgressBar)
    soundProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    musicProgress: cc.ProgressBar = null;

    @property(cc.Toggle)
    soundtoggle: cc.Toggle = null;

    @property(cc.Toggle)
    musictoggle: cc.Toggle = null;

    @property(cc.Label)
    versionLabel: cc.Label = null;

    start() {
        this.clock_btn.on(cc.Node.EventType.TOUCH_END, () => {
            this.node.destroy()
        });

        let musicPower = parseFloat(cc.sys.localStorage.getItem("bgmVolume"));
        let soundPower = parseFloat(cc.sys.localStorage.getItem("sfxVolume"));
        musicPower = (musicPower || musicPower == 0) ? musicPower : 1;
        soundPower = (soundPower || soundPower == 0) ? soundPower : 1;

        this.scheduleOnce(() => {
            this.musicProgress.progress = musicPower;
            this.soundProgress.progress = soundPower;
            this.musicSlider.progress = musicPower;
            this.soundSlider.progress = soundPower;
            this.soundtoggle.isChecked = (soundPower === 0) ? false : true;
            this.musictoggle.isChecked = (musicPower === 0) ? false : true;
        }, 0.1);
        if (this.versionLabel) {
            this.versionLabel.string = consts.appVersion;
        }
    }
    sliderListener(event, data) {
        switch (data) {
            case "music":
                let progress1 = event.progress;
                this.musicProgress.progress = progress1;
                this.musictoggle.isChecked = (progress1 === 0) ? false : true;
                AudioMgr.setBGMVolume(progress1);
                // if (consts.isAccessPlatform && consts.platform == PLATFORM.JIAOZI) {
                //     jaoziPlatfromSdk.setMusicEnabled(progress1 > 0);
                // }
                break;
            case "sound":
                let progress2 = event.progress;
                this.soundProgress.progress = progress2;
                this.soundtoggle.isChecked = (progress2 === 0) ? false : true;
                AudioMgr.setSFXVolume(progress2);
                // if (consts.isAccessPlatform && consts.platform == PLATFORM.JIAOZI) {
                //     jaoziPlatfromSdk.setSoundEnabled(progress2 > 0);
                // }
                break;
        }
    }

    toggleListener(event, data) {
        switch (data) {
            case "music":
                if (this.musictoggle.isChecked) {
                    //this.set
                    AudioMgr.setBGMVolume(1);
                    this.musicSlider.progress = 1;
                    this.musicProgress.progress = 1;
                    // cc.sys.localStorage.setItem("music", this.musicProgress.progress);
                    //AudioMgr.setBGMVolume(musicPower);

                } else {
                    this.musicSlider.progress = 0;
                    this.musicProgress.progress = 0;
                    AudioMgr.setBGMVolume(0);
                }
                // if (consts.isAccessPlatform && consts.platform == PLATFORM.JIAOZI) {
                //     jaoziPlatfromSdk.setMusicEnabled(this.musictoggle.isChecked);
                // }
                break;
            case "sound":
                if (this.soundtoggle.isChecked) {
                    let soundPower = 1;
                    this.soundSlider.progress = soundPower;
                    this.soundProgress.progress = soundPower;
                    AudioMgr.setSFXVolume(soundPower);
                } else {
                    this.soundSlider.progress = 0;
                    this.soundProgress.progress = 0;
                    AudioMgr.setSFXVolume(0);
                }
                // if (consts.isAccessPlatform && consts.platform == PLATFORM.JIAOZI) {
                //     jaoziPlatfromSdk.setSoundEnabled(this.soundtoggle.isChecked);
                // }
                break;
        }

        AudioMgr.playSFX("sound_jq_button");
    }

}
