import { GAME_TYPE, RECORD_BET_TYPE } from "../common/ClientEnum";
import { getPointOfCards } from "../gameLogic/blackJack/blackJackLogic";

import { Utils } from "../model/Utils";


const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    officeNum: cc.Label = null;

    @property(cc.Label)
    tiemLabel: cc.Label = null;

    @property(cc.Label)
    gameName: cc.Label = null;

    @property(cc.Label)
    roomNum: cc.Label = null;

    @property(cc.Label)
    zhuangCardTypeLabel: cc.Label = null;

    @property(cc.Label)
    xianCardTypeLabel: cc.Label = null;

    @property(cc.Label)
    xianCardTypeLabel2: cc.Label = null;

    @property(cc.Node)
    xianSpliteNode: cc.Node = null;

    @property(cc.Label)
    putValue: cc.Label = null;

    @property(cc.Label)
    getValue: cc.Label = null;

    @property(cc.Node)
    cardNode: cc.Node = null;

    @property(cc.Node)
    insuranceNode: cc.Node = null;

    @property(cc.Label)
    insuranceBet: cc.Label = null;

    @property(cc.Label)
    insuranceResult: cc.Label = null;

    @property(cc.Node)
    anteNode: cc.Node = null;

    @property(cc.Label)
    antePutValue: cc.Label = null;

    @property(cc.Label)
    anteGetValue: cc.Label = null;

    @property(cc.Node)
    ante1Node: cc.Node = null;

    @property(cc.Label)
    ante1PutValue: cc.Label = null;

    @property(cc.Label)
    ante1GetValue: cc.Label = null;

    @property(cc.Node)
    ante2Node: cc.Node = null;

    @property(cc.Label)
    ante2PutValue: cc.Label = null;

    @property(cc.Label)
    ante2GetValue: cc.Label = null;

    @property(cc.Node)
    playNode: cc.Node = null;

    @property(cc.Label)
    playPutValue: cc.Label = null;

    @property(cc.Label)
    playGetValue: cc.Label = null;

    @property(cc.Node)
    dealerNode: cc.Node = null;

    @property(cc.Label)
    delarPutValue: cc.Label = null;

    @property(cc.Label)
    delarGetValue: cc.Label = null;

    @property(cc.Label)
    xianLabel: cc.Label = null;

    @property(cc.Node)
    cardDetailNode:cc.Node = null;

    @property(cc.Node)
    putSignLabel:cc.Node = null;

    @property(cc.Node)
    seatLabel:cc.Label = null;
    start() {

    }

    init(data) {
        Utils.setLabelStrForLanguage(this.xianLabel, "palyer", [data.chairId + 1]);
        this.officeNum.string = data.roundId;
        this.tiemLabel.string = Utils.timestampToTime(data.addTime, 2);
        if (data.gameId == GAME_TYPE.THREE_POKER) {
            Utils.setLabelStrForLanguage(this.gameName, "game_three_poker");
        } else if (data.gameId == GAME_TYPE.BLACK_JACK) {
            Utils.setLabelStrForLanguage(this.gameName, "game_black_jack");
        }
        Utils.setLabelStrForLanguage(this.roomNum, "10" + data.roomId + "02");
        let gameInfo = JSON.parse(data.gameInfo);
        this.insuranceNode.active = gameInfo.IsInsurance;
        if (gameInfo.IsInsurance) {
            this.insuranceBet.string = Utils.formatMoneyNum(gameInfo.InsuranceBet);
            this.insuranceResult.string = Utils.formatMoneyNum(gameInfo.InsurancePayment);
            this.setTotalColor( gameInfo.InsuranceBet,gameInfo.InsurancePayment,this.insuranceResult);
        }
        this.putValue.string = Utils.formatMoneyNum(data.betMoney);
        this.getValue.string = Utils.formatMoneyNum(data.payment);
        this.setTotalColor(data.betMoney, data.payment, this.getValue);
        //显示庄家牌型
        this.setCardType(this.zhuangCardTypeLabel, gameInfo.DealerCards, gameInfo.DealerCardType);
        //显示闲家牌型
        if (gameInfo.isSplit) {
            this.xianSpliteNode.active = true;
            this.setCardType(this.xianCardTypeLabel, gameInfo.PlayerCards[0], gameInfo.PlayerCardType[0]);
            this.setCardType(this.xianCardTypeLabel2, gameInfo.PlayerCards[1], gameInfo.PlayerCardType[1]);
            this.xianSpliteNode.getComponent(cc.Widget).updateAlignment();
        } else {
            this.xianSpliteNode.active = false;
            this.setCardType(this.xianCardTypeLabel, gameInfo.PlayerCards, gameInfo.PlayerCardType);
        }
        //this.anteNode.active = !gameInfo.isSplit && (gameInfo.IsOne2One && gameInfo.IsSinglePK);
        if (gameInfo.isSplit) {
            this.anteNode.active = false;
        } else {
            if (gameInfo.IsOne2One) {
                if (gameInfo.IsSinglePK) {
                    this.anteNode.active = true;
                } else {
                    this.anteNode.active = false;
                }
            } else {
                this.anteNode.active = true;
            }
        }

        if (gameInfo && Object.keys(gameInfo).length > 0) {
            this.ante1Node.active = gameInfo.isSplit;
            this.ante2Node.active = gameInfo.isSplit;

            this.dealerNode.active = gameInfo.IsOne2One && !gameInfo.IsSinglePK;
            this.playNode.active = gameInfo.IsOne2One && !gameInfo.IsSinglePK;
            if(gameInfo.BetArr){
                this.antePutValue.string = gameInfo.BetArr[0] ? Utils.formatMoneyNum(gameInfo.BetArr[0]) : "0.00";
            }
            if(gameInfo.Settle){
                this.anteGetValue.string = gameInfo.Settle[0] ? Utils.formatMoneyNum(gameInfo.Settle[0]) : "0.00";
                this.setTotalColor( gameInfo.BetArr[0],gameInfo.Settle[0],this.anteGetValue);
            }
           
            if(gameInfo.BetArr){
                this.ante1PutValue.string = gameInfo.BetArr[0] ? Utils.formatMoneyNum(gameInfo.BetArr[0]) : "0.00";
            }
            
            if(gameInfo.Settle){
               this.ante1GetValue.string = gameInfo.Settle[0] ? Utils.formatMoneyNum(gameInfo.Settle[0]) : "0.00";
               this.setTotalColor( gameInfo.BetArr[0],gameInfo.Settle[0],this.ante1GetValue);
            }
            if(gameInfo.BetArr){
                this.ante2PutValue.string = gameInfo.BetArr[1] ? Utils.formatMoneyNum(gameInfo.BetArr[1]) : "0.00";
            }
            if(gameInfo.Settle){
               this.ante2GetValue.string = gameInfo.Settle[1] ? Utils.formatMoneyNum(gameInfo.Settle[1]) : "0.00";
               this.setTotalColor( gameInfo.BetArr[1],gameInfo.Settle[1],this.ante2GetValue);
            }
            this.playPutValue.string = gameInfo.PlayerBet ? Utils.formatMoneyNum(gameInfo.PlayerBet) : "0.00";
            this.playGetValue.string = gameInfo.PlayerPkMoney ? Utils.formatMoneyNum(gameInfo.PlayerPkMoney) : "0.00";
            this.setTotalColor( gameInfo.PlayerBet,gameInfo.PlayerPkMoney,this.playGetValue);

            this.delarPutValue.string = gameInfo.DealerBet ? Utils.formatMoneyNum(gameInfo.DealerBet) : "0.00";
            this.delarGetValue.string = gameInfo.DealerBet ? Utils.formatMoneyNum(gameInfo.DealerPkMoeny) : "0.00";
            this.setTotalColor(gameInfo.DealerBet, gameInfo.DealerPkMoeny,this.delarGetValue);
        }

        if(data.isTemp == RECORD_BET_TYPE.NORMAL_BET){
            this.cardDetailNode.active = true;
            this.putSignLabel.active = false;
        }else if(data.isTemp == RECORD_BET_TYPE.ALREADY_BET){
            this.cardDetailNode.active = false;
            this.putSignLabel.active = true;
            Utils.setLabelStrForLanguage(this.putSignLabel,"puted_bet");
            Utils.setLabelStrForLanguage(this.seatLabel, "xian", [data.chairId + 1]);
            this.setNoResult();
            //this.getValue.string = "--";
        }else if(data.isTemp == RECORD_BET_TYPE.NORMAL_BET){
            this.cardDetailNode.active = false;
            this.putSignLabel.active = true;
            Utils.setLabelStrForLanguage(this.putSignLabel,"canceled_bet");
            Utils.setLabelStrForLanguage(this.seatLabel, "xian", [data.chairId + 1]);
            this.setNoResult();
            //this.getValue.string = "--";
        }
    }
    setNoResult(){
        let labels = [this.getValue,this.insuranceResult,this.anteGetValue,this.ante1GetValue,this.ante2GetValue,this.playGetValue,this.delarGetValue];
        labels.forEach(element => {
            element.string = "--";
            element.node.color = new cc.Color(255, 255, 255);
        });
    }
    setCardType(label, cards, cardType) {
        if (cardType > 0) {
            let types = ["", "BJ", "five_dragron", "straight_card", "777", "persindent_bj", "orthodox_bj"];
            Utils.setLabelStrForLanguage(label, types[cardType]);
        } else {
            if (cards) {
                let point = getPointOfCards(cards);
                if (point > 21) {
                    Utils.setLabelStrForLanguage(label, "burst");
                } else {
                    Utils.setLabelStrForLanguage(label, "point", [point.toString()]);
                }
            }
        }
    }

    // setTotalColor(label, coin) {
    //     if (coin > 0) {
    //         label.node.color = new cc.Color(80, 228, 0);
    //     } else {
    //         label.node.color = new cc.Color(249, 0, 0);
    //     }
    // }

    setTotalColor(putValue, getValue, label) {
        if (getValue > putValue) {
            label.node.color = new cc.Color(80, 228, 0);
        } else if (getValue == putValue) {
            label.node.color = new cc.Color(255, 255, 255);
        } else {
            label.node.color = new cc.Color(249, 0, 0);
        }
    }
}
