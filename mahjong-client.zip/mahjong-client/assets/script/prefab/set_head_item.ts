
const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    icom: cc.Node = null;

    @property(cc.Node)
    sel: cc.Node = null;

    @property({ type: cc.SpriteFrame })
    icom_arr: cc.SpriteFrame[] = [];
    // LIFE-CYCLE CALLBACKS:
    tou_num = 0
    // onLoad () {}
    p_node
    start() {
        this.icom.on(cc.Node.EventType.TOUCH_END, () => {
            this.sel.active = true;
            this.p_node.tou_icom(this.tou_num)
        });
    }
    init(i, num, node) {
        this.icom.getComponent(cc.Sprite).spriteFrame = this.icom_arr[i]
        if (i == num) {
            this.sel.active = true;
        } else {
            this.sel.active = false;
        }
        this.tou_num = i;
        this.p_node = node;
    }

    // update (dt) {}
}
