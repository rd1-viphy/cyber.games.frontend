
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import AppEmitter from "../network/AppEmitter";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Button)
    btn_0: cc.Button = null;

    @property(cc.Button)
    btn_1: cc.Button = null;

    @property(cc.Node)
    headlayout: cc.Node = null;

    @property(cc.Prefab)
    headpre: cc.Prefab = null;

    default_num = 0
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}
    touchIndex = 0;
    start() {
        this.tou_icom(parseInt(PlayerMgr.getInstance().avatar));
    }
    touch_btn() {
        PlayerMgr.getInstance().setChangePhoto({ "avatar": this.touchIndex }, () => {
            PlayerMgr.getInstance().avatar = this.touchIndex.toString();
            AppEmitter.emit(consts.LOCAL_EVENT_NET_REFRESH_PHOTO, {});
            this.node.destroy();
        });

    }

    cancle_btn() {
        this.node.destroy();
    }
    tou_icom(n) {
        this.touchIndex = n;
        this.headlayout.removeAllChildren();
        for (let i = 0; i < 10; i++) {
            let pre = cc.instantiate(this.headpre);
            pre.getComponent("set_head_item").init(i, n, this);
            this.headlayout.addChild(pre)
        }
    }
}
