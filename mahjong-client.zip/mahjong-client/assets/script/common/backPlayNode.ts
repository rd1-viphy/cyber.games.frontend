import App from "../model/App";
import AudioMgr from "../model/AudioMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export default class backPlayNode extends cc.Component {

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;      //进度条

    @property(cc.Node)
    stopBtn: cc.Node = null;                //暂停按钮

    @property(cc.Node)
    playBtn: cc.Node = null;                //播放按钮


    @property(cc.Node)
    closeBtn: cc.Node = null;                //关闭按钮

    backView = null;
    totalTime = 0;
    clockTime = 0;
    isPlay = false;
    exitCb: Function = null
    init(backView, totalTime, exitCb: Function = null) {
        this.backView = backView;
        this.totalTime = totalTime;
        this.clockTime = 0;
        this.progressBar.progress = 0;
        this.isPlay = true;
        this.exitCb = exitCb;
        this.closeBtn.active = !App.isCustomerPlayBack;
    }

    btnClicked(event, data) {
        switch (data) {
            case "stop":
                this.playBtn.active = true;
                this.stopBtn.active = false;
                if (this.backView && this.backView.onPause) {
                    this.backView.onPause();
                }
                AudioMgr.pauseBGM();
                cc.director.pause();
                break;
            case "play":
                this.playBtn.active = false;
                this.stopBtn.active = true;
                if (this.backView && this.backView.onResume) {
                    this.backView.onResume();
                }
                AudioMgr.resumeBGM();
                cc.director.resume();
                break;
            case "again":
                this.backView.gameControl.init();
                break;
            case "fastWord":
                this.backView.gameControl.onFastWord();
                break;
            case "exit":
                cc.director.resume();
                if(this.exitCb){
                    this.exitCb();
                }
                break;    
        }
    }

    stopClock() {
        this.isPlay = false;
    }

    setProgress() {
        this.progressBar.progress = this.clockTime / this.totalTime;
    }

    update(dt) {
        if (this.isPlay) {
            if (this.clockTime >= this.totalTime) {
                this.stopClock();
            } else {
                this.clockTime += dt;
                this.setProgress();
            }
        }
    }

}
