import AudioMgr from "../model/AudioMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export default class BaseToggle extends cc.Component {

    start() {
        this.node.on("toggle", () => {
            AudioMgr.playSFX("sound_jq_button");
        })
    }
    
}
