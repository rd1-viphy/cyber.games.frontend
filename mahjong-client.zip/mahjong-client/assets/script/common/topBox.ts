import App from "../model/App";
import AudioMgr from "../model/AudioMgr";
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import RoomMgr from "../model/RoomMgr";
import { Utils } from "../model/Utils";
import NetConnect from "../network/NetConnect";



const { ccclass, property } = cc._decorator;

@ccclass
export default class topBox extends cc.Component {

    @property(cc.Label)
    moneyLabel: cc.Label = null;

    start() {
        if (App.currentScene != consts.GANE_BJACK_JACK_SCENE && App.currentScene != consts.GANE_THREE_POKER_SCENE &&
            App.currentScene != consts.GAME_CORNUCOPIA_SCENE && App.currentScene != consts.GAME_COLORFULGEMS_SCENE) {
            let currectMoney = PlayerMgr.getInstance().money * RoomMgr.getInstance().moneyScale;

            if (currectMoney > consts.MAX_COIN) {
                this.moneyLabel.string = Utils.formatNumDistance(consts.MAX_COIN);
            } else {
                if (App.currentScene == consts.GOLDSHOTING_ROOMSCENE) {
                    const num = (parseInt("" + currectMoney * 100) / 100).toFixed(2);
                    this.moneyLabel.string = Utils.formatNumDistance(num);
                } else {
                    this.moneyLabel.string = Utils.formatNumDistance(currectMoney.toFixed(2));
                }
            }

        }
    }

    /**
     * 返回按钮
     */
    backBtnClicked() {
        let backgametype = parseInt(Utils.getHttpKeysAndValus()["backgametype"]);
        if (backgametype) {



        } else {
            let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
            let roomType: number = consts.isAccessPlatform && roomTypeValue ? parseInt(roomTypeValue) : 0;
            switch (App.currentScene) {
                case consts.GANE_BJACK_JACK_SCENE:
                    cc.find("Canvas/script/GameView").getComponent("blackJackView").exit();
                    break;
                case consts.BLACK_JACK_TABLE_SCENE:
                    if (consts.isAccessPlatform) {

                    } else {
                        RoomMgr.getInstance().getBlackJackRoomList({}, (data) => {
                            RoomMgr.getInstance().roomList = data.RoomConfig;
                            App.changeScene({ "sceneName": consts.BLACK_JACK_ROOM_LIST_SCENE });
                        });
                    }
                    break;
                case consts.MAGIC_BLACK_JACK_SCENE:
                    cc.find("Canvas/script/GameView").getComponent("magicBlackJackView").exit();
                    break;

                case consts.GANE_THREE_POKER_SCENE:
                    cc.find("Canvas/script/threePokerView").getComponent("threePokerView").exit();
                    break;
                case consts.THREE_POKER_TABLE_SCENE:



                    break;
                case consts.GAME_CORNUCOPIA_SCENE:
                    cc.find("Canvas/script/cornucopiaView").getComponent("cornucopiaView").exit();
                    break;
                case consts.GAME_COLORFULGEMS_SCENE:
                    cc.find("Canvas/script/colorfulGemsView").getComponent("colorfulGemsView").exit();
                    break;
                case consts.PUSHDOTS_SCENE:
                    cc.find("Canvas/script/pushDotsScene").getComponent("pushDotsScene").exit();
                    break;
                case consts.GAME_RUMMY_SCENE:
                    cc.find("Canvas/script/rummyView").getComponent("rummyView").exit();
                    break;
                case consts.LOBBY_SCENE:
                    const username = Utils.getHttpKeysAndValus()['username'];
                    if (!username) {
                        NetConnect.disConnect();
                        App.changeScene({ "sceneName": consts.LOGIN_SCENE });
                    }
                    break;
                case consts.CLASSIC_BLACK_JACK_SCENE:
                    cc.find("Canvas/script/GameView").getComponent("classicBlackJackView").exit();
                    break;
                case consts.CLASSIC_JACK_TABLE_SCENE:




                    break;
                case consts.RUMMY_ROOM_LIST_SCENE:
                    App.changeScene({ "sceneName": consts.RUMMY_MODE_LIST_SCENE });
                    break;
                case consts.TEXAS_POKER_L_LOBBY_SCENE:
                    App.changeScene({ "sceneName": consts.LOBBY_SCENE });
                    break;
                case consts.TEXAS_POKER_L_ROOM_LIST_SCENE:
                    App.changeScene({ "sceneName": consts.TEXAS_POKER_L_LOBBY_SCENE });
                    break;
                case consts.ROWINGROOM_SCENE:
                case consts.DOGRACING_ROOMSCENE:
                case consts.GREATSAGERACING_ROOMSCENE:
                    AudioMgr.playSFX("sound_jq_button");
                    this.scheduleOnce(() => {
                        if (consts.isAccessPlatform) {
                            App.exitGame();
                        } else {
                            App.changeScene({ "sceneName": consts.LOBBY_SCENE });
                        }
                    }, 0.3);
                    break;
                case consts.CLASSIC_JACK_ROOM_SCENE:
                case consts.MAGIC_JACK_ROOM_SCENE:
                case consts.BLACK_JACK_ROOM_LIST_SCENE:
                case consts.THREE_POKER_ROOM_LIST_SCENE:
                case consts.CORNCUPIA_ROOM_LIST_SCENE:
                case consts.COLORFULGEMS_ROOM_LIST_SCENE:
                case consts.HORSE_RACING_ROOM_LIST_SCENE:
                case consts.PUSHDOTS_ROOM_LIST_SCENE:
                case consts.RUMMY_MODE_LIST_SCENE:
                case consts.SUPERCOW_ROOMSCENE:
                case consts.MONKEYRACING_RoomScene:
                case consts.CLASSICSHOT_ROOMSCENE:
                case consts.JOKERSHOTING_ROOMSCENE:
                case consts.GOLDSHOTING_ROOMSCENE:
                case consts.ROULETTE_ROOM_LIST_SCENE:

                    if (consts.isAccessPlatform) {

                        App.exitGame();

                    } else {
                        App.changeScene({ "sceneName": consts.LOBBY_SCENE });
                    }
                    break;


            }
        }
    }

    /**
     * 菜单按钮
     */
    menuClicked() {
        let opts1 = {
            prefabName: "setting",
            opts: { "zIndex": 1350 }
        }
        App.loadPopalPanel(opts1);
    }

}
