import consts = require("../model/Consts");

const { ccclass, property } = cc._decorator;

@ccclass
export default class SkeAnimSkinSetting extends cc.Component {

    protected onLoad(): void {
    }

    start() {
        let ske = this.node.getComponent(sp.Skeleton);
        let str = consts.language;
        if (str == "zh") {
            str = "cn";
        }
        ske.setSkin(str);
        ske.defaultSkin = str;
    }

    // update (dt) {}
}
