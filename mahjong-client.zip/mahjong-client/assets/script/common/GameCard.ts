import { Utils } from "../../script/model/Utils";
import AudioMgr from "../model/AudioMgr";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameCard extends cc.Component {

    // @property(cc.SpriteAtlas)
    // cardSpriteAtlas: cc.SpriteAtlas = null; //牌的图集

    @property(cc.Sprite)                    //牌
    card: cc.Sprite = null;

    scaleTime: number = 0.3;                 //翻牌时间
    moveTime: number = 0.5;                  //移动时间

    /** 動作 */
    myTween: cc.Tween;

    /** 牌號 */
    protected cardNum: number = 0;

    /**
     * 设置牌
     * @param num 
     */
    setCardNum(num: number = 0) {
        this.cardNum = num;
        let path = "poker/" + num.toString();
        Utils.setLoacalSpriteFrame(this.card, path);
    }

    /** 取得牌號 */
    getCardNum(): number {
        return this.cardNum;
    }

    init() {

    }

    setCardSize(type) {
        if (type == 1) {
            this.node.width = 52;
            this.node.height = 60;
        } else if (type == 2) {
            this.node.width = 41.6;
            this.node.height = 48;
        }
    }

    /**
     * 发牌以及牌的显示动作
     * @param num       牌的数字
     * @param position  牌的位置
     * @param aniType   发牌的动画类型  1.移动加翻转  2.移动   3.翻转  4.亮牌
     * @param cb        回调
     */
    sendCard(num: number, endPosition: cc.Vec3, aniType: number, cb: Function = null) {
        let playDeal = cc.tween(this.node).call(() => { AudioMgr.playSFX("sound_deal"); });
        let playFlip = cc.tween(this.node).call(() => { AudioMgr.playSFX("sound_flip"); });
        let moveAni = cc.tween(this.node).parallel(cc.tween(this.node).to(this.moveTime, { position: endPosition }), playDeal);
        let setNum = cc.tween(this.node).call(() => {
            this.setCardNum(num);
        });
        let scale1 = cc.tween(this.node).parallel(cc.tween(this.node).to(this.scaleTime, { scaleX: 0.1 }), playFlip);
        //let scale2 = cc.tween(this.node).parallel(cc.tween(this.node).to(this.scaleTime, { scaleX: 1 }),playFlip);
        let scale2 = cc.tween(this.node).to(this.scaleTime, { scaleX: 1 });
        let callback = cc.tween(this.node).call(() => {
            if (cb) {
                cb();
            }
        });
        if (this.myTween) {
            this.myTween.stop();
        }
        switch (aniType) {
            case 1:
                this.myTween = cc.tween(this.node)
                    .then(moveAni).delay(0.3).then(scale1).then(setNum).then(scale2).then(callback)
                break
            case 2:
                this.myTween = cc.tween(this.node)
                    .then(moveAni).then(callback)
                break
            case 3:
                this.myTween = cc.tween(this.node)
                    .then(scale1).then(setNum).then(scale2).then(callback)
                break
            case 4:
                this.myTween = cc.tween(this.node)
                    .then(setNum).then(callback)
                break;
        }
        this.myTween.start();
    }

    takeBackCardAni(pos, cb) {
        let playDeal = cc.tween(this.node).call(() => { AudioMgr.playSFX("sound_deal"); });
        let playFlip = cc.tween(this.node).call(() => { AudioMgr.playSFX("sound_flip"); });
        let moveAni = cc.tween(this.node).parallel(cc.tween(this.node).to(this.moveTime, { position: pos, scale: 0.5 }), playDeal);
        let scale1 = cc.tween(this.node).parallel(cc.tween(this.node).to(this.scaleTime, { scaleX: 0.1 }), playFlip);
        //let scale2 = cc.tween(this.node).parallel(cc.tween(this.node).to(this.scaleTime, { scaleX: 1 }),playFlip);
        let scale2 = cc.tween(this.node).to(this.scaleTime, { scaleX: 1 });
        let setNum = cc.tween(this.node).call(() => {
            this.setCardNum(0);
        });
        if (this.node["num"] > 0) {
            cc.tween(this.node).then(scale1).then(setNum).then(scale2).then(moveAni).call(() => {
                this.node.active = false;
                cb();
            }).start();
        } else {
            cc.tween(this.node).delay(this.scaleTime * 2).then(moveAni).call(() => {
                this.node.active = false;
                cb();
            }).start();
        }
    }

    sortCardAni(num){
       let currentPosX = this.node.getPosition().x;
       cc.tween(this.node).to(0.3,{"x":0}).delay(0.2).call(() => {
         this.setCardNum(num);
       }).to(0.3,{"x":currentPosX}).start();
    }
}
