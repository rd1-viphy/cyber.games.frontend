
import App from "../model/App";
import { platform } from "../model/Consts";
import consts = require("../model/Consts");
import { Utils } from "../model/Utils";

import { bundle_name, GameLoadImgLength, laozi_GameLoadImgLength, platform_game_name } from "./ClientEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class loadNode extends cc.Component {

    @property(cc.ProgressBar)
    loadProgress: cc.ProgressBar = null;

    @property(cc.Node)
    blackJackBg: cc.Node = null;

    @property(cc.Node)
    colorfulGemsBg: cc.Node = null;

    @property(cc.Node)
    classicBlackJackBg: cc.Node = null;

    @property(cc.Node)
    classicLogo: cc.Node = null;

    // @property(cc.Node)
    // barAni: cc.Node = null;

    @property(cc.ProgressBar)
    classicBlackJackLoadProgress: cc.ProgressBar = null;

    @property(cc.Label)
    percentLabel: cc.Label = null;

    @property(cc.Node)
    signBg: cc.Node = null;

    @property(cc.SpriteFrame)
    magicAceBgFrame_zh: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    magicAceBgFrame_en: cc.SpriteFrame = null;

    @property(cc.ProgressBar)
    signProgress: cc.ProgressBar = null;

    @property(cc.Node)
    logoNode: cc.Node = null;

    protected gameLoading = {
        "richer3": 0,
        "SanShui": 0,
        "Mahjong": 0,
        "PushDots": 0,
        "TexasPoker": 0,
        "horseracing": 0,
        "rowing": 0,
        "superCow": 0,
        "monkeyracing": 0,
        "casinoholdem": 0,
        "greatsageracing": 0,
        "texasholdem": 0,
        "sicbo": 0,
        "jokershoting": 0,
        "goldshoting": 0,
        "classicBlackJack": 0,
        "magicBlackJack": 0,
        "racebull": 0,
        "battlehall": 0,
        "eroulette": 0,
        "racedots": 0,
        "mahjongfortwo": 0
    }

    onLoad() {
        if (consts.isAccessPlatform) {
            //设置横竖屏对应内容
            this.setOrientationContent();
            this.logoNode.active = false;
            let gameId = Utils.getUrlGameId()["gameid"];
            if (gameId) {
                this.blackJackBg.active = gameId == "golden21";
                this.colorfulGemsBg.active = gameId == "gof";
                this.classicBlackJackBg.active = gameId == platform_game_name.classicBlackJack;
                let isLoading = gameId == "richer3" || gameId == "treasure" || gameId == "horseracing" || gameId == "magic21"
                    || gameId == "caspasusun_table" || gameId == platform_game_name.Mahjong || gameId == platform_game_name.PushDots
                    || gameId == platform_game_name.SixCardPoekr || gameId == platform_game_name.rowing || gameId == "superbull"
                    || gameId == platform_game_name.casinoholdem || gameId == platform_game_name.monkeyracing || gameId == platform_game_name.greatsageracing
                    || gameId == platform_game_name.texasholdem || gameId == platform_game_name.sicbo || gameId == platform_game_name.TexasPoker
                    || gameId == platform_game_name.classicshot || gameId == platform_game_name.jokershoting || gameId == platform_game_name.goldshoting
                    || gameId == platform_game_name.classicBlackJack || gameId == platform_game_name.pvplobby || gameId == platform_game_name.racebull
                    || gameId == platform_game_name.racedots || gameId == platform_game_name.texasgold || gameId == platform_game_name.eroulette
                    || gameId == platform_game_name.mahjongfortwo;

                this.loadProgress.node.active = !isLoading;
                this.signBg.active = isLoading;
                this.signProgress.node.active = isLoading;
                // if (gameId == "magic21") {
                //     if (consts.platform == PLATFORM.WANGPAI || consts.platform == PLATFORM.ZHIZUN || consts.platform == PLATFORM.A777) {
                //         if (consts.language == "en") {
                //             this.signBg.getComponent(cc.Sprite).spriteFrame = this.magicAceBgFrame_en;
                //         } else {
                //             this.signBg.getComponent(cc.Sprite).spriteFrame = this.magicAceBgFrame_zh;
                //         }

                //         this.loadProgress.node.active = true;
                //         this.signProgress.node.active = false;
                //     }
                // } else if (gameId == "classic21") {
                //     if(consts.platform != PLATFORM.LAOZI && consts.platform != PLATFORM.MY_OASIS && consts.platform != PLATFORM.JIAOZI){
                //         this.loadProgress.node.active = false;
                //         this.signBg.active = false;
                //         this.signProgress.node.active = false;
                //         if (consts.platform == PLATFORM.ZHIZUN || consts.platform == PLATFORM.A777) {
                //             Utils.setSpriteStrForLanguage(this.classicLogo, "classic_zhizun");
                //         } else {
                //             Utils.setSpriteStrForLanguage(this.classicLogo, "classic_ace");
                //         }
                //     }
                // } 
            }
        } else {
            this.logoNode.active = true;
        }
    }

    /**
     * 加载资源
     * @param type  
     */
    init(name, cb) {
        let totalProgress = 1;
        if (name == "lobby") {
            let dirNames = ["i18n/spine/" + consts.language, "i18n/sprite/" + consts.language, "i18n/sound/common", "i18n/sound/" + (consts.language == "tw" ? "zh" : consts.language), "poker", "deafultPhoto", "prefab"];
            let sceneNames = [consts.LOGIN_SCENE, consts.LOBBY_SCENE];
            totalProgress = dirNames.length + sceneNames.length;
            this.preLoadDir(cc.resources, dirNames, sceneNames, totalProgress, 0, cb);
        } else {
            let dirCommonNames = ["i18n/spine/" + consts.language, "i18n/sprite/" + consts.language, "i18n/sound/common", "i18n/sound/" + (consts.language == "tw" ? "zh" : consts.language), "poker", "prefab", "deafultPhoto"];
            let dirNames = ["i18n/spine/" + consts.language, "i18n/sprite/" + consts.language, "i18n/sound/common", "i18n/sound/" + (consts.language == "tw" ? "zh" : consts.language), "prefab"];

            let sceneNames = null;
            if (name == "cornucopia" || name == "colorfulGems" || name == "sixCardPoker" || name == "pushDots" || name == "superCow"
                || name == "sanShui" || name == "rummy" || name == "mahjong" || name == "niuNiu" || name == "casinoholdem" ||
                name == "texasholdem" || name == "sicbo" || name == "monkeyRacing" || name == "greatsageracing" || name == "luckybingo"
                || name == "classicshot" || name == "jokershoting" || name == "goldshoting" || name == "roulette") {
                sceneNames = [name + "RoomScene", name + "Scene"];
            } else if (name == "horseRacing" || name == "rowing" || name == "dogracing") {

                dirNames = []

                sceneNames = [name + "Scene"];
            } else if (name == "doublingFaceOff") {
                sceneNames = [name + "PlayBackScene"];
            } else if (name == "battlehall" || name == "racebull" || name == "racedots" || name == "mahjongfortwo") {
                sceneNames = [name + "Scene"];
            } else {
                sceneNames = [name + "RoomScene", name + "TableScene", name + "Scene"];
                if (name == "texasPokerLandscape") {
                    let str = "texasPokerL";
                    sceneNames = [str + "LobbyScene", str + "Scene", str + "ClubScene"];
                } else if (name == "texasgold") {
                    let str = "texasgold";
                    sceneNames = [str + "LobbyScene", str + "Scene", str + "RoomScene"];
                }
            }
            totalProgress = dirCommonNames.length + dirNames.length + sceneNames.length;

            cc.assetManager.loadBundle(name + "Bundle", (completedCount, totalCount) => {
                //this.refreshProgress(0, completedCount, totalCount, totalProgress);
            }, (err, bundle) => {
                if (err) {
                    cc.error("load bundle  fail");
                    return;
                }
                App.gameBundle = bundle;
                if (App.getBundleVersion(name)) {
                    consts.appVersion = App.getBundleVersion(name);
                }
                if (consts.isAccessPlatform && this.signBg.active) {
                    this.setGameBgSprite(name, () => {
                        this.preLoadDir(cc.resources, dirCommonNames, [], totalProgress, 0, () => {
                            this.preLoadDir(App.gameBundle, dirNames, sceneNames, totalProgress, dirCommonNames.length, cb);
                        });
                    });
                } else {
                    this.preLoadDir(cc.resources, dirCommonNames, [], totalProgress, 0, () => {

                        this.preLoadDir(App.gameBundle, dirNames, sceneNames, totalProgress, dirCommonNames.length, cb);
                    });
                }

            })
        }
    }

    initHasBonus(name, cb) {
        let totalProgress = 1;
        let dirCommonNames = ["i18n/spine/" + consts.language, "i18n/sprite/" + consts.language, "i18n/sound/common", "i18n/sound/" + (consts.language == "tw" ? "zh" : consts.language), "poker", "prefab", "deafultPhoto"];
        let dirNames = ["i18n/spine/" + consts.language, "i18n/sprite/" + consts.language, "i18n/sound/common", "i18n/sound/" + (consts.language == "tw" ? "zh" : consts.language), "prefab"];
        let dirBonusNames = ["i18n/sprite/" + consts.language, "prefab", "i18n/font/" + consts.language];

        let sceneNames = null;
        if (name == "pushDots" || name == "superCow") {
            sceneNames = [name + "RoomScene", name + "Scene"];
        } else {
            sceneNames = [name + "RoomScene", name + "TableScene", name + "Scene"];
        }

        totalProgress = dirCommonNames.length + dirNames.length + sceneNames.length + dirBonusNames.length;

        cc.assetManager.loadBundle(name + "Bundle", (err, bundle) => {
            if (err) {
                cc.error("load bundle  fail");
                return;
            }
            App.gameBundle = bundle;
            if (App.getBundleVersion(name)) {
                consts.appVersion = App.getBundleVersion(name);
            }
            if (consts.isAccessPlatform && this.signBg.active) {
                this.setGameBgSprite(name, () => {
                    this.preLoadDir(cc.resources, dirCommonNames, [], totalProgress, 0, () => {
                        this.preLoadDir(App.gameBundle, dirNames, sceneNames, totalProgress, dirCommonNames.length, () => {
                            this.preLoadDir(App.gameBundle, dirNames, sceneNames, totalProgress, dirCommonNames.length, () => {
                                cc.assetManager.loadBundle("doublingFaceOffBundle", (err, bundle) => {
                                    if (err) {
                                        cc.error("load bundle  fail");
                                        return;
                                    }


                                    this.preLoadDir(bundle, dirBonusNames, null, totalProgress, (dirCommonNames.length + dirNames.length + sceneNames.length), cb)
                                })
                            });
                        });
                    });
                });
            } else {
                this.preLoadDir(cc.resources, dirCommonNames, [], totalProgress, 0, () => {
                    this.preLoadDir(App.gameBundle, dirNames, sceneNames, totalProgress, dirCommonNames.length, () => {
                        cc.assetManager.loadBundle("doublingFaceOffBundle", (err, bundle) => {
                            if (err) {
                                cc.error("load bundle  fail");
                                return;
                            }


                            this.preLoadDir(bundle, dirBonusNames, null, totalProgress, (dirCommonNames.length + dirNames.length + sceneNames.length), cb)
                        })
                    });
                });
            }
        })
    }

    /**
     * 预加载资源
     * @param bundle 
     */
    preLoadDir(bundle, dirNames, sceneNames, totalProgress, startIndex, cb) {
        let dirIndex = 0;
        let preload = () => {
            bundle.loadDir(dirNames[dirIndex], (completedCount, totalCount, item) => {
                this.refreshProgress(dirIndex + startIndex, completedCount, totalCount, totalProgress);
            }, (err, assts) => {
                if (err) {
                    cc.error("preload err");
                } else {
                    assts.forEach(element => {
                        if (element && element._name) {
                            if (element instanceof cc.SpriteFrame) {
                                if (App.spriteCache.get(element["_name"])) {
                                    App.spriteCache.delete(element["_name"]);
                                }
                                App.spriteCache.set(element["_name"], element);
                            } else if (element instanceof sp.SkeletonData) {
                                if (App.spineCache.get(element["_name"])) {
                                    App.spineCache.delete(element["_name"]);
                                }
                                App.spineCache.set(element["_name"], element);
                            } else if (element instanceof cc.AudioClip) {
                                if (App.audioCache.get(element["_name"])) {
                                    App.audioCache.delete(element["_name"]);
                                }
                                App.audioCache.set(element["_name"], element);
                            } else if (element instanceof cc.Font) {
                                if (App.fontCache.get(element["_name"])) {
                                    App.fontCache.delete(element["_name"]);
                                }
                                App.fontCache.set(element["_name"], element);
                            }
                        }
                    });
                }
                dirIndex++;
                if (dirIndex < dirNames.length) {
                    preload();
                } else {
                    if (sceneNames && sceneNames.length > 0) {
                        this.preloadScenes(bundle, sceneNames, totalProgress, dirNames.length + startIndex, cb);
                    } else {
                        cb();
                        //bundle.loadDir("prefab");
                    }
                }
            });
        }
        preload();
    }

    /**
     * 预加载场景
     * @param sceneName 
     * @param cb 
     */
    preloadScenes(bundle, sceneNames: string, totalProgress: number, startIndex: number, cb) {
        let dirIndex = 0;
        let preload = () => {
            bundle.loadScene("scene/" + sceneNames[dirIndex], (completedCount, totalCount, item) => {
                this.refreshProgress(dirIndex + startIndex, completedCount, totalCount, totalProgress);
            }, (err) => {
                if (err) {
                    console.error("preload err");
                }
                dirIndex++;
                if (dirIndex < sceneNames.length) {
                    preload();
                } else {

                    cb();
                    //bundle.loadDir("prefab");
                }
            });
        }
        preload();
    }
    /**
     * 刷新进度
     * @param count 
     * @param completedCount 
     * @param totalCount 
     * @param totalProgress 
     */
    refreshProgress(count, completedCount, totalCount, totalProgress) {
        if (this.loadProgress.node.active) {
            this.loadProgress.progress = (count + completedCount / totalCount) / totalProgress;
        }
        if (this.signProgress.node.active) {
            this.signProgress.progress = (count + completedCount / totalCount) / totalProgress;
        }
        if (this.classicBlackJackLoadProgress.node.active) {
            this.classicBlackJackLoadProgress.progress = (count + completedCount / totalCount) / totalProgress;
            this.percentLabel.string = Math.floor(this.classicBlackJackLoadProgress.progress * 100) + "%";
        }
    }
    /**
     * 设置加载背景
     * @param gameName 
     * @param cb 
     */
    setGameBgSprite(gameName, cb) {
        let gameLoadLength: number = 0;

        gameLoadLength = parseInt(laozi_GameLoadImgLength[gameName]);


        if (gameName == platform_game_name.sicbo) {
            this.signBg.getComponent(cc.Sprite).type = cc.Sprite.Type.SIMPLE;
            this.signBg.getComponent(cc.Sprite).sizeMode = cc.Sprite.SizeMode.TRIMMED;
            this.signProgress.node.y = -637;
            this.signProgress.node.width = 720;
            this.signProgress.totalLength = 720;
            this.signProgress.barSprite.node.x = -360;
        }
        if (gameLoadLength > 0) {
            let loadingIdx: number = 0;
            if ((gameName == bundle_name.PushDots || gameName == bundle_name.rowing || gameName == bundle_name.richer3 ||
                gameName == bundle_name.eroulette || gameName == bundle_name.classicBlackJack || gameName == bundle_name.goldshoting || gameName == bundle_name.superCow ||
                gameName == bundle_name.texasholdem || gameName == bundle_name.magicBlackJack || gameName == bundle_name.horseracing)) {

                const loadingData = JSON.parse(cc.sys.localStorage.getItem("loadingData"));
                if (!!loadingData) {
                    let idx = loadingData[gameName];
                    if (idx) {
                        loadingIdx = idx % gameLoadLength;
                    }
                }
                this.gameLoading[gameName] = loadingIdx + 1;
                cc.sys.localStorage.setItem("loadingData", JSON.stringify(this.gameLoading));
            } else {
                loadingIdx = Math.ceil(Math.random() * gameLoadLength);
            }

            let loadPath = "loadBg/" + consts.language + "/loading" + loadingIdx;

            App.gameBundle.load(loadPath, cc.SpriteFrame, (err, texture: cc.SpriteFrame) => {
                if (err) {
                    console.error("load local spriteFrame err ", loadPath);
                    cb && cb();
                    return;
                }
                this.signBg.getComponent(cc.Sprite).spriteFrame = texture;
                cb && cb();
            });
        }
    }
    /**
     * 设置横竖屏方向的内容显示
     */
    setOrientationContent() {
        if (App.isPortraitOrientation()) {
            //加载进度条
            this.signProgress.node.y = -637;
            this.signProgress.node.width = 720;
            this.signProgress.totalLength = 720;
            this.signProgress.barSprite.node.x = -360;
        }
    }
}
