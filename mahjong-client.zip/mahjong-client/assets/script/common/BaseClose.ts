

const {ccclass, property} = cc._decorator;

@ccclass
export default class BaseClose extends cc.Component {
    start () {
       this.node.on(cc.Node.EventType.TOUCH_END,()=>{
           this.node.parent.parent.destroy();
       });
    }
}
