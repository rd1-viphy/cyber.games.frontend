/**
 * 游戏类型
 */
export enum GAME_TYPE {
    THREE_POKER = 1,
    MAGIC_BLACK_JACK = 2,
    BLACK_JACK = 3,
    CLASSIC21 = 4,
    CORNCUPIA = 5,
    COLORFULGEMS = 6,
    RUMMY = 7,
    HORSE_RACING = 10,
    PUSHDOTS = 11
}

/**
 * 玩家下注类型
 */
export enum PUT_BET_TYPE {
    NO_MOVE = 1,         //显示筹码在区域
    PERSON_TO_AREA = 2,  //筹码从玩家到区域
    AREA_TO_MASTER = 3,  //筹码从区域到庄家
    MASTER_TO_AREA = 4,  //筹码从庄家到区域
    AREA_TO_PERSON = 5   //筹码从区域到玩家
}

export enum RECORD_BET_TYPE {
    NORMAL_BET,          //正常下注
    ALREADY_BET,         //已下注
    CANCLE_BET           //取消下注
}

/**
 * 游戏gameid
 */
export enum platform_game_id {
    richer3 = 1,
    magic21 = 2,
    golden21 = 3,
    classic21 = 4,
    treasure = 5,
    gof = 6,
    rummy = 7,
    texas_table = 9,
    horseracing = 10,
    pushdots = 11,
    sixCardPoker = 12,
    caspasusun_table = 13,
    mahjong_table = 15,
    boatracing = 16,
    superbull = 17,
    bull = 18,
    monkeyracing = 19,
    casinoholdem = 20,
    texasholdem = 21,
    sicbo = 22,
    greatsageracing = 23,
    dogracing = 24,
    classicshoting = 25,
    luckybingo = 26,
    jokershoting = 27,
    goldshoting = 28,
    doublingfaceoff = 29,
    racebull = 30,
    pvplobby = 10000,
    eroulette = 32,
    racedots = 31,
    mahjongfortwo = 34,
    texasgold = 35
}

export enum platform_game_name {
    richer3 = "richer3",
    SanShui = "caspasusun_table",
    Mahjong = "mahjong_table",
    PushDots = "pushdots",
    TexasPoker = "texas_table",
    SixCardPoekr = "six_poker",
    horseracing = "horseracing",
    rowing = "boatracing",
    superCow = "superbull",
    niuNiu = "bull",
    monkeyracing = "monkeyracing",
    casinoholdem = "casinoholdem",
    dogracing = "dogracing",
    greatsageracing = "greatsageracing",
    texasholdem = "texasholdem",
    sicbo = "sicbo",
    classicshot = "classicshoting",
    luckybingo = "luckybingo",
    jokershoting = "jokershoting",
    goldshoting = "goldshoting",
    classicBlackJack = "classic21",
    magicBlackJack = "magic21",
    doublingFaceOff = "doublingfaceoff",
    racebull = "racebull",
    pvplobby = "pvplobby",
    eroulette = "eroulette",
    racedots = "racedots",
    texasgold = "texasgold",
    mahjongfortwo = "mahjongfortwo",
    rummy = "rummy",
    treasure = "treasure",
    gof = "gof"
}

export enum bundle_name {
    richer3 = "threePoker",
    SanShui = "caspasusun_table",
    Mahjong = "mahjong_table",
    PushDots = "pushDots",
    TexasPoker = "texas_table",
    SixCardPoekr = "six_poker",
    horseracing = "horseRacing",
    rowing = "rowing",
    superCow = "superCow",
    niuNiu = "bull",
    monkeyracing = "monkeyracing",
    casinoholdem = "casinoholdem",
    dogracing = "dogracing",
    greatsageracing = "greatsageracing",
    texasholdem = "texasholdem",
    sicbo = "sicbo",
    classicshot = "classicshoting",
    luckybingo = "luckybingo",
    jokershoting = "jokershoting",
    goldshoting = "goldshoting",
    classicBlackJack = "classicBlackJack",
    magicBlackJack = "magicBlackJack",
    doublingFaceOff = "doublingFaceOff",
    racebull = "racebull",
    battlehall = "battlehall",
    eroulette = "roulette",
    racedots = "racedots",
    texasgold = "texasgold",
    mahjongfortwo = "mahjongfortwo"
}


/**
 * 发牌类型
 * 发牌的动画类型  1.移动加翻转  2.移动   3.翻转  4.亮牌
 */
export enum SEND_CARD {
    MOVE_AND_FLIP = 1,
    MOVE = 2,
    FLIP = 3,
    NO_MOVE = 4
}

/**
 * 跳转场景类型枚举
 */
export enum gameSceneType {
    /** 平台大厅 */
    platform = 1,
    /** 选厅界面 */
    roomScene = 2,
    /** 选桌界面 */
    tableScene = 3,
    /** 棋牌大厅 */
    pvplobby = 4,
    /** 游戏界面 */
    gameScene = 5
}

/**
 * 游戏维护
 */
export enum GAME_PRESERVE {
    NORMAL = 0,          //游戏正常
    LIMIT = 1,           //表示游戏进入受限状态 玩家部分功能不可操作（对房卡类游戏的表现为创房按钮与代开按钮置灰）
    ENTER_PRESERVE = 2,  //表示游戏进入彻底维护（暂不用处理 一般会发6）
    NOTICE_1 = 3,        //向玩家发出游戏维护的通知 1（仅通知）
    NOTICE_2 = 4,        //向玩家发出游戏维护的通知 2（仅通知）
    EXIT_GAME = 5,       //将收到该消息的玩家强制踢回平台大厅
    PRESERVE_DIALOG = 6  //向收到该消息的玩家弹出游戏维护面板
}

export enum PermissionCode {
    /** 相机 */
    Camera = 0,
    /** 相册 */
    PhotoLibrary = 1,
    /** 麦克风 */
    MicroPhone = 2,
    /** sd卡读写(android) */
    Storage = 4,
}

export enum laozi_GameLoadImgLength {
    threePoker = 4,
    magicBlackJack = 4,
    colorfulGems = 0,
    cornucopia = 3,
    horseRacing = 4,
    mahjong = 4,
    sanShui = 7,
    sixCardPoker = 7,
    pushDots = 4,
    rowing = 4,
    superCow = 4,
    casinoholdem = 3,
    monkeyRacing = 3,
    greatsageracing = 3,
    texasholdem = 4,
    sicbo = 3,
    texasPokerLandscape = 4,
    classicshot = 3,
    jokershoting = 3,
    goldshoting = 4,
    classicBlackJack = 4,
    battlehall = 2,
    racebull = 3,
    racedots = 3,
    roulette = 3,
    mahjongfortwo = 3
}

export enum GameLoadImgLength {
    threePoker = 3,
    magicBlackJack = 3,
    colorfulGems = 0,
    cornucopia = 3,
    horseRacing = 3,
    mahjong = 4,
    sanShui = 7,
    sixCardPoker = 7,
    pushDots = 3,
    rowing = 3,
    superCow = 3,
    casinoholdem = 3,
    monkeyRacing = 3,
    greatsageracing = 3,
    texasholdem = 3,
    sicbo = 3,
    texasPokerLandscape = 4,
    classicshot = 3,
    jokershoting = 3,
    goldshoting = 3,
    classicBlackJack = 3,
    battlehall = 3,
    racebull = 3,
    racedots = 3,
    roulette = 2,
    mahjongfortwo = 3
}

/**
 * 屏幕方向
 */
export enum GameViewOrientation {
    /*横屏 */
    Landscape = 1,
    /**竖屏 */
    Portrait,
}