
import consts = require("../model/Consts");


const { ccclass, property } = cc._decorator;

@ccclass
export default class VersionLabel extends cc.Component {

    @property(cc.Label)
    label: cc.Label = null;

    private touchCount: number = 0;

    private touchMax: number = 2;

    protected onLoad(): void {
        this.node.on(cc.Node.EventType.TOUCH_END, this.versionTouch, this);
    }

    start() {
        this.label.string = consts.appVersion;
        this.node.opacity = 0;
        // if (consts.platform == PLATFORM.LAOZI) {
        //     this.node.opacity = 0;
        // } else {
        //     this.node.opacity = 255;
        // }
    }

    versionTouch() {
        //if (consts.platform != PLATFORM.LAOZI) { return };
        if (this.node.opacity == 0) {
            if (this.touchCount < this.touchMax) {
                this.touchCount++;
                this.unscheduleAllCallbacks();
                this.scheduleOnce(() => {
                    this.touchCount = 0;
                }, 5);
            } else {
                this.touchCount = 0;
                this.node.opacity = 255;
                this.unscheduleAllCallbacks();
                this.scheduleOnce(() => {
                    this.node.opacity = 0;
                }, 5);
            }
        }
    }

}
