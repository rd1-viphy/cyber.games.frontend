
import AudioMgr from "../model/AudioMgr";
import consts = require("../model/Consts");
import AppEmitter from "../network/AppEmitter";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    clockLabel: cc.Label = null;                         //倒计时数字

    @property({ visible: false })
    get clockTime() {
        return parseInt(this.clockLabel.string);
    }
    set clockTime(time: number) {
        this.clockLabel.string = time.toString() + " ";
    }

    @property(cc.Sprite)
    clockSprie: cc.Sprite = null;

    @property({ visible: false })

    get clockProgress() {
        return this.clockSprie.fillRange;
    }

    set clockProgress(progress: number) {
        this.clockSprie.fillRange = progress;
    }

    clockAni = null;
    state = 0;
    totalTime = 0;
    clockColor = new cc.Color(0, 255, 0);
    isSelf = false;
    private timeoutListener: () => void;

    setTimeoutListener(cb: () => void) {
        this.timeoutListener = cb;
    }
    /**
     * 开始倒计时
     * @param time 
     */
    startClock(time,state = 0,totalTime = time-1,isSelf = false) {
        this.isSelf = isSelf;
        if(totalTime>0){
            this.totalTime = totalTime;
            this.state = state;
            if (this.clockAni) {
                this.clockAni.stop();
            }
            this.clockLabel.node.scale = 1;
            this.clockTime = time;
            this.clockProgress = (time-1)/totalTime;
            this.clockSprie.node.color = new cc.Color(0, 255, 0);
            this.clockColor = new cc.Color(0, 255, 0);
            this.schedule(this.gameClock, 1);
            this.schedule(this.changeProgressBar, totalTime / 200);
        }
    }
    startProgress(time,progress,totalTime,color,isSelf = false){
        this.isSelf = isSelf;
        this.totalTime = totalTime;
        if (this.clockAni) {
            this.clockAni.stop();
        }
        this.clockLabel.node.scale = 1;
        this.clockTime = time;
        this.clockProgress = progress;
        this.clockSprie.node.color = color;
        this.clockColor = color;
        this.stopClock();
        this.schedule(this.gameClock, 1);
        this.schedule(this.changeProgressBar, totalTime / 200);
    }
    /**
     * 倒计时数字变化
     */
    gameClock() {
        if (this.clockTime <= 0) {
            this.unschedule(this.gameClock);
        } else {
            this.clockTime--;
            if (this.clockTime == 6) {
                // let gameView = cc.find("Canvas/script/GameView");
                // if(gameView&&gameView.getComponent("blackJackView")){
                //     gameView.getComponent("blackJackView").playDealerAni(1, "bet_wait");
                // }
                AppEmitter.emit(consts.LOCAL_ECENT_CLOCK_LAST_SIX,{});
            }
            if (this.clockTime <= 5 && this.clockTime > 0) {
                this.clockAni = cc.tween(this.clockLabel.node).to(0.6, { scale: 2.5 }).to(0.2, { scale: 1 });
                this.clockAni.start();
                if(this.isSelf){
                    AudioMgr.playSFX("sound_time_5_1");
                }
            } else if (this.clockTime == 0) {
                if(this.isSelf){
                    AudioMgr.playSFX("sound_time_0");
                }
                this.stopClock();
                if(this.timeoutListener)this.timeoutListener();
            }
        }
    }
    
    /**
     * 倒计时进度变化
     */
    changeProgressBar() {
        if (this.clockProgress <= 0) {
            this.unschedule(this.changeProgressBar);
        } else {
            this.clockProgress -= 0.005;
        }
        let color = this.clockSprie.node.color;
        if (this.clockProgress > 0.5) {
            let colorR = color.getR() + parseFloat((255 / 50).toString());
            if (colorR >= 0 && colorR <= 255) {
                this.clockSprie.node.color = new cc.Color(colorR, 255, 0);
                this.clockColor = new cc.Color(colorR, 255, 0);
            }
        } else {
            let colorG = color.getG() - parseFloat((255 / 50).toString());
            if (colorG >= 0 && colorG <= 255) {
                this.clockSprie.node.color = new cc.Color(255, colorG, 0);
                this.clockColor = new cc.Color(255, colorG, 0);
            }
        }
    }

    stopClock(){
        this.unschedule(this.gameClock);
        this.unschedule(this.changeProgressBar);
    }
}
