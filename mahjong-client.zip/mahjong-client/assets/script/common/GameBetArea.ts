
import AudioMgr from "../model/AudioMgr";
import { Utils } from "../model/Utils";
import { PUT_BET_TYPE } from "./ClientEnum";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameBetArea extends cc.Component {
    @property(cc.Prefab)
    betPrefab: cc.Prefab = null;
    chipPool: cc.NodePool = new cc.NodePool();

    @property(cc.Node)
    masterNode: cc.Node = null;

    @property(cc.Node)
    photoNode: cc.Node = null;

    @property([cc.SpriteFrame])
    betSpriteFrames: cc.SpriteFrame[] = [];

    moveTime = 0.3;
    masterPos;
    playerPos;
    init() {
        // let bets = this.node.children;
        // console.log("bets  length ===",bets.length);
        // bets.forEach(element => {
        //     this.chipPool.put(element);
        // });
        while(this.node.children.length > 0) {
            this.chipPool.put(this.node.children[this.node.children.length - 1]);
        }
        this.masterPos = Utils.changToNodePoint(this.masterNode, this.node);
        this.playerPos = Utils.changToNodePoint(this.photoNode, this.node);
    }
    /**
     * @param config 筹码配置
     * @param betNum 下注数额
     * @param type   下注类型  1.显示筹码在区域  2.筹码从玩家到区域   3.筹码从区域到庄家   4.筹码从庄家到区域   5.筹码从区域到玩家
     */
    addBet(config,betNum, type) {
        // let config = GameMgr.getInstance().chips;
        let index = config.length - 1;
        let creatorChip = (betNum) => {
            if (index >= 0) {
                let integerNum = parseInt((betNum / config[index]).toString());
                //创建筹码
                for (let i = 0; i < integerNum; i++) {
                    let chipStartPos;
                    let chipEndPos;
                    if (type == PUT_BET_TYPE.NO_MOVE) {
                        chipStartPos = chipEndPos = this.getAreaNextPos();
                    } else if (type == PUT_BET_TYPE.PERSON_TO_AREA) {
                        chipStartPos = this.playerPos;
                        chipEndPos = this.getAreaNextPos();
                    } else if (type == PUT_BET_TYPE.MASTER_TO_AREA) {
                        chipStartPos = this.masterPos;
                        chipEndPos = this.getAreaNextPos();
                    } else if (type == PUT_BET_TYPE.AREA_TO_PERSON){
                        chipStartPos = this.getAreaNextPos();
                        chipEndPos = this.playerPos;
                    }
                    let chip = null;
                    if (this.chipPool.size() > 0) {
                        chip = this.chipPool.get();
                    } else {
                        chip = cc.instantiate(this.betPrefab);
                    }
                    chip.active = true;
                    this.node.addChild(chip);
                    if(type != PUT_BET_TYPE.NO_MOVE){
                        AudioMgr.playSFX("sound_place_chip");
                    }
                    if(index>=0){
                        chip.getComponent(cc.Sprite).spriteFrame = this.betSpriteFrames[index];
                        //chip.getComponent("baseChip").setNum(index);
                        chip.num = config[index];
                    }
                    chip.setPosition(chipStartPos);
                    cc.tween(chip).to(this.moveTime, { position: chipEndPos }) 
                    .call(()=>{
                        if(type == PUT_BET_TYPE.AREA_TO_PERSON){
                            this.chipPool.put(chip);
                        }
                    })
                    .start();
                }
                let remainder = betNum % config[index];
                if (remainder > 0) {
                    index--;
                    creatorChip(remainder);
                }
            }else{
                if(betNum > 0){
                    let chipStartPos;
                    let chipEndPos;
                    if (type == PUT_BET_TYPE.NO_MOVE) {
                        chipStartPos = chipEndPos = this.getAreaNextPos();
                    } else if (type == PUT_BET_TYPE.PERSON_TO_AREA) {
                        chipStartPos = this.playerPos;
                        chipEndPos = this.getAreaNextPos();
                    } else if (type == PUT_BET_TYPE.MASTER_TO_AREA) {
                        chipStartPos = this.masterPos;
                        chipEndPos = this.getAreaNextPos();
                    } else if(type == PUT_BET_TYPE.AREA_TO_PERSON){
                        chipStartPos = this.getAreaNextPos();
                        chipEndPos = this.playerPos;
                    }
                    let chip = null;
                    if (this.chipPool.size() > 0) {
                        chip = this.chipPool.get();
                    } else {
                        chip = cc.instantiate(this.betPrefab);
                    }
                    chip.active = true;
                    this.node.addChild(chip);
                    chip.setPosition(chipStartPos);
                    cc.tween(chip).to(this.moveTime, { position: chipEndPos })
                    .call(()=>{
                        if(type == PUT_BET_TYPE.AREA_TO_PERSON){
                            this.chipPool.put(chip);
                        }
                    })
                    .start();
                }
            }
        }
        creatorChip(betNum);
    }
    /**
     * 获取当前筹码摆放位置
     */
    getAreaNextPos() {
        if(this.node.children.length>15){
            return cc.v2(0, 16 + 15 * 6);
            //return cc.v2(0, 16 + (this.node.children.length) * 6);
        }else{
            return cc.v2(0, 16 + (this.node.children.length) * 6);
        }
    }

    /**
    * 漂向庄家
    */
    betToMaster(isNotAll = false,cb = ()=>{}) {
        let bets = this.node.children;
        if (!isNotAll) {
            bets.forEach((bet) => {
                cc.tween(bet)
                .to(this.moveTime,{position:this.masterPos})
                .call(()=>{
                    this.chipPool.put(bet);
                })
                .call(cb)
                .start()
            });
        }
    }

    /**
     * 漂向自己
     */
    betToSelf(isNotAll,cb) {
        let bets = this.node.children;
        if (!isNotAll) {
            bets.forEach((bet) => {
                cc.tween(bet)
                .to(this.moveTime,{position:this.playerPos})
                .call(()=>{
                    this.chipPool.put(bet);
                })
                .call(cb)
                .start()
            });
        }
    }
    /**
     * 刷新筹码
     */
    refreshBet(config,betNum){
       //this.init();
       //this.node.destroyAllChildren();
       this.node.removeAllChildren();
       this.addBet(config,betNum,PUT_BET_TYPE.NO_MOVE);
    }
}
