// import GameMgr from "../../game/blackJack/script/model/blackJackMgr";
import { Utils } from "../model/Utils";



const {ccclass, property} = cc._decorator;

@ccclass
export default class GameChip extends cc.Component {

    @property(cc.Label)
    chipLabel: cc.Label = null;

    @property([cc.SpriteFrame])
    chipSpriteFrames:cc.SpriteFrame[] = [];

    @property(cc.Sprite)
    backSprite:cc.Sprite = null;

    start () {

    }
    
     /**
     * 设置筹码数目和纹理
     * @param {*} index 
     */
    setNum(index:number,num:number,isBackSprite = false){
        //let chipStr = Utils.formatCoinNum(GameMgr.getInstance().chips[index]*GameMgr.getInstance().moneyScale);
        let chipStr = Utils.formatCoinNum(num);
        this.chipLabel.string = chipStr;
        //if(chipStr.length>=4){
            this.chipLabel.node.scale = 0.8;
       // }
        //this.backSprite.spriteFrame = this.chipSpriteFrames[index]; 
        if(index >=0 ){
            let toggle = this.node.getComponent(cc.Toggle);
            if(toggle && !isBackSprite){
                toggle.normalSprite = this.chipSpriteFrames[index];
                toggle.pressedSprite = this.chipSpriteFrames[index];
                toggle.hoverSprite = this.chipSpriteFrames[index];
            }else{
                this.backSprite.spriteFrame = this.chipSpriteFrames[index];
            }
           
        }
        
    }

    // setThreedNum(index:number,){
    //     //let chipStr = Utils.formatCoinNum(threePorkerRoom.getInstance().betMultiples[index]);
    //     let chipStr = Utils.formatCoinNum(threePorkerRoom.getInstance().betMultiples[index]);
    //     this.chipLabel.string = chipStr;
    //     if(chipStr.length>=4){
    //         this.chipLabel.node.scale = 0.8;
    //     }
    //     this.backSprite.spriteFrame = this.chipSpriteFrames[index]; 
    // }
    /**
     * 设置筹码可以点击
     * @param {*} isClicked 
     */
    setChipIsClicked(isClicked:boolean){
        this.node.getComponent(cc.Toggle).interactable = isClicked;
    }
}
