
import { LOCAL_EVENT_POPUP_TIP } from "../model/Consts";
import { Utils } from "../model/Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    tipPanel: cc.Node = null;

    @property(cc.Node)
    tipLayout: cc.Node = null;

    @property(cc.Prefab)
    tipPrefab: cc.Prefab = null;

    @property(cc.Node)
    waitPanel: cc.Node = null;

    @property(cc.Node)
    waitSprite: cc.Node = null;

    showTip(data: object) {
        this.tipPanel.active = true;
        let tipText: string = data["tip"];
        let showTime: number = data["tipTime"] || 2;
        let params:string[] = data["params"];
        let tipNode = cc.instantiate(this.tipPrefab);
        let tiplabel = tipNode.getChildByName("tipLabel");
        if(tipText){
            Utils.setLabelStrForLanguage(tiplabel,tipText,params);
            this.tipLayout.addChild(tipNode);
            tipNode.scale = 0.5;
            cc.tween(tipNode)
                .to(0.5, { scale: 1 })
                .delay(showTime)
                .call(() => {
                    tipNode.destroy();
                })
                .start()
        }
    }

    showWait() {
        this.waitPanel.active = true;
        this.waitSprite.stopAllActions();
        cc.tween(this.waitSprite)
            .by(2, { angle: -360 })
            .repeatForever()
            .start()
    }

    hideWait() {
        //this.node.active = false;
        this.waitPanel.active = false;
        this.waitSprite.stopAllActions();
    }
}
