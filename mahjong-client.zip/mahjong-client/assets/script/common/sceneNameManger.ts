
import consts = require("../model/Consts");
import { platform_game_name } from "./ClientEnum";

export class sceneNameManger {

    /**
     * 根据当前场景名称获取游戏gameId
     * @param sceneName 
     * @returns 
     */
    static getCurGameId(sceneName: string) {
        let gameId: string = '';
        switch (sceneName) {
            // 三张扑克
            case consts.GANE_THREE_POKER_SCENE:
            case consts.THREE_POKER_TABLE_SCENE:
            case consts.THREE_POKER_ROOM_LIST_SCENE:
                gameId = platform_game_name.richer3;
                break;
            // 好运21点
            case consts.CLASSIC_BLACK_JACK_SCENE:
            case consts.CLASSIC_JACK_TABLE_SCENE:
            case consts.CLASSIC_JACK_ROOM_SCENE:
                gameId = platform_game_name.classicBlackJack;
                break;
            // 倍率21点
            case consts.MAGIC_BLACK_JACK_SCENE:
            case consts.MAGIC_JACK_TABLE_SCENE:
            case consts.MAGIC_JACK_ROOM_SCENE:
                gameId = platform_game_name.magicBlackJack;
                break;
            // 倍率推筒子
            case consts.PUSHDOTS_SCENE:
            case consts.PUSHDOTS_ROOM_LIST_SCENE:
                gameId = platform_game_name.PushDots;
                break;
            // 超级牛牛    
            case consts.SUPERCOW_SCENE:
            case consts.SUPERCOW_ROOMSCENE:
                gameId = platform_game_name.superCow;
                break;
            // 赛马    
            case consts.GAME_HORSERACING_SCENE:
            case consts.HORSE_RACING_ROOM_LIST_SCENE:
                gameId = platform_game_name.horseracing;
                break;
            // 赛艇
            case consts.ROWING_SCENE:
            case consts.ROWINGROOM_SCENE:
                gameId = platform_game_name.rowing;
                break;
            // 猴子爬树    
            case consts.MONKEYRACING_SCENE:
            case consts.MONKEYRACING_RoomScene:
                gameId = platform_game_name.monkeyracing;
                break;
            // 猴王登天
            case consts.GREATSAGERACING_SCENE:
            case consts.GREATSAGERACING_ROOMSCENE:
                gameId = platform_game_name.greatsageracing;
                break;
            // 经典射龙门
            case consts.CLASSICSHOT_SCENE:
            case consts.CLASSICSHOT_ROOMSCENE:
                gameId = platform_game_name.classicshot;
                break;
            // 黄金射龙门
            case consts.GOLDSHOTING_SCENE:
            case consts.GOLDSHOTING_ROOMSCENE:
                gameId = platform_game_name.goldshoting;
                break;
            // 倍率射龙门
            case consts.JOKERSHOTING_SCENE:
            case consts.JOKERSHOTING_ROOMSCENE:
                gameId = platform_game_name.jokershoting;
                break;
            // 抢庄妞妞
            case consts.racebullGameScene:
            case consts.racebullRoomScene:
                gameId = platform_game_name.racebull;
                break;
            // 抢庄推筒子
            case consts.racedotsGameScene:
            case consts.racedotsRoomScene:
                gameId = platform_game_name.racedots;
                break;
            // 二人麻将
            case consts.mahjongfortwoScene:
            case consts.mahjongfortwoRoomScene:
                gameId = platform_game_name.mahjongfortwo;
                break;
            // rummy
            case consts.GAME_RUMMY_SCENE:
            case consts.RUMMY_ROOM_LIST_SCENE:
            case consts.RUMMY_MODE_LIST_SCENE:
                gameId = platform_game_name.rummy;
                break;
            // 电子轮盘
            case consts.ROULETTE_ROOM_LIST_SCENE:
            case consts.ROULETTE_SCENE:
                gameId = platform_game_name.eroulette;
                break;
            // 电子百人德扑
            case consts.casinoholdemScenes.casinoholdemGameScene:
            case consts.casinoholdemScenes.casinoholdemRoomScene:
                gameId = platform_game_name.casinoholdem;
                break;
            // 电子黄金德扑
            case consts.texasholdemScenes.texasholdemGameScene:
            case consts.texasholdemScenes.texasholdemRoomScene:
                gameId = platform_game_name.texasholdem;
                break;
            // 电子骰宝
            case consts.sicboScenes.sicboGameScene:
            case consts.sicboScenes.sicboRoomScene:
                gameId = platform_game_name.sicbo;
                break;
            // 德州扑克金币场
            case consts.texasgoldScenes.texasgoldLobbyScene:
            case consts.texasgoldScenes.texasgoldRoomScene:
            case consts.texasgoldScenes.texasgoldScene:
                gameId = platform_game_name.texasgold;
                break;
            // 妞妞
            case consts.niuNiuScenes.niuNiuGameScene:
            case consts.niuNiuScenes.niuNiuRoomScene:
                gameId = platform_game_name.niuNiu;
                break;
            // 台湾麻将
            case consts.MAHJONG_SCENE:
            case consts.MAHJONG_ROOM_LIST_SCENE:
                gameId = platform_game_name.Mahjong;
                break;
            // 聚宝盆
            case consts.GAME_CORNUCOPIA_SCENE:
            case consts.CORNCUPIA_ROOM_LIST_SCENE:
                gameId = platform_game_name.treasure;
                break;
            // 五色宝石
            case consts.GAME_COLORFULGEMS_SCENE:
            case consts.COLORFULGEMS_ROOM_LIST_SCENE:
                gameId = platform_game_name.gof;
                break;
            // 德州扑克
            case consts.TEXAS_POKER_L_LOBBY_SCENE:
            case consts.TEXAS_POKER_L_ROOM_LIST_SCENE:
            case consts.TEXAS_POKER_L_SCENE:
            case consts.TEXAS_POKER_L_CLUB_SCENE:
                gameId = platform_game_name.TexasPoker;
                break;
            // 对战馆
            case consts.battleHallScene:
                gameId = platform_game_name.pvplobby;
                break;
            default:
                break;
        }
        return gameId;
    }
}