
import AudioMgr from "../model/AudioMgr";

const {ccclass, property} = cc._decorator;

@ccclass
export default class GameBaseButton extends cc.Component {
    start () {
        this.node.on(cc.Node.EventType.TOUCH_END,()=>{
           if(this.node.getComponent(cc.Button)&&this.node.getComponent(cc.Button).interactable){
             AudioMgr.playSFX("sound_btn_common_2");
           }
        });
    }
}
