/**
 * 游戏跑马灯
 */

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    msgLabel: cc.Label = null;//

    @property(cc.Node)
    maskNode: cc.Node = null;//遮罩

    @property
    text: string = '';

    @property
    moveSpeed: number = 100;//每秒走多少像素
    start() {
        this.text = "恭喜玩家James在德州撲克贏得獎金8888！";
        this.showMsg();
    }

    showMsg() {
        this.msgLabel.node.x = this.maskNode.width / 2 + 5;
        this.msgLabel.string = this.text;
         //@ts-ignore
        this.msgLabel._forceUpdateRenderData(true);
        const moveDistance = this.maskNode.width + 5 + this.msgLabel.node.width + 5;
        const duration = moveDistance / this.moveSpeed;
        let action = cc.tween(this.msgLabel.node)
            .repeatForever(cc.tween().to(duration, { x: -this.maskNode.width / 2 - this.msgLabel.node.width - 5 }).call(() => {
                this.msgLabel.node.x = this.maskNode.width / 2 + 5;
            }));
        action.stop();
        action.start();

    }
}
