// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class webViewNode extends cc.Component {

    @property(cc.WebView)
    webView: cc.WebView = null;
    
    divBtn = null;
    isMove = false;
    public init (data){
      let scheme = "testkey";
      this.webView.setJavascriptInterfaceScheme(scheme);
      this.webView.setOnJSCallback(()=>{
         this.closeWebView();
      });
      window.addEventListener("message",(event)=>{
        cc.log("message event =",event); 
        this.closeWebView();
      });
      this.webView.url = data.url;
     
    }
    protected onLoad(): void {
        this.createBackBtn();
    }

    private createBackBtn(){
        let cocos2dContainer = document.getElementById("Cocos2dGameContainer");
        let button: HTMLButtonElement = document.createElement("button");
        button.setAttribute("id", "webButton");
        button.style.position = "fixed"
        button.style.left = `20px`
        button.style.top = `20px`
        this.divBtn = button;
        let localResUrl = cc.url.raw("resources/image/back.png");
        button.style.backgroundColor = "transparent";
        
        cc.loader.load(localResUrl, (error, res) => {
            if (!error) {
                const imageUrl = res.nativeUrl;
                button.style.backgroundImage = `url(${imageUrl})`;
                button.style.width = res.width + "px";
                button.style.height = res.height + "px";
                button.style.backgroundColor = "transparent";
                button.style.borderColor = "transparent";

            }
        });
        button.onmousedown = (e) => {
            var ev = e || window.event;  //兼容ie浏览器
            //鼠标点击物体那一刻相对于物体左侧边框的距离=点击时的位置相对于浏览器最左边的距离-物体左边框相对于浏览器最左边的距离  
            var distanceX = ev.clientX - button.offsetLeft;
            var distanceY = ev.clientY - button.offsetTop;
            document.onmousemove = (e) => {
                var ev = e || window.event;  //兼容ie浏览器
                if ((ev.clientX - distanceX) > 0) {
                    this.isMove = true;
                    button.style.left = ev.clientX - distanceX + 'px';
                }
                if ((ev.clientY - distanceY) > 0) {
                    this.isMove = true;
                    button.style.top = ev.clientY - distanceY + 'px';
                }
            };
            document.onmouseup = () => {
                document.onmousemove = null;
                document.onmouseup = null;
            };
        };
        button.onclick = () => {
            if (!this.isMove) {
                var flag = confirm("确定要退出游戏吗？");
                if (flag) {
                    // window.parent.postMessage({hideBtn:false},"*")
                    // this.divBtn.remove();
                    // this.node.destroy();
                    this.closeWebView();
                }
            } else {
                this.isMove = false;
            }
        }

        button.style.zIndex = "1000";
        //this.divBtn.style.display = "none";
        cocos2dContainer.appendChild(button);
    }

    closeWebView(){
        cc.log("close webview")
        window.parent.postMessage({hideBtn:false},"*")
        this.divBtn.remove();
        this.node.destroy();
    }
}
