const { ccclass, property } = cc._decorator;

@ccclass
export default class CloseNodeByGlobalTouch extends cc.Component {
    protected sceneList: cc.Node[] = [];

    protected isStartContainsNode: boolean = false;

    onEnable() {
        if (this.sceneList.length > 0) {
            this.setEventListening(false);
        }
        this.sceneList = cc.director.getScene().children.filter((node) => node.name !== "PROFILER-NODE");
        this.setEventListening(true);
    }

    onDisable() {
        this.isStartContainsNode = false;
        this.setEventListening(false);
        this.unscheduleAllCallbacks();
    }

    onDestroy() {
        this.isStartContainsNode = false;
        this.setEventListening(false);
        this.unscheduleAllCallbacks();
    }

    protected setEventListening(isListen: boolean) {
        this.sceneList.forEach((node) => {
            if (cc.isValid(node)) {
                if (isListen) {
                    // MEMO:只能使用once，避免off後畫面觸控事件卡住
                    node.once(cc.Node.EventType.TOUCH_START, this.onTouchStart, this, true);
                    node.once(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this, true);
                    node.once(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this, true);
                    node.once(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this, true);
                }
                else {
                    node.targetOff(this);
                }
            }
        });

        if (isListen === false) {
            this.sceneList = [];
        }
    }

    protected onTouchStart(event: cc.Event.EventTouch) {
        this.isStartContainsNode = this.node.getBoundingBoxToWorld().contains(event.getLocation());
    }

    protected onTouchMove(event: cc.Event.EventTouch) {
        if (!this.isStartContainsNode) {
            this.closeActive();
        }
    }

    protected onTouchEnd(event: cc.Event.EventTouch) {
        this.isStartContainsNode = false;
        if (this.node.getBoundingBoxToWorld().contains(event.getLocation())) {
            // 效果只有一次，沒被關閉的話要重新監聽
            this.setEventListening(true);
        }
        else {
            this.closeActive();
        }
    }

    protected onTouchCancel(event: cc.Event.EventTouch) {
        this.isStartContainsNode = false;
        this.closeActive();
    }

    protected closeActive() {
        // memo:下一幀才執行，要先讓反冒泡的物件觸發event
        this.scheduleOnce(() => {
            this.node.active = false;
        }, 0);
    }
}
