const { ccclass, property } = cc._decorator;

/**
 * 拖曳類別
 * 1.用setMoveListening來監聽移動事件
 * 2.觸控區的大小限制在場景內
 * 3.可用interactable開關功能
 */
@ccclass
export default class Draggable extends cc.Component {
    /** 觸控區 */
    @property({
        tooltip: "觸控區",
        type: cc.Node,
        visible: true,
    })
    protected touchLayer: cc.Node = null;

    /** 觸碰最一開時的節點座標 */
    protected touchPos: cc.Vec2 = cc.v2(0, 0);

    /** 是否有移動 */
    protected isMove: boolean = false;

    /** 移動監聽方法 */
    protected moveListeningFun: (node: cc.Node, isDragEnd: boolean) => void = null;

    /** 是否註冊了觸控監聽 */
    protected isRegisterTouchEvent: boolean = false;

    @property({
        visible: false,
    })
    protected myInteractable: boolean = true;

    /** 移動事件是否被響應，如果為 false，則移動禁用 */
    @property({
        tooltip: "移動事件是否被響應，如果為 false，則移動禁用",
    })
    get interactable(): boolean {
        return this.myInteractable;
    }

    set interactable(value: boolean) {
        this.myInteractable = value;
        if (!CC_EDITOR) {
            if (this.myInteractable) {
                this.registerTouchEvent();
            }
            else {
                this.unregisterTouchEvent();
            }
        }
    }

    onEnable() {
        this.registerTouchEvent();
    }

    onDisable() {
        this.unregisterTouchEvent();
    }

    /** 註冊觸控監聽 */
    protected registerTouchEvent() {
        if (this.interactable && this.touchLayer && this.isRegisterTouchEvent === false) {
            this.touchLayer.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
            this.touchLayer.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
            this.touchLayer.on(cc.Node.EventType.TOUCH_END, this.onTouchEnded, this);
            this.touchLayer.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
            this.isRegisterTouchEvent = true;
        }
    }

    /** 解除觸控監聽 */
    protected unregisterTouchEvent() {
        if (this.touchLayer && this.isRegisterTouchEvent) {
            this.touchLayer.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
            this.touchLayer.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
            this.touchLayer.off(cc.Node.EventType.TOUCH_END, this.onTouchEnded, this);
            this.touchLayer.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
            this.isRegisterTouchEvent = false;
        }
    }

    onTouchStart(event: cc.Touch) {
        this.isMove = false;
        this.touchPos.x = this.node.x;
        this.touchPos.y = this.node.y;
    }

    onTouchMove(event: cc.Event.EventTouch) {
        event.stopPropagation();

        const delta = event.getDelta();
        const destX = this.touchPos.x + event.getLocation().x - event.getStartLocation().x;
        const destY = this.touchPos.y + event.getLocation().y - event.getStartLocation().y;
        if ((delta.x !== 0) || (delta.y !== 0)) {
            const moveablePosition = this.getMoveablePosition(destX, destY);

            const isChangeX: boolean = this.node.x !== moveablePosition.x;
            const isChangeY: boolean = this.node.y !== moveablePosition.y;
            if (isChangeX || isChangeY) {
                // 更新節點位置
                this.isMove = true;
                this.node.x = moveablePosition.x;
                this.node.y = moveablePosition.y;
                this.notifyMoveListening(false);
            }
        }
    }

    onTouchEnded(event: cc.Event.EventTouch) {
        event.stopPropagation();
        this.endDrag();
    }

    onTouchCancel(event: cc.Event.EventTouch) {
        event.stopPropagation();
        this.endDrag();
    }

    /** 拖曳結束 */
    protected endDrag() {
        if (this.isMove) {
            // 有移動過才通知
            this.notifyMoveListening(true);
            this.isMove = false;
        }
    }

    /** 計算移動後最終位置(會限制在視窗內) */
    protected getMoveablePosition(destX: number, destY: number): cc.Vec2 {
        // 手指位置(螢幕座標)轉成世界坐標系
        const position = this.node.parent.convertToWorldSpaceAR(new cc.Vec2(destX, destY));
        // 取得視窗尺寸
        const resolution = cc.view.getDesignResolutionSize();
        // 由 position x，y 扣掉節點寬高計算出可移動範圍
        const minX = position.x - (this.node.anchorX * this.node.width);
        const maxX = position.x + (1 - this.node.anchorX) * this.node.width;
        const minY = position.y - (this.node.anchorY * this.node.height);
        const maxY = position.y + (1 - this.node.anchorY) * this.node.height;

        let moveableX = position.x;
        let moveableY = position.y;
        // 邊界檢查，超過要限制在內，(世界座標 x, y)
        if (minX < 0) {
            moveableX = (this.node.anchorX * this.node.width);
        }
        else if (maxX > resolution.width) {
            moveableX = resolution.width - (1 - this.node.anchorX) * this.node.width;
        }

        if (minY < 0) {
            moveableY = (this.node.anchorY * this.node.height);
        }
        else if (maxY > resolution.height) {
            moveableY = resolution.height - (1 - this.node.anchorY) * this.node.height;
        }

        return this.node.parent.convertToNodeSpaceAR(new cc.Vec2(moveableX, moveableY));
    }

    /**
     * 通知監聽
     * @param isDragEnd 拖移是否結束
     */
    protected notifyMoveListening(isDragEnd: boolean) {
        if (this.moveListeningFun) {
            this.moveListeningFun(this.node, isDragEnd);
        }
    }

    /**
     * 設定移動監聽
     * @param cb 回呼方法
     */
    setMoveListening(cb: (node: cc.Node, isDragEnd: boolean) => void) {
        this.moveListeningFun = cb;
    }

    /** 取得移動前的位置 */
    getPositionBeforeMoving(): cc.Vec2 {
        return this.touchPos;
    }
}