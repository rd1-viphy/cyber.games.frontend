
import { GameViewOrientation, platform_game_id, platform_game_name } from "../common/ClientEnum";
import AppEmitter from "../network/AppEmitter";
import HttpUtils from "../network/HttpUtils";
import NetConnect from "../network/NetConnect";
import App from "./App";
import AudioMgr from "./AudioMgr";
import consts = require("./Consts");
import PlayerMgr from "./PlayerMgr";

import MahjongRoomMgr from "./roomMgr/mahjongRoomMgr";

import { Utils } from "./Utils";


import gameEventTrackingMgr, { GameEventTrackingTypeId } from "./gameEventTrackingMgr";

interface GameInfo {
    gameId: number,
    roomId: number,
    tableId: number,
    chairId: number,
    cacheData?: any,
}

/**
 * 房间管理类
 */
export default class RoomMgr {

    constructor() {
        AppEmitter.on(consts.GAME_DATA, this.enterThreePokerRoom, this);
        AppEmitter.on("onNewPlayerEnter", this.onNewPlayerEnter, this);
    }

    /** 创建单例 */
    public static _instance;
    public roomList = [];
    public tableList = [];
    public selectRoomId: number = 1;
    public selectGameId: number = 1;
    public roomRate: number = 1;    // 房间倍率
    public pageCount: number = 0;
    public gameData: object = {};
    public newPersonArr = [];
    public moneyScale = 1;

    /**房间静态配置 */
    public RoomConfig: any = null;
    /**断线的房间列表 */
    public againGameList: GameInfo[] = [];
    /**德州回放标记 */
    public isTexasBackView: boolean = false;
    /** 赛马回放标记 */
    public isHorseBackView: boolean = false;
    /** 好运21点翻倍对决开关 */
    public doublingFaceOff: boolean = false;
    /** 是否可以进三张扑克 */
    public isCanEnterThreePoker: boolean = false;

    public static getInstance(): RoomMgr {
        if (!this._instance) {
            this._instance = new RoomMgr();
        }
        return this._instance;
    }

    /**
     * 获取断线的游戏列表
     */
    public getAgainRoomList(successCallback: Function = null, failCallback: Function = null) {
        NetConnect.sendRequest(consts.GAME_GET_AGAIN_GAME_LIST, {}, (data) => {
            this.againGameList = data.gameList;
            successCallback && successCallback();
        }, true, () => {
            failCallback && failCallback();
        });
    }

    /**
     * 进入游戏
     * @param gameId 
     * @param roomType 
     */
    public enterGame(touchGameId: number, isHomeAgain: boolean, roomType: number = 0) {

        //先判断是否有断线信息 没有断线进大厅(判断是否在游戏场景，如果是游戏场景则要返回选房或者选桌界面)     有断线消息则断线重连
        let enter = () => {
            let gameInfo = this.getIsHaveAgainGameInfo(touchGameId);
            if (touchGameId == platform_game_id.pvplobby) {
                if (this.againGameList && this.againGameList.length > 0) {
                    gameInfo = this.againGameList[0];
                }
            }
            if (gameInfo) {
                cc.log("gameInfo " + gameInfo);
                this.enterGameAgain(gameInfo, roomType);
            } else {
                if (isHomeAgain) {
                    if (App.getIsGuestLogin()) {
                        this.enterGameNormal(touchGameId, roomType);
                    } else {

                        this.againEnterGameFail();

                    }
                } else {
                    //接平台判断是否有邀请
                    if (cc.sys.isNative) {

                    } else {
                        if (consts.isAccessPlatform) {
                            let gameId = null;
                            let roomId = null;
                            let password = "";

                            this.enterGameNormal(touchGameId, roomType);

                        } else {

                            this.enterGameNormal(touchGameId, roomType);

                        }
                    }
                }
            }
        }

        //获取断线信息
        this.getAgainRoomList(() => {
            enter();
        }, () => {
            enter();
        });
    }

    /**
     * 正常进入游戏
     */
    private enterGameNormal(gameId: number, roomType: number = 0) {
        const touchGameId = gameId;
        RoomMgr.getInstance().selectGameId = touchGameId;
        const entergametype = parseInt(Utils.getHttpKeysAndValus()["entergametype"]);

        if (touchGameId == platform_game_id.mahjong_table) {
            // 麻将
            App.preloadRes("mahjong", () => {
                cc.sys.localStorage.setItem("mahjongMianZe", true);
                App.changeScene({ "sceneName": consts.MAHJONG_ROOM_LIST_SCENE });
            })
        }
    }

    /**
     * 断线重连进入游戏
     */
    public enterGameAgain(gameInfo: GameInfo, roomType: number = 0) {
        const gameId = gameInfo.gameId;
        RoomMgr.getInstance().selectGameId = gameId;
        RoomMgr.getInstance().selectRoomId = gameInfo.roomId;
        if (gameId == platform_game_id.mahjong_table) {
            App.preloadRes("mahjong", () => {
                MahjongRoomMgr.getInstance().reJoinGame(gameInfo.roomId, () => {
                    this.againEnterGameFail();
                });
            });
        }
    }

    /**
     * 断线重进失败
     */
    public againEnterGameFail() {
        //被踢出游戏的话退到选桌界面
        if (App.currentScene == consts.lOADING_SCENE || App.currentScene == consts.LOGIN_SCENE) {
            if (consts.isAccessPlatform) {
                let gameId: string = Utils.getUrlGameId()["gameid"];
                let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
                let roomType: number = roomTypeValue ? parseInt(roomTypeValue) : 0;
                this.enterGameNormal(platform_game_id[gameId], roomType);
            } else {
                App.changeScene({ "sceneName": consts.LOBBY_SCENE, "type": 1 });
            }

            //cb && cb();
            //this.enterGameNormal();

        } else if (App.currentScene == consts.MAHJONG_SCENE) {
            App.changeScene({ "sceneName": consts.MAHJONG_ROOM_LIST_SCENE });
        }
    }

    /**
     * 游戏场景中断线重连(home 键断线和网络断开重连)
     */
    public gameSceneConnectAgain(gameID = 0) {
        let roomType = 0;
        if (consts.isAccessPlatform) {
            let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
            roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        }

        if (App.currentScene == consts.MAHJONG_SCENE) {
            this.enterGame(platform_game_id.mahjong_table, true, roomType);
        }
    }

    /**
     * 通过分享链接直接进入游戏
     * @param gameId 
     * @param roomId 
     * @param passord 
     */
    joinGameForShareUrl(gameId: number, roomId: number, password: string, failcb: Function) {
        switch (gameId) {

            case platform_game_id.mahjong_table:
                App.preloadRes("mahjong", () => {
                    MahjongRoomMgr.getInstance().joinMahjongTable({ gameId: platform_game_id.mahjong_table, roomId: roomId, password: password, step: 3 }, () => { }, () => {
                        failcb();
                    });
                });
                break;
            case platform_game_id.texas_table:
                // 俱乐部clubId传入时设定为负数
                if (roomId > 0) {
                    App.preloadRes("texasPokerLandscape", () => {
                        this.joinTexasPokerLPrivateRoom({ "tableId": roomId }, () => { }, () => {
                            failcb();
                        });
                    });
                } else {
                    this.joinClubForShareUrl(gameId, roomId, () => {
                        failcb();
                    });
                }
                break;

        }
    }

    /**
     * 通过分享链接直接进入俱乐部
     * @param gameId 
     * @param roomId 
     * @param passord 
     */
    joinClubForShareUrl(gameId: number, clubId: number, failcb: Function) {
        // 俱乐部分享链接特殊处理
        clubId = Math.abs(clubId);

    }

    /**
     * 判断是否有断线消息
     */
    public getIsHaveAgainGameInfo(gameId: number) {
        let againGameInfo = null;
        if (gameId && this.againGameList && this.againGameList.length > 0) {
            this.againGameList.forEach((gameInfo) => {
                if (gameInfo.gameId && gameInfo.roomId && gameInfo.tableId && gameInfo.gameId == gameId) {
                    againGameInfo = gameInfo;
                }
            });
        }
        return againGameInfo;
    }

    /**
     * 获取21点房间列表
     * @param requestData 
     * @param cb 
     */
    getBlackJackRoomList(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_QUERY_BLACK_JACK_ROOM_LIST, requestData, cb);
    }

    /**
     * 获取倍率21点房间列表
     * @param requestData 
     * @param cb 
     */
    getMagicBlackJackRoomList(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_MAGIC_QUERY_BLACK_JACK_ROOM_LIST, requestData, cb);
    }

    /**
    * 获取三张扑克房间列表
    * @param requestData 
    * @param cb 
    */
    getThreepokerRoomList(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_QUERY_THREE_POKER_ROOM_LIST, requestData, cb);
    }

    /**
     * 获取21点桌子列表
     * @param data 
     */
    getBlackJackList(requestData, cb, isShowLoading = true) {
        NetConnect.sendRequest(consts.GAME_QUERY_BLACK_JACK_TABLE_LIST, requestData, cb, isShowLoading);
    }

    /**
     * 获取聚宝盆房间列表
     * @param requestData 
     * @param cb 
     */
    getCornucopiaRoomList(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_QUERY_CORNCUPIA_ROOM_LIST, requestData, cb, true, failCb);
    }

    /**
     * 获取五彩聚宝盆房间列表
     * @param requestData 
     * @param cb 
     */
    getColorfulGemsRoomList(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_QUERY_CORNCUPIA_ROOM_LIST, requestData, cb, true, failCb);
    }

    /**
     * 获取倍率21点桌子列表
     * @param requestData 
     * @param cb 
     * @param isShowLoading 
     */
    getMagicBlackJackList(requestData, cb, isShowLoading = true) {
        NetConnect.sendRequest(consts.GAME_QUERY_MAGIC_BLACK_JACK_TABLE_LIST, requestData, cb, isShowLoading);
    }

    /**
    * 获取富贵三宝桌子列表
    * @param data 
    */
    getThreeCardsList(requestData, cb, isShowLoading = true, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_QUERY_THREE_CARDS_TABLE_LIST, requestData, cb, isShowLoading, failCb);
    }

    /**
     * 三张扑克换桌
     * @param requestData 
     * @param cb 
     */
    threePokerChangeTable(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_QUERY_THREE_POKER_CHANGE_TABLE, requestData, cb);
    }

    /**
     * 快速加入21点游戏
     */
    quickJoinBlackJackGame(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_QUICK_JOIN_BLACK_JACK_TABLE, requestData, cb);
    }

    /**
     * 快速加入倍率21点游戏
     * @param requestData 
     * @param cb 
     */
    quickJoinMagicBlackJackGame(requestData, cb, failCb: Function = () => { }) {
        NetConnect.sendRequest(consts.GAME_MAGIC_QUICK_JOIN_BLACK_JACK_TABLE, requestData, cb, true, failCb);
    }

    /**
     * 快速加入三张扑克游戏
     */
    quickJoinThreeCardsGame(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_QUICK_JOIN_THREE_CARDS_TABLE, requestData, cb, true, failCb);
    }
    /**
     * 加入21点桌子
     * @param requestData 
     * @param cb 
     */
    joinBlackJackTable(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_BLACK_JACK_JOIN_TABLE, requestData, cb);
    }

    /**
     * 加入倍率21点桌子
     * @param requestData 
     * @param cb 
     */
    joinMagicBlackJackTable(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_MAGIC_BLACK_JACK_JOIN_TABLE, requestData, cb, true, failCb);
    }

    /**
     * 加入三张桌子
     * @param requestData 
     * @param cb 
     */
    joinThreeCardsTable(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_THREE_CARDS_JOIN_TABLE, requestData, cb, true, failCb);
    }

    /**
    * 进入游戏
    * @param {*} data 
    */
    enterThreePokerRoom(gameData) {
        App.showLog("gameTableData", gameData);
        RoomMgr.getInstance().gameData = gameData;
        App.changeScene({ "sceneName": consts.GANE_THREE_POKER_SCENE });
    }

    enterBlackJackGame(gameData) {
        RoomMgr.getInstance().gameData = gameData;
        this.newPersonArr = [];
        App.changeScene({ "sceneName": consts.GANE_BJACK_JACK_SCENE });
    }

    enterMagicBlackJackGame(gameData) {
        RoomMgr.getInstance().getAgainRoomList(() => {
            if (this.againGameList.length > 0) {
                this.againGameList.forEach((game) => {
                    if (game.gameId == platform_game_id.magic21) {
                        NetConnect.sendRequest(consts.GAME_MAGIC_JOIN_GAME_AGAIN, {}, (roomData: object) => {
                            RoomMgr.getInstance().gameData = roomData;
                            this.newPersonArr = [];
                            App.changeScene({ "sceneName": consts.MAGIC_BLACK_JACK_SCENE });
                        })
                    }
                })
            }
        })
    }

    /**
     * 加入聚宝盆桌子
     * @param requestData 
     * @param cb 
     */
    joinCornucopiaTable(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_CORNCUPIA_JOIN_TABLE, requestData, cb, true, failCb);
    }

    /**
     * 进入聚宝盆
     * @param gameData 
     */
    enterCornucopiaGame(gameData) {
        RoomMgr.getInstance().gameData = gameData;
        this.newPersonArr = [];
        App.changeScene({ "sceneName": consts.GAME_CORNUCOPIA_SCENE });
    }

    /**
     * 进入五彩聚宝盆
     * @param gameData 
     */
    enterColorfulGemsGame(gameData) {
        RoomMgr.getInstance().gameData = gameData;
        this.newPersonArr = [];
        App.changeScene({ "sceneName": consts.GAME_COLORFULGEMS_SCENE });
    }

    onNewPlayerEnter(data) {
        this.newPersonArr.push(data);
    }

    /**
    * 获取经典黑杰克的桌子列表
    * @param requestData 
    * @param cb 
    * @param isShowLoading 
    */
    getClassicBlackJackList(requestData, cb, isShowLoading = true) {
        NetConnect.sendRequest(consts.GAME_QUERY_CLASSIC_BLACK_JACK_TABLE_LIST, requestData, cb, isShowLoading);
    }

    /**
     * 加入经典黑杰克点桌子
     * @param requestData 
     * @param cb 
     */
    joinClassicBlackJackTable(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_CLASSIC_BLACK_JACK_JOIN_TABLE, requestData, cb, true, failCb);
    }

    /**
    * 获取经典黑杰克的房间列表
    * @param requestData 
    * @param cb 
    */
    getClassicBlackJackRoomList(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_CLASSIC_QUERY_BLACK_JACK_ROOM_LIST, requestData, cb);
    }

    /**
     * 获取好运21点配置
     * @param requestData 
     * @param cb 
     */
    getClassic21Config(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_CLASSIC_GET_CONFIG, requestData, cb);
    }

    /**
     * 快速加入经典黑杰克游戏
     * @param requestData 
     * @param cb 
     */
    quickJoinClassicBlackJackGame(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_CLASSIC_QUICK_JOIN_BLACK_JACK_TABLE, requestData, cb, true, failCb);
    }

    enterClassicBlackJackGame(gameData) {
        RoomMgr.getInstance().getAgainRoomList(() => {
            if (this.againGameList.length > 0) {
                this.againGameList.forEach((game) => {
                    if (game.gameId == platform_game_id.classic21) {
                        NetConnect.sendRequest(consts.GAME_CLASSIC_JOIN_GAME_AGAIN, {}, (roomData: object) => {
                            RoomMgr.getInstance().gameData = roomData;
                            this.newPersonArr = [];
                            App.changeScene({ "sceneName": consts.CLASSIC_BLACK_JACK_SCENE });
                        })
                    }
                })
            }
        })
    }

    /**
     * 查询自己创建的房间列表
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    createByMeTexasPokerL(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_CREATE_BY_ME, requestData, cb, false, failCb);
    }

    /**
     * 查询公桌列表
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    commonTexasPokerL(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_COMMON, requestData, cb, false, failCb);
    }

    /**
     * 查询私人房间配置
     * @param cb 
     * @param failCb 
     */
    getTexasPokerLConfig(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_GET_CONFIG, requestData, cb, true, failCb);
    }

    /**
     * 创建德州横版私人房间
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    creatTexasPokerLPrivateRoom(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_CREATE, requestData, cb, true, failCb);
    }

    /**
     * 查询德州横版私人房间
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    queryTexasPokerLPrivateRoom(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_QUERY, requestData, cb, true, failCb);
    }

    /**
    * 准备德州横版私人房间
    * @param requestData 
    * @param cb 
    * @param failCb 
    */
    confirmTexasPokerLPrivateRoom(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_CONFIRM, requestData, cb, true, failCb);
    }

    /**
     * 加入德州横版私人房间
     * @param requestData 
     * @param cb 
     */
    joinTexasPokerLPrivateRoom(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PRIVATE_ROOM_JOIN, requestData, cb, true, failCb);
    }

    /**
     * 查询德州横版公共房间
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    queryTexasPokerLPublicRoom(requestData, cb, failCb: Function = null) {
        // NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PUBLIC_ROOM_QUERY, requestData, cb, true, failCb);
    }

    /**
     * 加入德州横版公共房间
     * @param requestData 
     * @param cb 
     */
    joinTexasPokerLPublicRoom(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_PUBLIC_ROOM_JOIN, requestData, cb);
    }

    /**
     * 查询个人/代开战绩汇总信息
     * @param requestData 
     * @param cb 
     */
    getTexasPokerLHistorySummary(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_HISTORY_SUMMARY, requestData, cb);
    }

    /**
     * 查询某桌内的战绩（包括个人/代开）
     * @param requestData 
     * @param cb 
     */
    getTexasPokerLHistoryList(requestData, cb) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_HISTORY_LIST, requestData, cb);
    }

    /**
     * 查询某桌内的战绩（包括个人/代开）
     * @param requestData
     * @param cb
     */
    getTexasPokerLHistory(requestData, cb, failCb) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_GET_HISTORY, requestData, cb, true, failCb);
    }

    /**
     * 玩家的统计数据
     * @param requestData
     * @param cb
     */
    getTexasPokerLStatistics(requestData, cb, failCb) {
        NetConnect.sendRequest(consts.GAME_TEXAS_POKER_L_GET_STATISTICS, requestData, cb, true, failCb);
    }

    /**
     * 查询进桌子密钥信息
     */
    queryJoinKeyInfo(requestData, cb, failCb) {
        NetConnect.sendRequest(consts.GAME_QUERY_JOIN_KEY_INFO, requestData, cb, true, failCb);
    }

    /**
     * 进入德州回放
     */
    public joinTexasPokerPlayback(tableUuid: string, roundLimit: number) {
        const obj = {
            apiGameId: platform_game_name.TexasPoker,
            tableUuid: tableUuid,
            roundLimit: roundLimit,
        }
        HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, consts.HTTP_ROUTE.FIND_PALYER_BACK, obj, (responseData) => {
            const backData = JSON.parse(responseData);
            if (backData.code == 0) {
                App.preloadRes("texasPokerLandscape", () => {
                    RoomMgr.getInstance().isTexasBackView = true;
                    RoomMgr.getInstance().gameData = backData.data;
                    App.changeScene({ "sceneName": consts.TEXAS_POKER_L_SCENE, "type": 1 });
                })
            }
        })
    }

    /**
     * 设置房间翻倍对决状态
     * @param roomList 
     */
    public setRoomDoublingFaceOffStatus(roomList) {
        let doublingFaceOff = false;
        if (roomList && roomList.length > 0) {
            roomList.forEach((roomInfo) => {
                if (roomInfo.DoublingFaceOff == 1) {
                    doublingFaceOff = true;
                }
            });
        }
        RoomMgr.getInstance().doublingFaceOff = doublingFaceOff;
    }

    /**
     * 检测宿主游戏中是否有翻倍对决在进行
     * @param hostGameId 
     */
    public isCheckDoublingFaceing(hostGameId: number, cb) {
        NetConnect.sendRequest(consts.DoublingFaceChecking, {
            gameId: platform_game_id.doublingfaceoff,
            hostGameId: hostGameId
        }, () => {
            cb(true);
        }, true, () => {
            cb(false);
        })
    }

    public recDoublingFaceing() {

    }

    /**
     * 进入好运21点回放
     * @param roundId 
     * @param playerId 
     */
    public joinClassic21PlayBack(roundId: string, playerId: number) {
        NetConnect.connectBack(() => {
            PlayerMgr.getInstance().getBackPlay({
                "roundId": roundId,
                "vcode": Utils.getHttpKeysAndValus()["vcode"],
                "gameId": platform_game_name.classicBlackJack,
                "token": Utils.getHttpKeysAndValus()["token"],
                "playerId": playerId,
            }, (data) => {
                App.preloadRes("horseRacing", () => {
                    RoomMgr.getInstance().isHorseBackView = true;
                    RoomMgr.getInstance().gameData = data.data;
                    App.changeScene({ sceneName: consts.CLASSIC_BLACK_JACK_SCENE })
                })
            })
        })
    }

}


