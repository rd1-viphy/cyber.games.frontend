
import NetConnect from "../network/NetConnect";
import consts = require("./Consts");
import { Utils } from "./Utils";

const { ccclass, property } = cc._decorator;

@ccclass
export default class PlayerMgr {

   private static _instance = null;

   /** 用户id */
   public userID: string = "";
   /** 用户id */
   public uid: string = "";
   /** 用户昵称 */
   public nickName: string = "";
   /** 平台id */
   public agentId: string = "";
   /** 用户头像 */
   public avatar: string = "";
   /** 金币数量 */
   public money: number = 0;
   /** vip等级 */
   public vipLevel: number = 0;
   public realMoney: number = 0;
   public leadMoney: number = 100000;
   /** 08新手标记：0表示新手 */
   public userFlag = 0;
   /** 好运新手标记: 1表示新手 */
   public isGameNewPlayer: number = 0;
   /**房卡声明的提示 */
   public isNotice: number = 0;

   public static getInstance(): PlayerMgr {
      if (!this._instance) {
         this._instance = new PlayerMgr();
      }
      return this._instance;
   }

   public initData(data: object) {
      this.uid = data["uid"];
      this.nickName = data["username"];
      this.agentId = data["agent"];
      this.avatar = data["avatar"];
      this.money = data["money"];
      this.userID = data["uid"];
      this.vipLevel = data["vipLevel"];
      this.realMoney = data["money"];
      //this.userFlag = data["userFlag"];
      this.userFlag = 1;
      this.isGameNewPlayer = data["isGameNewPlayer"];
      this.isNotice = data["isNotice"];
   }

   /**
    * 获取玩家信息
    * @param cb 
    */
   public getPersonData(cb) {
      NetConnect.sendRequest(consts.GAME_GET_PERSON_DATA, {}, cb);
   }

   /**
    * 更换头像
    * @param data 
    * @param cb 
    */
   public setChangePhoto(data, cb) {
      NetConnect.sendRequest(consts.GAME_CHANGE_PHOTO, data, cb);
   }

   /**
    * 获取玩家金币数量
    * @param cb 
    */
   getPlayerMoney(cb) {
      NetConnect.sendRequest(consts.GAME_QUERY_PLAYER_MONEY, {}, cb);
   }

   /**
    * 获取游戏的注单记录
    * @param data 
    * @param cb 
    */
   public getGameRecord(data, cb) {
      NetConnect.sendRequest(consts.GAME_GET_RECORD, data, cb);
   }

   /**
    * 获取游戏的额度记录
    * @param data 
    * @param cb 
    */
   public getGameMoneyRecord(data, cb) {
      NetConnect.sendRequest(consts.GAME_QUERY_MONEY_RECORD, data, cb);
   }

   /**
    * 获取游戏对应记录数目
    * @param data 
    * @param cb 
    */
   public getGameRecordCount(data, cb) {
      NetConnect.sendRequest(consts.GAME_QUERY_RECORD_COUNT, data, cb);
   }

   /**
    * 顯示玩家自己的金幣
    */
   public showSelfMoneyLabel(moneyLabel: cc.Label) {
      let currectMoney = this.money;
      if (currectMoney > consts.MAX_COIN) {
         moneyLabel.string = consts.MAX_COIN.toString();
      } else {

         moneyLabel.string = Utils.formatNumDistance(Utils.onDealPoint(currectMoney));

      }
   }

   /**
    * 获取回放记录
    * @param data 
    * @param cb 
    */
   public getBackPlay(data, cb) {
      NetConnect.sendRequest(consts.GAME_BACK_PLAY, data, cb);
   }

}
