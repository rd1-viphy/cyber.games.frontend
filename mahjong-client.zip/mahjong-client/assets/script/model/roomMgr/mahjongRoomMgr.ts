
import { platform_game_id, platform_game_name } from "../../common/ClientEnum";
import AppEmitter from "../../network/AppEmitter";
import HttpUtils from "../../network/HttpUtils";
import NetConnect from "../../network/NetConnect";

import App from "../App";
import consts = require("../Consts");
import MahjongBackModel from "../mahjongBackModel";
import { Utils } from "../Utils";

enum MahjongRoute {
    GET_ROOM_CONFIG = "mahjongRoom.mahjongRoomHandler.getRoomConfig",
    ROOM_LIST = "mahjongRoom.mahjongRoomHandler.getRoomList",
    JOIN_ROOM = "mahjongRoom.mahjongRoomHandler.joinRoom",
    CREATE_ROOM = "mahjongRoom.mahjongRoomHandler.createRoom",
    WATCH_GAME = "mahjongRoom.mahjongRoomHandler.joinRoomWatch",
    REJOIN_GAME = "mahjong.mahjongGameHandler.rejoinGame",
    GET_GAME_GRADE = "mahjongRoom.mahjongRoomHandler.getGameRecords",
    GET_GAME_INFO = "mahjongRoom.mahjongRoomHandler.getGameDetail",
    RENEW_ROOM = "mahjongRoom.mahjongRoomHandler.renewRoom",
    CONFIRM_JOIN_ROOM = "mahjongRoom.mahjongRoomHandler.confirmJoinRoom",
    GET_RENEW_ROOM = "mahjongRoom.mahjongRoomHandler.getRenewRoom"
}

export default class MahjongRoomMgr {

    constructor() {
        AppEmitter.on("onPlayerJoinGamePush", this.enterMahjongGame, this);
    }

    public static _instance;
    public roomList = [];
    public selRoomId: number = 1;
    public selRoomType: number = 1;
    public roomRate: number = 1;
    public moneyScale: number = 1;
    public gameData: Object = {};
    public newPersonArr = [];
    public isBackView: boolean = false;
    public isFreeTable: boolean = false;
    public isFreeEmoji: boolean = false;
    public startTime: number;
    public endTime: number;

    public static getInstance(): MahjongRoomMgr {
        if (!this._instance) {
            this._instance = new MahjongRoomMgr();
        }
        return this._instance;
    }

    /**
     * 获取麻将房间列表
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    getMahjongRoomList(requestData, cb, failCb: Function = null) {
        NetConnect.sendRequest(MahjongRoute.ROOM_LIST, requestData, cb, false, failCb);
    }

    /**
     * 创建麻将桌子
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    createMahjongTable(requestData, cb: Function = null) {
        NetConnect.sendRequest(MahjongRoute.CREATE_ROOM, requestData, cb);
    }

    /**
     * 加入麻将桌子
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    joinMahjongTable(requestData, cb: Function = null, failcb: Function = null) {
        NetConnect.sendRequest(MahjongRoute.JOIN_ROOM, requestData, cb, true, failcb)
    }

    /**
     * 加入麻将桌子观战
     * @param requestData 
     * @param cb 
     * @param failCb 
     */
    watchMajongTable(requestData, cb: Function = null, failCb: Function = null) {
        NetConnect.sendRequest(MahjongRoute.WATCH_GAME, requestData, cb, true, failCb);
    }

    /**
     * 进入麻将桌子
     * @param gameData 
     */
    enterMahjongGame(gameData) {
        App.showLog("onPlayerJoinGamePush", gameData)
        MahjongRoomMgr.getInstance().gameData = gameData;
        NetConnect.pomelo.isLoadingScene = true;
        AppEmitter.emit(consts.LOCAL_CLEAR_ROOMSCENETIMER);
        App.changeScene({ sceneName: consts.MAHJONG_SCENE })
    }

    /**
     * 进入回放
     */
    public joinPlayback(tableUuid: string, roundLimit: number) {
        const obj = {
            apiGameId: platform_game_name.Mahjong,
            tableUuid: tableUuid,
            roundLimit: roundLimit,
        }
        HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, consts.HTTP_ROUTE.FIND_PALYER_BACK, obj, (responseData) => {
            const backData = JSON.parse(responseData);
            if (backData.code == 0) {
                App.preloadRes("mahjong", () => {
                    MahjongRoomMgr.getInstance().isBackView = true;
                    MahjongBackModel.initData(backData.data);
                })
            }
        })
    }

    /**
     * 获取创房配置
     * @param data 
     */
    queryCreateRoomConfig(cb) {
        NetConnect.sendRequest(MahjongRoute.GET_ROOM_CONFIG, { gameId: platform_game_id.mahjong_table }, cb);
    }

    /**
     * 重连游戏
     * @param failcb 
     */
    reJoinGame(roomId: number, failcb: Function) {
        NetConnect.sendRequest(MahjongRoute.REJOIN_GAME, { gameId: platform_game_id.mahjong_table, roomId: roomId }, () => { }, true, failcb);
    }

    /**
     * 大厅内拉取玩家战绩
     */
    getGameRecords(requestData, cb) {
        NetConnect.sendRequest(MahjongRoute.GET_GAME_GRADE, requestData, cb);
    }

    /**
     * 房间内对局详情
     * @param requestData 
     * @param cb 
     */
    getGameInfo(requestData, cb) {
        NetConnect.sendRequest(MahjongRoute.GET_GAME_INFO, requestData, cb);
    }

    /**
     * 續房
     * @param requestData 
     * @param cb 
     */
    renewRoom(requestData, cb, failCb) {
        NetConnect.sendRequest(MahjongRoute.RENEW_ROOM, requestData, cb, true, failCb);
    }

    /**
    * 续房邀请，加入房间
    * @param requestData 
    * @param cb 
    */
    confirmJoinRoom(requestData, cb, failCb) {
        NetConnect.sendRequest(MahjongRoute.CONFIRM_JOIN_ROOM, requestData, cb, true, failCb);
    }

    /**
     * 获取是否还有可续房的房间
     */
    getRenewRoom(requestData, cb, failCb) {
        NetConnect.sendRequest(MahjongRoute.GET_RENEW_ROOM, requestData, cb, true, failCb);
    }

    /**
     * 複製房間信息
     */
    copyRoomInfo(roomConfig, shareTextModel: string, roomId: string, roomName: string, shareRoomInfo?: string,) {
        const copyTip = "copy_success";
        const gameName = "揪咖台灣麻將";
        const password = roomConfig.password;
        const anteStr: string = roomConfig.baseScore.toString();
        const pointStr: string = roomConfig.fanPoint.toString();
        const personNumStr: string = roomConfig.maxPlayerNum + "人";
        const roundNumStr: string = roomConfig.maxRoundNum + "圈";
        let topStr: string = "";
        if (roomConfig.maxFan == 0) {
            topStr = "無限台";
        } else {
            topStr = roomConfig.maxFan + "台";
        }

        let createType = ["普通牌桌", "代開牌桌", "公開牌桌"]
        const roomType: string = createType[roomConfig.createType - 1];

        let payCreateType = ["主揪支付", "AA支付"];
        const payType: string = payCreateType[roomConfig.costType - 1];
        const flowerStr: string = roomConfig.hasFlowerCard ? "有花" : "無花";
        const roomSetStr: string = roomConfig.isWatchGame ? "允許觀戰" : "不允許觀戰";

        let specialPlayStr = "暫無";
        if (roomConfig.isReadyHand) {
            specialPlayStr += " 限聽";
        }
        if (roomConfig.isLimitSelfDraw) {
            specialPlayStr += " 限自摸";
        }
        if (roomConfig.isAutoHu) {
            specialPlayStr += " 強制胡牌";
        }
        if (roomConfig.isDealerNoPoint) {
            specialPlayStr += " 莊家無台";
        }
        if (roomConfig.hasFlowerWord) {
            specialPlayStr += " 見花見字";
        }
        specialPlayStr = this.repliceEmptyStr(specialPlayStr);

        let specialTypeStr = "暫無";
        if (roomConfig.hasTianDi) {
            specialTypeStr += " 天胡、地胡";
        }
        if (roomConfig.hasRobFlower) {
            specialTypeStr += " 七搶一";
        }
        if (roomConfig.hasEightFlower) {
            specialTypeStr += " 八枝花";
        }
        specialTypeStr = this.repliceEmptyStr(specialTypeStr);

        if (cc.sys.isNative) {

            const shareText: string = Utils.formatStr(shareTextModel, gameName, roomName, roomId, password, roomType, anteStr, pointStr,
                topStr, flowerStr, personNumStr, roundNumStr, roomSetStr, specialPlayStr, specialTypeStr, payType, '');
            // let success = Utils.copyToClipBoard(shareText);
            // if (success) {
            App.showToast(copyTip);
            //}
        } else {
            if (consts.isAccessPlatform) {

                let gameId = Utils.getUrlGameId()["gameid"];
                const roomInfo: string = Utils.formatStr(shareRoomInfo, gameName, roomName, roomId, password, roomType, anteStr, pointStr,
                    topStr, flowerStr, personNumStr, roundNumStr, roomSetStr, specialPlayStr, specialTypeStr, payType);

            } else {
                const shareUrl: string = Utils.splicingParameters({ tableJoinKey: roomConfig.tableJoinKey })
                const shareText: string = Utils.formatStr(shareTextModel, gameName, roomName, roomId, password, roomType, anteStr, pointStr,
                    topStr, flowerStr, personNumStr, roundNumStr, roomSetStr, specialPlayStr, specialTypeStr, payType, shareUrl);
                let success = Utils.copyToClipBoard(shareText);
                if (success) {
                    App.showToast(copyTip);
                }
            }
        }
    }

    repliceEmptyStr(str) {
        let newStr = "";
        if (str.length > 2) {
            newStr = str.replace("暫無 ", "");
        }
        return newStr;
    }

    getIsIncludeActivities(startTime: number, endTime: number) {
        if (startTime && endTime) {
            let currectTime = Utils.getCurrentTimestamp();
            return currectTime >= startTime && currectTime <= endTime;
        } else {
            return false;
        }
    }

}