
const { ccclass, property } = cc._decorator;
import Emitter from "../network/AppEmitter"
import consts = require("../model/Consts");
import App from "./App";
import NetConnect from "../network/NetConnect";
import { Utils } from "./Utils";
import { GAME_PRESERVE, platform_game_id, platform_game_name } from "../common/ClientEnum";
import RoomMgr from "./RoomMgr";
import AppEmitter from "../network/AppEmitter";
import PlayerMgr from "./PlayerMgr";

import { platform } from "../model/Consts";
import { sceneNameManger } from "../common/sceneNameManger";

import gameEventTrackingMgr, { GameEventTrackingTypeId } from "./gameEventTrackingMgr";
@ccclass
export default class SceneMgr extends cc.Component {
    onLoad() {
        //将该节点设为常驻节点
        cc.game.addPersistRootNode(this.node);
        /* 游戏进入前台 */
        cc.game.on(cc.game.EVENT_SHOW, function () {
            cc.log('game enter foreground');
            cc.director.resume();
            if (!App.isPlayVideo) {
                cc.audioEngine.resumeAll();
            }
            if (!App.isCustomerPlayBack) {
                if (!((App.currentScene == consts.lOADING_SCENE || App.currentScene == consts.LOGIN_SCENE) && !consts.isAccessPlatform)) {
                    NetConnect.connect(() => {
                        if (App.currentScene == consts.lOADING_SCENE) {
                            let component = cc.find("Canvas").getComponent("LoadScene");
                            if (component) {
                                component.enterGame();
                            }
                        } else {
                            RoomMgr.getInstance().gameSceneConnectAgain();
                        }
                        AppEmitter.emit(consts.LOCAL_GAME_BACK_SHOW);
                    });
                }
            }
        });
        /* 游戏进入后台 */
        cc.game.on(cc.game.EVENT_HIDE, function () {
            cc.audioEngine.pauseAll();
            cc.log('game enter background');


            NetConnect.disConnect();
            if (!((App.currentScene == consts.lOADING_SCENE || App.currentScene == consts.LOGIN_SCENE || App.currentScene == consts.battleHallScene) && !consts.isAccessPlatform)) {
                if (cc.find('Canvas/loadNode')) {
                    cc.find('Canvas/loadNode').stopAllActions();
                    cc.find('Canvas/loadNode').removeFromParent();
                }
            }
        });
        /**
       * 切换场景
       */
        Emitter.on(consts.LOCAL_EVENT_CHANGE_SCENE, function (data) {
            App.currentScene = data.sceneName;
            App.showLoading();
            if (!consts.isAccessPlatform && data.orientation) {
                App.setGameViewOrientation(data.orientation);
            }
            gameEventTrackingMgr.getInstance().onChangeSceneLoading(data.sceneName);
            cc.director.loadScene(data.sceneName, () => {
                App.hideLoading();
                gameEventTrackingMgr.getInstance().onChangeSceneScuess(data.sceneName);

            });
            // if(data.sceneName != App.currentScene){
            //     popupPanelEventCallback("loadNode",data);
            // }else{
            //     cc.director.loadScene(data.sceneName);
            // }
        });
        /**
       * 切换场景执行加载完成回调
       */
        Emitter.on(consts.LOCAL_EVENT_CHANGE_SCENE_WITH_CB, function (data) {
            App.currentScene = data.sceneName;
            App.showLoading();
            cc.director.loadScene(data.sceneName, () => {
                App.hideLoading();
                if (data.cb) {
                    data.cb();
                }
            });
            // if(data.sceneName != App.currentScene){
            //     popupPanelEventCallback("loadNode",data);
            // }else{
            //     cc.director.loadScene(data.sceneName);
            // }
        });

        /**
         * 加载prefab动画
         */
        var prefabLoadAnimation = function (node: cc.Node) {
            let bgNode = node.getChildByName("bg");
            if (bgNode) {
                bgNode.stopAllActions();
                bgNode.setScale(0);
                cc.tween(bgNode)
                    .to(0.2, { "scale": 1.2 })
                    .to(0.1, { "scale": 1 })
                    .start()
            }
        }
        /**
         * 加载弹窗prefab
         * @param {*} prefabName   名称
         * @param {*} opts         参数
         * @param {*} zIndex       层级
         * @param {*} cb           prefab对象回调
         */
        var popupPanelEventCallback = function (prefabName: string, opts: any, zIndex: number = 1000, cb: Function = null) {
            var prefabPath = 'prefab/' + prefabName;
            if (cc.find('Canvas').getChildByName(prefabName)) {
                cc.find('Canvas').getChildByName(prefabName).stopAllActions();
                cc.find('Canvas').getChildByName(prefabName).removeFromParent();
                return;
            }
            cc.resources.load(prefabPath, cc.Prefab, function (error, prefab) {
                if (error) {
                    cc.error(error);
                    return;
                }
                var instance = cc.instantiate(<cc.Prefab>prefab);
                cc.find('Canvas').addChild(instance);
                instance.getComponent(cc.Widget) && instance.getComponent(cc.Widget).updateAlignment();
                prefabLoadAnimation(instance);
                //cc.find("Canvas/alert").addChild(instance);
                if (prefabName.indexOf("/") > -1) {
                    prefabName = prefabName.substr(prefabName.indexOf("/") + 1);
                }
                var controlComponent = instance.getComponent(prefabName);
                controlComponent && controlComponent.init && controlComponent.init(opts); //所有弹出层控制组件都应实现这个函数，确保触发事件时传递的参数能传递到界面

                instance.zIndex = zIndex;
                instance.active = true;

                cb && cb(null, instance);
            });
        };

        /* 面板弹窗等 */
        Emitter.on(consts.LOCAL_EVENT_POPUP_PANEL, function (eventData: Object) {
            let prefabName: string = eventData["prefabName"];
            let opts: object = eventData["opts"];
            opts = opts || {};
            cc.log('=====show popup prefab %s=====', prefabName, opts);
            popupPanelEventCallback(prefabName, opts["data"], opts["zIndex"] || 1000);
        });
        /**获取加载条 */
        var getLoadingBox = function (zIndex: number, cb: Function) {
            var tipBox = cc.find('Canvas/tipBox');
            if (!tipBox) return;
            tipBox.zIndex = zIndex;
            cb(null, tipBox);
        };

        /* loading 显示加载条*/
        Emitter.on(consts.LOCAL_EVENT_POPUP_LOADING, function (tip: string) {
            //zIndex=1300
            getLoadingBox(1600, function (err: Error, tipBox: cc.Node) {
                tipBox.getComponent('tipBox').showWait(tip);
                tipBox.active = true;
            });
        });
        /**隐藏加载条 */
        Emitter.on(consts.LOCAL_EVENT_CLOSE_LOADING, function () {
            //zIndex=1300
            getLoadingBox(1600, function (err: Error, tipBox: cc.Node) {
                tipBox && tipBox.getComponent('tipBox').hideWait();
            });
        });
        /* tip 提示语框*/
        Emitter.on(consts.LOCAL_EVENT_POPUP_TIP, function (tipData: any) {
            //zIndex=1300
            if (tipData) {//非空的时候才显示
                getLoadingBox(1600, function (err: Error, tipBox: cc.Node) {
                    tipBox.getComponent('tipBox').showTip(tipData);
                    tipBox.active = true;
                });
            }
        });
        /* 提示框 */
        Emitter.on(consts.LOCAL_EVENT_POPUP_DIALOG, function (opts: object) {
            opts = opts || {};
            //这里直接显示onLoad时载入的prefab，并修改一些内容，zIndex=100
            popupPanelEventCallback('dialogBox', opts, opts["zIndex"] || 1400);
        });
        /**
         * 断线提示框
         */
        Emitter.on(consts.LOVAL_EVENT_NET_DISCONNECT, () => {
            cc.director.resume();
            App.hideLoading();
            let opts = {
                contentLabel: "game_net_disconnect",
                confirmLabel: "connect",
                cancleLabel: "exit",
                confirmCallback: () => {
                    if (!((App.currentScene == consts.lOADING_SCENE || App.currentScene == consts.LOGIN_SCENE) && !consts.isAccessPlatform)) {
                        NetConnect.connect(() => {
                            if (cc.find("Canvas/netConnetDialogBox")) {
                                cc.find("Canvas/netConnetDialogBox").removeFromParent();
                            }
                            if (App.currentScene == consts.lOADING_SCENE) {
                                let component = cc.find("Canvas").getComponent("LoadScene");
                                if (component) {
                                    component.enterGame();
                                }
                            } else {
                                //骰宝短线重连特殊处理
                                RoomMgr.getInstance().gameSceneConnectAgain(platform_game_id.sicbo);
                            }
                        });
                    }
                },
                cancleCallback: () => {
                    if (cc.find("Canvas/netConnetDialogBox")) {
                        cc.find("Canvas/netConnetDialogBox").removeFromParent();
                    }
                    if (cc.sys.isNative) {
                        App.exitGame();
                    } else {
                        if (consts.isAccessPlatform) {
                            App.exitGame();
                        } else {
                            if (cc.find("Canvas/netConnetDialogBox")) {
                                cc.find("Canvas/netConnetDialogBox").removeFromParent();
                            }
                        }
                    }
                }
            }
            if (!App.isManualDisconnect) {
                if (cc.find("Canvas/netConnetDialogBox")) {
                    return;
                }
                if (!NetConnect.pomelo.isConnected) {
                    popupPanelEventCallback('netConnetDialogBox', opts, 1500);
                }
            } else {
                App.isManualDisconnect = false;
            }
        });

        /**
         * 维护提示框
         */
        Emitter.on(consts.LOCAL_EVENT_GAME_MAINTENANCE, () => {
            App.hideLoading();
            let opts = {
                contentLabel: "game_maintenance",
                okCallback: () => {
                    App.exitGame();
                }
            }
            popupPanelEventCallback('dialogBox', opts, 1500);
        });
        /**
         * 正在其他游戏的提示
         */
        Emitter.on(consts.LOCAL_EVENT_PLAYING_OTHER_GAME, (str) => {
            App.hideLoading();
            let opts = {
                contentLabel: "already_other_game",
                params: [str],
                okCallback: () => {
                    App.exitGame();
                }
            }
            popupPanelEventCallback('dialogBox', opts, 1500);
        });
        /**
        * 加載遊戲中的彈窗
        */
        Emitter.on(consts.LOCAL_EVENT_GAME_POPUL, (opts) => {
            let prefabName = opts.prefabName;
            let prefabPath = opts.prefabPath;
            let prefabComponent = opts.prefabComponent;
            let notAction = opts.notAction;
            if (prefabName && prefabPath) {
                if (cc.find('Canvas').getChildByName(prefabName)) {
                    cc.find('Canvas').getChildByName(prefabName).stopAllActions();
                    cc.find('Canvas').getChildByName(prefabName).removeFromParent();
                    return;
                }
                App.gameBundle.load(prefabPath + "/" + prefabName, cc.Prefab, function (error, prefab) {
                    if (error) {
                        cc.error(error);
                        return;
                    }
                    if (cc.find('Canvas').getChildByName(prefabName)) {
                        return;
                    }
                    var instance = cc.instantiate(<cc.Prefab>prefab);
                    cc.find('Canvas').addChild(instance);
                    instance.getComponent(cc.Widget) && instance.getComponent(cc.Widget).updateAlignment();
                    if (!notAction) {
                        prefabLoadAnimation(instance);
                    }

                    if (prefabComponent) {
                        var controlComponent = instance.getComponent(prefabComponent);
                        //@ts-ignore
                        if (prefabComponent && controlComponent && controlComponent.init) {
                            //@ts-ignore
                            controlComponent.init(opts.data);
                        }
                    }

                    if (opts.zIndex) {
                        instance.zIndex = opts.zIndex;
                    }
                    instance.active = true;
                });
            }
        });

        /**
         * 监听服务端测试日志
         */
        Emitter.on(consts.ON_SERVER_TEST_LOG, (data) => {
            let timestamp = new Date();
            App.showLog("onBackEndLog:" + timestamp, data);
        });

        /**
         * 错误日志的监听和上传sdk
         */
        let sendMskForSDK = (errMsg, file, line) => {

        }
        if (cc.sys.isNative) {
            //@ts-ignore
            window.__errorHandler = function (errMsg, file, line, message, error) {

                sendMskForSDK(JSON.stringify(error.stack), file, line);
            }
        } else {
            window.onerror = (errMsg, file, line, message, error) => {

                sendMskForSDK(JSON.stringify(error.stack), file, line);
            }
        }
        //维护消息的监听
        Emitter.on(consts.ON_GLOBAL_MESSAGE, (data) => {

            switch (data.messageId) {
                case GAME_PRESERVE.NORMAL: //游戏正常
                    App.globalStatus = data.messageId;
                    break;
                case GAME_PRESERVE.LIMIT: //表示游戏进入受限状态 玩家部分功能不可操作（对房卡类游戏的表现为创房按钮与代开按钮置灰）
                    Emitter.emit(consts.LOCAL_REFRESH_AGENT_LIST, { page: 1, size: 4 });
                    App.globalStatus = data.messageId;
                    break;
                case GAME_PRESERVE.ENTER_PRESERVE://表示游戏进入彻底维护（暂不用处理 一般会发6）
                    Emitter.emit(consts.LOCAL_EVENT_GAME_MAINTENANCE);
                    break;
                case GAME_PRESERVE.NOTICE_1:   //向玩家发出游戏维护的通知 1（仅通知）
                    App.showToast("global_notice1");
                    break;
                case GAME_PRESERVE.NOTICE_2:   //向玩家发出游戏维护的通知 2（仅通知）
                    App.showToast("global_notice2");
                    break;
                case GAME_PRESERVE.EXIT_GAME: //将收到该消息的玩家强制踢回平台大厅
                    App.exitGame();
                    break;
                case GAME_PRESERVE.PRESERVE_DIALOG://向收到该消息的玩家弹出游戏维护面板
                    Emitter.emit(consts.LOCAL_EVENT_GAME_MAINTENANCE);
                    break;
            }
        });

        // 提示推送
        Emitter.on(consts.GAME_ON_FLASH, (data) => {
            cc.log("=====onFlash===", data);
            App.showToast(data.code);
        });

        //全局主钱包/平台币金钱变更推送
        Emitter.on(consts.GAME_ON_MAIN_MONEY_CHANGED, (data) => {
            cc.log("=====onMainMoneyChanged===", data);
            // 刷新玩家平台币
            PlayerMgr.getInstance().money = data.money;
            Emitter.emit(consts.LOCAL_EVENT_UPDATEPLAYERGOLD);
        });

        //主钱包/平台币呼叫破产储值
        Emitter.on(consts.GAME_ON_RECHARGE, (data) => {
            cc.log("=====onRecharge===", data);
            // 弹出破产储值
            Emitter.emit(consts.LOCAL_EVENT_SHOW_RECHARGE);
        });

        //提示连接断开
        Emitter.on(consts.GAME_NOTICE_TIME_OUT_MESSAGE, () => {
            const showScenes = [consts.sanShuiScenes.SAN_SHUI_GAME_SCENE, consts.sanShuiScenes.SAN_SHUI_ROOM_SCENE, consts.MAHJONG_ROOM_LIST_SCENE, consts.MAHJONG_SCENE, consts.sixCardPokerScenes.SIX_CARD_POKER_GAME_SCENE, consts.sixCardPokerScenes.SIX_CARD_POKER_ROOM_SCENE, consts.TEXAS_POKER_L_LOBBY_SCENE, consts.TEXAS_POKER_L_ROOM_LIST_SCENE, consts.TEXAS_POKER_L_SCENE];
            if (showScenes.indexOf(App.currentScene) > -1) {
                App.hideLoading();
                console.log("=====net will be disconnected===");
                //  App.showToast("net_will_be_disconnect", 3);
                let opts = {
                    contentLabel: "net_will_be_disconnect",
                    confirmLabel: "connect",
                    cancleLabel: "exit",
                    confirmCallback: () => {
                        NetConnect.connect(() => {
                            if (cc.find("Canvas/netConnetDialogBox")) {
                                cc.find("Canvas/netConnetDialogBox").removeFromParent();
                            }
                            RoomMgr.getInstance().gameSceneConnectAgain();
                        });
                    },
                    cancleCallback: () => {
                        if (cc.find("Canvas/netConnetDialogBox")) {
                            cc.find("Canvas/netConnetDialogBox").removeFromParent();
                        }
                        if (cc.sys.isNative) {
                            App.exitGame();
                        } else {
                            if (consts.isAccessPlatform) {
                                App.exitGame();
                            } else {
                                if (cc.find("Canvas/netConnetDialogBox")) {
                                    cc.find("Canvas/netConnetDialogBox").removeFromParent();
                                }
                            }
                        }
                    }
                }
                // if (!NetConnect.pomelo.isConnected) {
                popupPanelEventCallback('netConnetDialogBox', opts, 1500);
                //}
                NetConnect.disConnect();
            }
        });

        /** 在线时间达到条件*/
        // Emitter.on(consts.ON_GUEST_TIMEOUT_MESSAGE,()=>{
        //     App.hideLoading();
        //     let opts = {
        //         contentLabel: "game_guest_experience_end",
        //         okCallback: () => {
        //            // App.exitGame();
        //         }
        //     }
        //     popupPanelEventCallback('dialogBox', opts, 1500);
        // });

        /** 游客加入房间失败*/
        Emitter.on(consts.LOCAL_GUEST_JOIN_GAME_FAIL, (data) => {
            App.hideLoading();
            let opts = {
                contentLabel: data.msg,
                okCallback: () => {
                    // App.exitGame();
                }
            }
            popupPanelEventCallback('dialogBox', opts, 1500);
        });

        /**
        * 监听服务端公共调试消息
        */
        Emitter.on(consts.ON_GLOBAL_PUBLICPUSH, (data) => {
            App.showLog("publicPush:" + new Date(), data);
        });

    }
}
