
import AppEmitter from "../network/AppEmitter";

import App from "./App";
import consts = require("./Consts");

export class Utils {

    static format(parmas1 = null, parmas2 = null) {
        var as = [].slice.call(arguments), fmt = as.shift(), i = 0;
        return fmt.replace(/%(\w)?(\d)?([dfsx])/ig, function (_, a, b, c) {
            var s = b ? new Array(b - 0 + 1).join(a || '') : '';
            if (c == 'd') s += parseInt(as[i++]);
            return b ? s.slice(b * -1) : s;
        })
    }

    static formatStr(fstr: string, ...params: any[]) {
        if (typeof fstr !== 'string') {
            var objects = [];
            for (var i = 0; i < arguments.length; i++) {
                //@ts-ignore
                objects.push(inspect(arguments[i]));
            }
            return objects.join(' ');
        }
        var i = 1;
        var args = arguments;
        var len = args.length;
        var formatRegExp = new RegExp("%%|%s|%d|%j", "g");
        //@ts-ignore
        var str = String(fstr).replace(formatRegExp, function (x) {
            if (x === '%%') return '%';
            if (i >= len) return x;
            switch (x) {
                case '%s':
                    return String(args[i++]);
                case '%d':
                    return Number(args[i++]);
                case '%j':
                    return JSON.stringify(args[i++]);
                default:
                    return x;
            }
        });
        for (var x = args[i]; i < len; x = args[++i]) {
            if (x === null || typeof x !== 'object') {
                str += ' ' + x;
            } else {
                //@ts-ignore
                str += ' ' + inspect(x);
            }
        }
        return str;
    }

    /**
     * 验证是否全为数字
     */
    static checkEditStringIsNum(str: string): Boolean {
        //var reg = /^[0~9]+.?[0~9]*$/;
        for (var i = 0; i < str.length; i++) {
            cc.log("stringInt ===", parseInt(str.charAt(i)));
            if (!(parseInt(str.charAt(i)) >= 0 && parseInt(str.charAt(i)) < 10)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 验证电话号码 
     */
    static checkPhoneEditStringIsNum(id: string): Boolean {
        if (!id || typeof (id) != 'string' || id.length != 11 || !id.match(/^[0-9]{11}$/)) {
            return false;
        }
        return true;
    }


    /**
     * 格式化分数
     */
    static formatGarde(label: cc.Label, grade: number) {
        label.string = grade > 0 ? ("+" + grade) : grade.toString();
        label.node.color = grade >= 0 ? (new cc.Color(10, 240, 28)) : (new cc.Color(240, 22, 22));
    }

    /**
     * 根据时间戳计算时间差
     * @param {*} tiemStamp 
     */
    static getTimerFromTimeStamp(tiemStamp: number) {
        let currentTimeStamp = Date.parse(new Date().toString()) / 1000;
        return (currentTimeStamp - tiemStamp);
    }

    /**
     * 获取某个区域的随机点
     * @param {*} point  区域坐标
     * @param {*} width  区域宽度
     * @param {*} height 区域高度
     */
    static getRandomPosInRect(area: cc.Node): cc.Vec2 {
        let point = area.getPosition();
        let width = area.width;
        let height = area.height;
        let startPointX = point.x - width / 2;
        let startPointY = point.y - height / 2;
        let addX = Math.random() * width;
        let addY = Math.random() * height;
        return cc.v2(startPointX + addX, startPointY + addY);
    }

    /**
     * 获取url参数键值
     */
    static getHttpKeysAndValus(): Object {
        var url = window.document.location.href.toString(); //获取的完整url
        var u = url.split("?");
        if (typeof (u[1]) == "string") {
            u = u[1].split("&");
            var get = {};
            for (var i in u) {
                var j = u[i].split("=");
                get[j[0]] = j[1];
            }
            return get;
        } else {
            return {};
        }
    }

    /**
     * url转小写
     * @returns 
     */
    static getUrlGameId() {
        let url = window.document.location.href.toLowerCase();
        var u = url.split("?");
        if (typeof (u[1]) == "string") {
            u = u[1].split("&");
            var get = {};
            for (var i in u) {
                var j = u[i].split("=");
                get[j[0]] = j[1];
            }
            return get;
        } else {
            return {};
        }
    }

    /**
     * 不区分大小写获取参数
     */
    static getUrlParamsNotCaseSensitive() {
        let url = window.document.location.href.toLowerCase();
        var u = url.split("?");
        if (typeof (u[1]) == "string") {
            u = u[1].split("&");
            var get = {};
            for (var i in u) {
                var j = u[i].split("=");
                get[j[0]] = j[1];
            }
            return get;
        } else {
            return {};
        }
    }

    /**
     * 分享URL回调
     * @returns 
     */
    static urlParse() {
        var url = window.document.location.href.toString();
        var u = url.split("?");
        if (typeof (u[1]) == "string") {
            u = u[1].split("$@");
            var get = {};
            for (var i in u) {
                var j = u[i].split("=");
                get[j[0]] = j[1];
            }
            return get;
        } else {
            return {};
        }
    }

    /**
     * 设置多语言文字
     * @param label 
     * @param name 
     * @param params 
     */
    static setLabelStrForLanguage(label: cc.Label | cc.Node, name: string, params: string[] = []) {
        label.getComponent("i18nLabel").init(name, params);
    }

    /**
     * 设置多语言图片
     * @param sprite 
     * @param name 
     */
    static setSpriteStrForLanguage(sprite: cc.Sprite | cc.Node, name: string) {
        if (sprite.getComponent("i18nSprite")) {
            //sprite.getComponent("i18nSprite").string = name;
            sprite.getComponent("i18nSprite").refreshSpriteFrame(name);
        }
    }

    /**
     * 设置多语言spine动画
     * @param spineNode 
     * @param name 
     */
    static setSpineStrForLanguage(spineNode: cc.Node, spineName: string, aniName: string) {
        spineNode.getComponent("i18nSpine").init(spineName, aniName);
    }

    /**
     * 设置本地图片资源
     * @param sprite 
     * @param path 
     */
    static setLoacalSpriteFrame(sprite: cc.Sprite | cc.Node, path: string) {
        cc.resources.load(path, cc.SpriteFrame, (err, texture: cc.SpriteFrame) => {
            if (err) {
                console.error("load local spriteFrame err ", path);
                return;
            }
            sprite.getComponent(cc.Sprite).spriteFrame = texture;
        });
    }

    /**
     * 设置富文本多语言文字
     * @param richText 
     * @param name 
     * @param params 
     */
    static setRichTextStrForLanguage(richText: cc.RichText | cc.Node, name: string, params: string[] = []) {
        richText.getComponent("i18nRichText").init(name, params);
    }

    /**
     * 加载本地预制资源
     * @param path 
     * @param bundle 
     */
    static loadLocalPrefab(path: string, bundle: cc.AssetManager.Bundle, parentNode: cc.Node) {
        bundle.load(path, cc.Prefab, (error, prefab) => {
            if (error) {
                console.log("load prefab err", path);
                return;
            }
            parentNode.addChild(cc.instantiate(<cc.Prefab>prefab));
        });
    }

    /**
     * 设置远程图片资源
     * @param sprite 
     * @param path 
     */
    static setRemoteSpriteFrame(sprite: cc.Sprite | cc.Node, path: string) {
        if (path) {
            if (App.spriteCache.get(path)) {
                sprite.getComponent(cc.Sprite).spriteFrame = App.spriteCache.get(path);
            } else {
                cc.assetManager.loadRemote(path, (err, texture: any) => {
                    if (err) {
                        console.error("load romate spriteFrame err", path);
                        return;
                    }
                    var spriteFrame = new cc.SpriteFrame(texture);
                    App.spriteCache.set(path, spriteFrame);
                    sprite.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                });
            }
        }
    }

    /**
     * 获取最后一位的数字
     */
    static getLastNum(str: string) {
        for (let i = str.length - 1; i >= 0; i--) {
            let charCode = str.charCodeAt(i);
            if (charCode > 47 && charCode < 58) {
                return str.charAt(i);
            }
        }
    }

    /**
     * 格式化筹码数额
     */
    static formatCoinNum(num: number, isLower: boolean = false): string {
        if (num >= 0) {
            let numStr = num.toString();
            if (num >= 1000 && num < 1000000) {
                numStr = num / 1000 + (isLower ? "k" : "K");
            } else if (num >= 1000000 && num < 1000000000) {
                numStr = num / 1000000 + (isLower ? "m" : "M");
            } else if (num >= 1000000000 && num < 1000000000000) {
                numStr = num / 1000000000 + (isLower ? "b" : "B");
            } else if (num >= 1000000000000) {
                numStr = num / 1000000000000 + (isLower ? "t" : "T");
            }
            return numStr;
        } else {
            return num.toString();
        }
    }

    /**
     * 向下保留两位小数
     * @param value 
     * @param length 
     */
    static floorrRound(value: number, length: number) {
        return Math.round(Math.floor(value * Math.pow(10, length))) / Math.pow(10, length);
    }

    /**
     * 数字千分位分割
     * @param num 
     */
    static formatNumDistance(num) {
        //    if(num > 999999999.99){
        //      num = 999999999.99;
        //    }
        let numStrs = num.toString().split(".");
        let integeStr = numStrs[0].replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
        if (numStrs.length > 1) {
            return integeStr + "." + numStrs[1];
        } else {
            return integeStr;
        }
    }

    /**
     * 格式化金额
     */
    static formatMoneyNum(num: number): string {
        let numStr: string = num.toString();
        if (num >= 1000000 && num < 1000000000) {
            numStr = this.formatNumDistance(this.floorrRound(num / 1000000, 2)) + "M";
            //numStr = (num / 1000000).toFixed(2) + "M";
        } else if (num >= 1000000000) {
            if (num >= 100000000000000) {
                numStr = "999,999.99" + "B";
            } else {
                //numStr = (num / 1000000000).toFixed(2) + "B"
                numStr = this.formatNumDistance(this.floorrRound(num / 1000000000, 2)) + "B"
            }
        } else {
            numStr = this.formatNumDistance(num.toFixed(2));
        }
        return numStr;
    }

    /**
     * @param num 数值
     * @param length 保留的小数位
     * @param isLower 字母大小写
     */
    static formatUnit(num: number, length: number, isLower: boolean = false): string {
        let numStr = Math.floor(num).toString();
        if (num >= 1000 && num < 1000000) {
            numStr = this.floorrRound(num / 1000, length) + (isLower ? "k" : "K");
        } else if (num >= 1000000 && num < 1000000000) {
            numStr = this.floorrRound(num / 1000000, length) + (isLower ? "m" : "M");
        } else if (num >= 1000000000 && num < 1000000000000) {
            numStr = this.floorrRound(num / 1000000000, length) + (isLower ? "b" : "B");
        } else if (num >= 1000000000000) {
            numStr = this.floorrRound(num / 1000000000000, length) + (isLower ? "t" : "T");
        }
        return numStr;
    }

    /**
     * 特殊格式 1万以下全部显示，1万以上显示单位
     * @param num 数值
     * @param length 保留的小数位
     * @param isLower 字母大小写
     */
    static formatUnitSpecial(num: number, length: number, isLower: boolean = false): string {
        let numStr = Math.floor(num).toString();
        if (num >= 10000 && num < 1000000) {
            numStr = this.floorrRound(num / 1000, length) + (isLower ? "k" : "K");
        } else if (num >= 1000000 && num < 10000000000) {
            numStr = this.floorrRound(num / 1000000, length) + (isLower ? "m" : "M");
        } else if (num >= 1000000000 && num < 1000000000000) {
            numStr = this.floorrRound(num / 1000000000, length) + (isLower ? "b" : "B");
        } else if (num >= 1000000000000) {
            numStr = this.floorrRound(num / 1000000000000, length) + (isLower ? "t" : "T");
        }
        return numStr;
    }

    /**
     * 
     * @param num 数值
     */
    static formatToJiazi(num: number): string {
        let numberlist = [1000, 1000000, 1000000000, 1000000000000];
        let str = ["K", "M", "B", "T"];
        const len = parseInt(num.toString()).toString().length;
        let number = Math.floor(num);
        if (len > 10) {
            for (let i = 0; i < numberlist.length; i++) {
                const element = numberlist[i];
                const num = this.floorrRound(number / element, 0);
                const len2 = parseInt(num.toString()).toString().length;
                if (len2 < 10) {
                    return this.formatNumDistance(num) + str[i];
                }
            }
        }
        return this.formatNumDistance(number);
    }

    /***
     * 4位有效数字 
     */
    static formatUnitFour(num: number, length: number, isLower: boolean = false) {
        let str = ""
        let numStr = num.toString();
        if (num >= 10000 && num < 1000000) {
            str = isLower ? "k" : "K"
            numStr = this.floorrRound(num / 1000, length).toString()
        } else if (num >= 1000000 && num < 10000000000) {
            str = isLower ? "m" : "M"
            numStr = this.floorrRound(num / 1000000, length).toString()
        } else if (num >= 1000000000 && num < 1000000000000) {
            str = isLower ? "b" : "B"
            numStr = this.floorrRound(num / 1000000000, length).toString()
        } else if (num >= 1000000000000) {
            str = isLower ? "t" : "T"
            numStr = this.floorrRound(num / 1000000000000, length).toString()
        }

        if (numStr.length >= 5) {
            let len = 0
            let numStr1 = ""
            for (let i = 0; i < numStr.length; i++) {
                if (len == 4) {
                    break
                }
                numStr1 += numStr[i]

                if (numStr[i] != ".") {
                    len++
                }
            }
            numStr = Number(numStr1).toString()
        }
        return numStr + str;
    }

    /**
     * 将一个节点装换为另一个节点的坐标
     * @param worldNode 
     * @param node 
     */
    static changToNodePoint(worldNode, node) {
        let worldPos = worldNode.parent.convertToWorldSpaceAR(worldNode.position)
        let nodePos = node.convertToNodeSpaceAR(worldPos);
        return nodePos;
    }

    /**
     * 获取字符串字节长度
     * @param val 
     */
    static getStringLength(val: string): number {
        var str = new String(val);
        var bytesCount: number = 0;
        for (var i = 0, n = str.length; i < n; i++) {
            var c = str.charCodeAt(i);
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                bytesCount += 1;
            } else {
                bytesCount += 2;
            }
        }
        return bytesCount;
    }

    /**
     * 昵称截取
     * @param nickName 
     */
    static tailoringNickName(nickName: string): string {
        let limitLength = 12;
        if (!consts.isAccessPlatform) {
            limitLength = 13;
        } else {

            limitLength = 13;

        }
        let newStr = nickName;
        if (nickName && this.getStringLength(nickName) > limitLength) {
            let newName = "";
            for (let i = 0; i < nickName.length; i++) {
                newName = newName + nickName.charAt(i);
                if (this.getStringLength(newName) == limitLength) {
                    newStr = newName + "...";
                } else if (this.getStringLength(newName) == (limitLength + 1)) {
                    newStr = newName.substring(0, newName.length - 1) + "...";
                }
            }
        }
        return newStr;
    }

    /**
     * ＜4个字，就最后1个字用*代替
     * ≥4个字，就最后2个字用*代替
     * @param nickName 
     * @returns 
     */
    static nickNameChange(nickName: string, isShowPoint: boolean = true) {
        let limitLen: number = 4;
        let limitLength = 12;
        if (!consts.isAccessPlatform) {
            limitLength = 12;
        } else {

            limitLength = 13;

        }
        let newStr = nickName;
        if (nickName && this.getStringLength(nickName) > limitLength) {
            let newName = "";
            for (let i = 0; i < nickName.length; i++) {
                newName = newName + nickName.charAt(i);
                if (this.getStringLength(newName) == limitLength) {
                    newStr = newName;
                } else if (this.getStringLength(newName) == (limitLength + 1)) {
                    newStr = newName.substring(0, newName.length - 1);
                }
            }
        }

        if (newStr.length > limitLen) {
            if (this.getStringLength(newStr) == limitLength) {
                newStr = newStr.substring(0, newStr.length - 2) + "**";
            } else {
                if (isShowPoint) {
                    newStr = newStr.substring(0, newStr.length - 2) + "**...";
                } else {
                    newStr = newStr.substring(0, newStr.length - 2) + "**";
                }
            }
        } else {
            newStr = newStr.substring(0, newStr.length - 1) + "*";
        }

        return newStr;
    }


    /**
     * 截取昵称
     * @param name 昵称
     * @param length 保留长度
     */
    static subStringNickName(name: string, length: number): string {
        let newName = name;
        if (name.length >= length + 1) {
            newName = name.substring(0, length) + "...";
        }
        return newName;
    }

    /**
     * 获取某个区域的随机点
     * @param {*} point  区域坐标
     * @param {*} width  区域宽度
     * @param {*} height 区域高度
     */
    static getRandomPosInRect1(point, width, height, num) {
        let startPointX = point.x - width / 2;
        let startPointY = point.y - height / 2;
        let addX = 15;
        let addY = 15 + num * 5;
        return cc.v2(startPointX + addX, startPointY + addY);
    }

    /**
     * 获取当前时间戳
     * @returns 
     */
    static getCurrentTimestamp() {
        return Date.parse(new Date().toString());
    }

    /**
     * 根据时间格式获取时间戳
     */
    static getTimestampForFormat(timeFormat: string) {
        if (timeFormat) {
            return new Date(timeFormat).getTime();
        } else {
            return 0;
        }
    }

    /**
     * 根据时间戳计算时间
     */
    static timestampToTime(timestamp, type) {
        let format = (num) => {
            let newStr = "";
            if (num > 9) {
                newStr = num.toString();
            } else {
                newStr = "0" + num;
            }
            return newStr;
        }
        var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        var Y = date.getFullYear() + '/';
        var M = format(date.getMonth() + 1) + "/";
        var D = format(date.getDate()) + ' ';
        var h = format(date.getHours()) + ':';
        var m = format(date.getMinutes());
        var s = format(date.getSeconds());
        if (type == 1) {
            return Y + M + D + h + m;
        } else {
            return M + D + h + m;
        }
    }

    static formatTimestamp2(timestamp: number) {
        let format = (num) => {
            let newStr = "";
            if (num > 9) {
                newStr = num.toString();
            } else {
                newStr = "0" + num;
            }
            return newStr;
        }
        var date = new Date(timestamp);
        var Y = date.getFullYear() + '/';
        var M = format(date.getMonth() + 1) + "/";
        var D = format(date.getDate());
        return Y + M + D;
    }

    static timestampToTime3(timestamp, type) {
        let format = (num) => {
            let newStr = "";
            if (num > 9) {
                newStr = num.toString();
            } else {
                newStr = "0" + num;
            }
            return newStr;
        }
        var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        var Y = date.getFullYear() + '年';
        var M = format(date.getMonth() + 1) + "月";
        var D = format(date.getDate()) + '日';
        var h = format(date.getHours()) + ':';
        var m = format(date.getMinutes());
        var s = format(date.getSeconds());
        if (type == 1) {
            if (consts.language == "en") {
                // ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Spt","Oct","Nov","Dec"]
                let months = [
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                ];
                return `${months[date.getMonth()]} ${format(date.getDate())},${date.getFullYear()}`;
            }
            return Y + M + D + ", " + h + m;
        } else {
            return M + D + h + m;
        }
    }

    /**
     * 初始化时间戳
     */
    static formatTimestamp(timestamp: number, format: string) {
        let formatNum = (num) => {
            let newStr = "";
            if (num > 9) {
                newStr = num.toString();
            } else {
                newStr = "0" + num;
            }
            return newStr;
        }
        var date = new Date(timestamp.toString().length == 10 ? timestamp * 1000 : timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        var Y = date.getFullYear() + "";
        var M = formatNum(date.getMonth() + 1);
        var D = formatNum(date.getDate());
        var h = formatNum(date.getHours());
        var m = formatNum(date.getMinutes());
        var s = formatNum(date.getSeconds());
        let str = format;
        let strY = str.replace("Y", Y);
        let strM = strY.replace("M", M);
        let strD = strM.replace("D", D);
        let strh = strD.replace("h", h);
        let strm = strh.replace("m", m);
        let newStr = strm.replace("s", s);
        return newStr;
    }

    /**
     * 数字补全，不足补0
     * @param num    当前数字   
     * @param length 数字长度
     */
    static prefixInteger(num, length) {
        return (Array(length).join('0') + num).slice(-length);
    }

    /**
     * 四舍五入
     * @param value 需要处理的值
     * @param pos 保留的小数位数
     */
    static round(value: number, length: number) {
        return Math.round(value * Math.pow(10, length)) / Math.pow(10, length);
    }

    /**
     * 小数转化为百分比
     * @param point 
     */
    static toPercent(point) {
        let str = Number(point * 100).toFixed(0);
        str += "%";
        return str;
    }

    /**
     * 强制保留2位小数
     */
    static fomatFloat(num) {
        return (parseInt(num * 100 + "") / 100).toFixed(2);
    }

    static getPointsAngle(start, end) {
        var angle = Math.atan2((end.x - start.x), (end.y - start.y))  //弧度  
        var theta = angle * (180 / Math.PI);  //角度 
        return theta;
    }

    /**
     * 数字为整数时，小数位补0
     */
    static getFloatStr(num) {
        num += '';
        num = num.replace(/[^0-9|\.]/g, ''); //清除字符串中的非数字非.字符

        if (/^0+/) {
            //清除字符串开头的0
            num = num.replace(/^0+/, '');
        }
        if (!/\./.test(num)) {
            //为整数字符串在末尾添加.00
            num += '.00';
        }
        if (/^\./.test(num)) {
            //字符以.开头时,在开头添加0
            num = '0' + num;
            num += '00';        //在字符串末尾补零
            num = num.match(/\d+\.\d{2}/)[0];
        }
        return num;
    }

    static randomNumber(min, max) {
        let fRound = Math.floor(Math.random() * (max - min + 1) + min);
        return fRound;
    }

    /**
     * 获取存储数据
     * @param key 
     */
    static getItem(key: string): any {
        let itemData = cc.sys.localStorage.getItem(key);
        let data = null;
        if (itemData) {
            data = JSON.parse(itemData);
        }
        return data;
    }

    /**
     * 保存存储数据
     * @param key 
     * @param data 
     */
    static setItem(key: string, data: any) {
        if (data) {
            let itemData = JSON.stringify(data);
            if (itemData) {
                cc.sys.localStorage.setItem(key, itemData);
            }
        }
    }

    /**
     * @param key 删除指定存储数据
     */
    static removeItem(key: string) {
        cc.sys.localStorage.removeItem(key);
    }

    /**
     * 舍弃小数点后的数字
     */
    static onDealPoint(value) {
        if (typeof (value) === "string") {
            return value.replace(/\.\d+/g, '');
        } else if (typeof (value) === "number") {
            return Number(value.toString().replace(/\.\d+/g, ''));
        }
    }

    /**
     * web端复制文字
     */
    static copyToClipBoard(str: string): boolean {
        var input = str + '';
        const el = document.createElement('textarea');
        el.value = input;
        el.setAttribute('readonly', '');
        // el.style.contain = 'strict';
        el.style.position = 'absolute';
        el.style.left = '-9999px';
        el.style.fontSize = '12pt'; // Prevent zooming on iOS

        const selection = getSelection();
        var originalRange = null;
        if (selection.rangeCount > 0) {
            originalRange = selection.getRangeAt(0);
        }
        document.body.appendChild(el);
        el.select();
        el.selectionStart = 0;
        el.selectionEnd = input.length;

        var success = false;
        try {
            success = document.execCommand('copy');
        } catch (err) { }

        document.body.removeChild(el);

        if (originalRange) {
            selection.removeAllRanges();
            selection.addRange(originalRange);
        }
        if (success) {
            cc.log("复制成功");
        } else {
            cc.log("复制失败");
        }
        return success;
    }

    /**加载远程json文件 */
    static loadRemoteFile(url: string) {
        // 测试
        url = "http://192.168.3.180:18080/asset/ShieldedWord.json";
        cc.assetManager.loadRemote(url, (err, jsonAsset: cc.JsonAsset) => {
            if (err) {
                cc.log("远程文件加载失败");
            } else {
                cc.log(JSON.stringify(jsonAsset.json));
            }
        })
    }

    /**
     * 验证输入文本是否合法不合法替换为*
     * @param inputTxt 输入文本
     * @param txts 屏蔽字库
     * @returns 返回新的字符串
     */
    static checkInputTxtIsRight(inputTxt: string, txts: string[]): string {
        if (inputTxt) {
            for (let i = 0; i < inputTxt.length; i++) {
                txts.forEach(str => {
                    var reg = new RegExp(str);
                    if (reg.test(inputTxt)) {
                        let symbol = "";
                        for (let index = 0; index < str.length; index++) {
                            symbol += "*";
                        }
                        inputTxt = inputTxt.replace(str, symbol);
                    }
                })
            }
        }
        return inputTxt;
    }

    static connectParasForHttpUrl(url: string, jsonData: Object) {
        let connectUrl = "";
        if (jsonData) {
            let keys = Object.keys(jsonData);
            keys.forEach((element, index) => {
                if (index == 0) {
                    connectUrl = connectUrl + "?" + element + "=" + jsonData[element];
                } else {
                    connectUrl = connectUrl + "&" + element + "=" + jsonData[element];
                }
            });
        }
        return url + connectUrl;
    }

    /**
     * 处理金币最大值
     * @param currectMoney 
     * @param moneyLabel 
     */
    static moneyMaxProcess(currectMoney, moneyLabel) {
        if (currectMoney > consts.MAX_COIN) {
            moneyLabel.string = Utils.formatNumDistance(consts.MAX_COIN);
        } else {
            moneyLabel.string = Utils.formatNumDistance(currectMoney.toFixed(2));
        }
    }

    /**
     * 房卡游戏链接拼接参数
     */
    static splicingParameters(gameInfo: object) {
        let localUrl: string = window.document.location.href.toString();
        if (localUrl.indexOf("?") < 0) {
            localUrl += "?";
        }
        for (const key in gameInfo) {
            if (Object.prototype.hasOwnProperty.call(gameInfo, key)) {
                const element = gameInfo[key];
                let value = this.getHttpKeysAndValus()[key]
                if (value) {
                    localUrl = localUrl.replace(value, element);
                    //this.getHttpKeysAndValus()[key] = element;
                } else {
                    localUrl += ("&" + key + "=" + element);
                }
            }
        }
        if (localUrl.charAt(localUrl.indexOf("?") + 1) == "&") {
            localUrl = localUrl.slice(0, localUrl.indexOf("?") + 1) + localUrl.slice(localUrl.indexOf("?") + 2);
        }

        return localUrl;
    }

    static onFilterEmoji(str) {
        return str = str.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, "");
    }

    /** 加法 */
    static onAdd(a: number, b: number) {
        //@ts-ignore
        return new Decimal(a).add(new Decimal(b)).toNumber();
    }

    /** 减法 */
    static onSub(a: number, b: number) {
        //@ts-ignore
        return new Decimal(a).sub(new Decimal(b)).toNumber();
    }

    /** 乘法 */
    static onMul(a: number, b: number) {
        //@ts-ignore
        return new Decimal(a).mul(new Decimal(b)).toNumber();
    }

    /** 除法 */
    static onDiv(a: number, b: number) {
        //@ts-ignore
        return new Decimal(a).div(new Decimal(b)).toNumber();
    }

    /**
     * SDK破產彈窗
     */
    static showSDKOpenBroken() {

    }

    /**
     * SDK跑马灯
     * @param nodeMarquee 
     */
    static showSDKMarquee(nodeMarquee) {

    }

    /**
     * 角子平台bigInt数值转换
     * @param str 
     * @returns 
     */
    static checkNumberUnit(str) {
        const unit = str[str.length - 1];
        let num = Number(str.substr(0, str.length - 1));
        if (unit == "C") {
            num = num * 1;
        } else if (unit == "K") {
            num = num * 1000;
        } else if (unit == "M") {
            num = num * 1000000;
        } else if (unit == "B") {
            num = num * 1000000000;
        } else if (unit == "T") {
            num = num * 1000000000000;
        }
        return num;
    }

    static getObject(obj) {
        if (Object.keys(obj).length === 0) {
            return false;
        }
        return true;
    }

}