/**
 * 游戏入口 
 * 游戏数据的初始化
 */
import Net from "../network/NetConnect"
import Emitter from "../network/AppEmitter"
import AudioMgr from "./AudioMgr";
import consts = require("../model/Consts");
import { i18nMgr } from "../i18n/i18nMgr";
import { GameViewOrientation, GAME_PRESERVE } from "../common/ClientEnum";
import { Utils } from "./Utils";

import { jaoziPlatfromSdk } from "../sdk/jiaoziPlatFormSdk";
export default class App {
    constructor() {
        this.init();
    }
    static currentScene = "loadScene";          //当前场景
    static isManualDisconnect = false;          //是否手动断线
    static isRefrshGold = false;                //是否需要刷新金币
    static isBetChip = false;                   //是否下注
    static isWatchGame = false;                 //是否觀戰
    static isGameStart = false;                 //遊戲是否開始
    static isPlayVideo = false;
    static isCustomerPlayBack = false;
    static globalStatus = GAME_PRESERVE.NORMAL; //维护状态
    static gameBundle: cc.AssetManager.Bundle = null;
    static miniGameBundle: cc.AssetManager.Bundle = null;
    public static spriteCache = new Map();        //图片缓存
    public static spineCache = new Map();         //动画缓存
    public static audioCache = new Map();         //声音缓存
    public static fontCache = new Map();          //字体缓存
    /** 房间昵称屏蔽字库 */
    public static shieldDatas: any[] = [];

    static outOpenList = null;

    public init() {
        //打包构建后读取配置中的参数
        if (CC_BUILD) {
            //@ts-ignore
            if (window.ws_adress) {
                //@ts-ignore
                consts.ws_adress = window.ws_adress;
            }
            //@ts-ignore
            if (window.language) {
                //@ts-ignore
                consts.language = window.language;
            }

            //@ts-ignore
            consts.isAccessPlatform = window.isAccessPlatform;

            //@ts-ignore
            consts.isBattleHall = window.isBattleHall;

            //@ts-ignore
            if (window.appVersion) {
                //@ts-ignore
                consts.appVersion = window.appVersion;
            }
            //@ts-ignore
            if (window.platform) {
                //@ts-ignore
                consts.platform = window.platform;
            }
            //@ts-ignore
            if (window.chessReqUrl) {
                //@ts-ignore
                consts.chessReqUrl = window.chessReqUrl;
            }
            if (App.getBundleVersion('client')) {
                consts.appVersion = App.getBundleVersion('client');
            }
        }
        Net.init();
        Emitter.init();
        AudioMgr.init();
        //多语言
        i18nMgr.setLanguage(consts.language);

    }
    /**
     * 切换场景
     * @param sceneName 
     */
    public static changeScene(data: object) {
        Emitter.emit(consts.LOCAL_EVENT_CHANGE_SCENE, data);
    }
    /**
     * 切换场景添加场景加载完成回调
     * @param sceneName 
     */
    public static changeSceneWithCb(data: object) {
        Emitter.emit(consts.LOCAL_EVENT_CHANGE_SCENE_WITH_CB, data);
    }
    /**
     * 加载弹窗
     * @param eventData 
     */
    public static loadPopalPanel(eventData: Object) {
        Emitter.emit(consts.LOCAL_EVENT_POPUP_PANEL, eventData);
    }
    /**
     * 加载提示框
     * @param eventData 
     */
    public static loadDialogBox(eventData: Object) {
        Emitter.emit(consts.LOCAL_EVENT_POPUP_DIALOG, eventData);
    }
    /**显示加载条 */
    public static showLoading() {
        Emitter.emit(consts.LOCAL_EVENT_POPUP_LOADING);
    }
    /**隐藏加载条 */
    public static hideLoading() {
        Emitter.emit(consts.LOCAL_EVENT_CLOSE_LOADING);
    }
    /**
     * 弹出吐司
     * @param tip        提示文字
     * @param delayTime  提示显示时间
     */
    public static showToast(tip: string, delayTime: number = 0, params: string[] = []) {
        cc.log("showToast : " + tip)
        Emitter.emit(consts.LOCAL_EVENT_POPUP_TIP, { "tip": tip, "tipTime": delayTime, params: params });
    }
    /**
     * 打印日志
     * @param name 日志名称
     * @param data 日志数据
     */
    public static showLog(name: string, data: object) {
        cc.log(name + ":" + JSON.stringify(data));
    }

    /**
     * 加载场景和资源
     */

    public static preloadRes(name, cb) {
        let prefabPath = "prefab/loadNode"
        cc.resources.load(prefabPath, cc.Prefab, function (error, prefab) {
            if (error) {
                cc.error(error);
                return;
            }
            var instance = cc.instantiate(<cc.Prefab>prefab);
            instance.zIndex = 1500;
            cc.find('Canvas').addChild(instance);
            instance.getComponent("loadNode").init(name, cb);
        });
    }
    /**
     * 加载场景和资源
     */
    public static preloadMultiRes(name, cb) {
        let prefabPath = "prefab/loadNode"
        cc.resources.load(prefabPath, cc.Prefab, function (error, prefab) {
            if (error) {
                cc.error(error);
                return;
            }
            var instance = cc.instantiate(<cc.Prefab>prefab);
            instance.zIndex = 1500;
            cc.find('Canvas').addChild(instance);
            instance.getComponent("loadNode").initHasBonus(name, cb);
        });
    }
    public static loadGamePopul(data) {
        Emitter.emit(consts.LOCAL_EVENT_GAME_POPUL, data);
    }
    public static removePanel(panelName: string) {
        const panel = cc.find("Canvas/" + panelName);
        if (panel) {
            panel.destroy();
        }
    }
    /**
     * 退出游戏，调用平台方法
     */
    public static exitGame() {
        console.log("退出游戏");

    }
    /**
     * 刷新好运和平台金币
     */
    public static refreshPlatformScore() {

    }
    /**
     * 清除声网缓存
     */
    public static clearAgoraCache() {

    }
    /**
     * 判断是否是行动官网游客登录
     * @returns 
     */
    public static getIsGuestLogin(): boolean {
        const playerentertype = Utils.getUrlGameId()[consts.playerEnterName];
        return consts.isAccessPlatform && playerentertype && playerentertype == consts.playerEnterType
    }
    /**
     * 设置屏幕方向
     */
    public static setGameViewOrientation(orientation: number) {
        if (cc.sys.isMobile) {
            // if (orientation == GameViewOrientation.Portrait) {
            //     cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
            // } else {
            //     cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
            // }
            cc.view.setOrientation(cc.macro.ORIENTATION_AUTO);
            cc.view.enableAutoFullScreen([
                cc.sys.BROWSER_TYPE_BAIDU,
                cc.sys.BROWSER_TYPE_BAIDU_APP,
                cc.sys.BROWSER_TYPE_WECHAT,
                cc.sys.BROWSER_TYPE_MOBILE_QQ,
                cc.sys.BROWSER_TYPE_MIUI,
                cc.sys.BROWSER_TYPE_HUAWEI,
                cc.sys.BROWSER_TYPE_UC,
                //@ts-ignore
            ].indexOf(cc.sys.browserType) < 0);
        }
    }
    /**
     * 判断当前设置是否是竖屏
     */
    public static isPortraitOrientation(): boolean {
        //@ts-ignore
        var settings = window._CCSettings;
        return settings && settings.orientation === 'portrait';
    }

    public static getBundleVersion(bundleName: string): string {
        //@ts-ignore
        if (Window._ModuleVersionConfig && Window._ModuleVersionConfig[bundleName]) {
            if (consts.serverVersion) {
                //@ts-ignore
                return "client:" + Window._ModuleVersionConfig[bundleName] + " server:" + consts.serverVersion;
            } else {
                //@ts-ignore
                return "client:" + Window._ModuleVersionConfig[bundleName];
            }
        }
        return consts.appVersion;
    }
}
