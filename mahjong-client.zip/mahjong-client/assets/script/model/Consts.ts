
const consts = {
  /**配置信息 */


  ws_adress: "wss://gs.jojo99.dev/conn",

  /**http请求地址 和资源加载路径*/
  videoWebAdress: "",
  chessReqUrl: {
    HttpAdress: "http://35.229.253.75:3106/",
    sensitiveWordsAdress: "",
  },

  /**遊戲語言 */
  language: "tw",
  /** 遊戲版本號 */
  appVersion: "v-1.2.0",
  /** server版本号 */
  serverVersion: "",
  /** 是否接入平台*/
  isAccessPlatform: false,
  /** 接入平台名稱*/
  platform: "default",
  /** 是否是对战馆 */
  isBattleHall: false,

  RESPONSE_CODE_OK: 0,//响应成功
  MAX_COIN: 9999999999.99,

  /* 本地事件 */
  LOCAL_EVENT_CHANGE_SCENE: "localEventChangeScene",                    //切换场景
  LOCAL_EVENT_CHANGE_SCENE_WITH_CB: "localEventChangeSceneWithCB",      //切换场景执行加载完成回调
  LOCAL_EVENT_POPUP_PANEL: "localEventPopupPanel",                      //弹窗
  LOCAL_EVENT_POPUP_LOADING: "localEventPopupLoading",                  //显示loading
  LOCAL_EVENT_CLOSE_LOADING: "localEventCloseLoading",                  //隐藏loading  
  LOCAL_EVENT_POPUP_TIP: "localEventPopupTip",                          //tip
  LOCAL_EVENT_POPUP_DIALOG: "localEventPopupDialog",                    //提示框
  LOCAL_EVENT_REFRESH_PERSON: "localEventRefreshPerson",                //刷新玩家
  LOVAL_EVENT_NET_DISCONNECT: "net_disconnect",                         //网络连接断开
  LOCAL_EVENT_GAME_MAINTENANCE: "localEventMaintenance",                //游戏维护中
  LOCAL_EVENT_PLAYING_OTHER_GAME: "localPlayingOtherGame",              //正在其他游戏中的提示
  LOCAL_EVENT_NET_REFRESH_PHOTO: "refreshPhoto",                        //刷新头像
  LOCAL_ECENT_CLOCK_LAST_SIX: "clockFor6",                              //倒计时六秒
  LOCAL_EVENT_SHOWCHIPSEIINGVIEW: "showChipSettingView",                //筹码设置页面 
  LOLAL_EVENT_SHOWGAMERULEVIEW: "showGameRuleView",                     //三张扑克游戏规则页面
  LOCAL_EVENT_SHOWGUIDEAWARDVIEW: "showGuideAwardView",                 //三张扑克新手引导奖励界面
  LOCAL_EVENT_GAME_POPUL: "loadGamePopul",
  LOCAL_EVENT_SHOWTEACHVIDEO: "showTeachVideo",                         //三张扑克教学影片
  LOCAL_EVENT_UPDATEPLAYERGOLD: "updatePlayerGold",                     //更新玩家金币数量
  LOCAL_EVENT_SHOW_RECHARGE: "showRecharge",                            //弹出破产储值
  LOCAL_REFRESH_AGENT_LIST: "refreshAgentList",                         //刷新代开列表
  LOCAL_RELEASE_PERSIST_ROOT_NODE: "releasePersistRootNode",            //释放常驻节点 
  LOCAL_CLEAR_ROOMSCENETIMER: "clearRoomSceneTimer",                    //进房间的时候清除RoomScene定时器
  LOCAL_CURRECT_SCENE_JUMP_SCHEDULE: "currectSceneJumpSchedule",        //当前场景跳转的倒计时
  LOCAL_GAME_BACK_SHOW: "gameBackShow",                                 //遊戲切後台回來
  LOCAL_GAME_NOT_ENOUGH_GOLD: "notEnoughGoldCoins",                     //金币不足提示
  LOCAL_GAME_REACH_BET_LIMIT: "reachBetLimit",                          //达到押注上限提示
  LOCAL_GUEST_JOIN_GAME_FAIL: "guestJoinGameFail",
  LOCAL_BATTLE_SEAT_HINT: "battleHallSeatHint",                         //对战馆点击有人座位提示

  /** 监听服务端测试日志 */
  ON_SERVER_TEST_LOG: "onBackEndLog",
  /** 设置玩家状态、是否新手 */
  ON_SET_PLAYERSTATUS: "lobby.lobbyHander.setNewPlayerStatus",
  /** 维护的监听 */
  ON_GLOBAL_MESSAGE: "onGlobalMaintainMessage",
  /**公共调试消息 */
  ON_GLOBAL_PUBLICPUSH: "publicPush",

  /**游戏大厅请求接口 */
  GAME_LOGIN: "connector.enterHandler.enter",                                                     //游戏登录       
  GAME_GET_AGAIN_GAME_LIST: "connector.enterHandler.getGameList",                                 //获取断线列表
  GAME_QUERY_BLACK_JACK_TABLE_LIST: "lobby.blackJackLobbyHandler.queryTableList",                 //获取21点桌子列表
  GAME_BLACK_JACK_JOIN_TABLE: "lobby.blackJackLobbyHandler.joinTable",                            //21点进入桌子
  GAME_QUICK_JOIN_BLACK_JACK_TABLE: "lobby.blackJackLobbyHandler.quickJoinGame",                  //21点快速加入游戏
  GAME_QUERY_BLACK_JACK_ROOM_LIST: "lobby.blackJackLobbyHandler.queryRoomList",                   //21点获取房间列表
  GAME_JOIN_GAME_AGAIN: "blackJack.gameHandler.reJoinGame",                                       //重新进入游戏
  GAME_QUERY_CORNCUPIA_ROOM_LIST: "lobby.cornucopia.roomList",
  GAME_CORNCUPIA_JOIN_TABLE: "cornucopia.game.enterRoom",
  GAME_QUERY_JOIN_KEY_INFO: "connector.enterHandler.queryJoinKeyInfo",                            //查询进桌子密钥信息

  GAME_QUERY_MAGIC_BLACK_JACK_TABLE_LIST: "lobby.magicBlackJackLobbyHandler.queryTableList",      //获取倍率21点桌子列表
  GAME_MAGIC_BLACK_JACK_JOIN_TABLE: "lobby.magicBlackJackLobbyHandler.joinTable",                 //倍率21点进入桌子
  GAME_MAGIC_QUICK_JOIN_BLACK_JACK_TABLE: "lobby.magicBlackJackLobbyHandler.quickJoinGame",       //倍率21点快速加入游戏
  GAME_MAGIC_QUERY_BLACK_JACK_ROOM_LIST: "lobby.magicBlackJackLobbyHandler.queryRoomList",        //倍率21点获取房间列表
  GAME_MAGIC_JOIN_GAME_AGAIN: "magicBlackJack.gameHandler.reJoinGame",                            //倍率重新进入游戏

  GAME_QUERY_CLASSIC_BLACK_JACK_TABLE_LIST: "lobby.classicBlackJackLobbyHandler.queryTableList",  //获取经典21点桌子列表
  GAME_CLASSIC_BLACK_JACK_JOIN_TABLE: "lobby.classicBlackJackLobbyHandler.joinTable",             //经典21点进入桌子
  GAME_CLASSIC_QUICK_JOIN_BLACK_JACK_TABLE: "lobby.classicBlackJackLobbyHandler.quickJoinGame",   //经典21点快速加入游戏
  GAME_CLASSIC_QUERY_BLACK_JACK_ROOM_LIST: "lobby.classicBlackJackLobbyHandler.queryRoomList",    //经典21点获取房间列表
  GAME_CLASSIC_JOIN_GAME_AGAIN: "classicBlackJack.gameHandler.reJoinGame",                        //经典重新进入游戏
  GAME_CLASSIC_GET_CONFIG: "classicBlackJack.gameHandler.webConfig",                              //获取好运21点配置

  GAME_QUERY_THREE_CARDS_TABLE_LIST: "lobby.threeCardLobbyHandler.queryTableList",                //三张扑克获取桌子列表
  GAME_THREE_CARDS_JOIN_TABLE: "lobby.threeCardLobbyHandler.joinTable",                           //三张扑克进入桌子
  GAME_QUICK_JOIN_THREE_CARDS_TABLE: "lobby.threeCardLobbyHandler.quickJoinGame",                 //三张扑克快速加入游戏
  GAME_QUERY_THREE_POKER_ROOM_LIST: "lobby.threeCardLobbyHandler.queryRoomList",                  //三张获取房间列表
  GAME_QUERY_THREE_POKER_CHANGE_TABLE: "lobby.threeCardLobbyHandler.changeTable",                 //三张获换桌

  GAME_CHANGE_PHOTO: "lobby.lobbyHander.changeAvatar",                  //更换头像
  GAME_GET_PERSON_DATA: "lobby.lobbyHander.getUserInfo",                //获取玩家信息 
  GAME_GET_RECORD: "lobby.lobbyRecord.queryGameRecord",                 //获取战绩记录
  GAME_QUERY_MONEY_RECORD: "lobby.lobbyRecord.queryMoneyRecord",        //获取额度记录
  GAME_QUERY_RECORD_COUNT: "lobby.lobbyRecord.queryAllGameRecordCount", //获取记录游戏数目
  GAME_DATA: "GAME_DATA",                                               //服务器推送的桌子信息
  GAME_QUERY_PLAYER_MONEY: "lobby.lobbyHander.asyncSiteMoney",          //查询玩家金币数
  GAME_ON_FLASH: "onFlash",                                             //向前端推送该消息，会在前端滑出对应的文字提示
  GAME_ON_MAIN_MONEY_CHANGED: "onMainMoneyChanged",                     //全局主钱包/平台币金钱变更推送
  GAME_ON_RECHARGE: "onRecharge",                                       //当玩家平台币不足以支撑继续游戏时，向前端推送该消息，进入破产储值环节

  GAME_QUERY_HORSE_ROOM_LIST: "lobby.horseRaceLobby.roomList",          //赛马房间列表
  GAME_HORSE_JOIN_TABLE: "horseRace.game.enterRoom",                    //赛马加入房间

  GAME_QUERY_DOUBLING_ROOM_LIST: "lobby.doublingFaceOffLobby.roomList", //翻倍房间列表
  GAME_DOUBLING_JOIN_TABLE: "doublingFaceOff.game.enterRoom",           //翻倍加入房间

  GAME_BACK_PLAY: "lobby.lobbyRecord.findPlayBack",                     //回放

  DoublingFaceChecking: "doublingFace.game.checking",

  /** 游客登录*/
  GAME_QUERY_ENTER_CONSTOMER: "connector.guestEnterHandler.enter",
  /** 在线时间达到条件*/
  ON_GUEST_TIMEOUT_MESSAGE: "onGuestTimeoutMessage",
  /** 对战馆新手标识接口 */
  Get_isGameNewPlayer: "lobby.lobbyHander.isGameNewPlayer",

  // 德州扑克横版
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_CREATE_BY_ME: "texasPokerRoom.privateRoom.createByMe",  //查询自己创建的房间列表
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_COMMON: "texasPokerRoom.privateRoom.common",            //查询私人厅的公桌列表
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_GET_CONFIG: "texasPokerRoom.privateRoom.getConfig",     //查询私人配置
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_CREATE: "texasPokerRoom.privateRoom.create",            //创建私人房间/桌子
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_QUERY: "texasPokerRoom.privateRoom.query",              //查询私人房间/桌子
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_CONFIRM: "texasPokerRoom.privateRoom.confirm",          //准备进入私人房间/桌子
  GAME_TEXAS_POKER_L_PRIVATE_ROOM_JOIN: "texasPokerRoom.privateRoom.join",                //加入私人房间/桌子
  GAME_TEXAS_POKER_L_PUBLIC_ROOM_JOIN: "texasPokerRoom.publicRoom.join",                  //加入公共房间
  GAME_TEXAS_POKER_L_HISTORY_SUMMARY: "texasPokerRoom.history.summary",                   //查询个人/代开战绩汇总信息
  GAME_TEXAS_POKER_L_HISTORY_LIST: "texasPokerRoom.history.list",                         //查询某桌内的战绩（包括个人/代开）
  GAME_TEXAS_POKER_L_GET_HISTORY: "texasPokerRoom.history.load",                          //查看战绩
  GAME_TEXAS_POKER_L_GET_STATISTICS: "texasPokerRoom.statistics.get",                     //玩家的统计数据
  GAME_NOTICE_TIME_OUT_MESSAGE: "onNoticeTimeoutMessage",                                 //断线前提示

  /* 场景名 */
  lOADING_SCENE: "loadScene",
  LOGIN_SCENE: "loginScene",
  LOBBY_SCENE: "lobbyScene",
  GANE_BJACK_JACK_SCENE: "blackJackScene",
  BLACK_JACK_TABLE_SCENE: "blackJackTableScene",
  BLACK_JACK_ROOM_LIST_SCENE: "blackJackRoomScene",

  MAGIC_BLACK_JACK_SCENE: "magicBlackJackScene",
  MAGIC_JACK_TABLE_SCENE: "magicBlackJackTableScene",
  MAGIC_JACK_ROOM_SCENE: "magicBlackJackRoomScene",

  CLASSIC_BLACK_JACK_SCENE: "classicBlackJackScene",
  CLASSIC_JACK_TABLE_SCENE: "classicBlackJackTableScene",
  CLASSIC_JACK_ROOM_SCENE: "classicBlackJackRoomScene",

  /** 德州撲克 */
  TEXAS_POKER_L_LOBBY_SCENE: "texasPokerLLobbyScene",
  TEXAS_POKER_L_ROOM_LIST_SCENE: "texasPokerLRoomScene",
  TEXAS_POKER_L_SCENE: "texasPokerLScene",
  TEXAS_POKER_L_CLUB_SCENE: "texasPokerLClubScene",

  /** 聚宝盆 */
  GAME_CORNUCOPIA_SCENE: "cornucopiaScene",
  CORNCUPIA_ROOM_LIST_SCENE: "cornucopiaRoomScene",

  /** 五彩版聚宝盆 */
  GAME_COLORFULGEMS_SCENE: "colorfulGemsScene",
  COLORFULGEMS_ROOM_LIST_SCENE: "colorfulGemsRoomScene",

  /**三张扑克*/
  GANE_THREE_POKER_SCENE: "threePokerScene",
  THREE_POKER_TABLE_SCENE: "threePokerTableScene",
  THREE_POKER_ROOM_LIST_SCENE: "threePokerRoomScene",

  /** 赛马 */
  GAME_HORSERACING_SCENE: "horseRacingScene",
  HORSE_RACING_ROOM_LIST_SCENE: "horseRacingRoomScene",

  /** 推筒子 */
  PUSHDOTS_SCENE: "pushDotsScene",
  PUSHDOTS_ROOM_LIST_SCENE: "pushDotsRoomScene",

  /** 麻将 */
  MAHJONG_SCENE: "mahjongScene",
  MAHJONG_ROOM_LIST_SCENE: "mahjongRoomScene",

  /** 赛艇 */
  ROWING_SCENE: "rowingScene",
  ROWINGROOM_SCENE: "rowingRoomScene",

  /** 超级牛牛 */
  SUPERCOW_SCENE: "superCowScene",
  SUPERCOW_ROOMSCENE: "superCowRoomScene",

  /** 赛狗 */
  DOGRACING_SCENE: "dogracingScene",
  DOGRACING_ROOMSCENE: "dogracingRoomScene",

  /** 猴王登天 */
  GREATSAGERACING_SCENE: "greatsageracingScene",
  GREATSAGERACING_ROOMSCENE: "greatsageracingRoomScene",

  /** 猴子爬树 */
  MONKEYRACING_SCENE: "monkeyRacingScene",
  MONKEYRACING_RoomScene: "monkeyRacingRoomScene",

  /** 射龙门 */
  CLASSICSHOT_SCENE: "classicshotScene",
  CLASSICSHOT_ROOMSCENE: "classicshotRoomScene",

  /** 倍率射龙门 */
  JOKERSHOTING_SCENE: "jokershotingScene",
  JOKERSHOTING_ROOMSCENE: "jokershotingRoomScene",

  /** 黄金射龙门 */
  GOLDSHOTING_SCENE: "goldshotingScene",
  GOLDSHOTING_ROOMSCENE: "goldshotingRoomScene",

  /**抢庄妞妞 */
  racebullGameScene: "racebullScene",
  racebullRoomScene: "racebullRoomScene",

  /**抢庄推筒子 */
  racedotsGameScene: "racedotsScene",
  racedotsRoomScene: "racedotsRoomScene",

  /** 对战馆 */
  battleHallScene: "battlehallScene",

  /** 二人麻将 */
  mahjongfortwoScene: "mahjongfortwoScene",
  mahjongfortwoRoomScene: "mahjongfortwoRoomScene",

  /** rummy(拉密)遊戲 */
  GAME_RUMMY_SCENE: "rummyScene",
  /** rummy(拉密)選區 */
  RUMMY_ROOM_LIST_SCENE: "rummyRoomScene",
  /** rummy(拉密)選模式 */
  RUMMY_MODE_LIST_SCENE: "rummyModeScene",

  /** 電子輪盤 */
  ROULETTE_ROOM_LIST_SCENE: "rouletteRoomScene",
  ROULETTE_SCENE: "rouletteScene",

  /**妞妞 */
  niuNiuScenes: {
    niuNiuRoomScene: "niuNiuRoomScene",
    niuNiuGameScene: "niuNiuScene"
  },

  /**电子百人德州 */
  casinoholdemScenes: {
    casinoholdemGameScene: "casinoholdemScene",
    casinoholdemRoomScene: "casinoholdemRoomScene"
  },

  /**黄金百人德州 */
  texasholdemScenes: {
    texasholdemGameScene: "texasholdemScene",
    texasholdemRoomScene: "texasholdemRoomScene"
  },

  /**电子骰宝 */
  sicboScenes: {
    sicboGameScene: "sicboScene",
    sicboRoomScene: "sicboRoomScene"
  },

  /**幸运宾果 */
  luckybingoScenes: {
    luckybingoGameScene: "luckybingoScene",
    luckybingoRoomScene: "luckybingoRoomScene"
  },

  /**德扑金币场 */
  texasgoldScenes: {
    texasgoldLobbyScene: "texasgoldLobbyScene",
    texasgoldRoomScene: "texasgoldRoomScene",
    texasgoldScene: "texasgoldScene"
  },

  /* 弹出层名 */
  SETTING_PANEL: "settingPanel",//设置
  RULE_PANEL: "rulePanel",//规则

  /**path */
  SOUND_BG: "Snd_Bg_Music",
  SOUND_PUT_BET: "bet_sound",

  threePokerRoomIds: [10102, 10202, 10302, 10402, 10502],
  threePokerZhiZunRoomIds: [11102, 11202, 11302, 11402, 11502],
  threePokerA777RoomIds: [12102, 12202, 12302, 12402, 12502],

  /**十三水场景 */
  sanShuiScenes: {
    SAN_SHUI_ROOM_SCENE: "sanShuiRoomScene",
    SAN_SHUI_GAME_SCENE: "sanShuiScene"
  },

  /**刷新私人房列表 */
  SANSHUI_REFRESH_PRIVITE_ROOM: "refreshPrivateRoom",
  REFRESH_PUBLIC_ROOM: "refreshPublicRoom",

  /**六花场景 */
  sixCardPokerScenes: {
    SIX_CARD_POKER_ROOM_SCENE: "sixCardPokerRoomScene",
    SIX_CARD_POKER_GAME_SCENE: "sixCardPokerScene"
  },

  DOUBLINGFACEOFF_PLAYBACK_SCENE: "doublingFaceOffPlayBackScene",

  ViewAction: {
    /** 退出h5游戏 */
    ExitGame: 41,
    /***********以下action在全屏webview下，不做自动关闭webview处理*********/
    /** 音乐开关 */
    MusicSwitch: 500,
    /** 音效开关 */
    EffectSwitch: 501,
    /** 用于游戏，在lobbySdk加载完成后, 隐藏web原生关闭按钮 */
    LobbySDKLoaded: 502,
    /** 用于切换横竖屏 */
    OrientationSwitch: 503,
    /** ga数据埋点 */
    GATrackData: 1000,
    /** ga屏幕跟踪 */
    GATrackScreen: 1001,
  },

  Orientation: {
    /**
     * Oriented vertically
     * @property ORIENTATION_PORTRAIT
     * @type {Number}
     */
    ORIENTATION_PORTRAIT: 1,

    /**
     * Oriented horizontally
     * @property ORIENTATION_LANDSCAPE
     * @type {Number}
     */
    ORIENTATION_LANDSCAPE: 2,

    /**
     * Oriented automatically
     * @property ORIENTATION_AUTO
     * @type {Number}
     */
    ORIENTATION_AUTO: 3,
  },

  /*** 游戏名字*/
  GameName: {
    game_1: "三張撲克",
    game_2: "倍率21點",
    game_3: "黃金21點",
    game_4: "好运21點",
    game_5: "聚寶盆",
    game_6: "五色寶石",
    game_9: "德州撲克",
    game_13: "十三張",
    game_29: "翻倍對決",
  },

  HTTP_ROUTE: {
    GET_SHIELDED_WORD: "",
    FIND_PALYER_BACK: "v1/gameApi/findPlayBack",
    GET_AGORA_TOKEN: "v1/gameApi/agoraToken",
    SET_SWITCH_CACHE: "v1/gameApi/setSwitchCache",
    GET_SWITCH_CACHE: "v1/gameApi/getSwitchCache",
    GET_SERVER_VERSION: "v1/gameApi/getVersion"
  },

  playerEnterName: "playerentertype",
  playerEnterType: "guest"

  //   sanShuiVideoUrl:"http://games.maiyun.net.cn/",
  //   sanShuiVideoPackage:"video_test/"
}

export = consts;
