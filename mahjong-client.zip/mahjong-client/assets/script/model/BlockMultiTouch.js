/**
 * 按钮防止连点的设置
 */
cc.Class({
    extends: cc.Component,

    onLoad() {
        //将该节点设为常驻节点
        cc.game.addPersistRootNode(this.node);
        cc.Node.maxTouchNum = 1;
        cc.Node.touchNum = 0;
        this.__dispatchEvent__ = cc.Node.prototype.dispatchEvent;
        let self = this;
        if (!cc.sys.isNative) {
            cc.Node.prototype.dispatchEvent = function (event) {
                switch (event.type) {
                    case 'touchstart':
                        if (cc.Node.touchNum < cc.Node.maxTouchNum) {
                            cc.Node.touchNum++;
                            cc.Node.touchNum = cc.Node.touchNum > 1 ? 1 : cc.Node.touchNum
                            this._canTouch = true;
                            self.__dispatchEvent__.call(this, event);
                        }
                        break;
                    case 'touchmove':
                        if (!this._canTouch && cc.Node.touchNum < cc.Node.maxTouchNum) {
                            this._canTouch = true;
                            cc.Node.touchNum++;
                            cc.Node.touchNum = cc.Node.touchNum > 1 ? 1 : cc.Node.touchNum
                        }

                        if (this._canTouch) {
                            self.__dispatchEvent__.call(this, event);
                        }
                        break;
                    case 'touchend':
                        if (this._canTouch) {
                            this._canTouch = false;
                            cc.Node.touchNum--;
                            cc.Node.touchNum = cc.Node.touchNum < 0 ? 0 : cc.Node.touchNum
                            self.__dispatchEvent__.call(this, event);
                        }
                        break;
                    case 'touchcancel':
                        if (this._canTouch) {
                            this._canTouch = false;
                            cc.Node.touchNum--;
                            cc.Node.touchNum = cc.Node.touchNum < 0 ? 0 : cc.Node.touchNum
                            self.__dispatchEvent__.call(this, event);
                        }
                        break;
                    default:
                        self.__dispatchEvent__.call(this, event);
                }
            };

            var __onPostActivated__ = cc.Node.prototype._onPostActivated;
            cc.Node.prototype._onPostActivated = function (active) {
                if (!active && this._canTouch) {
                    this._canTouch = false;
                    cc.Node.touchNum--;
                    cc.Node.touchNum = cc.Node.touchNum < 0 ? 0 : cc.Node.touchNum
                }
                __onPostActivated__.call(this, active);
            };

            var __onPreDestroy__ = cc.Node.prototype._onPreDestroy;
            cc.Node.prototype._onPreDestroy = function () {
                if (this._canTouch) {
                    this._canTouch = false;
                    cc.Node.touchNum--;
                    cc.Node.touchNum = cc.Node.touchNum < 0 ? 0 : cc.Node.touchNum
                }

                __onPreDestroy__.call(this);
            };
        }

    },

    start() {
    },

    onDestroy() {
        cc.Node.prototype.dispatchEvent = this.__dispatchEvent__;
    },
});
