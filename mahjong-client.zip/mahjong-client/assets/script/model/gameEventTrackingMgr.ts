
import { gameSceneType, platform_game_name } from "../common/ClientEnum";
import { sceneNameManger } from "../common/sceneNameManger";

import consts = require("./Consts");
import PlayerMgr from "./PlayerMgr";
import RoomMgr from "./RoomMgr";
import { Utils } from "./Utils";

/**
 * 点击进入方式
 */
export enum GameEnterType {
    /** 立即玩 */
    gameScene = 1,
    /** 选桌 */
    tableScene = 2,
    /** 选厅 */
    roomScene = 3,
    /** 棋牌大厅 */
    pvplobby = 4,
}

export enum GameEventTrackingTypeId {
    /** 进入选桌loading */
    enterTableLoading = "Lobby_Event_JoinGameLobbyLoading",
    /** 成功进入选桌 */
    enterTableSuccess = "GLobby_Event_LoadingSuccess",
    /** 还没进桌就离开游戏 */
    tableSceneLeave = "GLobby_Click_LeaveGame",
    /** 进入游戏桌loading */
    enterGameLoading = "Lobby_Event_JoinGameLoading",
    /** 成功进入游戏桌 */
    enterGameSuccess = "Game_Event_LoadingSuccess",
    /** 放置筹码 */
    putChip = "Game_Click_BetChips",
    /** 进桌还没放置筹码就离开 */
    noBetLeaveTable = "Game_Event_LeaveGame",
    /** 确认下注 */
    confirmBet = "Game_Click_ConfirmBet",
    /** 取消下注 */
    cancelBet = "009",
    /** 重复下注 */
    repeatBet = "Game_Click_RepeatBet",
    /** 触发'你已下注请等待本局结束' */
    isBetNotLeaveGame = "Game_Event_NotLeaveGame",
    /** 初级桌 */
    primaryTbale = "GLobby_Click_JuniorTable",
    /** 中级桌 */
    mediumTable = "GLobby_Click_IntermediateTable",
    /** 高级桌 */
    seniorTable = "GLobby_Click_AdvancedTable",
    /** 进入配桌loading */
    mateloading = "Game_Event_TableMatchLoading",
    /** 成功匹配 */
    mateSuccess = "Game_Event_TableMatchSuccess",
    /** 取消匹配 */
    cancelMate = "Game_Click_TableMatchLeave",
    /** 再来一局 */
    againMatch = "Game_Click_PlayAgain",
    /** 抢庄妞妞自动准备 */
    racebullAutoReady = "Game_Click_AutoPrepare",
    /** 成功进入黄金德州扑克选玩法界面 */
    enterTexasholdemSelMethod = "GLobby_Event_GoldTexasLoadingSuccess",
    /** 点击casino玩法(百人德州撲克) */
    touchCasinoholdem = "GLobby_Click_TableCasino",
    /** 点击Texas玩法(黃金德州撲克) */
    touchTexasholdem = "GLobby_Click_TableTexas",
    /** 骰宝点击入桌 */
    sicboClickEnterTable = "Lobby_GameIcon_Click_SelectMachine",
}

export enum eventName {
    /** 进入选桌厅loading */
    Lobby_Event_JoinGameLobbyLoading = "進入選桌廳loading",
    /** 成功进入选桌 */
    GLobby_Event_LoadingSuccess = "成功進入選桌廳",
    /** 还没进桌就离开游戏 */
    GLobby_Click_LeaveGame = "還沒進桌就離開遊戲",
    /** 进入游戏桌loading */
    Lobby_Event_JoinGameLoading = "進入遊戲桌loading",
    /** 成功进入游戏桌 */
    Game_Event_LoadingSuccess = "成功進入遊戲桌",
    /** 放置筹码 */
    Game_Click_BetChips = "放置籌碼",
    /** 进桌还没放置筹码就离开 */
    Game_Event_LeaveGame = "進桌但還沒遊戲就離開",
    /** 确认下注 */
    Game_Click_ConfirmBet = "確認下注",
    /** 重复下注 */
    Game_Click_RepeatBet = "重複下注",
    /** 触发'你已下注请等待本局结束' */
    Game_Event_NotLeaveGame = "觸發'你已下注請等待本局結束'",
    /** 初级桌 */
    GLobby_Click_JuniorTable = "初級桌",
    /** 中级桌 */
    GLobby_Click_IntermediateTable = "中級桌",
    /** 高级桌 */
    GLobby_Click_AdvancedTable = "高級桌",
    /** 进入配桌loading */
    Game_Event_TableMatchLoading = "進入配桌loading",
    /** 成功匹配 */
    Game_Event_TableMatchSuccess = "成功配桌",
    /** 取消匹配 */
    Game_Click_TableMatchLeave = "取消匹配",
    /** 再来一局 */
    Game_Click_PlayAgain = "再來一局",
    /** 抢庄妞妞自动准备 */
    Game_Click_AutoPrepare = "自動準備(搶莊妞妞)",
    /** 成功进入黄金德州扑克选玩法界面 */
    GLobby_Event_GoldTexasLoadingSuccess = "成功進入黃金德州撲克介面",
    /** 点击casino玩法(百人德州撲克) */
    GLobby_Click_TableCasino = "casino玩法(黃金德州撲克)",
    /** 点击Texas玩法(黃金德州撲克) */
    GLobby_Click_TableTexas = "Texas玩法(黃金德州撲克)",
    /** 骰宝点击入桌 */
    Lobby_GameIcon_Click_SelectMachine = "點擊入桌"
}

export default class gameEventTrackingMgr {

    public static _instance;

    public enterType: number = 0;

    public static getInstance(): gameEventTrackingMgr {
        if (!this._instance) {
            this._instance = new gameEventTrackingMgr();
        }
        return this._instance;
    }

    setEventTracking(gameId: string, typeId: string) {
        const vcode = Utils.getHttpKeysAndValus()["vcode"];
        const agentId = PlayerMgr.getInstance().agentId;
        let entertype: number = 1;
        let urlGameId: string = Utils.getUrlGameId()["gameid"];
        let entergametype = parseInt(Utils.getHttpKeysAndValus()["entergametype"]);
        if (urlGameId == "pvplobby") {
            if (entergametype) {
                if (entergametype == gameSceneType.roomScene) {
                    entertype = GameEnterType.roomScene;
                } else if (entergametype == gameSceneType.tableScene) {
                    entertype = GameEnterType.tableScene;
                } else if (entergametype == gameSceneType.gameScene) {
                    entertype = GameEnterType.gameScene;
                }
            } else {
                entertype = GameEnterType.pvplobby;
            }
        } else {
            if (entergametype == gameSceneType.roomScene) {
                entertype = GameEnterType.roomScene;
            } else if (entergametype == gameSceneType.tableScene) {
                entertype = GameEnterType.tableScene;
            } else if (entergametype == gameSceneType.gameScene) {
                entertype = GameEnterType.gameScene;
            }
        }
        const obj = {
            Message: eventName[typeId],
            GameRoom: RoomMgr.getInstance().selectRoomId
        }

    }

    setOpenBroken(gameId: string, typeId: string) {
        // this.setEventTracking(gameId, GameEventTrackingTypeId.noEnoughGold);
        // this.setEventTracking(gameId, typeId);
    }

    onChangeSceneLoading(sceneName) {
        const gameId = sceneNameManger.getCurGameId(sceneName);
        if (gameId && gameId != platform_game_name.pvplobby) {
            const isTableScene: boolean = sceneName.endsWith("TableScene");
            const isRoomScene: boolean = sceneName.endsWith("RoomScene");
            if (!isTableScene && !isRoomScene) {
                gameEventTrackingMgr.getInstance().setEventTracking(gameId, GameEventTrackingTypeId.enterGameLoading);
            }
            // 进入选桌厅loading由平台记录
            // if (isTableScene || isRoomScene) {
            //     gameEventTrackingMgr.getInstance().setEventTracking(gameId, GameEventTrackingTypeId.enterTableLoading);
            // }
        }
    }

    onChangeSceneScuess(sceneName) {
        const gameId = sceneNameManger.getCurGameId(sceneName);
        if (gameId) {
            if (gameId != platform_game_name.pvplobby) {
                const isTableScene: boolean = sceneName.endsWith("TableScene");
                if (isTableScene) {
                    gameEventTrackingMgr.getInstance().setEventTracking(gameId, GameEventTrackingTypeId.enterTableSuccess);
                } else {
                    const isRoomScene: boolean = sceneName.endsWith("RoomScene");
                    if (isRoomScene) {
                        gameEventTrackingMgr.getInstance().setEventTracking(gameId, GameEventTrackingTypeId.enterTableSuccess);
                    }
                    if (!isRoomScene) {
                        gameEventTrackingMgr.getInstance().setEventTracking(gameId, GameEventTrackingTypeId.enterGameSuccess);
                    }
                }
            }
        }
    }

    onEnterRoomEvent(gameId, roomId) {
        let evnetType = null;

        if (roomId == 2) {
            evnetType = GameEventTrackingTypeId.primaryTbale;
        } else if (roomId == 3) {
            evnetType = GameEventTrackingTypeId.mediumTable;
        } else if (roomId == 4) {
            evnetType = GameEventTrackingTypeId.seniorTable;
        }
        gameEventTrackingMgr.getInstance().setEventTracking(gameId, evnetType);

    }

}