import App from "./App";

/**
 * 屏幕适配
 */
const { ccclass, property } = cc._decorator;

@ccclass
export default class ScreenAdaption extends cc.Component {

    onLoad() {
        this.refreshAdaptation();
    }

    refreshAdaptation() {
        // const designWidth: number = 1280;
        // const designHeight: number = 720;

        let canvas: cc.Canvas = this.node.getComponent(cc.Canvas);
        const designWidth = canvas.designResolution.width;
        const designHeight = canvas.designResolution.height;
        let designRote = designWidth / designHeight;
        let realSize = cc.view.getFrameSize();
        let realRate = realSize.width / realSize.height;
        console.log('real width:' + realSize.width);
        console.log('real height:' + realSize.height);
        if (designRote > realRate) {
            canvas.fitWidth = true;
            canvas.fitHeight = false;
        } else if (designRote < realRate) {
            canvas.fitWidth = false;
            canvas.fitHeight = true;
        } else {
            canvas.fitWidth = true;
            canvas.fitHeight = true;
        }
    }
}
