/**
 * 音效管理
 */
import consts = require("../model/Consts");
import App from "./App";
export default class AudioMgr {

    public static bgmVolume: number = 1.0;

    public static sfxVolume: number = 1.0;

    public static bgmAudioID: number = -1;
    public static sfxAudioID: number = -1;
    /**
     * 初始化音效
     */
    public static init() {
        let bgValue: string = cc.sys.localStorage.getItem("bgmVolume");
        if (bgValue != null) {
            this.setBGMVolume(parseFloat(bgValue));
            //this.bgmVolume = parseFloat(bgValue);
           
        }

        var sfxValue = cc.sys.localStorage.getItem("sfxVolume");
        if (sfxValue != null) {
            //this.sfxVolume = parseFloat(sfxValue);
            this.setSFXVolume(parseFloat(sfxValue));
        }
    }
    /**
     * 获取音效文件的路径
     * @param name 
     * @param isLanguagePlay 
     */
    public static getUrl(name: string, isLanguagePlay: boolean): string {
        let fileName: string = "";
        if (isLanguagePlay) {
            if (consts.language == "en") {
                fileName = "en";
            } else {
                fileName = "zh";
            }
        } else {
            fileName = "common";
        }
        return "i18n/sound/" + fileName + "/" + name;
    }
    /**
     * 播放背景音乐的文件
     * @param name            文件名称
     * @param isLanguagePlay  是否是多语言
     */
    public static playBGM(name: string, isBundle: boolean = false, isLanguagePlay: boolean = false, cb = null) {
        var audioUrl = this.getUrl(name, isLanguagePlay);
        let bundle = null;
        let bgmAudioID = null;
        if (App.audioCache.get(name)) {
            if (this.bgmAudioID >= 0) {
                cc.audioEngine.stop(this.bgmAudioID);
            }
            bgmAudioID = cc.audioEngine.playMusic(App.audioCache.get(name), true);
            this.bgmAudioID = bgmAudioID;
            cb && cb(bgmAudioID);
        } else {
            if (isBundle) {
                bundle = App.gameBundle;
            } else {
                bundle = cc.resources;
            }
            bundle.load(audioUrl, cc.AudioClip, (err, autoClip) => {
                if (err) {
                    console.error("loadAudioErr:" + name);
                    return;
                }
                //if (this.bgmVolume > 0) {
                    if (this.bgmAudioID >= 0) {
                        cc.audioEngine.stop(this.bgmAudioID);
                    }
                    bgmAudioID = cc.audioEngine.playMusic(<cc.AudioClip>autoClip, true);
                    this.bgmAudioID = bgmAudioID;
                    cb && cb(bgmAudioID);
                //}

            });
        }


    }
    /**
     * 播放音效的文件
     * @param name            文件名称
     * @param isLanguagePlay  是否是多语言
     */
    public static playSFX(name: string, isBundle: boolean = false, isLanguagePlay: boolean = false, cb = null, isloop: boolean = false) {
        var audioUrl = this.getUrl(name, isLanguagePlay);
        let bundle = null;
        let sfxAudioID = null;
        if (App.audioCache.get(name)) {
            if (this.sfxVolume > 0) {
                sfxAudioID = cc.audioEngine.playEffect(App.audioCache.get(name), isloop);
                this.sfxAudioID = sfxAudioID;
                cb && cb(sfxAudioID);
            }
        } else {
            if (isBundle) {
                bundle = App.gameBundle;
            } else {
                bundle = cc.resources;
            }

            bundle.load(audioUrl, cc.AudioClip, (err, autoClip) => {
                if (err) {
                    console.error("loadAudioErr:" + name);
                    return;
                }
                App.audioCache.set(name, autoClip);
                if (this.sfxVolume > 0) {
                    // if(this.sfxAudioID >= 0){
                    //     cc.audioEngine.stop(this.sfxAudioID);
                    // }
                    sfxAudioID = cc.audioEngine.playEffect(<cc.AudioClip>autoClip, isloop);
                    this.sfxAudioID = sfxAudioID;
                    cb && cb(sfxAudioID);
                }
            });
        }

    }
    /**
     * 设置背景音乐的音量
     * @param v 
     */
    public static setBGMVolume(v: number, isSave = true) {
        if (this.bgmAudioID >= 0) {
            if (v > 0) {
                cc.audioEngine.resumeMusic();
            }
            else {
                cc.audioEngine.pauseMusic();
            }
        }
        if (this.bgmVolume != v) {
            if (isSave) {
                cc.sys.localStorage.setItem("bgmVolume", v);
            }
            this.bgmVolume = v;
            cc.audioEngine.setMusicVolume(v);
        }
    }
    /**
     * 设置音效的音量
     * @param v 
     */
    public static setSFXVolume(v: number, isSave = true) {
        if (this.sfxVolume != v) {
            if (isSave) {
                cc.sys.localStorage.setItem("sfxVolume", v);
            }
            this.sfxVolume = v;
            cc.audioEngine.setEffectsVolume(v);
        }
    }
    /**
     * 暂停音乐播放
     */
    public static pauseBGM() {
        if (this.bgmAudioID >= 0) {
            cc.audioEngine.pauseMusic();
        }
    }
    /**
     * 恢复音乐播放
     */
    public static resumeBGM() {
        if (this.bgmAudioID >= 0) {
            cc.audioEngine.resumeMusic();
        }
    }
    /**
     * 停止所有音頻
     */
    public static pauseAll() {
        cc.audioEngine.pauseAll();
    }
    /**
     * 恢復所有音頻
     */
    public static resumeAll() {
        cc.audioEngine.resumeAll();
    }
    /**
     * 通过音效id 停止音頻
     * @param audioId 
     */
    public static stopAudio(audioId) {
        if (audioId) {
            cc.audioEngine.stop(audioId);
        }
    }
    /**
    * 获取音效的状态
    * @param audioId 
    * @returns 
    */
    public static getAudioSata(audioId):number {
        if (audioId) {
            return cc.audioEngine.getState(audioId);
        }else{
            return 0;
        }
    }

    /**
     * 停止所有音效
     */
    public static stopAllSFXValume(){
        cc.audioEngine.stopAllEffects();
    }
}
