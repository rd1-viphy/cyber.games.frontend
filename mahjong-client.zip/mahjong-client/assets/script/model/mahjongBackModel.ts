import AppEmitter from "../network/AppEmitter";



export default class MahjongBackModel {

    public static backData = [];

    public static originBackData = [];

    public static timeInterval: number = 1500;

    public static curMsgCout: number = 0;

    public static forWardIdx: number = 0;

    public static timerMsg = [];

    public static filterRouterList = [
        "mahjong.mahjongGameHandler.playerAction",
        "onVotePlayerActionPush",
        "onVoteDisbandStartPush",
        "onVoteResultPush",
        "onPlayerAllReadyPush",
        "onRoomDisbandPush"
    ]

    public static initData(backData) {
        this.curMsgCout = 0;
        this.destoryTimer();
        this.originBackData = this.onFilterRoute(backData);
        this.backData = [];
        this.backData = JSON.parse(JSON.stringify(this.originBackData));
        for (let i = 0; i < this.backData.length; i++) {
            const msgData = this.backData[i];
            this.timerMsg[i] = setTimeout(() => {
                AppEmitter.emit(msgData.route, msgData.msg);
                this.curMsgCout += 1;
            }, this.timeInterval * i);
        }
    }

    public static destoryTimer() {
        for (let i = 0; i < this.timerMsg.length; i++) {
            if (this.timerMsg[i] !== undefined) {
                clearTimeout(this.timerMsg[i]);
            }
        }
    }

    public static rePlayBack() {
        this.backData = [];
        this.backData = JSON.parse(JSON.stringify(this.originBackData));
        this.curMsgCout = 1;
        this.destoryTimer();
        for (let i = 1; i < this.backData.length; i++) {
            const msgData = this.backData[i];
            this.timerMsg[i] = setTimeout(() => {
                AppEmitter.emit(msgData.route, msgData.msg);
                this.curMsgCout += 1;
            }, this.timeInterval * i);
        }
    }

    public static fastForward() {
        this.destoryTimer();
        if (this.curMsgCout < this.backData.length) {
            const msgData = this.backData[this.curMsgCout];
            AppEmitter.emit(msgData.route, msgData.msg);
            this.curMsgCout += 1;
            this.forWardIdx = this.curMsgCout;
            for (let i = 0; i < this.backData.length; i++) {
                if (i < this.backData.length - this.curMsgCout) {
                    const msgData = this.backData[i + this.curMsgCout];
                    this.timerMsg[i] = setTimeout(() => {
                        AppEmitter.emit(msgData.route, msgData.msg);
                        this.curMsgCout += 1;
                    }, this.timeInterval * i);
                }
            }
        }
    }

    public static onFilterRoute(data) {
        let msgRouteList = [];
        for (let i = 0; i < data.records.length; i++) {
            const msgData = data.records[i];
            const isFilter = this.onGetFileterRoute(msgData);
            if (!isFilter) {
                msgRouteList.push(msgData);
            }
        }
        return msgRouteList;
    }

    public static onGetFileterRoute(msgData) {
        let isFilter = false;
        for (let m = 0; m < this.filterRouterList.length; m++) {
            const filterMsg = this.filterRouterList[m];
            if (msgData.route == filterMsg) {
                isFilter = true;
            }
        }
        return isFilter;
    }

}
