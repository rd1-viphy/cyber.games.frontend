
import { GameViewOrientation, platform_game_id, platform_game_name } from "../common/ClientEnum";
import NetConnect from "../network/NetConnect";

import App from "./App";
import consts = require("./Consts");
import gameEventTrackingMgr, { GameEventTrackingTypeId } from "./gameEventTrackingMgr";
import PlayerMgr from "./PlayerMgr";
import RoomMgr from "./RoomMgr";

import { Utils } from "./Utils";

export default class sceneSkipMgr {

    public static _instance;

    public static getInstance(): sceneSkipMgr {
        if (!this._instance) {
            this._instance = new sceneSkipMgr();
        }
        return this._instance;
    }

    /**
     * 三张扑克选厅界面
     */
    richer3RoomScene() {
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        const isPreload = cc.assetManager.getBundle("threePokerBundle");
        RoomMgr.getInstance().getThreepokerRoomList({ "gameId": platform_game_id.richer3, "roomType": roomType }, (data) => {
            RoomMgr.getInstance().roomList = data.rooms;
            NetConnect.sendRequest(consts.Get_isGameNewPlayer, {
                gameId: platform_game_id.richer3
            }, (data) => {
                PlayerMgr.getInstance().isGameNewPlayer = data.isGameNewPlayer;
                if (isPreload) {
                    PlayerMgr.getInstance().isGameNewPlayer = 0;
                    RoomMgr.getInstance().isCanEnterThreePoker = true;
                    App.changeScene({ "sceneName": consts.THREE_POKER_ROOM_LIST_SCENE });
                } else {
                    App.preloadRes("threePoker", () => {
                        RoomMgr.getInstance().isCanEnterThreePoker = true;
                        App.changeScene({ "sceneName": consts.THREE_POKER_ROOM_LIST_SCENE });
                    });
                }
            })
        });
    }

    /**
     * 三张扑克选桌界面
     */
    richer3TableScene() {
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        let roomId = RoomMgr.getInstance().selectRoomId != 1 ? RoomMgr.getInstance().selectRoomId : Utils.getHttpKeysAndValus()["enterroomid"];
        if (roomId) {
            const isPreload = cc.assetManager.getBundle("threePokerBundle");
            NetConnect.sendRequest(consts.Get_isGameNewPlayer, {
                gameId: platform_game_id.richer3
            }, (data) => {
                PlayerMgr.getInstance().isGameNewPlayer = data.isGameNewPlayer;
                if (data.isGameNewPlayer) {
                    RoomMgr.getInstance().getThreepokerRoomList({ "gameId": platform_game_id.richer3, "roomType": roomType }, (data) => {
                        RoomMgr.getInstance().roomList = data.rooms;
                        App.preloadRes("threePoker", () => {
                            RoomMgr.getInstance().isCanEnterThreePoker = true;
                            App.changeScene({ "sceneName": consts.THREE_POKER_ROOM_LIST_SCENE });
                        });
                    })
                } else {
                    RoomMgr.getInstance().getThreeCardsList({ "roomId": roomId, "gameId": platform_game_id.richer3 }, (data) => {
                        RoomMgr.getInstance().tableList = data;
                        RoomMgr.getInstance().pageCount = data.maxPage;
                        RoomMgr.getInstance().selectRoomId = roomId;
                        if (isPreload) {
                            cc.sys.localStorage.setItem("threePokerRoomMark", roomId);
                            App.changeScene({ "sceneName": consts.THREE_POKER_TABLE_SCENE, "type": 1 });
                        } else {
                            App.preloadRes("threePoker", () => {
                                cc.sys.localStorage.setItem("threePokerRoomMark", roomId);
                                App.changeScene({ "sceneName": consts.THREE_POKER_TABLE_SCENE, "type": 1 });
                            })
                        }
                    });
                }
            })
        }
    }

    /**
     * 三张扑克游戏界面
     */
    richer3GameScene(roomId) {
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        const isPreload = cc.assetManager.getBundle("threePokerBundle");
        RoomMgr.getInstance().selectRoomId = roomId;
        cc.sys.localStorage.setItem("threePokerRoomMark", roomId);
        NetConnect.sendRequest(consts.Get_isGameNewPlayer, {
            gameId: platform_game_id.richer3
        }, (data) => {
            PlayerMgr.getInstance().isGameNewPlayer = data.isGameNewPlayer;
            if (data.isGameNewPlayer) {
                RoomMgr.getInstance().getThreepokerRoomList({ "gameId": platform_game_id.richer3, "roomType": roomType }, (data) => {
                    RoomMgr.getInstance().roomList = data.rooms;
                    App.preloadRes("threePoker", () => {
                        RoomMgr.getInstance().isCanEnterThreePoker = true;
                        App.changeScene({ "sceneName": consts.THREE_POKER_ROOM_LIST_SCENE });
                    });
                })
            } else {
                if (isPreload) {
                    RoomMgr.getInstance().isCanEnterThreePoker = true;
                    RoomMgr.getInstance().quickJoinThreeCardsGame({ "gameId": 1, "roomId": roomId }, () => { })
                } else {
                    App.preloadRes("threePoker", () => {
                        RoomMgr.getInstance().isCanEnterThreePoker = true;
                        RoomMgr.getInstance().quickJoinThreeCardsGame({ "gameId": 1, "roomId": roomId }, () => { })
                    });
                }
            }
        })
    }

    /**
     * 好运21点选厅界面
     */
    classic21RoomScene() {
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        RoomMgr.getInstance().getClassicBlackJackRoomList({ "roomType": roomType }, (data) => {
            RoomMgr.getInstance().roomList = data.RoomConfig;
            RoomMgr.getInstance().setRoomDoublingFaceOffStatus(data.RoomConfig);
            if (data.RoomConfig.length > 0 && data.RoomConfig[0] && data.RoomConfig[0].money_Scale) {
                RoomMgr.getInstance().moneyScale = data.RoomConfig[0].money_Scale;
                cc.log("get room scale ==", RoomMgr.getInstance().moneyScale);
            }
            if (RoomMgr.getInstance().doublingFaceOff) {
                const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                if (isPreload) {
                    App.changeScene({ "sceneName": consts.CLASSIC_JACK_ROOM_SCENE });
                } else {
                    App.preloadMultiRes("classicBlackJack", () => {
                        App.changeScene({ "sceneName": consts.CLASSIC_JACK_ROOM_SCENE });
                    });
                }
            } else {
                const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                if (isPreload) {
                    App.changeScene({ "sceneName": consts.CLASSIC_JACK_ROOM_SCENE });
                } else {
                    App.preloadMultiRes("classicBlackJack", () => {
                        App.changeScene({ "sceneName": consts.CLASSIC_JACK_ROOM_SCENE });
                    });
                }
            }
        });
    }

    /**
     * 好运21点选桌界面
     */
    classic21TableScene() {
        let roomId = RoomMgr.getInstance().selectRoomId != 1 ? RoomMgr.getInstance().selectRoomId : Utils.getHttpKeysAndValus()["enterroomid"];
        if (roomId) {
            RoomMgr.getInstance().selectGameId = platform_game_id.classic21;
            RoomMgr.getInstance().getClassic21Config({ "gameId": platform_game_id.classic21, "roomId": parseInt(roomId) }, (data) => {
                RoomMgr.getInstance().doublingFaceOff = data.webConfig.DoublingFaceOff == 1 ? true : false;
                RoomMgr.getInstance().moneyScale = data.webConfig.money_Scale;
                cc.log("get room scale ==", RoomMgr.getInstance().moneyScale);

                RoomMgr.getInstance().getClassicBlackJackList({ "gameId": platform_game_id.classic21, "roomid": parseInt(roomId), "page": 1, "size": 3, "type": 0 }, (data) => {
                    RoomMgr.getInstance().tableList = data.currentTables;
                    RoomMgr.getInstance().pageCount = data.pageCount;
                    RoomMgr.getInstance().selectRoomId = parseInt(roomId);
                    if (RoomMgr.getInstance().doublingFaceOff) {
                        const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                        if (isPreload) {
                            cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                            App.changeScene({ "sceneName": consts.CLASSIC_JACK_TABLE_SCENE, "type": 1 });
                        } else {
                            App.preloadMultiRes("classicBlackJack", () => {
                                cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                                App.changeScene({ "sceneName": consts.CLASSIC_JACK_TABLE_SCENE, "type": 1 });
                            })
                        }
                    } else {
                        const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                        if (isPreload) {
                            cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                            App.changeScene({ "sceneName": consts.CLASSIC_JACK_TABLE_SCENE, "type": 1 });
                        } else {
                            App.preloadRes("classicBlackJack", () => {
                                cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                                App.changeScene({ "sceneName": consts.CLASSIC_JACK_TABLE_SCENE, "type": 1 });
                            });
                        }
                    }
                });
            })
        }
    }

    /**
     * 好运21点游戏界面
     */
    classic21GameScene(roomId) {
        RoomMgr.getInstance().selectGameId = platform_game_id.classic21;
        RoomMgr.getInstance().getClassic21Config({ "gameId": platform_game_id.classic21, "roomId": roomId }, (data) => {
            RoomMgr.getInstance().doublingFaceOff = data.webConfig.DoublingFaceOff == 1 ? true : false;
            RoomMgr.getInstance().moneyScale = data.webConfig.money_Scale;

            if (RoomMgr.getInstance().doublingFaceOff) {
                const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                if (isPreload) {
                    cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                    RoomMgr.getInstance().quickJoinClassicBlackJackGame({ "roomid": roomId }, (data) => {
                        RoomMgr.getInstance().enterClassicBlackJackGame(data);
                    });
                } else {
                    App.preloadMultiRes("classicBlackJack", () => {
                        cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                        RoomMgr.getInstance().quickJoinClassicBlackJackGame({ "roomid": roomId }, (data) => {
                            RoomMgr.getInstance().enterClassicBlackJackGame(data);
                        });
                    })
                }
            } else {
                const isPreload = cc.assetManager.getBundle("classicBlackJackBundle");
                if (isPreload) {
                    cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                    RoomMgr.getInstance().quickJoinClassicBlackJackGame({ "roomid": roomId }, (data) => {
                        RoomMgr.getInstance().enterClassicBlackJackGame(data);
                    });
                } else {
                    App.preloadRes("classicBlackJack", () => {
                        cc.sys.localStorage.setItem("classic21BlackJackRoomMark", roomId);
                        RoomMgr.getInstance().quickJoinClassicBlackJackGame({ "roomid": roomId }, (data) => {
                            RoomMgr.getInstance().enterClassicBlackJackGame(data);
                        });
                    });
                }
            }
        })
    }

    /**
     * 倍率21点选厅界面
     */
    magic21RoomScene() {
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType = roomTypeValue ? parseInt(roomTypeValue) : 0;
        const isPreload = cc.assetManager.getBundle("magicBlackJackBundle");
        RoomMgr.getInstance().getMagicBlackJackRoomList({ "roomType": roomType }, (data) => {
            RoomMgr.getInstance().roomList = data.RoomConfig;
            if (data.RoomConfig.length > 0 && data.RoomConfig[0] && data.RoomConfig[0].money_Scale) {
                RoomMgr.getInstance().moneyScale = data.RoomConfig[0].money_Scale;
                cc.log("get room scale ==", RoomMgr.getInstance().moneyScale);
            }
            if (isPreload) {
                App.changeScene({ "sceneName": consts.MAGIC_JACK_ROOM_SCENE });
            } else {
                App.preloadRes("magicBlackJack", () => {
                    App.changeScene({ "sceneName": consts.MAGIC_JACK_ROOM_SCENE });
                });
            }
        });
    }

    /**
     * 倍率21点选桌界面
     */
    magic21TableScene() {
        let roomId = RoomMgr.getInstance().selectRoomId != 1 ? RoomMgr.getInstance().selectRoomId : Utils.getHttpKeysAndValus()["enterroomid"];
        if (roomId) {
            const isPreload = cc.assetManager.getBundle("magicBlackJackBundle");
            RoomMgr.getInstance().getMagicBlackJackList({ "roomid": roomId, "page": 1, "size": 3, "type": 0 }, (data) => {
                RoomMgr.getInstance().tableList = data.currentTables;
                RoomMgr.getInstance().pageCount = data.pageCount;
                RoomMgr.getInstance().selectRoomId = roomId;
                if (isPreload) {
                    cc.sys.localStorage.setItem("magic21BlackJackRoomMark", roomId);
                    App.changeScene({ "sceneName": consts.MAGIC_JACK_TABLE_SCENE, "type": 1 });
                } else {
                    App.preloadRes("magicBlackJack", () => {
                        cc.sys.localStorage.setItem("magic21BlackJackRoomMark", roomId);
                        App.changeScene({ "sceneName": consts.MAGIC_JACK_TABLE_SCENE, "type": 1 });
                    })
                }
            });
        }
    }

    /**
     * 倍率21点游戏界面
     */
    magicGameScene(roomId) {
        const isPreload = cc.assetManager.getBundle("magicBlackJackBundle");
        if (isPreload) {
            cc.sys.localStorage.setItem("magic21BlackJackRoomMark", roomId);
            RoomMgr.getInstance().quickJoinMagicBlackJackGame({ "roomid": roomId }, (data) => {
                RoomMgr.getInstance().enterMagicBlackJackGame(data);
            });
        } else {
            App.preloadRes("magicBlackJack", () => {
                cc.sys.localStorage.setItem("magic21BlackJackRoomMark", roomId);
                RoomMgr.getInstance().quickJoinMagicBlackJackGame({ "roomid": roomId }, (data) => {
                    RoomMgr.getInstance().enterMagicBlackJackGame(data);
                });
            });
        }
    }


}