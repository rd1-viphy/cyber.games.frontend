import { gameSceneType, platform_game_name } from "../common/ClientEnum";
import { Utils } from "./Utils";

export class parameterValidator {

    static acePvplobbyValidator(): boolean {
        let gameId: string = Utils.getUrlGameId()["gameid"];
        let targetGameId: string = Utils.getHttpKeysAndValus()["pvpgameid"];
        let entergametype = parseInt(Utils.getHttpKeysAndValus()["entergametype"]);
        let backgametype = parseInt(Utils.getHttpKeysAndValus()["backgametype"]);
        let roomId = parseInt(Utils.getHttpKeysAndValus()["enterroomid"]);

        if (gameId == "pvplobby") {
            if (targetGameId) {
                if (targetGameId == platform_game_name.richer3) {
                    if (entergametype == gameSceneType.gameScene) {
                        if (roomId) {
                            if (roomId != 10202 && roomId != 10302 && roomId != 10402) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    }
                } else if (targetGameId == platform_game_name.classicBlackJack) {
                    if (entergametype == gameSceneType.gameScene) {
                        if (roomId) {
                            if (roomId != 22 && roomId != 23 && roomId != 24) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    }
                } else if (targetGameId == platform_game_name.magicBlackJack) {
                    if (entergametype == gameSceneType.gameScene) {
                        if (roomId) {
                            if (roomId != 12 && roomId != 13 && roomId != 14) {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    }
                } else if (targetGameId == platform_game_name.PushDots || targetGameId == platform_game_name.eroulette ||
                    targetGameId == platform_game_name.casinoholdem || targetGameId == platform_game_name.jokershoting ||
                    targetGameId == platform_game_name.superCow) {
                    if (entergametype == gameSceneType.tableScene) {
                        return false;
                    }
                }
            } 
        } else {
            if (gameId == platform_game_name.greatsageracing || gameId == platform_game_name.rowing || gameId == platform_game_name.horseracing) {
                if (entergametype == gameSceneType.tableScene) {
                    return false;
                }
            }
        }

        return true;
    }

}