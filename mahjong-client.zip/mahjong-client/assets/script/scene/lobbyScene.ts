

import App from "../model/App";
import AudioMgr from "../model/AudioMgr";
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import RoomMgr from "../model/RoomMgr";

import { Utils } from "../model/Utils";
import NetConnect from "../network/NetConnect";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    nickName: cc.Label = null;

    @property(cc.Node)
    photo: cc.Node = null;

    @property(cc.Node)
    gameContent: cc.Node = null;

    @property(cc.Sprite)
    gameLogo: cc.Sprite = null;

    // @property([cc.SpriteFrame])
    // logoSpriteFrame:cc.SpriteFrame[] = [];

    roomCardIndex = [3, 6, 7, 8];
    enLanguageIndex = [0, 1, 4, 5, 9, 10, 11, 12, 14, 28];
    noShowIndex = [4, 15, 17, 22, 26];
    public _3dGameInfo = {
        36: "roulette",
        37: "cashorcrash",
        38: "keno",
    }

    start() {
        AudioMgr.pauseBGM();
        this.nickName.string = Utils.tailoringNickName(PlayerMgr.getInstance().nickName);
        Utils.setRemoteSpriteFrame(this.photo, PlayerMgr.getInstance().avatar);
        const gameType = Utils.getHttpKeysAndValus()['gameType'];
        if (gameType == "roomCard") {
            this.gameContent.children.forEach((element, index) => {
                element.active = this.roomCardIndex.indexOf(index) > -1;
            });
            //this.gameLogo.spriteFrame = this.logoSpriteFrame[0];
            Utils.setSpriteStrForLanguage(this.gameLogo, "logo3");
        } else if (gameType == "chess") {
            if (consts.language == "en") {
                this.gameContent.children.forEach((element, index) => {
                    element.active = this.enLanguageIndex.indexOf(index) >= 0;
                });
            } else {
                this.gameContent.children.forEach((element, index) => {
                    element.active = this.roomCardIndex.indexOf(index) < 0 && this.noShowIndex.indexOf(index) < 0;
                });
            }
            Utils.setSpriteStrForLanguage(this.gameLogo, "logo2");
            //this.gameLogo.spriteFrame = this.logoSpriteFrame[1];
        }


    }

    btnClicked(event, data) {
        if (data == "36" || data == "37" || data == "38") {
            let url = '';
            if (data === "36") {
                url = `https://localhost.aug888.com/${this._3dGameInfo[data]}/?apiGameId=${data}&username=${sessionStorage.getItem("account")}&language=${Utils.getHttpKeysAndValus()["language"]}&gameid=${this._3dGameInfo[data]}`;
            } else if (data === "37") {
                url = `https://localhost.aug888.com/${this._3dGameInfo[data]}/launch.html?&usertoken=${sessionStorage.getItem("account")}&host=wss://localhost.aug888.com/coc.ws`;
            } else if (data === "38") {
                url = `https://localhost.aug888.com/${this._3dGameInfo[data]}/launch.html?&usertoken=${sessionStorage.getItem("account")}&host=wss://localhost.aug888.com/keno/wss`;
            }

            cc.log("open webview url:", url);
            let opts = {
                prefabName: "webViewNode",
                //opts: { data: {url:"https://localhost.aug888.com/roulette3d/?apiGameId=36"+"&username="+sessionStorage.getItem("account")}}
                opts: { data: { url: url } }
            }
            App.loadPopalPanel(opts);
            //隐藏最上层的返回按钮
            window.parent.postMessage({ hideBtn: true }, "*")
        } else {
            let touchGameId = parseInt(data);
            // if(touchGameId == platform_game_id.mahjong){
            //     App.showToast("敬請期待");
            // }else{
            let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
            let roomType: number = roomTypeValue ? parseInt(roomTypeValue) : 0;
            RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
            //}
        }
    }
}
