
const { ccclass, property } = cc._decorator;
import { platform_game_id } from "../common/ClientEnum";
import { i18nMgr } from "../i18n/i18nMgr";
import App from "../model/App";
import AudioMgr from "../model/AudioMgr";
import consts = require("../model/Consts");
import RoomMgr from "../model/RoomMgr";

import { Utils } from "../model/Utils";
import NetConnect from "../network/NetConnect";
@ccclass
export default class loginClass extends cc.Component {

    @property(cc.EditBox)
    accountEditor: cc.EditBox = null;

    @property(cc.Prefab)
    dialogBox: cc.Prefab = null;

    @property(cc.Label)
    versionLabel: cc.Label = null;

    @property({
        tooltip: "logo图片",
        type: cc.Sprite
    })
    logoSprite: cc.Sprite = null;

    @property({
        tooltip: "logo集",
        type: cc.SpriteFrame
    })
    logoSpriteFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "桌子图片",
        type: cc.Sprite
    })
    tableSprite: cc.Sprite = null;

    @property({
        tooltip: "桌子图片集",
        type: cc.SpriteFrame
    })
    tableSpriteFrames: cc.SpriteFrame[] = [];

    @property({
        tooltip: "多語言選擇文字",
        type: cc.Label
    })
    languageLabel: cc.Label = null;

    @property({
        tooltip: "多語言選擇標識",
        type: cc.Node
    })
    arrowNode: cc.Node = null;

    @property({
        tooltip: "多語言選擇框",
        type: cc.Node
    })
    languageDialog: cc.Node = null;

    @property({
        tooltip: "多語言選擇框",
        type: cc.Toggle
    })
    languageToggle: cc.Toggle = null;
    start() {
        if (sessionStorage.getItem("account")) {
            this.accountEditor.string = sessionStorage.getItem("account");
        }
        this.versionLabel.string = consts.appVersion;

        const gameType = Utils.getHttpKeysAndValus()['gameType'];
        if (gameType == "roomCard") {
            this.logoSprite.spriteFrame = this.logoSpriteFrames[1];
            this.tableSprite.spriteFrame = this.tableSpriteFrames[1];
        } else if (gameType == "chess") {
            this.logoSprite.spriteFrame = this.logoSpriteFrames[0];
            this.tableSprite.spriteFrame = this.tableSpriteFrames[0];
        } else if (gameType == "battleHall") {
            this.logoSprite.spriteFrame = this.logoSpriteFrames[1];
            this.tableSprite.spriteFrame = this.tableSpriteFrames[1];
        }
        // let gameLaneuage = cc.sys.localStorage.getItem("gameLanguage");
        // if (gameLaneuage) {
        //     consts.language = gameLaneuage;
        //     i18nMgr.setLanguage(consts.language);
        //     if (gameLaneuage == "tw") {
        //         this.languageLabel.string = "繁體中文";
        //     } else if (gameLaneuage == "en") {
        //         this.languageLabel.string = "ENGLISH";
        //     }
        // }
    }

    loginBtnClicked(event: cc.Event) {
        AudioMgr.playSFX("sound_btn_enter");
        if (this.accountEditor.string == "") {
            App.showToast("game_input_account");
            return;
        }
        //this.addParameters(this.accountEditor.string);
        //cc.sys.localStorage.setItem("account", this.accountEditor.string);
        sessionStorage.setItem("account", this.accountEditor.string)

        // // 测试
        // App.preloadRes("lobby",()=>{
        //     App.changeScene({ "sceneName": consts.LOBBY_SCENE, "type": 1 });
        // });
        // return;
        NetConnect.connect(() => {
            RoomMgr.getInstance().enterGame(7, false, 0);
        });

        return;


    }

    toggleClicked(event, data) {
        consts.language = data;
        i18nMgr.setLanguage(consts.language);
        this.languageToggle.isChecked = false;
        this.arrowNode.scaleY = -1;
        this.languageDialog.active = false;
        App.spriteCache.clear();
        App.spineCache.clear();
        App.audioCache.clear();
        if (data == "tw") {
            this.languageLabel.string = "繁體中文";
        } else if (data == "en") {
            this.languageLabel.string = "ENGLISH";
        }
        cc.sys.localStorage.setItem("gameLanguage", data);
    }
    /**
     * 添加参数
     */
    addParameters(account: string) {
        if (Utils.getHttpKeysAndValus()["username"]) {
            Utils.getHttpKeysAndValus()["username"] = account;
        } else {
            var url = window.document.location.href.toString(); //获取的完整url 
            var u = url.split("?");
            if (u.length > 1) {
                window.document.location.href = url + "&username=" + account;
            } else {
                window.document.location.href = url + "?username=" + account;
            }
        }
    }

    accountInputEnd() {
        let editorStr = this.accountEditor.string;
        //let newStr = Utils.tailoringNickName(editorStr);
        // if (newStr.indexOf("...") > -1) {
        //     newStr = newStr.replace("...", "");
        // }
        this.accountEditor.string = editorStr;
    }

    selectLanguageClicked(event) {
        let toggle = this.languageToggle;
        this.arrowNode.scaleY = toggle.isChecked ? 1 : -1;
        this.languageDialog.active = toggle.isChecked;
    }
}
