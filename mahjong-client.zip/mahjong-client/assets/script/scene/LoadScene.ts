
import { platform_game_id, platform_game_name } from "../common/ClientEnum";
import { i18nMgr } from "../i18n/i18nMgr";
import App from "../model/App";
import consts = require("../model/Consts");
import RoomMgr from "../model/RoomMgr";
import MahjongRoomMgr from "../model/roomMgr/mahjongRoomMgr";




import { Utils } from "../model/Utils";
import NetConnect from "../network/NetConnect";

import ScreenAdaption from "../model/screenAdaptation";


const { ccclass, property } = cc._decorator;
@ccclass
export default class loadScene extends cc.Component {

    @property(cc.Label)
    loginLabel: cc.Label = null;

    @property(cc.Node)
    starAniNode: cc.Node = null;

    onLoad() {
        cc.debug.setDisplayStats(false);
        new App();
        //设置当前方向
        this.setCanvasSizeOfOrientation();
    }

    start() {
        //获取当前语言
        let languageMap = new Map();
        languageMap.set("zh-cn", "zh");
        languageMap.set("zh-tw", "tw");
        languageMap.set("en-us", "en");
        languageMap.set("ja-JP", "jp");
        languageMap.set("ja-jp", "jp");
        let currentLanguage = languageMap.get(Utils.getHttpKeysAndValus()["language"]);
        if (currentLanguage) {
            consts.language = currentLanguage;
        }
        i18nMgr.setLanguage(consts.language);
        //入口 判斷是否接入平台
        if (consts.isAccessPlatform) {
            this.loginLabel.node.active = true;
            //this.showGameIcon();
            //先判讀是否有回放
            const apiGameId = Utils.getHttpKeysAndValus()["apiGameId"];
            const tableUuid = Utils.getHttpKeysAndValus()["tableUuid"];
            const roundLimit = Utils.getHttpKeysAndValus()["roundLimit"];
            const roundId = Utils.getHttpKeysAndValus()["roundId"];
            const playerId = Utils.getHttpKeysAndValus()["playerId"];
            const chairId = Utils.getHttpKeysAndValus()["chairId"];
            if (apiGameId) {
                App.isCustomerPlayBack = true;
                if (tableUuid && roundLimit) {
                    if (apiGameId == platform_game_name.Mahjong) {
                        MahjongRoomMgr.getInstance().joinPlayback(tableUuid, roundLimit);
                    } else if (apiGameId == platform_game_name.TexasPoker) {
                        RoomMgr.getInstance().joinTexasPokerPlayback(tableUuid, roundLimit);
                    }
                } else if (roundId && playerId) {

                }
            } else {
                NetConnect.connect(() => {
                    this.enterGame();
                });
            }
        } else {
            const gameType = Utils.getHttpKeysAndValus()['gameType'];
            if (gameType == "battleHall") {
                consts.isBattleHall = true;
            }
            const username = Utils.getHttpKeysAndValus()['username'];
            if (username) {
                sessionStorage.setItem("account", username)
                if (consts.isBattleHall) {

                } else {
                    // NetConnect.connect(() => {
                    //     App.preloadRes("lobby", () => {
                    //         App.changeScene({ "sceneName": consts.LOBBY_SCENE });
                    //     });
                    // })
                    NetConnect.connect(() => {
                        this.enterGame();
                    });
                }
            }
            // else {
            //     this.loginLabel.node.active = false;
            //     App.preloadRes("lobby", () => {
            //         App.changeScene({ "sceneName": consts.LOGIN_SCENE, "type": 2 });
            //     });
            // }
        }
    }

    enterGame() {
        this.loginLabel.node.active = false;
        let roomTypeValue = Utils.getHttpKeysAndValus()["roomType"];
        let roomType: number = roomTypeValue ? parseInt(roomTypeValue) : 0;
        if (App.getIsGuestLogin()) {
            // //快速加入游戏,先判断是否
            // App.preloadRes("magicBlackJack", () => {
            //     RoomMgr.getInstance().selectRoomId = 100000;
            //     RoomMgr.getInstance().quickJoinMagicBlackJackGame({ "roomid": RoomMgr.getInstance().selectRoomId }, (data) => {
            //         RoomMgr.getInstance().enterMagicBlackJackGame(data);
            //       });
            // });
            let gameId: string = Utils.getUrlGameId()["gameid"];
            const touchGameId = platform_game_id[gameId];
            RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
        } else {
            let gameId: string = Utils.getUrlGameId()["gameid"];
            if (gameId == "pvplobby") {
                let targetGameId: string = "";

                targetGameId = Utils.getHttpKeysAndValus()["ecasinogameid"];

                let entergametype = parseInt(Utils.getHttpKeysAndValus()["entergametype"]);
                if (entergametype) {
                    const touchGameId = platform_game_id[targetGameId];
                    if (targetGameId) {

                    } else {
                        // 未携带ecasinogameid时，进入棋牌大厅
                        let touchGameId = platform_game_id[gameId];
                        RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
                    }
                } else {
                    // 进入棋牌大厅
                    let touchGameId = platform_game_id[gameId];
                    RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
                }
            } else {
                let touchGameId = platform_game_id[gameId];
                let entergametype = parseInt(Utils.getHttpKeysAndValus()["entergametype"]);
                if (entergametype) {
                    // 进入游戏指定场景
                    if (touchGameId == platform_game_id.richer3) {

                    } else {
                        RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
                    }
                } else {
                    RoomMgr.getInstance().enterGame(touchGameId, false, roomType);
                }
            }
        }
    }

    /**
     * 设置当前场景的大小根据加载方向
     */
    setCanvasSizeOfOrientation() {
        if (App.isPortraitOrientation()) {
            //设置竖屏
            const canvas: cc.Canvas = cc.find("Canvas").getComponent(cc.Canvas);
            const adaptation = cc.find("Canvas").getComponent(ScreenAdaption);
            if (canvas) {
                canvas.designResolution = new cc.Size(720, 1280);
                canvas.node.setContentSize(720, 1280);
                canvas.getComponent(cc.Widget).updateAlignment();
                if (adaptation) {
                    adaptation.refreshAdaptation();
                }
                this.starAniNode.rotation = 90;
            }
        }
    }
}
