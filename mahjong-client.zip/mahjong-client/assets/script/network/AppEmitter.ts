/**
 * 事件的分发类
 */
const { ccclass, property } = cc._decorator;
@ccclass
export default class AppEmitter {
    public static appEmitter;
    public static init() {
        const root = <any>window;
        this.appEmitter = root.EventEmitter;
    }
    public static emit = function (eventName: string, eventData: Object = null) {
        cc.log('===触发服务器事件，事件名称:%s===============', eventName );
        this.appEmitter.prototype.emit(eventName, eventData);
    }
    public static on = function (eventName: string, listener: Function, obj: Object = null) {
        cc.log('===添加服务器事件，事件名称:%s===============', eventName);
        this.appEmitter.prototype.on(eventName, listener, obj);
    }

    public static off = function (eventName: string, listener: Function = null) {
        cc.log('===关闭服务器事件，事件名称:%s===============', eventName);
        this.appEmitter.prototype.off(eventName, listener);
    }
}
