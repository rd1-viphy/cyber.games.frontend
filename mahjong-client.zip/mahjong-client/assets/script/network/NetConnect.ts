
import App from "../model/App";
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import { Utils } from "../model/Utils";
import AppEmitter from "./AppEmitter";
import { GAME_PRESERVE } from "../common/ClientEnum";
import HttpUtils from "./HttpUtils";

/**
 * 网络加载模块
 */
const { ccclass, property } = cc._decorator;
@ccclass
export default class NetConnect {
    private static errCodes = [9999, 1004, 605, 600, 551, 500, 499, 402, 305, 110, 241, 945, 231, 216, 238, 225, 601, 249, 403,
        901, 902, 903, 904, 905, 906, 907, 908, 909, 911, 912, 914, 915, 920, 921, 922, 927, 928, 929, 930, 931, 932, 933, 934,
        936, 937, 938, 939, 940, 941, 945, 970, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 968, 239, 712, 723,
        724, 731, 732, 741, 742, 743, 744, 745, 746, 747, 748, 761, 762, 766, 771, 772, 261, 1001, 1002, 1003, 1004, 1109, 1112,
        1152, 1153, 1201, 259, 287, 971, 3401, 3402, 3403, 251, 1009];

    private static battleErrCodes = [3, 215, 261, 40, 243, 3404];

    public static pomelo;
    public static init() {
        const root = <any>window;
        this.pomelo = root.pomelo;
    }

    private static throttleTime: number = 1000;

    private static lastReqTime: number = 0;

    /**
     * 连接网络
     * @param cb 连接成功的回调
     */
    public static connect(cb: Function = null) {
        //重连之后重新登录
        let login = () => {
            App.hideLoading();
            let loginData = {};
            let loginAdress = consts.GAME_LOGIN;
            if (consts.isAccessPlatform) {
                //先判断是不是行动官网
                if (App.getIsGuestLogin()) {
                    // const username = cc.sys.localStorage.getItem("guestUsername"); 
                    // if(username){
                    //     loginData["username"] = username;
                    // }
                    loginAdress = consts.GAME_QUERY_ENTER_CONSTOMER;
                } else {
                    loginData['gameId'] = Utils.getUrlGameId()["gameid"];
                    loginData["token"] = Utils.getHttpKeysAndValus()["token"];
                    loginData["vcode"] = Utils.getHttpKeysAndValus()["vcode"];
                    loginData["roomType"] = Utils.getHttpKeysAndValus()["roomType"];

                    // if (!CC_BUILD) {
                    //     loginData["username"] = Utils.getHttpKeysAndValus()["username"];
                    // }
                    //loginData["username"] = Utils.getHttpKeysAndValus()["username"];
                }
            } else {
                //loginData["username"] = cc.sys.localStorage.getItem("account");
                loginData["username"] = sessionStorage.getItem("account");
                if (consts.isBattleHall) {
                    loginData["gameId"] = "pvpLobby";
                }
            }
            this.sendRequest(loginAdress, loginData, (data) => {
                PlayerMgr.getInstance().initData(data["playerInfo"]);
                if (data["serverStatus"]) {
                    App.globalStatus = data["serverStatus"];
                } else {
                    App.globalStatus = GAME_PRESERVE.NORMAL;
                }

                // HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, consts.HTTP_ROUTE.GET_SERVER_VERSION, {}, (responseData) => {
                //     const httpData = JSON.parse(responseData);
                //     if (httpData.code == 0) {
                //         consts.serverVersion = httpData.data;
                //     }
                // })


                NetConnect.sendRequest(consts.GAME_QUERY_PLAYER_MONEY, {}, (data) => {
                    App.isRefrshGold = false;
                    PlayerMgr.getInstance().money = data.money;
                    AppEmitter.emit(consts.LOCAL_EVENT_UPDATEPLAYERGOLD);
                })

                if (App.getIsGuestLogin() && data.playerInfo && data.playerInfo.username) {
                    //cc.sys.localStorage.setItem("guestUsername",data.playerInfo.username);
                }
                cb && cb();
            }, true, (data) => {
                //登录失败，返回平台
                if (data.code == 605 && data.oldGameId) {
                    AppEmitter.emit(consts.LOCAL_EVENT_PLAYING_OTHER_GAME, consts.GameName["game_" + data.oldGameId]);
                } else {
                    setTimeout(() => {
                        App.exitGame();
                    }, 1000);
                }

            });
        }
        App.showLoading();
        if (this.pomelo.isConnected) {
            this.disConnect();
        }
        //App.isManualDisconnect = false;
        this.pomelo.init({
            // host: consts.GEME_HOST,
            // port: consts.GAME_PORT,
            url: consts.ws_adress,
            log: true,
            reconnect: false,
        }, () => {
            App.isManualDisconnect = false;
            login();
        });
    }

    public static connectBack(cb: Function = null) {
        //重连之后重新登录
        let login = () => {
            App.hideLoading();
            cb && cb();
        }
        App.showLoading();
        if (this.pomelo.isConnected) {
            this.disConnect();
        }
        App.isManualDisconnect = false;
        this.pomelo.init({
            //@ts-ignore
            url: consts.ws_adress,
            log: true,
            reconnect: false,
        }, () => {
            login();
        });
    }

    /**
     * 断开连接
     */
    public static disConnect() {
        App.isManualDisconnect = true;
        this.pomelo.disconnect(true);
    }
    /**
     * 网络请求
     * @param route 消息id
     * @param msg   消息体  
     * @param cb    回调
     */
    public static sendRequest(route: string, msg: Object, cb: Function = null, isShowLoading = true, failCb: Function = null) {
        if (!msg) {
            msg = {};
        }
        if (!this.pomelo.isConnected) {
            //提示网络连接失败
            cc.warn("网络连接断开");
            AppEmitter.emit(consts.LOVAL_EVENT_NET_DISCONNECT);
            return;
        }

        // 刷新金币请求强制间隔一秒钟
        if (route == consts.GAME_QUERY_PLAYER_MONEY) {
            cc.log("刷新金币请求时间: " + new Date());
            let curTime = new Date().getTime();
            if (curTime - this.lastReqTime < this.throttleTime) {
                cc.log("刷新金币次数太频繁了！！！")
                return
            };
            this.lastReqTime = curTime;
        }

        cc.log('===发送消息，route:%s,请求数据:%s===============', route, JSON.stringify(msg));
        if (isShowLoading) {
            App.showLoading();
        }
        this.pomelo.request(route, msg, isShowLoading, (data) => {
            cc.log('===消息响应，route:%s,响应数据:%s===============', route, JSON.stringify(data));
            if ((route == consts.GAME_THREE_CARDS_JOIN_TABLE || route == consts.GAME_QUICK_JOIN_THREE_CARDS_TABLE)) {
                if (data.code != 0 && data.isShowLoading) {
                    App.hideLoading();
                }
            } else {
                if (data.isShowLoading) {
                    App.hideLoading();
                }
            }
            if (data.code == 0) {
                cb && cb(data);
            } else {
                if (data.code) {
                    if (data.code == 285) {
                        AppEmitter.emit(consts.LOCAL_EVENT_GAME_MAINTENANCE);
                    } else if (data.code == 290) {
                        AppEmitter.emit(consts.LOCAL_GUEST_JOIN_GAME_FAIL, { msg: "290" });
                    } else if (data.code == 17239) {
                        //金币不足
                        AppEmitter.emit(consts.LOCAL_GAME_NOT_ENOUGH_GOLD);
                    } else if (data.code == 17228) {
                        //玩家下注过高(高于配置允许最大值)
                        AppEmitter.emit(consts.LOCAL_GAME_REACH_BET_LIMIT);
                    }
                    else {
                        if (this.errCodes.indexOf(data.code) > -1 && !CC_DEBUG) {
                            cc.error("err code not show:" + data.code);
                        } else {
                            if (consts.isBattleHall && this.battleErrCodes.indexOf(data.code) > -1) {
                                //AppEmitter.emit(consts.LOCAL_BATTLE_SEAT_HINT);
                            } else {
                                //提示错误信息
                                cc.log("提示错误信息 : " + data.code)
                                App.showToast(data.code);
                            }
                        }
                        failCb && failCb(data);
                        if (cc.find("Canvas/loadNode")) {
                            cc.find("Canvas/loadNode").destroy();
                        }
                    }

                }
            }
        });
    }

}
