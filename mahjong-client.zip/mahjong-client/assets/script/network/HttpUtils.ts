import consts = require("../model/Consts");
import { Utils } from "../model/Utils";

export default class HttpUtils {
    /**
     * get请求
     * @param route   接口
     * @param params  参数
     * @param cb      
     */
    public static httpGet(httpUrl: string, route: string, params: Object, cb: Function) {
        let url = Utils.connectParasForHttpUrl(httpUrl + route, params);
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                var respone = xhr.responseText;
                cb && cb(respone);
                cc.log("response http get:" + route, respone);
            }
        };
        xhr.onerror = function (error) {
            cc.error('httpUtils onreadystatechange  onerror====' + xhr.readyState + '===' + xhr.status);
        };
        cc.log("request http:", url);
        xhr.open("GET", url , true);
        //xhr.setRequestHeader("Accept-Encoding", "application,json");
        // xhr.setRequestHeader("Access-Control-Allow-Origin","*");　　//允许所有域名访问
        // xhr.setRequestHeader("Access-Control-Allow-Methods", "POST,GET,OPTIONS,DELETE");
        // xhr.setRequestHeader("Access-Control-Max-Age", "3600");
        // xhr.setRequestHeader("Access-Control-Allow-Headers", "x-requested-with,Authorization");
        // xhr.setRequestHeader("Access-Control-Allow-Credentials", "true");
        xhr.timeout = 5000;// 5 seconds for timeout
        xhr.send();
    }
    /**
     * post 请求
     * @param route 
     * @param params 
     * @param cb 
     */
    public static httpPost(httpUrl: string, route: string, params: Object, cb: Function) {
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function () {
            cc.log('xhr.readyState=' + xhr.readyState + '  xhr.status=' + xhr.status);
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                var respone = xhr.responseText;
                cb && cb(respone);
                cc.log("response http:" + route, respone);
            }
        };
        xhr.onerror = function (error) {
            cc.error('httpUtils onreadystatechange  onerror====' + xhr.readyState + '===' + xhr.status);
        };
        cc.log("request http post:", route, httpUrl + route, JSON.stringify(params));
        xhr.open("POST", httpUrl + route, true);
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.timeout = 5000;// 5 seconds for timeout  
        xhr.send(JSON.stringify(params));
    }
}
