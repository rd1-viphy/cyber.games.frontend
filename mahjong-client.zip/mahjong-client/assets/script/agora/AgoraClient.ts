/**
 * 声网
 */
import App from "../model/App";
import consts = require("../model/Consts");
import PlayerMgr from "../model/PlayerMgr";
import { Utils } from "../model/Utils";
import AppEmitter from "../network/AppEmitter";
import HttpUtils from "../network/HttpUtils";
import { AgoraAudioStatus, AgoraCache, AgoraCacheInfo, AgoraUserInfo, AgoraVideoStatus } from "./AgoraDeclare";
import AgoraView from "./AgoraView";
const { ccclass, property } = cc._decorator;
@ccclass
export default class AgoraClient extends cc.Component {
   @property(cc.Prefab)
   target: cc.Prefab = null;

   /**s声网的应用id */
   private app_id: string = "cb3080ae462e4668ab98bcf4d9602bda";
   /**频道名称 */
   private channel: string = "";
   /**App的token */
   private token: string = "";
   /**加入声网的用户组 */
   private userInfos: AgoraUserInfo[] = [];
   /* 用来放置本地客户端 */
   private client = null;
   /* 用来放置本地音视频频轨道对象*/
   private localAudioTrack = null;
   private localVideoTrack = null;

   /**自己的userId */
   private selfUserID: string = "";
   /**视频刷新时间 */
   private refreshTime: number = 1000 / 24;

   private isPermission: boolean = false;

   onLoad() {
      //游戏进入后台
      cc.game.on(cc.game.EVENT_HIDE, () => {
         this.leaveCall();
         cc.audioEngine.pauseAll();
      });
      if(CC_BUILD){
         this.isPermission = this.getDevicedPermission();
      }else{
         this.isPermission = false;
      }
     
      AppEmitter.on(consts.LOVAL_EVENT_NET_DISCONNECT, this.netDisconnect, this);
   }
   /**
    * 声网初始化
    * @param token      
    * @param channel    
    * @param userInfos 
    */
   init(token: string, channel: string, userInfos: AgoraUserInfo[]) {
      this.channel = channel;
      this.token = token;
      this.userInfos = userInfos;
      this.selfUserID = PlayerMgr.getInstance().userID;
      if(this.isPermission){
           //@ts-ignore
           AgoraRTC.enableLogUpload();
           //@ts-ignore
           AgoraRTC.setLogLevel(0);
           this.startBasicCall();
      }
      // HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, consts.HTTP_ROUTE.GET_AGORA_TOKEN, { channelName: this.channel, uid: PlayerMgr.getInstance().uid, role: this.isPermission ? 1 : 2 }, (data) => {
      //    let responseData = JSON.parse(data);
      //    if (responseData.data && responseData.data.token) {
      //       this.token = responseData.data.token;
      //       //App.showToast("开始加入声网");
      //       //@ts-ignore
      //       AgoraRTC.enableLogUpload();
      //       //@ts-ignore
      //       AgoraRTC.setLogLevel(0);
           
      //       this.startBasicCall();
      //    }
      //});

   }
   /**
    * 监听玩家离开
    */
   protected onUserLeft() {
      this.client.on("user-left", (user) => {
         if (user && user.uid) {
            this.getAgoraView(user.uid).node.active = false;
         }
      });
   }
   /**
       * 监听用户发布
       */
   protected onPublishUser() {
      this.client.on("user-published", async (user, mediaType) => {
         // 开始订阅远端用户。
         await this.client.subscribe(user, mediaType);
         cc.log("subscribe success");
         const agoraView = this.getUserInfo(user.uid).agoraView;
         agoraView.active = true;
         // 表示本次订阅的是视频。
         if (mediaType === "video") {
            const remoteVideoTrack = user.videoTrack;
            this.getUserInfo(user.uid).videoTrack = remoteVideoTrack;
            //显示别人的视频
            let agoraViewComponent = this.getAgoraView(user.uid);
            if (agoraViewComponent.videoState == AgoraVideoStatus.open) {
               this.showVideo(remoteVideoTrack, user.uid);
               //this.checkVideoTrackIsActive(remoteVideoTrack, user.uid);
            }

         }
         // 表示本次订阅的是音频。
         if (mediaType === "audio") {
            // 订阅完成后，从 `user` 中获取远端音频轨道对象。
            const remoteAudioTrack = user.audioTrack;
            // 播放音频因为不会有画面，不需要提供 DOM 元素的信息。
            remoteAudioTrack.play();
            this.getUserInfo(user.uid).audioTrack = remoteAudioTrack;
            let agoraViewComponent = this.getAgoraView(user.uid);
            if (agoraViewComponent.audioState == AgoraAudioStatus.open) {
               agoraViewComponent.setAudioIsOpen(AgoraAudioStatus.open);
            }
         }
      });

   }
   /**
    * 取消的用户发布监听
    */
   protected onUnpublishUser() {
      this.client.on("user-unpublished", async (user, mediaType) => {
         if (mediaType === "video") {
            //删除视频节点
            this.removeVideo(user.uid);
         }
         if (mediaType === "audio") {
            this.removeAudio(user.uid);
            let agoraViewComponent = this.getAgoraView(user.uid);
            if(agoraViewComponent){
               agoraViewComponent.talkingAni.node.active = false;
            }
            
         }
      });
   }
   /**
    * 监听远端说话的人
    */
   protected onLicenseVolumeIndicator() {
      this.client.enableAudioVolumeIndicator();
      this.client.on("volume-indicator", (result) => {
         result.forEach((volume, index) => {
            console.log(`${index} UID ${volume.uid} Level ${volume.level}`);
            let userId = volume.uid;
            let level = volume.level;
            let agoraView = this.getAgoraView(userId);
            if (agoraView) {
               agoraView.setIsTalking(level > 15);
            }
         });
      });
   }
   /**
    * 监听token即将过期
    */
   public onTokenPrivilegeWillExpire() {
      this.client.on("token-privilege-will-expire", async () => {
         cc.log("token  即将过期");
         // 重新申请
         HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, consts.HTTP_ROUTE.GET_AGORA_TOKEN, { channelName: this.channel, uid: PlayerMgr.getInstance().uid, role: 1 }, async (data) => {
            let responseData = JSON.parse(data);
            if (responseData.data && responseData.data.token) {
               this.token = responseData.data.token;
               cc.log("更新token为", this.token);
               const premission = await this.client.renewToken(this.token);
               cc.log("更新完token ", premission);
            }
         });
      });
   }

   public tokenPrivilegeDidExpire() {
      this.client.on("token-privilege-did-expire", async () => {
         cc.log("token  已经过期");
         // HttpUtils.httpGet(consts.chessReqUrl.HttpAdress, "agora/getToken", { channelName: this.channel, uid: PlayerMgr.getInstance().uid }, async (data) => {
         //    let responseData = JSON.parse(data);
         //    if (responseData.token) {
         //       this.token = responseData.token;
         //       await this.client.renewToken(this.token);
         //    }
         //});
      });
   }

   //加入频道
   protected async startBasicCall() {
      //@ts-ignore
      if (AgoraRTC) {
         if (this.isPermission) {
            //@ts-ignore
            this.client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
            this.onPublishUser();
            this.onUnpublishUser();
            this.onUserLeft();
            this.onLicenseVolumeIndicator();
            this.onTokenPrivilegeWillExpire();
            // this.client.leave();
            // if (this.client.connectionState == "CONNECTED") {
            //    if (this.localAudioTrack) {
            //       this.localAudioTrack.close();
            //    }
            //    if (this.localVideoTrack) {
            //       this.localVideoTrack.close();
            //    }
            //    this.client.leave();
            //    cc.log("声网连接中，退出声网");
            // }
            //自己加入频道

            await this.client.join(this.app_id, this.channel, this.token, this.selfUserID);
            //@ts-ignore
            this.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
            // 通过摄像头采集的视频创建本地视频轨道对象。
            //@ts-ignore
            this.localVideoTrack = await AgoraRTC.createCameraVideoTrack();
            // 将这些音视频轨道对象发布到频道中。
            await this.client.publish([this.localAudioTrack, this.localVideoTrack]);
            //添加自己的音视频信息
            this.getUserInfo(this.selfUserID).audioTrack = this.localAudioTrack;
            this.getUserInfo(this.selfUserID).videoTrack = this.localVideoTrack;
            let agoraView = this.getAgoraView(this.selfUserID);
            agoraView.node.active = true;
            //显示自己的视频
            this.showVideo(this.localVideoTrack, this.selfUserID);
            agoraView.setAudioIsOpen(AgoraAudioStatus.open);
            agoraView.setAudioIsOpen(AgoraVideoStatus.open);
            //this.checkVideoTrackIsActive(this.localVideoTrack, this.selfUserID);
            console.log("加入频道");

            //App.showToast("设备支持");
            console.log("设备支持");
            // 通过麦克风采集的音频创建本地音频轨道对象。
         } else {
            //App.showToast("设备不支持");
            console.log("设备不支持");
         }
      }

   }

   //离开频道
   public async leaveCall() {
      // 销毁本地音视频轨道。
      if (this.localAudioTrack) {
         this.localAudioTrack.close();
      }
      if (this.localVideoTrack) {
         this.localVideoTrack.close();
      }
      if (this.client) {
         // 遍历远端用户。
         this.userInfos.forEach(user => {
            //删除视频节点
            this.removeVideo(user.userId);
            this.removeAudio(user.userId);
            const agoraView = this.getUserInfo(user.userId).agoraView;
            if (agoraView) {
               agoraView.active = false;
            }
         });
      }
      // 离开频道。
      if (this.client) {
         await this.client.leave();
         this.cancleLicense();
      }

   }

   /**
    * 显示视频
    */
   protected showVideo(videoTrack, userId: string) {
      const agoraView = this.getUserInfo(userId).agoraView;
      //agoraView.active = true;
      let agoraViewComponent = agoraView.getComponent(AgoraView);
      agoraViewComponent.setVideoIsOpen(AgoraVideoStatus.open, videoTrack);
      //本地的video渲染节点
      let videoNode = agoraViewComponent.video.node;
      const videoWidth = videoNode.width;
      const videoHeight = videoNode.height;
      //创建video显示父节点的标签
      const cocos2dContainer = document.getElementById("Cocos2dGameContainer");
      const playerContainer = document.createElement("div");
      playerContainer.id = userId;
      playerContainer.style.zIndex = "-10";
      playerContainer.style.width = videoWidth + "px";
      playerContainer.style.height = videoHeight + "px";
      playerContainer.style.position = "fixed"
      playerContainer.style.left = "0px";
      playerContainer.style.top = "0px";
      playerContainer.style.backgroundColor = "transparent";
      playerContainer.style.borderColor = "transparent";
      cocos2dContainer.appendChild(playerContainer);
      videoTrack.play(playerContainer);
      //创建需要渲染的canvas

      const canvas = document.createElement("canvas");
      canvas.id = "canvas_" + userId;
      canvas.style.zIndex = "-11";
      canvas.style.width = videoWidth + "px";
      canvas.style.height = videoHeight + "px";
      canvas.style.position = "fixed"
      canvas.style.left = "20px";
      canvas.style.bottom = "20px";
      cocos2dContainer.appendChild(canvas);

      //开始渲染
      const video: HTMLVideoElement = <HTMLVideoElement>document.getElementById("video_" + videoTrack.getTrackId());
      //video.style.transform = "rotate(90deg)";
      //setTimeout(() => video.play(), 100);
      const interval = setInterval(() => {
         let ctx = canvas.getContext("2d");
         ctx.drawImage(video, 0, 0, videoWidth, videoHeight);
         let texture = new cc.Texture2D();
         texture.initWithData(ctx.getImageData(0, 0, videoWidth, videoHeight).data, cc.Texture2D.PixelFormat.RGBA8888, videoWidth, videoHeight);
         videoNode.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
      }, this.refreshTime);
      this.getUserInfo(userId).interval = interval;
   }
   /**
    * 移除视频
    */
   public removeVideo(userId: string) {
      //停止渲染
      let interval = this.getUserInfo(userId).interval;
      if (interval) {
         clearInterval(interval);
         interval = null;
         //this.getUserInfo(userId).videoTrack = null;
         //this.getUserInfo(userId).audioTrack = null;
      }
      //移除video父节点的标签
      const playerContainer = document.getElementById(userId);
      if (playerContainer) {
         playerContainer.remove();
      }
      //移除canvas
      const canvas = document.getElementById("canvas_" + userId);
      if (canvas) {
         canvas.remove();
      }
      //隐藏video节点
      let agoraView = this.getUserInfo(userId).agoraView;
      if (agoraView) {
         //agoraView.getComponent(AgoraView).setVideoIsOpen(AgoraVideoStatus.close,null);
         agoraView.getComponent(AgoraView).videoFrame.active = false;
      }

      // const photo = this.getUserInfo(userId).photo;
      // photo.removeAllChildren();
   }
   /**
    * 移除音频
    * @param userId 
    */
   public removeAudio(userId: string) {
      this.getUserInfo(userId).audioTrack = null;
      let agoraView = this.getUserInfo(userId).agoraView;
      //agoraView.getComponent(AgoraView).setAudioIsOpen(AgoraAudioStatus.close);
   }
   //关闭自己的音频
   public closeLocalAudio() {
      if (this.localAudioTrack) {
         this.localAudioTrack.setEnabled(false);
      }
      let agoraView = this.getAgoraView(this.selfUserID);
      if (agoraView) {
         agoraView.setAudioIsOpen(AgoraAudioStatus.close);
      }
   }
   //打开自己的音频
   public openLocalAudio() {
      if (this.localAudioTrack) {
         this.localAudioTrack.setEnabled(true);
      }
      let agoraView = this.getAgoraView(this.selfUserID);
      if (agoraView) {
         agoraView.setAudioIsOpen(AgoraAudioStatus.open);
      }

   }
   //关闭自己的视频
   public closeLocalVideo() {
      if (this.localVideoTrack) {
         this.localVideoTrack.setEnabled(false);
         let user = this.getUserInfo(this.selfUserID);
         clearInterval(user.interval);
      }
      let agoraView = this.getAgoraView(this.selfUserID);
      if (agoraView) {
         agoraView.setVideoIsOpen(AgoraVideoStatus.close, null);
      }
   }
   //打开自己的视频
   public openLocalVideo() {
      if (this.localVideoTrack) {
         //this.localVideoTrack.play();
         this.localVideoTrack.setEnabled(true);
         this.showVideo(this.localVideoTrack, this.selfUserID);
         //this.showVideo(this.localVideoTrack,this.selfUserID);
      }
      let agoraView = this.getAgoraView(this.selfUserID);
      if (agoraView) {
         agoraView.setVideoIsOpen(AgoraVideoStatus.open, this.localVideoTrack);
      }
   }
   /**
    * 关闭别人的音频
    */
   public closeOtherAudio(userId: string) {
      let user = this.getUserInfo(userId);
      if (user && user.audioTrack) {
         user.audioTrack.stop();
      }

      let agoraView = this.getAgoraView(userId);
      if (agoraView && user) {
         agoraView.setAudioIsOpen(AgoraAudioStatus.close);
      }

   }
   /**
   * 打开别人的音频
   */
   public openOtherAudio(userId: string) {
      let user = this.getUserInfo(userId);
      if (user && user.audioTrack) {
         user.audioTrack.play();
      }

      let agoraView = this.getAgoraView(userId);
      if (agoraView && user) {
         agoraView.setAudioIsOpen(AgoraAudioStatus.open);
      }

   }
   /**
    * 关闭别人的视频
    */
   public closeOtherVideo(userId: string) {
      let user = this.getUserInfo(userId);
      if (user && user.videoTrack) {
         user.videoTrack.stop();
         clearInterval(user.interval);
      }

      let agoraView = this.getAgoraView(userId);
      if (agoraView && user) {
         agoraView.setVideoIsOpen(AgoraVideoStatus.close, null);
      }
   }

   /**
    * 打开别人的视频
    */
   public openOtherVideo(userId: string) {
      let user = this.getUserInfo(userId);
      if (user && user.videoTrack) {
         //user.videoTrack.play();
         this.showVideo(user.videoTrack, userId);
      }
      let agoraView = this.getAgoraView(userId);
      if (agoraView && user) {
         agoraView.setVideoIsOpen(AgoraVideoStatus.open, user.videoTrack);
      }
   }
   /**
    * 設置音量大小
    */
   public setAudioVolume(userId: string, volume: number) {
      let user = this.getUserInfo(userId);
      if (user && user.audioTrack) {
         user.audioTrack.setVolume(volume);
         if (volume > 0) {
            user.audioTrack.play();
         } else {
            user.audioTrack.stop();
         }
      }
      let agoraView = this.getAgoraView(userId);
      if (agoraView && user) {
         agoraView.setVolume(volume);
      }
   }
   /**
    * 通过userId 获取
    * @param uersId 
    */
   private getUserInfo(userId: string) {
      if (this.userInfos) {
         let userSize = this.userInfos.length;
         for (let index = 0; index < userSize; index++) {
            const element = this.userInfos[index];
            if (element.userId == userId) {
               return element;
            }
         }
      }
   }


   public changeAgoraView(userId, agoraItem) {
      if (userId) {
         let tempNode = agoraItem
         this.getUserInfo(userId).agoraView = tempNode;
      }
   }

   public changeShowVideo(userId) {
      if (userId) {
         let user = this.getUserInfo(userId);
         let agoraView = this.getUserInfo(userId).agoraView;
         agoraView.active = true;
         if (userId && user.videoTrack) {
            this.showVideo(user.videoTrack, userId);
         }
         if (agoraView && user) {
            let agoraViewComponent = agoraView.getComponent(AgoraView);
            agoraViewComponent.setVideoIsOpen(AgoraVideoStatus.open, user.videoTrack);
         }
      }
   }

   /**
    * 获取对应agoraView
    */
   public getAgoraView(userId: string): AgoraView {
      if (this.userInfos) {
         let userSize = this.userInfos.length;
         for (let index = 0; index < userSize; index++) {
            const element = this.userInfos[index];
            if (element.userId == userId) {
               if (element.agoraView && element.agoraView.getComponent(AgoraView)) {
                  return element.agoraView.getComponent(AgoraView);
               }
               return null;
            }
         }
      } else {
         return null;
      }
   }
   /**
    * 增加用户
    */
   public addUser(userInfo: AgoraUserInfo) {
      let include: boolean = false;
      this.userInfos.forEach((element) => {
         if (element.userId == userInfo.userId) {
            include = true;
         }
      });
      if (!include) {
         this.userInfos.push(userInfo);
      }
   }
   /**
    * 删除用户
    * @param userId 
    */
   public delectUser(userId: string) {
      let agoraView = this.getAgoraView(userId);
      if (agoraView) {
         agoraView.node.active = false;
      }
      let delectIndex = -1;
      this.userInfos.forEach((element, index) => {
         if (element.userId == userId) {
            delectIndex = index;
         }
      });
      if (delectIndex > -1) {
         this.userInfos.splice(delectIndex, 1);
      }
   }
   checkVideoTrackIsActive(videoTrack, userId) {
      if (videoTrack) {
         //@ts-ignore
         AgoraRTC.checkVideoTrackIsActive(videoTrack).then(result => {
            console.log(`${result ? "available" : "unavailable"}`);
            if (!result) {
               //关闭某个人的视频
               if (userId) {
                  this.removeVideo(userId);
               }
            }
         }).catch(e => {
            console.log("check video track error!", e);
         });
      }
   }
   /**
    * 网络断开连接
    */
   netDisconnect() {
      this.leaveCall();
   }
   /**
    * 获取设备支持
    */
   getDevicedPermission(): boolean {
      let premisson = false;
      let supportWebRtc = !!(window.RTCPeerConnection && navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.WebSocket);
      if (supportWebRtc) {
         console.log("WebRtc support");
         //版本比对
         //@ts-ignore
         var parser = new UAParser();
         var result = parser.getResult();
         var browser = result.browser;
         var os = result.os;
         if (os.name.toLowerCase() == "android") {
            if (browser.name.toLowerCase().indexOf("webview")) {
               premisson = parseInt(browser.version) > 76;
            } else {
               premisson = true;
            }
         } else if (os.name.toLowerCase() == "ios") {
            premisson = parseFloat(os.version) >= 14.3;
         } else {
            if (browser.name.toLowerCase() == 'chrome') {
               premisson = parseInt(browser.version) >= 58;
            } else if (browser.name.toLowerCase() == 'safari') {
               premisson = parseInt(browser.version) >= 11;
            } else if (browser.name.toLowerCase() == 'firefox') {
               premisson = parseInt(browser.version) >= 56;
            } else if (browser.name.toLowerCase() == 'opera') {
               premisson = parseInt(browser.version) >= 45;
            } else {
               premisson = true;
            }
         }
      } else {
         console.log("WebRtc not support");
         premisson = false;
      }
      console.log("support premission=", premisson);
      return premisson;
   }
   /**
    * 取消监听
    */
   protected cancleLicense() {
      if (this.client) {
         this.client.off("user-published");
         this.client.off("user-unpublished");
         this.client.off("volume-indicator");
         this.client.off("user-left");
         this.client.off("token-privilege-will-expire")
         AppEmitter.off(consts.LOVAL_EVENT_NET_DISCONNECT);
         cc.game.off(cc.game.EVENT_HIDE);
      }
   }
   /**
    * 获取用户缓存信息
    */
   getUserCacheInfo(getUserId:string ){
      let getUserCacheInfo:AgoraCacheInfo = null;
      let agoraCache = cc.sys.localStorage.getItem("agoraCache"); 
      let agoraCacheData:AgoraCache = null;
      if(agoraCache){
         agoraCacheData = JSON.parse(agoraCache);
      } 
      if(agoraCacheData){
         let userCacheInfos = agoraCacheData.userCacheInfo;
         if(userCacheInfos && userCacheInfos.length > 0){
            userCacheInfos.forEach((userCache)=>{
               if(userCache.userId == getUserId){
                  getUserCacheInfo = userCache
               }
            });
         }
      }
      return getUserCacheInfo;
   }
   /**
    * 存入用户缓存信息
    * @param setUserInfo 
    */
   setUserCacheInfo(setUserInfo:AgoraCacheInfo){
      let agoraCache = cc.sys.localStorage.getItem("agoraCache"); 
      let agoraCacheData:AgoraCache = null;
      if(agoraCache){
         agoraCacheData = JSON.parse(agoraCache);
         if(agoraCacheData){
            let userCacheInfos = agoraCacheData.userCacheInfo;
            if(userCacheInfos && userCacheInfos.length > 0){
               let include  = false;
               userCacheInfos.forEach((userCache)=>{
                  if(userCache.userId == setUserInfo.userId){
                    include = true;
                    userCache.videoCache = setUserInfo.videoCache;
                    userCache.audioCache = setUserInfo.audioCache;
                  }
               });
               if(!include){
                  userCacheInfos.push (setUserInfo);
               }
               cc.sys.localStorage.setItem("agoraCache",JSON.stringify(agoraCacheData));
            }
         }
      }else{
         agoraCacheData = {userCacheInfo:[]};
         agoraCacheData.userCacheInfo.push(setUserInfo);
         cc.sys.localStorage.setItem("agoraCache",JSON.stringify(agoraCacheData));
      } 
   }

   onDestroy() {
      if (this.client) {
         this.client.leave();
      }
      this.cancleLicense();
   }
}
