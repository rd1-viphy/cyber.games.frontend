import PlayerMgr from "../model/PlayerMgr";
import AgoraClient from "./AgoraClient";
import { AgoraAudioStatus, AgoraCacheInfo, AgoraVideoStatus } from "./AgoraDeclare";
import AgoraView from "./AgoraView";


const { ccclass, property } = cc._decorator;

@ccclass
export default class AgoraSwitchNode extends cc.Component {
    @property({
        tooltip: "开关图集",
        type: cc.SpriteFrame
    })
    switchSpriteFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "声音开关背景",
        type: cc.Sprite
    })
    audioBtnBg: cc.Sprite = null;

    @property({
        tooltip: "视频开关背景",
        type: cc.Sprite
    })
    videoBtnBg: cc.Sprite = null;

    @property({
        tooltip:"語音進度條",
        type:cc.ProgressBar
    })
    audioProgressBar:cc.ProgressBar = null;

    @property({
        tooltip:"語音滑動條",
        type:cc.Slider
    })
    audioSlider:cc.Slider = null;

    agoraClient: AgoraClient = null;
    userId: string = "";
    init(agoraClient: AgoraClient, uersId: string) {
        this.agoraClient = agoraClient;
        this.userId = uersId;
        this.scheduleOnce(()=>{
            this.refreshProgress();
        },0.2);
        //显示
        this.audioBtnBg.node.parent.active = this.userId == PlayerMgr.getInstance().uid;
        this.audioProgressBar.node.active = this.userId != PlayerMgr.getInstance().uid;
        this.audioSlider.node.active = this.userId != PlayerMgr.getInstance().uid;
        // //根据缓存显示
        // let userCache = this.agoraClient.getUserCacheInfo(this.userId);
        // if(userCache){
        //      let audioCache = userCache.audioCache;
        //      let videoCache = userCache.videoCache;
        //      let agoraView: AgoraView = this.agoraClient.getAgoraView(this.userId);
        //      agoraView.audioState = audioCache;
        //      agoraView.videoState  = videoCache;
        //  }
        this.refreshBtnBg();
    }
 
    /**
     * 声音开关控制
     * @param event 
     */
    audioToggleClicked(event) {
        let agoraView: AgoraView = this.agoraClient.getAgoraView(this.userId);
        if(agoraView){
            if (agoraView.audioState == AgoraAudioStatus.close) {
                if (this.userId == PlayerMgr.getInstance().uid) {
                    this.agoraClient.openLocalAudio();
                } else {
                    this.agoraClient.openOtherAudio(this.userId);
                }
            } else {
                if (this.userId == PlayerMgr.getInstance().uid) {
                    this.agoraClient.closeLocalAudio();
                } else {
                    this.agoraClient.closeOtherAudio(this.userId);
                }
            }
        }
        this.refreshBtnBg();
    }
    /**
     * 视频开关控制
     * @param event 
     */
    videoToggleCliecked(event) {
        
        let agoraView: AgoraView = this.agoraClient.getAgoraView(this.userId);
        cc.log("========视频开关控制start");
        if(agoraView){
            cc.log("========",agoraView.videoState);
            if (agoraView.videoState == AgoraVideoStatus.close) {
                if (this.userId == PlayerMgr.getInstance().uid) {
                    this.agoraClient.openLocalVideo();
                } else {
                    this.agoraClient.openOtherVideo(this.userId);
                }
            } else {
                if (this.userId == PlayerMgr.getInstance().uid) {
                    this.agoraClient.closeLocalVideo();
                } else {
                    this.agoraClient.closeOtherVideo(this.userId);
                }
            }
            this.refreshBtnBg();
        }
        cc.log("========视频开关控制end");
    }
    sliderDraggle(event){
       let progess = event.progress;
       this.agoraClient.setAudioVolume(this.userId,progess*100);
       this.refreshProgress();
    }
    refreshBtnBg() {
        //刷新按钮状态
        let agoraView: AgoraView = this.agoraClient.getAgoraView(this.userId);
        if (agoraView) {
            this.audioBtnBg.spriteFrame = this.switchSpriteFrame[agoraView.audioState];
            this.videoBtnBg.spriteFrame = this.switchSpriteFrame[agoraView.videoState];
        }
        // let userCache = this.agoraClient.getUserCacheInfo(this.userId);
        // let userCacheData:AgoraCacheInfo = {userId:null,videoCache:null,audioCache:null};
        // if(userCache){
        //     userCacheData = userCache;
        // }
        // userCacheData.userId = this.userId;
        // userCacheData.videoCache = agoraView.videoState;
        // userCacheData.audioCache = agoraView.audioState;
        // this.agoraClient.setUserCacheInfo(userCacheData);
    }

    refreshProgress(){
        let agoraView: AgoraView = this.agoraClient.getAgoraView(this.userId);
        if (agoraView) {
           this.audioSlider.progress = agoraView.volume/100;
           this.audioProgressBar.progress = agoraView.volume/100;

        // let userCache = this.agoraClient.getUserCacheInfo(this.userId);
        // let userCacheData:AgoraCacheInfo = {userId:null,videoCache:null,audioCache:null};
        // if(userCache){
        //     userCacheData = userCache;
        // }
        // userCacheData.userId = this.userId;
        // userCacheData.videoCache = agoraView.videoState;
        // userCacheData.audioCache = agoraView.volume/100>0?1:0;
        // this.agoraClient.setUserCacheInfo(userCacheData);
        }
    }

    
}
