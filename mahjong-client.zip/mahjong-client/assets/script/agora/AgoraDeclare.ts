
/**
 * 声网用户信息
 */
export interface AgoraUserInfo {
    agoraView: cc.Node,
    userId: string,
    videoTrack: any,
    audioTrack: any,
    interval: any
}
/**
 * 用户视频开关
 */
export enum AgoraVideoStatus {
    open,
    close
}

/**
 * 用户音频开关
 */
export enum AgoraAudioStatus {
    open,
    close
}
/**
 * 本地缓存
 */
export interface AgoraCache {
    userCacheInfo: AgoraCacheInfo[],
}
/**
 * 本地缓存用户讯息
 */
export interface AgoraCacheInfo {
    userId:string,
    videoCache: number,
    audioCache: number
}