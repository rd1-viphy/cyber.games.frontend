import { AgoraAudioStatus, AgoraVideoStatus } from "./AgoraDeclare";

/**
 *声网 显示view
 */
const { ccclass, property } = cc._decorator;

@ccclass
export default class AgoraView extends cc.Component {

    @property({
        tooltip: "视频窗口",
        type: cc.Node
    })
    videoFrame: cc.Node = null;

    @property({
        tooltip: "视频渲染精灵",
        type: cc.Sprite
    })
    video: cc.Sprite = null;

    @property({
        tooltip: "视频标识",
        type: cc.Sprite
    })
    videoMark: cc.Sprite = null;

    @property({
        tooltip: "音频标识",
        type: cc.Sprite
    })
    audioMark: cc.Sprite = null;

    @property({
        tooltip: "讲话动画",
        type: sp.Skeleton
    })
    talkingAni: sp.Skeleton = null;

    @property({
        tooltip: "视频标识的精灵集",
        type: cc.SpriteFrame
    })
    videoSpriteFrame: cc.SpriteFrame[] = [];

    @property({
        tooltip: "音频标识的精灵集",
        type: cc.SpriteFrame
    })
    audioSpriteFrame: cc.SpriteFrame[] = [];
    /**
     * 初始化
     */
    init() {

    }
   
    /**当前视频状态 */
    videoState: number = AgoraVideoStatus.open;
    /**当前音频状态 */
    audioState: number = AgoraAudioStatus.open;
    /**通話音量 */
    volume: number = 100;
    /**
     * 设置视频是否打开
     */
    setVideoIsOpen(status: number,videoTrack) {
        this.videoState = status;
        this.videoFrame.active = status == AgoraVideoStatus.open && videoTrack;
        this.videoMark.spriteFrame = this.videoSpriteFrame[status];
        //this.refreshSelfNodeShow();
    }

    /**
     * 设置音频是否打开
     */
    setAudioIsOpen(status: number) {
        this.audioState = status;
        this.audioMark.spriteFrame = this.audioSpriteFrame[status];
        if(status == AgoraAudioStatus.close){
            this.talkingAni.node.active = false;
        }
       // this.refreshSelfNodeShow();
    }
    /**
     * 正在讲话
     */
    setIsTalking(isTalking: boolean) {
        if (isTalking && this.volume > 0 && this.audioState == AgoraAudioStatus.open) {
            this.talkingAni.node.active = true;
        }else{
            this.talkingAni.node.active = false;
        }
    }

    /**
     * 设置语音大小
     * @param volume 
     */
    setVolume(volume: number) {
        this.volume = volume;
        if (volume == 0) {
            this.audioMark.spriteFrame = this.audioSpriteFrame[1];
        } else {
            this.audioMark.spriteFrame = this.audioSpriteFrame[0];
        }
    }
    /**
     * 刷新自己的显示
     */
    refreshSelfNodeShow() {
        this.node.active = (this.audioState == AgoraAudioStatus.open || this.videoState == AgoraVideoStatus.open);
    }
}
