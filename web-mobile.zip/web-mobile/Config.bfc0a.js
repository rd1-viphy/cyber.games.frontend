window.gameConfig = {
    WS_URL: '//47.129.229.29:3535',
    PROTO_URL: '//47.129.229.29:9595/assets/cyber.games.bin',
    HTTP_URL:'http://192.168.3.180',
    IS_ACCESS:false,
}