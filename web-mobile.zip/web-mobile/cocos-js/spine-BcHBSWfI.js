System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var spine = exports("default", 'assets/spine-u3j38j0v.wasm'); /* asset-hash:ac8c224c */

		})
	};
}));
