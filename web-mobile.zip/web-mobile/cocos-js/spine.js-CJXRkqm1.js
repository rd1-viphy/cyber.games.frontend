System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var spine_js = exports("default", 'assets/spine.js.mem-1a7qSucW.bin'); /* asset-hash:d098f0b6 */

		})
	};
}));
