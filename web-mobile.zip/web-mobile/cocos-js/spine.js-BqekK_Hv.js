System.register([], (function (exports, module) {
	'use strict';
	return {
		execute: (function () {

			var spine_js = exports("default", 'assets/spine.js.mem-DnIU7NNm.bin'); /* asset-hash:6d524334 */

		})
	};
}));
