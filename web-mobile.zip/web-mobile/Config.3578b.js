window.gameConfig = {
    WS_URL: 'wss://bcg-demo.t9live.cc/ws',
    PROTO_URL: 'https://bcg-demo.t9live.cc/conf/assets/cyber.games.bin',
    HTTP_URL: 'https://bcg-demo.t9live.cc/bridge.api/',
    DESCRIPTION_URL: 'https://bcg-demo.t9live.cc/help/',
    IS_ACCESS: false,
    VERSION: "v202601152104",
    LANGUAGE: "tw",
}