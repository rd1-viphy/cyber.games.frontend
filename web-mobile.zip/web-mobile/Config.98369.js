window.gameConfig = {
    WS_URL: 'wss://bcg-demo.t9live.cc/ws',
    PROTO_URL: 'https://bcg-demo.t9live.cc/conf/assets/cyber.games.bin',
    HTTP_URL: 'https://bcg-demo.t9live.cc/bridge.api/',
    IS_ACCESS: false,
    VERSION: "v08291650",
}