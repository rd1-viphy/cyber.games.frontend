System.register("chunks:///_virtual/BacPusherTBettingState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "b238cKP/LxNbbmYpC7gNU2X", "BacPusherTBettingState", undefined);
      var BacPusherTBettingState = exports('BacPusherTBettingState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTBettingState, _BaseState);
        function BacPusherTBettingState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTBettingState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableMainGameView.showGameClock();
          this.gameTable.tableBetView.setAreaBtnsTouchStatus(true);
          this.gameTable.tableMainGameView.setBetNodeStatus(true);
          this.gameTable.tableMainGameView.refreshAllBtnsStatus();
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Please_Bet);
          AudioManager.playSound('Female/Female_StartBet');
        };
        _proto.exit = function exit() {
          this.gameTable.tableBetView.setAreaBtnsTouchStatus(false);
          this.gameTable.tableMainGameView.setBetNodeStatus(false);
          this.gameTable.tableMainGameView.cancleBetData();
          this.gameTable.tableMainGameView.hideGameClock();
        };
        return BacPusherTBettingState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/bacPusherTBundle", ['./BacPusherTBettingState.ts', './BacPusherTDealCardState.ts', './BacPusherTGame.ts', './BacPusherTGameTale.ts', './BacPusherTOpenCardState.ts', './BacPusherTPrepareState.ts', './BacPusherTSettleState.ts', './BacPusherTStopBetState.ts', './BacPusherTTableController.ts', './BacPusherTTableReplayController.ts', './BacPusherTEnum.ts', './BacPusherTTableModel.ts', './BacPusherTTableProxy.ts', './BacPusherTMainGameView.ts', './BacPusherTTableBetView.ts', './BacPusherTTableCardView.ts', './BacPusherTTableChipView.ts', './BacPusherTTableSettleView.ts', './BacPusherTTableTipView.ts', './BacPusherTVerifyCardView.ts'], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

System.register("chunks:///_virtual/BacPusherTDealCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "7a0f1EDzalPpKO6fPDR2j1q", "BacPusherTDealCardState", undefined);
      var BacPusherTDealCardState = exports('BacPusherTDealCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTDealCardState, _BaseState);
        function BacPusherTDealCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTDealCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          //this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Deal_Card);
          this.gameTable.tableVerifyCardView.disCards();
        };
        _proto.exit = function exit() {};
        return BacPusherTDealCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTEnum.ts", ['cc'], function (exports) {
  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "26a70VIIe9Kb6q/I1LVBXut", "BacPusherTEnum", undefined);
      var BacPusherTCardType = exports('BacPusherTCardType', /*#__PURE__*/function (BacPusherTCardType) {
        BacPusherTCardType["BIE_TEN"] = "\u9C49\u5341";
        BacPusherTCardType["ONE_POINT"] = "\u4E00\u9EDE";
        BacPusherTCardType["ONE_AND_HALF"] = "\u4E00\u9EDE\u534A";
        BacPusherTCardType["TWO_POINT"] = "\u4E8C\u9EDE";
        BacPusherTCardType["TWO_AND_HALF"] = "\u4E8C\u9EDE\u534A";
        BacPusherTCardType["THREE_POINT"] = "\u4E09\u9EDE";
        BacPusherTCardType["THREE_AND_HALF"] = "\u4E09\u9EDE\u534A";
        BacPusherTCardType["FOUR_POINT"] = "\u56DB\u9EDE";
        BacPusherTCardType["FOUR_AND_HALF"] = "\u56DB\u9EDE\u534A";
        BacPusherTCardType["FIVE_POINT"] = "\u4E94\u9EDE";
        BacPusherTCardType["FIVE_AND_HALF"] = "\u4E94\u9EDE\u534A";
        BacPusherTCardType["SIX_POINT"] = "\u516D\u9EDE";
        BacPusherTCardType["SIX_AND_HALF"] = "\u516D\u9EDE\u534A";
        BacPusherTCardType["SEVEN_POINT"] = "\u4E03\u9EDE";
        BacPusherTCardType["SEVEN_AND_HALF"] = "\u4E03\u9EDE\u534A";
        BacPusherTCardType["EIGHT_POINT"] = "\u516B\u9EDE";
        BacPusherTCardType["EIGHT_AND_HALF"] = "\u516B\u9EDE\u534A";
        BacPusherTCardType["NINE_POINT"] = "\u4E5D\u9EDE";
        BacPusherTCardType["NINE_AND_HALF"] = "\u4E5D\u9EDE\u534A";
        BacPusherTCardType["TWO_EIGHT_GANG"] = "\u4E8C\u516B\u69D3";
        BacPusherTCardType["ONE_BAO"] = "\u4E00\u5BF6";
        BacPusherTCardType["TWO_BAO"] = "\u4E8C\u5BF6";
        BacPusherTCardType["THREE_BAO"] = "\u4E09\u5BF6";
        BacPusherTCardType["FOUR_BAO"] = "\u56DB\u5BF6";
        BacPusherTCardType["FIVE_BAO"] = "\u4E94\u5BF6";
        BacPusherTCardType["SIX_BAO"] = "\u516D\u5BF6";
        BacPusherTCardType["SEVEN_BAO"] = "\u4E03\u5BF6";
        BacPusherTCardType["EIGHT_BAO"] = "\u516B\u5BF6";
        BacPusherTCardType["NINE_BAO"] = "\u4E5D\u5BF6";
        BacPusherTCardType["WHITE_PAIR"] = "\u767D\u677F\u5C0D";
        return BacPusherTCardType;
      }({}));
      var BacPusherTBetType = exports('BacPusherTBetType', ['平倍', '翻倍', '超牛']);
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTGame.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGame.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseGame;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGame = module.BaseGame;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "0bf6d7AlIBMnKeQTZ/iKXeX", "BacPusherTGame", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTGame = exports('BacPusherTGame', (_dec = ccclass('BacPusherTGame'), _dec(_class = /*#__PURE__*/function (_BaseGame) {
        _inheritsLoose(BacPusherTGame, _BaseGame);
        function BacPusherTGame() {
          return _BaseGame.apply(this, arguments) || this;
        }
        return BacPusherTGame;
      }(BaseGame)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTGameTale.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGameTale.ts', './BaseTableReplayController.ts', './BacPusherTTableProxy.ts', './BacPusherTTableController.ts', './BacPusherTTableModel.ts', './BacPusherTBettingState.ts', './BacPusherTDealCardState.ts', './BacPusherTSettleState.ts', './BacPusherTOpenCardState.ts', './BacPusherTPrepareState.ts', './BacPusherTStopBetState.ts', './bc_niuniu_s.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BaseGameTale, BaseTableReplayController, BacPusherTTableProxy, BacPusherTTableController, BacPusherTTableModel, BacPusherTBettingState, BacPusherTDealCardState, BacPusherTSettleState, BacPusherTOpenCardState, BacPusherTPrepareState, BacPusherTStopBetState, Phase;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGameTale = module.BaseGameTale;
    }, function (module) {
      BaseTableReplayController = module.BaseTableReplayController;
    }, function (module) {
      BacPusherTTableProxy = module.BacPusherTTableProxy;
    }, function (module) {
      BacPusherTTableController = module.BacPusherTTableController;
    }, function (module) {
      BacPusherTTableModel = module.BacPusherTTableModel;
    }, function (module) {
      BacPusherTBettingState = module.BacPusherTBettingState;
    }, function (module) {
      BacPusherTDealCardState = module.BacPusherTDealCardState;
    }, function (module) {
      BacPusherTSettleState = module.BacPusherTSettleState;
    }, function (module) {
      BacPusherTOpenCardState = module.BacPusherTOpenCardState;
    }, function (module) {
      BacPusherTPrepareState = module.BacPusherTPrepareState;
    }, function (module) {
      BacPusherTStopBetState = module.BacPusherTStopBetState;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;
      cclegacy._RF.push({}, "1c65d4bkhVItJr2bofn6/Ap", "BacPusherTGameTale", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTGameTale = exports('BacPusherTGameTale', (_dec = ccclass('BacPusherTGameTale'), _dec2 = property({
        type: BacPusherTTableProxy
      }), _dec3 = property({
        type: BaseTableReplayController
      }), _dec4 = property({
        type: BacPusherTTableController
      }), _dec5 = property({
        type: BacPusherTTableModel
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseGameTale) {
        _inheritsLoose(BacPusherTGameTale, _BaseGameTale);
        function BacPusherTGameTale() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseGameTale.call.apply(_BaseGameTale, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "tableProxy", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableReplayController", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableController", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableModel", _descriptor4, _assertThisInitialized(_this));
          _this.states = [{
            stateCode: Phase.Prepare,
            state: new BacPusherTPrepareState()
          }, {
            stateCode: Phase.DealCards,
            state: new BacPusherTDealCardState()
          }, {
            stateCode: Phase.Betting,
            state: new BacPusherTBettingState()
          }, {
            stateCode: Phase.StopBet,
            state: new BacPusherTStopBetState()
          }, {
            stateCode: Phase.OpenCards,
            state: new BacPusherTOpenCardState()
          }, {
            stateCode: Phase.Settle,
            state: new BacPusherTSettleState()
          }];
          return _this;
        }
        var _proto = BacPusherTGameTale.prototype;
        _proto.onDestroy = function onDestroy() {
          this.tableAllCardVerifyInfoView.onDestroy();
          this.tableSingCardVerifyInfoView.onDestroy();
        };
        return BacPusherTGameTale;
      }(BaseGameTale), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tableProxy", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tableReplayController", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "tableController", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "tableModel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTMainGameView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseMainGameView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseMainGameView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseMainGameView = module.BaseMainGameView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "eabc9+ZkjtLno1ia1dOAYK3", "BacPusherTMainGameView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTMainGameView = exports('BacPusherTMainGameView', (_dec = ccclass('BacPusherTMainGameView'), _dec(_class = /*#__PURE__*/function (_BaseMainGameView) {
        _inheritsLoose(BacPusherTMainGameView, _BaseMainGameView);
        function BacPusherTMainGameView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseMainGameView.call.apply(_BaseMainGameView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        return BacPusherTMainGameView;
      }(BaseMainGameView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTOpenCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "a1328eHNWtBWLYxALoo6zrO", "BacPusherTOpenCardState", undefined);
      var BacPusherTOpenCardState = exports('BacPusherTOpenCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTOpenCardState, _BaseState);
        function BacPusherTOpenCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTOpenCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Deal_Card);
          if (!isConnectAgain) {
            this.gameTable.tableCardView.startOpenCard();
            this.gameTable.tableVerifyCardView.startOpenCard();
          }
        };
        _proto.exit = function exit() {
          this.gameTable.tableTipView.hideTip();
        };
        return BacPusherTOpenCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTPrepareState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "1049cxMMbhM94cpKA8E3nd2", "BacPusherTPrepareState", undefined);
      var BacPusherTPrepareState = exports('BacPusherTPrepareState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTPrepareState, _BaseState);
        function BacPusherTPrepareState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTPrepareState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableModel.initData();
          this.gameTable.initView();
        };
        _proto.exit = function exit() {};
        return BacPusherTPrepareState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTSettleState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "e07aay8xXpM6J1XnLDQLpVG", "BacPusherTSettleState", undefined);
      var BacPusherTSettleState = exports('BacPusherTSettleState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTSettleState, _BaseState);
        function BacPusherTSettleState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTSettleState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableSettleView.showResult();
          this.gameTable.tableBetView.showWinAreaLight();
        };
        _proto.exit = function exit() {};
        return BacPusherTSettleState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTStopBetState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "c2fd9f848hEL69lfnIZAhOT", "BacPusherTStopBetState", undefined);
      var BacPusherTStopBetState = exports('BacPusherTStopBetState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacPusherTStopBetState, _BaseState);
        function BacPusherTStopBetState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacPusherTStopBetState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Stop_Bet);
          AudioManager.playSound('Female/Female_EndBet');
        };
        _proto.exit = function exit() {};
        return BacPusherTStopBetState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableBetView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableBetView.ts', './BetPercentItem.ts', './bc_pushdot.ts', './BacPusherTEnum.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Node, Label, BaseTableBetView, BetPercentItem, BetType, BacPusherTBetType;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      Label = module.Label;
    }, function (module) {
      BaseTableBetView = module.BaseTableBetView;
    }, function (module) {
      BetPercentItem = module.BetPercentItem;
    }, function (module) {
      BetType = module.BetType;
    }, function (module) {
      BacPusherTBetType = module.BacPusherTBetType;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;
      cclegacy._RF.push({}, "d3974/Ob1ZPc4pfE3ILY8kv", "BacPusherTTableBetView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableBetView = exports('BacPusherTTableBetView', (_dec = ccclass('BacPusherTTableBetView'), _dec2 = property([BetPercentItem]), _dec3 = property(Node), _dec4 = property(Label), _dec5 = property([Node]), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableBetView) {
        _inheritsLoose(BacPusherTTableBetView, _BaseTableBetView);
        function BacPusherTTableBetView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableBetView.call.apply(_BaseTableBetView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _initializerDefineProperty(_this, "betPercentItems", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "betTypeSelectNode", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "betTypeSelectLabel", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "betPageNode", _descriptor4, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = BacPusherTTableBetView.prototype;
        _proto.initView = function initView() {
          _BaseTableBetView.prototype.initView.call(this);
          this.betPercentItems.forEach(function (element) {
            element.showBetPercentInfo({
              betNum: '0',
              betPercent: 0,
              betPerosnNum: 0
            });
          });
        };
        _proto.updateView = function updateView() {
          _BaseTableBetView.prototype.updateView.call(this);
          this.refrershBetTypeSelect(0);
        };
        _proto.bettingDecisions = function bettingDecisions(touchAreaIndex) {
          return true;
        };
        _proto.refreshNoFreeShow = function refreshNoFreeShow() {};
        _proto.refreshAreaOdds = function refreshAreaOdds() {
          //刷新区域赔率
          var odds = this.gameTable.tableModel.tableConfig.odds;
          for (var i = 0; i < this.oddsLabel.length; i++) {
            if (this.oddsLabel[i]) {
              this.oddsLabel[i].string = "1:" + odds[i];
            }
          }
        };
        _proto.refreshBankerAndPlayerBetStatistic = function refreshBankerAndPlayerBetStatistic(betStatInfo) {
          if (betStatInfo) {
            //平倍
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker1], betStatInfo.normalBanker1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker2], betStatInfo.normalBanker2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker3], betStatInfo.normalBanker3);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player1], betStatInfo.normalPlayer1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player2], betStatInfo.normalPlayer2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player3], betStatInfo.normalPlayer3);
            //翻倍
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker1Double], betStatInfo.doubleBanker1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker2Double], betStatInfo.doubleBanker2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker3Double], betStatInfo.doubleBanker3);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player1Double], betStatInfo.doublePlayer1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player2Double], betStatInfo.doublePlayer2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player3Double], betStatInfo.doublePlayer3);
            //超牛
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker1SuperNiu], betStatInfo.superBanker1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker2SuperNiu], betStatInfo.superBanker2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Banker3SuperNiu], betStatInfo.superBanker3);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player1SuperNiu], betStatInfo.superPlayer1);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player2SuperNiu], betStatInfo.superPlayer2);
            this.setBetPercentItemInfo(this.betPercentItems[BetType.Player3SuperNiu], betStatInfo.superPlayer3);
          }
        };
        _proto.setBetPercentItemInfo = function setBetPercentItemInfo(betPercentItem, betStatUnit) {
          betPercentItem.showBetPercentInfo({
            betNum: betStatUnit == null ? void 0 : betStatUnit.totalBet,
            betPercent: betStatUnit == null ? void 0 : betStatUnit.percent,
            betPerosnNum: betStatUnit == null ? void 0 : betStatUnit.count
          });
        };
        _proto.betTypeSelectBtnClicked = function betTypeSelectBtnClicked(event) {
          this.betTypeSelectNode.active = !this.betTypeSelectNode.active;
        };
        _proto.betTypeBtnClicked = function betTypeBtnClicked(event, data) {
          var betType = parseInt(data);
          this.betTypeSelectNode.active = false;
          this.refrershBetTypeSelect(betType);
        };
        _proto.refrershBetTypeSelect = function refrershBetTypeSelect(betType) {
          this.betPageNode.forEach(function (node, index) {
            node.active = index === betType;
          });
          this.betTypeSelectLabel.string = BacPusherTBetType[betType];
        };
        return BacPusherTTableBetView;
      }(BaseTableBetView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "betPercentItems", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "betTypeSelectNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "betTypeSelectLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "betPageNode", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableCardView.ts', './Emitter.ts', './GlobalData.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Label, tween, BaseTableCardView, Emitter, GlobalEvent, BaccaratConsts;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Label = module.Label;
      tween = module.tween;
    }, function (module) {
      BaseTableCardView = module.BaseTableCardView;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }, function (module) {
      BaccaratConsts = module.BaccaratConsts;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "7c0bd7MyV5LwJwRit+T68Yi", "BacPusherTTableCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableCardView = exports('BacPusherTTableCardView', (_dec = ccclass('BacPusherTTableCardView'), _dec2 = property({
        type: Label
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableCardView) {
        _inheritsLoose(BacPusherTTableCardView, _BaseTableCardView);
        function BacPusherTTableCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableCardView.call.apply(_BaseTableCardView, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "pointLabels", _descriptor, _assertThisInitialized(_this));
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacPusherTTableCardView.prototype;
        _proto.initView = function initView() {
          _BaseTableCardView.prototype.initView.call(this);
          this.pointLabels.forEach(function (label) {
            label.node.parent.active = false;
          });
        };
        _proto.disCards = function disCards() {};
        _proto.startOpenCard = function startOpenCard() {
          var _this2 = this;
          var cardPosOrders = this.gameTable.tableModel.getCardPosOrders();
          var sortCards = this.gameTable.tableModel.getSortedOpenCards();
          //const sortTypes = this.gameTable.tableModel.getSortedCardTypes();
          var cardTween = tween(this.node);
          this.show();
          var _loop = function _loop() {
            var cardInfo = sortCards[index];
            var order = cardPosOrders[index];
            var cardType = _this2.gameTable.tableModel.getCardType(cardInfo);
            //const type = sortTypes[index];
            cardTween.call(function () {
              //显示牌
              _this2.showCards([2 * order, 2 * order + 1], cardInfo);
              Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, cardInfo);
            }).delay(BaccaratConsts.showCardTime).call(function () {
              //翻牌
              _this2.flopCards([2 * order, 2 * order + 1]);
            }).delay(BaccaratConsts.flopCardTime).call(function () {
              //显示点数
              _this2.showCardType(order, cardType);
            }).delay(0.1);
          };
          for (var index = 0; index < sortCards.length; index++) {
            _loop();
          }
          cardTween.start();
        };
        _proto.showPoint = function showPoint(playerPoint, bankerPoint, isPlayer, playSound) {};
        _proto.showCardType = function showCardType(index, cardType) {
          var pointLabel = this.pointLabels[index];
          if (pointLabel) {
            pointLabel.string = cardType;
            pointLabel.node.parent.active = true;
          }
        };
        _proto.showCards = function showCards(cardIndexs, cardsInfos) {
          var _this3 = this;
          if (cardIndexs.length > 0 && cardsInfos.length > 0 && cardIndexs.length === cardsInfos.length) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this3.cards[index];
              if (card && cardsInfos[cardIndex]) {
                card.setCard(cardsInfos[cardIndex], true);
              }
            });
          }
        };
        _proto.flopCards = function flopCards(cardIndexs) {
          var _this4 = this;
          if (cardIndexs.length > 0) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this4.cards[index];
              if (card && card.node.active) {
                card.flopCard();
              }
            });
          }
        };
        _proto.hideCards = function hideCards() {
          this.cards.forEach(function (card) {
            card.node.active = false;
          });
        };
        _proto.showAllCards = function showAllCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo) {
            var cardPosOrders = this.gameTable.tableModel.getCardPosOrders();
            var sortCards = this.gameTable.tableModel.getSortedOpenCards();
            //const sortTypes = this.gameTable.tableModel.getSortedCardTypes();
            this.show();
            for (var index = 0; index < sortCards.length; index++) {
              var cardInfo = sortCards[index];
              var order = cardPosOrders[index];
              var cardType = this.gameTable.tableModel.getCardType(cardInfo);
              //显示点数
              this.showCardType(order, cardType);
              //显示牌
              this.showCards([2 * order, 2 * order + 1], cardInfo);
              this.cards[2 * order].showCardFront();
              this.cards[2 * order + 1].showCardFront();
            }
          }
        };
        return BacPusherTTableCardView;
      }(BaseTableCardView), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "pointLabels", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableChipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableChipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableChipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableChipView = module.BaseTableChipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "62c931dCpZN87ZVXyzKJvVg", "BacPusherTTableChipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableChipView = exports('BacPusherTTableChipView', (_dec = ccclass('BacNiuniuTableChipView'), _dec(_class = /*#__PURE__*/function (_BaseTableChipView) {
        _inheritsLoose(BacPusherTTableChipView, _BaseTableChipView);
        function BacPusherTTableChipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableChipView.call.apply(_BaseTableChipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacPusherTTableChipView.prototype;
        _proto.initView = function initView() {};
        _proto.updateView = function updateView() {
          this.refreshCoinValue();
        };
        return BacPusherTTableChipView;
      }(BaseTableChipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableController.ts', './PlayerMgr.ts', './NumberFormatUtil.ts', './PopupMgr.ts', './GlobalData.ts', './Logger.ts', './bc_pushdot.ts'], function (exports) {
  var _inheritsLoose, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, BaseTableController, PlayerMgr, NumberFormatUtil, PopupMgr, BacPusherTBetTypeName, ErrorCodeTip, Logger, Phase;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableController = module.BaseTableController;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      BacPusherTBetTypeName = module.BacPusherTBetTypeName;
      ErrorCodeTip = module.ErrorCodeTip;
    }, function (module) {
      Logger = module.Logger;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "32fefhzB8JLgoUsCKcU+M3S", "BacPusherTTableController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableController = exports('BacPusherTTableController', (_dec = ccclass('BacPusherTTableController'), _dec(_class = /*#__PURE__*/function (_BaseTableController) {
        _inheritsLoose(BacPusherTTableController, _BaseTableController);
        function BacPusherTTableController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableController.call.apply(_BaseTableController, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacPusherTTableController.prototype;
        _proto.onGamePrepare = function onGamePrepare(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Prepare);
          //刷新roundId
          this.gameTable.tableMainGameView.refreshRoundId(data.roundId);
          //判断是否清空牌靴
          if (data.isShoeCleared) {
            this.gameTable.tableModel.openedCards = [];
            this.gameTable.tableModel.unOpenedCards = data.hashedCards;
            this.gameTable.tableAllCardVerifyInfoView.resetAllCards();
          }
          if (data.isRoadsCleared) {
            this.gameTable.tableModel.roadInfos = [];
          }
        };
        _proto.setGameTableShow = function setGameTableShow(tableData) {
          _BaseTableController.prototype.setGameTableShow.call(this, tableData);
          this.gameTable.tableModel.dices = tableData.table.dices;
          this.gameTable.tableModel.startIndex = tableData.table.startIndex;
        };
        _proto.onGameDealCards = function onGameDealCards(data) {
          this.gameTable.tableModel.dealCardsInfo = data.dealtCards;
          this.gameTable.tableModel.dices = data.dices;
          this.gameTable.tableModel.startIndex = data.startIndex;
          this.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
        };
        _proto.onGameBet = function onGameBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Betting);
        };
        _proto.onGameStopBet = function onGameStopBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.StopBet);
        };
        _proto.onGameOpenCards = function onGameOpenCards(data) {
          var openCards = data.cardsInfo;
          // openCards.playerCards.sort((a, b) => a.index - b.index);
          // openCards.bankerCards.sort((a, b) => a.index - b.index);
          this.gameTable.tableModel.cardsInfo = openCards;
          this.gameTable.tableModel.refreshAllCardsOpenStatus(data.cardsInfo);
          this.gameTable.stateMachineManager.transitionTo(Phase.OpenCards);
        };
        _proto.onGameSettlement = function onGameSettlement(data) {
          this.gameTable.tableModel.settleData = data.roadInfos[data.roadInfos.length - 1];
          this.gameTable.stateMachineManager.transitionTo(Phase.Settle);
          this.gameTable.tableModel.roadInfos = data.roadInfos;
        };
        _proto.onGameBetPush = function onGameBetPush(data) {
          this.gameTable.tableBetView.refreshBankerAndPlayerBetStatistic(data.betStatInfo);
        };
        _proto.onGamePlayerSettlement = function onGamePlayerSettlement(data) {
          this.gameTable.tableModel.playerSettlementSummary = data;
          PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(data.coin);
          this.gameTable.tableModel.refreshTableCoin();
        };
        _proto.showBetError = function showBetError(type, errorMsg) {
          PopupMgr.instance.showToast(BacPusherTBetTypeName[type] + "\u4E0B\u6CE8\u5931\u6557:" + errorMsg);
        };
        _proto.isSettlePhase = function isSettlePhase(phase) {
          return phase === Phase.Settle;
        };
        _proto.requestBet = /*#__PURE__*/function () {
          var _requestBet = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(betRequest) {
            var _this2 = this;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return this.gameTable.tableProxy.sendGameBetRequest(betRequest).then(function (betResponse) {
                    _this2.gameTable.tableModel.preBetData = [];
                    var successBetInfos = betResponse.successDetails;
                    //成功下注
                    for (var i = 0; i < successBetInfos.length; i++) {
                      var betDetail = successBetInfos[i].detail;
                      _this2.gameTable.tableModel.addBet(false, betDetail);
                      _this2.gameTable.tableBetView.refreshAreaBetChip(betDetail.type);
                    }
                    var failedDetails = betResponse.failedResults;
                    //失败下注 提示 退回筹码
                    var _loop = function _loop(_i) {
                      Logger.errNet('下注失败:', failedDetails[_i].code);
                      _this2.gameTable.tableBetView.refreshAreaBetChip(failedDetails[_i].detail.type);
                      _this2.scheduleOnce(function () {
                        var errorMsg = ErrorCodeTip[failedDetails[_i].code] || "未知";
                        _this2.showBetError(failedDetails[_i].detail.type, errorMsg);
                      }, 0.5 * _i);
                    };
                    for (var _i = 0; _i < failedDetails.length; _i++) {
                      _loop(_i);
                    }
                    PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(betResponse.coin);
                    _this2.gameTable.tableMainGameView.refreshBetOpreateStatus();
                  });
                case 2:
                case "end":
                  return _context.stop();
              }
            }, _callee, this);
          }));
          function requestBet(_x) {
            return _requestBet.apply(this, arguments);
          }
          return requestBet;
        }();
        return BacPusherTTableController;
      }(BaseTableController)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableModel.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableModel.ts', './game.ts', './bc_niuniu_s.ts', './BacPusherTEnum.ts'], function (exports) {
  var _inheritsLoose, _createClass, cclegacy, _decorator, BaseTableModel, MahjongColor, Phase, BacPusherTCardType;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableModel = module.BaseTableModel;
    }, function (module) {
      MahjongColor = module.MahjongColor;
    }, function (module) {
      Phase = module.Phase;
    }, function (module) {
      BacPusherTCardType = module.BacPusherTCardType;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "972dddzKGJMLr5u7Dn0u5kv", "BacPusherTTableModel", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableModel = exports('BacPusherTTableModel', (_dec = ccclass('BacPusherTTableModel'), _dec(_class = /*#__PURE__*/function (_BaseTableModel) {
        _inheritsLoose(BacPusherTTableModel, _BaseTableModel);
        function BacPusherTTableModel() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableModel.call.apply(_BaseTableModel, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _this._dices = [];
          _this._startIndex = 0;
          return _this;
        }
        var _proto = BacPusherTTableModel.prototype;
        _proto.getCardsPoint = function getCardsPoint(cards) {
          var point = 0;
          for (var i = 0; i < cards.length; i++) {
            var card = cards[i];
            var value = Number(card.value);
            if (value >= 10) {
              point += 10;
            } else {
              point += value;
            }
          }
          point = point % 10;
          return point;
        };
        _proto.refreshAllCardsOpenStatus = function refreshAllCardsOpenStatus(roundOpenedCards) {
          this.openedCards = this.gameTable.tableModel.openedCards;
          this.unOpenedCards = this.gameTable.tableModel.unOpenedCards;
          var roundOpenedCardsList = roundOpenedCards.bankerCards.concat(roundOpenedCards.player1Cards).concat(roundOpenedCards.player2Cards).concat(roundOpenedCards.player3Cards);
          this.refreshAllCardsData(this.openedCards, this.unOpenedCards, roundOpenedCardsList);
        };
        _proto.getSortedHashCards = function getSortedHashCards() {
          var dealtCards = this.gameTable.tableModel.dealCardsInfo;
          var startIndex = this.gameTable.tableModel.startIndex;
          var sortCards = dealtCards.slice(2 * startIndex, 8).concat(dealtCards.slice(0, 2 * startIndex));
          return sortCards;
        };
        _proto.getCardPosOrders = function getCardPosOrders() {
          var startIndex = this.gameTable.tableModel.startIndex;
          var orderArr = [0, 1, 2, 3];
          var cardPosOrder = orderArr.slice(startIndex, 4).concat(orderArr.slice(0, startIndex));
          return cardPosOrder;
        };
        _proto.getSortedOpenCards = function getSortedOpenCards() {
          var startIndex = this.gameTable.tableModel.startIndex;
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          var bankerCards = cardsInfo.bankerCards;
          var player1Cards = cardsInfo.player1Cards;
          var player2Cards = cardsInfo.player2Cards;
          var player3Cards = cardsInfo.player3Cards;
          var cardsArr = [bankerCards, player1Cards, player2Cards, player3Cards];
          var sortCards = cardsArr.slice(startIndex, 4).concat(cardsArr.slice(0, startIndex));
          return sortCards;
        }
        /*
        public getSortedCardTypes() {
            const startIndex = this.gameTable.tableModel.startIndex;
            const cardsInfo: OpenCardsInfo = this.gameTable.tableModel.cardsInfo as OpenCardsInfo;
            const typeArr = [cardsInfo.bankerType, cardsInfo.player1Type, cardsInfo.player2Type, cardsInfo.player3Type];
            const sortTypes = typeArr.slice(startIndex, 4).concat(typeArr.slice(0, startIndex));
            return sortTypes;
        }*/;
        _proto.getCardType = function getCardType(cards) {
          if (cards.length !== 2) {
            throw new Error('cards length must be 2');
          }
          var cardType = BacPusherTCardType.BIE_TEN;
          //判断是否有白板
          if (cards.some(function (card) {
            return card.color === MahjongColor.Dragon;
          })) {
            //判断是否白板对
            if (cards[0].color === cards[1].color) {
              cardType = BacPusherTCardType.WHITE_PAIR;
            } else {
              var halfTypeArr = [BacPusherTCardType.ONE_AND_HALF, BacPusherTCardType.TWO_AND_HALF, BacPusherTCardType.THREE_AND_HALF, BacPusherTCardType.FOUR_AND_HALF, BacPusherTCardType.FIVE_AND_HALF, BacPusherTCardType.SIX_AND_HALF, BacPusherTCardType.SEVEN_AND_HALF, BacPusherTCardType.EIGHT_AND_HALF, BacPusherTCardType.NINE_AND_HALF];
              var pushCards = cards.filter(function (card) {
                return card.color !== MahjongColor.Dragon;
              });
              if (pushCards && pushCards.length === 1) {
                cardType = halfTypeArr[pushCards[0].value - 1];
              } else {
                throw new Error('cards type error for have wgite board');
              }
            }
          } else {
            //判断是否有对子
            if (cards[0].color === cards[1].color && cards[0].value === cards[1].value) {
              var doubleTypeArr = [BacPusherTCardType.ONE_BAO, BacPusherTCardType.TWO_BAO, BacPusherTCardType.THREE_BAO, BacPusherTCardType.FOUR_BAO, BacPusherTCardType.FIVE_BAO, BacPusherTCardType.SIX_BAO, BacPusherTCardType.SEVEN_BAO, BacPusherTCardType.EIGHT_BAO, BacPusherTCardType.NINE_BAO];
              cardType = doubleTypeArr[cards[0].value - 1];
            } else if (cards.some(function (card) {
              return card.value === 2 && card;
            }) && cards.some(function (card) {
              return card.value === 8;
            })) {
              //判断是否有二八杠
              cardType = BacPusherTCardType.TWO_EIGHT_GANG;
            } else {
              var normalTypeArr = [BacPusherTCardType.BIE_TEN, BacPusherTCardType.ONE_POINT, BacPusherTCardType.TWO_POINT, BacPusherTCardType.THREE_POINT, BacPusherTCardType.FOUR_POINT, BacPusherTCardType.FIVE_POINT, BacPusherTCardType.SIX_POINT, BacPusherTCardType.SEVEN_POINT, BacPusherTCardType.EIGHT_POINT, BacPusherTCardType.NINE_POINT];
              var typeIndex = (cards[0].value + cards[1].value) % 10;
              cardType = normalTypeArr[typeIndex];
            }
          }
          return cardType;
        };
        _createClass(BacPusherTTableModel, [{
          key: "isCanBet",
          get: function get() {
            return this.gameTable.stateMachineManager.getCurrentState().statCode === Phase.Betting;
          }
        }, {
          key: "dices",
          get: function get() {
            return this._dices;
          },
          set: function set(value) {
            this._dices = value;
          }
        }, {
          key: "startIndex",
          get: function get() {
            return this._startIndex;
          },
          set: function set(value) {
            this._startIndex = value;
          }
        }]);
        return BacPusherTTableModel;
      }(BaseTableModel)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableProxy.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableProxy.ts', './ClientEnum.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableProxy, GameName;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableProxy = module.BaseTableProxy;
    }, function (module) {
      GameName = module.GameName;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "79ca2ORjEBIOZ75i2tKZX6+", "BacPusherTTableProxy", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableProxy = exports('BacPusherTTableProxy', (_dec = ccclass('BacPusherTTableProxy'), _dec(_class = /*#__PURE__*/function (_BaseTableProxy) {
        _inheritsLoose(BacPusherTTableProxy, _BaseTableProxy);
        function BacPusherTTableProxy() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableProxy.call.apply(_BaseTableProxy, [this].concat(args)) || this;
          _this.gameName = GameName.Bc_Pushdot;
          _this.gameTable = void 0;
          return _this;
        }
        return BacPusherTTableProxy;
      }(BaseTableProxy)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableReplayController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableReplayController.ts', './GameModel.ts', './GlobalData.ts', './PlayerMgr.ts', './Emitter.ts', './NumberFormatUtil.ts', './BaccaratData.ts', './AudioManager.ts', './bc_niuniu_s.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableReplayController, GameModel, GlobalEvent, PlayerMgr, Emitter, NumberFormatUtil, ReplayConstsData, AudioManager, Phase;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableReplayController = module.BaseTableReplayController;
    }, function (module) {
      GameModel = module.GameModel;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      ReplayConstsData = module.ReplayConstsData;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "1cd11V6XYNJQKTkKeos+nA4", "BacPusherTTableReplayController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTTableReplayController = exports('BacPusherTTableReplayController', (_dec = ccclass('BacPusherTTableReplayController'), _dec(_class = /*#__PURE__*/function (_BaseTableReplayContr) {
        _inheritsLoose(BacPusherTTableReplayController, _BaseTableReplayContr);
        function BacPusherTTableReplayController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableReplayContr.call.apply(_BaseTableReplayContr, [this].concat(args)) || this;
          _this.gameTable = null;
          return _this;
        }
        var _proto = BacPusherTTableReplayController.prototype;
        _proto.setReplayData = function setReplayData() {
          var replayData = GameModel.ins.replayData;
          var detail = replayData.detail;
          PlayerMgr.instance.id = replayData.playerId;
          this.gameTable.tableReplayView.show();
          this.gameTable.tableMainGameView.hideLoadNode();
          var profile = detail.profileMap[PlayerMgr.instance.id];
          if (profile) {
            PlayerMgr.instance.profile = profile;
            var betLimits = PlayerMgr.instance.profile.betLimits;
            this.gameTable.tableModel.personLimits = [NumberFormatUtil.formatMoneyToNumber(betLimits[0]), NumberFormatUtil.formatMoneyToNumber(betLimits[1])];
          }
          var config = replayData.config;
          this.gameTable.tableModel.tableInfo = {
            /** 桌 ID */
            id: replayData.tableId,
            /** 桌名 */
            name: replayData.tableName,
            /** 局 ID */
            roundId: replayData.roundId,
            /** 游戏阶段 */
            phase: 0,
            /** 当前阶段剩余时长信息 */
            durationInfo: null,
            /** 当前玩家在本局的下注信息 */
            betInfos: [],
            /** 当前局的庄闲下注统计信息 */
            betStatInfo: null,
            /** 当前牌靴的明牌信息 */
            openedCards: [],
            /** 当前牌靴的非明牌信息 */
            hashedCards: [],
            /** 当前牌靴的路单信息 */
            roadInfos: [],
            /** 历史聊天信息 */
            historyMessages: [],
            /** 发出的暗牌，< 开牌阶段时都会包含这个字段 */

            /** 玩家的结算结果 */
            settlementSummary: null,
            /** 桌配置 */
            config: config,
            onlinePlayers: 0,
            broadcastInfo: null
          };
          this.gameTable.tableModel.tableConfig = config;
        };
        _proto.setTableInfoShow = function setTableInfoShow() {
          var _detail$settleInfo, _detail$settleInfo2;
          var detail = GameModel.ins.replayData.detail;
          var playerSettleInfo = detail.settleMap[PlayerMgr.instance.id];
          var playCoinInfo = detail.initCoinMap[PlayerMgr.instance.id];
          if (playCoinInfo) {
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playCoinInfo);
            this.gameTable.tableModel.refreshTableCoin();
          }
          this.gameTable.tableModel.cardsInfo = detail.openCardsInfo;

          //关闭视频
          Emitter.emit(GlobalEvent.EVENT_GAME_CLOSE_VIDEO);
          //显示牌桌信息
          this.gameTable.tableMainGameView.refreshRoomInfo();
          //刷新筹码显示
          this.gameTable.tableChipView.refreshCoinValue();
          //显示各区域赔率
          this.gameTable.tableBetView.refreshAreaOdds();

          //刷新起始路单
          this.gameTable.tableModel.roadInfos = (_detail$settleInfo = detail.settleInfo) == null ? void 0 : _detail$settleInfo.roadInfos.slice(0, ((_detail$settleInfo2 = detail.settleInfo) == null ? void 0 : _detail$settleInfo2.roadInfos.length) - 1);
        };
        _proto.setReplayProcess = function setReplayProcess() {
          var _this2 = this;
          var replayData = GameModel.ins.replayData;
          var detail = replayData.detail;
          var playerSettleInfo = detail.settleMap[PlayerMgr.instance.id];
          var processTimes = ReplayConstsData.showTableInfoTime;
          // 发牌
          this.scheduleOnce(function () {
            _this2.processForDisCards(detail);
          }, processTimes);
          processTimes += ReplayConstsData.discardTime;
          // 下注
          if (playerSettleInfo) {
            AudioManager.playSound('Female/Female_StartBet');
            this.scheduleOnce(function () {
              var settlementInfos = playerSettleInfo.settlementInfos;
              _this2.processForBetting(settlementInfos, replayData);
            }, processTimes);
            processTimes += ReplayConstsData.betTime;
          }
          //开牌
          this.scheduleOnce(function () {
            _this2.processForOpenCard();
          }, processTimes);
          processTimes += ReplayConstsData.openCardTime;
          //结算
          this.scheduleOnce(function () {
            _this2.processForSettle(playerSettleInfo, detail);
          }, processTimes);
        };
        _proto.processForDisCards = function processForDisCards(detail) {
          this.gameTable.tableModel.dealCardsInfo = detail.dealCardsInfo.dealtCards;
          this.gameTable.tableModel.dices = detail.dealCardsInfo.dices;
          this.gameTable.tableModel.startIndex = detail.dealCardsInfo.startIndex;
          this.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
        };
        _proto.processForBetting = function processForBetting(settlementInfos, replayData) {
          var _replayData$detail$be;
          for (var i = 0; i < settlementInfos.length; i++) {
            this.gameTable.tableModel.addBet(false, {
              type: settlementInfos[i].betType,
              bet: settlementInfos[i].bet
            });
            this.gameTable.tableBetView.refreshAreaBetChip(settlementInfos[i].betType);
          }
          //刷新庄闲下注信息
          var statInfo = (_replayData$detail$be = replayData.detail.bettingInfo) == null || (_replayData$detail$be = _replayData$detail$be.statInfoMap) == null ? void 0 : _replayData$detail$be[replayData.currency];
          if (statInfo) {
            this.gameTable.tableModel.tableInfo.betStatInfo = statInfo;
            this.gameTable.tableBetView.refreshBankerAndPlayerBetStatistic(statInfo);
          }
          this.gameTable.tableModel.refreshTableBetCoin();
          PlayerMgr.instance.coin -= this.gameTable.tableModel.getTotalBetNum();
          //刷新玩家金币
          this.gameTable.tableModel.refreshTableCoin();
        };
        _proto.processForOpenCard = function processForOpenCard() {
          this.gameTable.tableCardView.startOpenCard();
          this.gameTable.tableVerifyCardView.startOpenCard();
        };
        _proto.processForSettle = function processForSettle(playerSettleInfo, detail) {
          var _detail$settleInfo3, _detail$settleInfo4, _detail$settleInfo5;
          this.gameTable.tableModel.playerSettlementSummary = playerSettleInfo;
          this.gameTable.tableModel.settleData = (_detail$settleInfo3 = detail.settleInfo) == null ? void 0 : _detail$settleInfo3.roadInfos[((_detail$settleInfo4 = detail.settleInfo) == null ? void 0 : _detail$settleInfo4.roadInfos.length) - 1];
          this.gameTable.tableSettleView.showResult();
          this.gameTable.tableBetView.showWinAreaLight();
          if (playerSettleInfo) {
            this.gameTable.tableSettleView.showSelfResult();
            //刷新玩家金币
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playerSettleInfo.coin);
            this.gameTable.tableModel.refreshTableCoin();
          }
          //刷新路单
          this.gameTable.tableModel.roadInfos = (_detail$settleInfo5 = detail.settleInfo) == null ? void 0 : _detail$settleInfo5.roadInfos;
          this.gameTable.tableRoadMapView.refreshRoadMap(this.gameTable.tableModel.roadInfos);
        };
        return BacPusherTTableReplayController;
      }(BaseTableReplayController)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableSettleView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableSettleView.ts', './NumberFormatUtil.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableSettleView, NumberFormatUtil, AudioManager, BaccaratRoundResultType;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableSettleView = module.BaseTableSettleView;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratRoundResultType = module.BaccaratRoundResultType;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "c038fgxsa5DW4yMhPYeOw8q", "BacPusherTTableSettleView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuTableSettleView = exports('BacNiuniuTableSettleView', (_dec = ccclass('BacPusherTTableSettleView'), _dec(_class = /*#__PURE__*/function (_BaseTableSettleView) {
        _inheritsLoose(BacNiuniuTableSettleView, _BaseTableSettleView);
        function BacNiuniuTableSettleView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableSettleView.call.apply(_BaseTableSettleView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuTableSettleView.prototype;
        _proto.showResult = function showResult() {
          this.show();
          var settleData = this.gameTable.tableModel.settleData;
          if (settleData) {
            var resultStr = BaccaratRoundResultType[settleData.bankerWinType];
            this.roundResultLabel.string = resultStr;
            this.roundResultBg.spriteFrame = this.roundResultBgSpriteFrame[settleData.bankerWinType];
            var soundStrs = ['Female/Female_Tie', 'Female/Female_BankerWin', 'Female/Female_PlayerWin'];
            AudioManager.playSound(soundStrs[settleData.bankerWinType]);
          }
        };
        _proto.getSettleGrade = function getSettleGrade() {
          var playerSettlementSummary = this.gameTable.tableModel.playerSettlementSummary;
          if (playerSettlementSummary) {
            var showCoin = NumberFormatUtil.formatMoneyToNumber(playerSettlementSummary.totalProfit);
            return showCoin;
          }
          return 0;
        };
        return BacNiuniuTableSettleView;
      }(BaseTableSettleView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTTableTipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableTipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableTipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableTipView = module.BaseTableTipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "ece6cK51G1No5QQu0uXh+dT", "BacPusherTTableTipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuTableTipView = exports('BacNiuniuTableTipView', (_dec = ccclass('BacPusherTTableTipView'), _dec(_class = /*#__PURE__*/function (_BaseTableTipView) {
        _inheritsLoose(BacNiuniuTableTipView, _BaseTableTipView);
        function BacNiuniuTableTipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableTipView.call.apply(_BaseTableTipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuTableTipView.prototype;
        _proto.updateView = function updateView() {};
        return BacNiuniuTableTipView;
      }(BaseTableTipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacPusherTVerifyCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BacPusherTTableCardView.ts', './DiceItem.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BacPusherTTableCardView, DiceItem;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BacPusherTTableCardView = module.BacPusherTTableCardView;
    }, function (module) {
      DiceItem = module.DiceItem;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "000fecI6tNPjq3xpcTFEt+k", "BacPusherTVerifyCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacPusherTVerifyCardView = exports('BacPusherTVerifyCardView', (_dec = ccclass('BacPusherTVerifyCardView'), _dec2 = property(DiceItem), _dec(_class = (_class2 = /*#__PURE__*/function (_BacPusherTTableCardV) {
        _inheritsLoose(BacPusherTVerifyCardView, _BacPusherTTableCardV);
        function BacPusherTVerifyCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BacPusherTTableCardV.call.apply(_BacPusherTTableCardV, [this].concat(args)) || this;
          //骰子
          _initializerDefineProperty(_this, "diceItems", _descriptor, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = BacPusherTVerifyCardView.prototype;
        _proto.updateView = function updateView() {
          if (this.gameTable.tableModel.dealCardsInfo) {
            this.disCards();
          }
          if (this.gameTable.tableModel.cardsInfo) {
            this.showAllCards();
          }
        };
        _proto.disCards = function disCards() {
          this.show();
          var cardsInfo = this.gameTable.tableModel.dealCardsInfo;
          var diceNums = this.gameTable.tableModel.dices;
          this.showDices(diceNums);
          var sortCards = this.gameTable.tableModel.getSortedHashCards();
          this.cards.forEach(function (card, index) {
            var cardInfo = sortCards[index];
            card.disCard(cardInfo);
          });
        };
        _proto.showDices = function showDices(deces) {
          this.diceItems.forEach(function (dice, index) {
            dice.init(deces[index]);
          });
        };
        _proto.showVerifyCards = function showVerifyCards() {
          // const cardsInfos: OpenCardsInfo = this.gameTable.tableModel.cardsInfo as OpenCardsInfo;
          // if (cardsInfos) {
          //     this.cards.forEach((card, index) => {
          //         (card as MahjongVerifyCardItem).setCard(cardsInfos[index], false);
          //     });
          // }
        };
        return BacPusherTVerifyCardView;
      }(BacPusherTTableCardView), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "diceItems", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/bacPusherTBundle', 'chunks:///_virtual/bacPusherTBundle'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});