System.register("chunks:///_virtual/BacaraCustomRoadLogic.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaccaratEnum.ts', './BacaratAutoLogic.ts', './proccessor.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, _createClass, cclegacy, _decorator, Component, BaccaratBetType, BaccaratAutoLogic, bigRoadPreProcess, BaccaratGameRoadConfig, SeekBankerRoadInfoData, SeekPlayerRoadInfoData;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Component = module.Component;
    }, function (module) {
      BaccaratBetType = module.BaccaratBetType;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      bigRoadPreProcess = module.bigRoadPreProcess;
    }, function (module) {
      BaccaratGameRoadConfig = module.BaccaratGameRoadConfig;
      SeekBankerRoadInfoData = module.SeekBankerRoadInfoData;
      SeekPlayerRoadInfoData = module.SeekPlayerRoadInfoData;
    }],
    execute: function () {
      var _dec, _class, _class2;
      cclegacy._RF.push({}, "9ed4c48fSBMlrwBHaFznRAV", "BacaraCustomRoadLogic", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacaraCustomRoadLogic = exports('BacaraCustomRoadLogic', (_dec = ccclass('BacaraCustomRoadLogic'), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(BacaraCustomRoadLogic, _Component);
        function BacaraCustomRoadLogic() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this._maxLine = BaccaratGameRoadConfig.customBigRoad.rowCount;
          _this._maxCeil = BaccaratGameRoadConfig.customBigRoad.colCount;
          return _this;
        }
        var _proto = BacaraCustomRoadLogic.prototype;
        _proto.addRoad = function addRoad(roadType, roadIndex) {
          var seekRoad = BaccaratAutoLogic.ins.getCustomSeekRoadStogeForIndex(roadIndex);
          seekRoad.push(roadType === BaccaratBetType.Banker ? SeekBankerRoadInfoData : SeekPlayerRoadInfoData);
          var isCanAdd = this.isCanAdd(seekRoad);
          if (isCanAdd) {
            BaccaratAutoLogic.ins.setCustomSeekRoadStogeForIndex(roadIndex, seekRoad);
          }
          return isCanAdd;
        };
        _proto.reverseRoad = function reverseRoad(roadIndex) {
          var seekRoad = BaccaratAutoLogic.ins.getCustomSeekRoadStogeForIndex(roadIndex);
          if (seekRoad && seekRoad.length > 0) {
            seekRoad.pop();
            BaccaratAutoLogic.ins.setCustomSeekRoadStogeForIndex(roadIndex, seekRoad);
          }
        };
        _proto.clearRoad = function clearRoad(roadIndex) {
          BaccaratAutoLogic.ins.setCustomSeekRoadStogeForIndex(roadIndex, []);
        };
        _proto.isCanAdd = function isCanAdd(seekRoad) {
          var bigRoadFragment = bigRoadPreProcess({
            bigRoadRowCount: this._maxLine,
            roadInfos: seekRoad
          });
          if (bigRoadFragment.length > this._maxCeil) {
            return false;
          }
          for (var i = 0; i < bigRoadFragment.length; i++) {
            var roadFragment = bigRoadFragment[i];
            var cells = roadFragment.cells;
            if (cells.length > this._maxCeil - 1 - i + roadFragment.rowCount) {
              return false;
            }
          }
          return true;
        };
        _proto.getSeekRoadFragment = function getSeekRoadFragment(roadIndex) {
          var seekRoadInfo = BaccaratAutoLogic.ins.getCustomSeekRoadStogeForIndex(roadIndex);
          return bigRoadPreProcess({
            bigRoadRowCount: this._maxLine,
            roadInfos: seekRoadInfo
          });
        };
        _proto.getIsSetSeekRoadInfo = function getIsSetSeekRoadInfo() {
          var seekRoadInfo = BaccaratAutoLogic.ins.getCustomSeekRoadStoge();
          if (seekRoadInfo && seekRoadInfo.length > 0) {
            for (var index = 0; index < seekRoadInfo.length; index++) {
              if (seekRoadInfo[index] && seekRoadInfo[index].length > 0) {
                return true;
              }
            }
          }
          return false;
        };
        _createClass(BacaraCustomRoadLogic, null, [{
          key: "ins",
          get: function get() {
            if (!this._instance) {
              this._instance = new BacaraCustomRoadLogic();
            }
            return this._instance;
          }
        }]);
        return BacaraCustomRoadLogic;
      }(Component), _class2._instance = void 0, _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacaraCustomRoadView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BacaraCustomRoadLogic.ts', './BaccaratEnum.ts', './BaccardTableRoadItem.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Node, ToggleContainer, Prefab, instantiate, v3, Animation, Component, BacaraCustomRoadLogic, BaccaratBetType, BaccardTableRoadItem, BaccaratGameRoadConfig;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Node = module.Node;
      ToggleContainer = module.ToggleContainer;
      Prefab = module.Prefab;
      instantiate = module.instantiate;
      v3 = module.v3;
      Animation = module.Animation;
      Component = module.Component;
    }, function (module) {
      BacaraCustomRoadLogic = module.BacaraCustomRoadLogic;
    }, function (module) {
      BaccaratBetType = module.BaccaratBetType;
    }, function (module) {
      BaccardTableRoadItem = module.BaccardTableRoadItem;
    }, function (module) {
      BaccaratGameRoadConfig = module.BaccaratGameRoadConfig;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3;
      cclegacy._RF.push({}, "62ecdkxJcdM94pb+KZaFDZw", "BacaraCustomRoadView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacaraCustomRoadView = exports('BacaraCustomRoadView', (_dec = ccclass('BacaraCustomRoadView'), _dec2 = property(Node), _dec3 = property(ToggleContainer), _dec4 = property(Prefab), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(BacaraCustomRoadView, _Component);
        function BacaraCustomRoadView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "roadContent", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "roadSelectToggleContainer", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "roadItemPrefab", _descriptor3, _assertThisInitialized(_this));
          _this._selectedRoadIndex = 0;
          return _this;
        }
        var _proto = BacaraCustomRoadView.prototype;
        // 紀錄當前選擇的路線索引
        _proto.start = function start() {
          this.refreshRoadView();
        };
        _proto.roadOpreateBtnClicked = function roadOpreateBtnClicked(_, touchName) {
          var isRefresh = true;
          switch (touchName) {
            case 'banker':
              isRefresh = BacaraCustomRoadLogic.ins.addRoad(BaccaratBetType.Banker, this._selectedRoadIndex);
              break;
            case 'player':
              isRefresh = BacaraCustomRoadLogic.ins.addRoad(BaccaratBetType.Player, this._selectedRoadIndex);
              break;
            case 'reverse':
              BacaraCustomRoadLogic.ins.reverseRoad(this._selectedRoadIndex);
              break;
            case 'clear':
              BacaraCustomRoadLogic.ins.clearRoad(this._selectedRoadIndex);
              break;
          }
          if (isRefresh) {
            this.refreshRoadView();
          }
        };
        _proto.toggleClicked = function toggleClicked(_, touchIndexStr) {
          var touchIndex = parseInt(touchIndexStr);
          this._selectedRoadIndex = touchIndex;
          this.refreshRoadView();
        };
        _proto.refreshRoadView = function refreshRoadView() {
          this.roadContent.removeAllChildren();
          var roadFragment = BacaraCustomRoadLogic.ins.getSeekRoadFragment(this._selectedRoadIndex);
          var config = BaccaratGameRoadConfig.customBigRoad;
          for (var i = 0; i < roadFragment.length; i++) {
            var cells = roadFragment[i].cells;
            var rowCount = roadFragment[i].rowCount;
            for (var j = 0; j < cells.length; j++) {
              var _roadItem$getComponen;
              var roadItem = instantiate(this.roadItemPrefab);
              var cell = cells[j];
              var pos = v3(0, 0, 0);
              if (j < rowCount) {
                pos = v3(config.startPos.x + i * config.horizontalSpacing, config.startPos.y + j * config.verticalSpacing);
              } else {
                pos = v3(config.startPos.x + (i + (j - rowCount + 1)) * config.horizontalSpacing, config.startPos.y + (rowCount - 1) * config.verticalSpacing);
              }
              roadItem.setPosition(pos);
              roadItem.scale = v3(2, 2, 1);
              roadItem.getComponent(BaccardTableRoadItem).initView(cell);
              (_roadItem$getComponen = roadItem.getComponent(Animation)) == null || _roadItem$getComponen.stop();
              this.roadContent.addChild(roadItem);
            }
          }
        };
        return BacaraCustomRoadView;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "roadContent", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "roadSelectToggleContainer", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "roadItemPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacaratAutoLogic.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaccaratData.ts'], function (exports) {
  var _createClass, cclegacy, sys, LocalStorageKey;
  return {
    setters: [function (module) {
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      sys = module.sys;
    }, function (module) {
      LocalStorageKey = module.LocalStorageKey;
    }],
    execute: function () {
      cclegacy._RF.push({}, "291e4jIJ5hF9YqrEHVKhoVK", "BacaratAutoLogic", undefined);
      var defaultAutoBetOption = exports('defaultAutoBetOption', {
        betType: 0,
        betValue: 0,
        betRound: 0,
        stop4Win: 0,
        stop4Lose: 0
      });
      var defaultAutoSeekRoadOption = exports('defaultAutoSeekRoadOption', {
        betType: 0,
        betValue: 0,
        stop4Win: 0,
        stop4Lose: 0,
        seek4Tie: true
      });
      var BaccaratAutoLogic = exports('BaccaratAutoLogic', /*#__PURE__*/function () {
        function BaccaratAutoLogic() {}
        var _proto = BaccaratAutoLogic.prototype;
        _proto.initAutoBetOption = function initAutoBetOption(personLimits) {
          defaultAutoBetOption.stop4Lose = personLimits[0];
          defaultAutoBetOption.stop4Win = personLimits[0];
          defaultAutoSeekRoadOption.stop4Lose = personLimits[0];
          defaultAutoSeekRoadOption.stop4Win = personLimits[0];
        };
        _proto.getAutoBetLocalStroge = function getAutoBetLocalStroge() {
          var autoBetOption = sys.localStorage.getItem(LocalStorageKey.Bac_AutoBetOption);
          if (autoBetOption) {
            return JSON.parse(autoBetOption);
          } else {
            return defaultAutoBetOption;
          }
        };
        _proto.setAutoBetLocalStroge = function setAutoBetLocalStroge(autoBetOption) {
          sys.localStorage.setItem(LocalStorageKey.Bac_AutoBetOption, JSON.stringify(autoBetOption));
        };
        _proto.resetAutoBetLocalStroge = function resetAutoBetLocalStroge() {
          sys.localStorage.setItem(LocalStorageKey.Bac_AutoBetOption, JSON.stringify(defaultAutoBetOption));
        };
        _proto.setAutoSeekRoadStoge = function setAutoSeekRoadStoge(autoSeekRoads) {
          sys.localStorage.setItem(LocalStorageKey.Bac_CustomSeekRoad, JSON.stringify(autoSeekRoads));
        };
        _proto.getCustomSeekRoadStoge = function getCustomSeekRoadStoge() {
          var autoSeekRoads = sys.localStorage.getItem(LocalStorageKey.Bac_CustomSeekRoad);
          if (autoSeekRoads) {
            return JSON.parse(autoSeekRoads);
          }
          return [];
        };
        _proto.setCustomSeekRoadStogeForIndex = function setCustomSeekRoadStogeForIndex(roadIndex, autoSeekRoad) {
          var autoSeekRoads = this.getCustomSeekRoadStoge();
          autoSeekRoads[roadIndex] = autoSeekRoad;
          this.setAutoSeekRoadStoge(autoSeekRoads);
        };
        _proto.getCustomSeekRoadStogeForIndex = function getCustomSeekRoadStogeForIndex(roadIndex) {
          var autoSeekRoads = this.getCustomSeekRoadStoge();
          return autoSeekRoads[roadIndex] || [];
        };
        _proto.getAutoSeekRoadLocalStroge = function getAutoSeekRoadLocalStroge() {
          var autoSeekOption = sys.localStorage.getItem(LocalStorageKey.Bac_AutoSeekRoadOption);
          if (autoSeekOption) {
            return JSON.parse(autoSeekOption);
          } else {
            return defaultAutoSeekRoadOption;
          }
        };
        _proto.setAutoSeekRoadLocalStroge = function setAutoSeekRoadLocalStroge(autoSeekOption) {
          sys.localStorage.setItem(LocalStorageKey.Bac_AutoSeekRoadOption, JSON.stringify(autoSeekOption));
        };
        _proto.resetAutoSeekRoadLocalStroge = function resetAutoSeekRoadLocalStroge() {
          sys.localStorage.setItem(LocalStorageKey.Bac_AutoSeekRoadOption, JSON.stringify(defaultAutoSeekRoadOption));
        };
        _createClass(BaccaratAutoLogic, null, [{
          key: "ins",
          get: function get() {
            if (!BaccaratAutoLogic._instance) {
              BaccaratAutoLogic._instance = new BaccaratAutoLogic();
            }
            return BaccaratAutoLogic._instance;
          }
        }]);
        return BaccaratAutoLogic;
      }());
      BaccaratAutoLogic._instance = null;
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacaratInterface.ts", ['cc'], function () {
  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "db31a9MMjBEtq/2/jSNYDhO", "BacaratInterface", undefined);
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaraTableSettleView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableSettleView.ts', './NumberFormatUtil.ts', './BacaratAutoLogic.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Sprite, SpriteFrame, Color, BaseTableSettleView, NumberFormatUtil, BaccaratAutoLogic, AudioManager, BaccaratEvents, BaccaratRoundResultType, BaccaratSelfResultType;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Sprite = module.Sprite;
      SpriteFrame = module.SpriteFrame;
      Color = module.Color;
    }, function (module) {
      BaseTableSettleView = module.BaseTableSettleView;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratEvents = module.BaccaratEvents;
      BaccaratRoundResultType = module.BaccaratRoundResultType;
      BaccaratSelfResultType = module.BaccaratSelfResultType;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "a81e0hxyKVOj6WYPaHzyEEk", "BaccaraTableSettleView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaraTableSettleView = exports('BaccaraTableSettleView', (_dec = ccclass('BaccaraTableSettleView'), _dec2 = property(Sprite), _dec3 = property(SpriteFrame), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableSettleView) {
        _inheritsLoose(BaccaraTableSettleView, _BaseTableSettleView);
        function BaccaraTableSettleView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableSettleView.call.apply(_BaseTableSettleView, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "roundResultBg", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "roundResultBgSpriteFrame", _descriptor2, _assertThisInitialized(_this));
          _this.gameTable = void 0;
          _this.regeistEvents = [{
            eventName: BaccaratEvents.RefreshSelfResult,
            method: _this.showSelfResult,
            caller: _assertThisInitialized(_this)
          }];
          return _this;
        }
        var _proto = BaccaraTableSettleView.prototype;
        _proto.initView = function initView() {
          this.hide();
          this.selfResultNode.active = false;
        };
        _proto.updateView = function updateView() {};
        _proto.showResult = function showResult() {
          this.show();
          var settleData = this.gameTable.tableModel.settleData;
          if (settleData) {
            var resultStr = BaccaratRoundResultType[settleData.winnerType];
            this.roundResultLabel.string = resultStr;
            this.roundResultBg.spriteFrame = this.roundResultBgSpriteFrame[settleData.winnerType];
            var soundStrs = ['Female/Female_Tie', 'Female/Female_BankerWin', 'Female/Female_PlayerWin'];
            AudioManager.playSound(soundStrs[settleData.winnerType]);
          }
        };
        _proto.showSelfResult = function showSelfResult() {
          var playerSettlementSummary = this.gameTable.tableModel.playerSettlementSummary;
          if (playerSettlementSummary) {
            this.selfResultNode.active = true;
            var showCoin = NumberFormatUtil.formatMoneyToNumber(playerSettlementSummary.totalPayment) - NumberFormatUtil.formatMoneyToNumber(playerSettlementSummary.totalBet);
            var showResultStr = '';
            var coinStr = '';
            if (showCoin > 0) {
              showResultStr = BaccaratSelfResultType[1];
              coinStr = "+" + showCoin;
            } else if (showCoin < 0) {
              showResultStr = BaccaratSelfResultType[2];
              coinStr = "" + showCoin;
            } else {
              showResultStr = BaccaratSelfResultType[0];
            }
            this.selfResultLabel.string = showResultStr;
            this.selfGradeLabel.string = coinStr;
            this.selfGradeLabel.color = showCoin > 0 ? Color.GREEN : Color.RED;

            //判斷是否停止下注
            var winStop = BaccaratAutoLogic.ins.getAutoBetLocalStroge().stop4Win;
            var loseStop = BaccaratAutoLogic.ins.getAutoBetLocalStroge().stop4Lose;
            if (showCoin >= 0 && showCoin >= winStop || showCoin < 0 && Math.abs(showCoin) >= loseStop) {
              this.gameTable.tableModel.setStopAutoBet();
            }
          }
        };
        return BaccaraTableSettleView;
      }(BaseTableSettleView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "roundResultBg", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "roundResultBgSpriteFrame", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratAutoSettingView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseAutoSettingView.ts', './BaccartAutoBetSettingNode.ts', './BaccartAutoSeekRoadSettingNode.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BaseAutoSettingView, BaccartAutoBetSettingNode, BaccartAutoSeekRoadSettingNode;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseAutoSettingView = module.BaseAutoSettingView;
    }, function (module) {
      BaccartAutoBetSettingNode = module.BaccartAutoBetSettingNode;
    }, function (module) {
      BaccartAutoSeekRoadSettingNode = module.BaccartAutoSeekRoadSettingNode;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "b6625f8s8xKzq9ENnieZ8RQ", "BaccaratAutoSettingView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratAutoSettingView = exports('BaccaratAutoSettingView', (_dec = ccclass('BaccaratAutoSettingView'), _dec2 = property(BaccartAutoBetSettingNode), _dec3 = property(BaccartAutoSeekRoadSettingNode), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseAutoSettingView) {
        _inheritsLoose(BaccaratAutoSettingView, _BaseAutoSettingView);
        function BaccaratAutoSettingView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseAutoSettingView.call.apply(_BaseAutoSettingView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _initializerDefineProperty(_this, "autoBetSettingNode", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "autoSeekRoadSettingNode", _descriptor2, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = BaccaratAutoSettingView.prototype;
        _proto.initView = function initView() {
          this.autoBetSettingNode.init(this);
          this.autoSeekRoadSettingNode.init(this);
        };
        _proto.updateView = function updateView() {};
        return BaccaratAutoSettingView;
      }(BaseAutoSettingView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "autoBetSettingNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "autoSeekRoadSettingNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratBettingState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratTableBetView.ts', './BaccaratMainGameView.ts', './BaccaratTableTipView.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratTableBetView, BaccaratMainGameView, BaccaratTableTipView, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratTableBetView = module.BaccaratTableBetView;
    }, function (module) {
      BaccaratMainGameView = module.BaccaratMainGameView;
    }, function (module) {
      BaccaratTableTipView = module.BaccaratTableTipView;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "ba3e6NuJqNI/6/cwii6qcJN", "BaccaratBettingState", undefined);
      var BaccaratBettingState = exports('BaccaratBettingState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratBettingState, _BaseState);
        function BaccaratBettingState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratBettingState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.getView(BaccaratMainGameView).showGameClock();
          this.gameTable.getView(BaccaratTableBetView).setAreaBtnsTouchStatus(true);
          this.gameTable.getView(BaccaratMainGameView).setBetNodeStatus(true);
          this.gameTable.getView(BaccaratMainGameView).refreshAllBtnsStatus();
          this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Please_Bet);
          if (this.gameTable.tableModel.isCanAutoBet) {
            this.gameTable.getView(BaccaratTableBetView).autoBet();
          }
          if (this.gameTable.tableModel.isAutoSeekRoad) {
            this.gameTable.getView(BaccaratTableBetView).autoSeekRoad();
          }
          AudioManager.playSound('Female/Female_StartBet');
        };
        _proto.exit = function exit() {
          this.gameTable.getView(BaccaratTableBetView).setAreaBtnsTouchStatus(false);
          this.gameTable.getView(BaccaratMainGameView).setBetNodeStatus(false);
          this.gameTable.getView(BaccaratMainGameView).cancleBetData();
          this.gameTable.getView(BaccaratMainGameView).hideGameClock();
        };
        return BaccaratBettingState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/baccaratBundle", ['./BaccaratGame.ts', './BaccaratBettingState.ts', './BaccaratDealCardState.ts', './BaccaratGame2.ts', './BaccaratGameTale.ts', './BaccaratOpenCardState.ts', './BaccaratPrepareState.ts', './BaccaratSettleState.ts', './BaccaratStopBetState.ts', './BaccaratTableController.ts', './BacaraCustomRoadLogic.ts', './BacaratAutoLogic.ts', './BacaratInterface.ts', './BaccaratEnum.ts', './BaccaratTableModel.ts', './BaccaratTableProxy.ts', './BacaraCustomRoadView.ts', './BaccaraTableSettleView.ts', './BaccaratAutoSettingView.ts', './BaccaratMainGameView.ts', './BaccaratTableBetView.ts', './BaccaratTableCardView.ts', './BaccaratTableChipView.ts', './BaccaratTableTipView.ts', './BaccaratVerifyCardView.ts', './BaccartAutoBetSettingNode.ts', './BaccartAutoSeekRoadSettingNode.ts'], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

System.register("chunks:///_virtual/BaccaratDealCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratVerifyCardView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratVerifyCardView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratVerifyCardView = module.BaccaratVerifyCardView;
    }],
    execute: function () {
      cclegacy._RF.push({}, "dd4291DDfFNUqOBxI1FaiCh", "BaccaratDealCardState", undefined);
      var BaccaratDealCardState = exports('BaccaratDealCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratDealCardState, _BaseState);
        function BaccaratDealCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratDealCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          //this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Deal_Card);
          this.gameTable.getView(BaccaratVerifyCardView).disCards();
        };
        _proto.exit = function exit() {};
        return BaccaratDealCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratEnum.ts", ['cc'], function (exports) {
  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "bb009TNJ0hIZb3CvW0JpE13", "BaccaratEnum", undefined);
      var BaccaratBetBtn = exports('BaccaratBetBtn', /*#__PURE__*/function (BaccaratBetBtn) {
        BaccaratBetBtn[BaccaratBetBtn["Again"] = 0] = "Again";
        BaccaratBetBtn[BaccaratBetBtn["Sure"] = 1] = "Sure";
        BaccaratBetBtn[BaccaratBetBtn["Cancle"] = 2] = "Cancle";
        return BaccaratBetBtn;
      }({}));
      var BaccaratCardIndex = exports('BaccaratCardIndex', /*#__PURE__*/function (BaccaratCardIndex) {
        BaccaratCardIndex[BaccaratCardIndex["Player1"] = 0] = "Player1";
        BaccaratCardIndex[BaccaratCardIndex["Player2"] = 1] = "Player2";
        BaccaratCardIndex[BaccaratCardIndex["Banker1"] = 2] = "Banker1";
        BaccaratCardIndex[BaccaratCardIndex["Banker2"] = 3] = "Banker2";
        BaccaratCardIndex[BaccaratCardIndex["Player3"] = 4] = "Player3";
        BaccaratCardIndex[BaccaratCardIndex["Banker3"] = 5] = "Banker3";
        return BaccaratCardIndex;
      }({}));
      var BaccaratBetType = exports('BaccaratBetType', /*#__PURE__*/function (BaccaratBetType) {
        BaccaratBetType[BaccaratBetType["Banker"] = 0] = "Banker";
        BaccaratBetType[BaccaratBetType["Player"] = 1] = "Player";
        return BaccaratBetType;
      }({}));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratGame.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGame.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseGame;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGame = module.BaseGame;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "31891dM++BLaq3b/icOFXQL", "BaccaratGame", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratGame = exports('BaccaratGame', (_dec = ccclass('BaccaratGame'), _dec(_class = /*#__PURE__*/function (_BaseGame) {
        _inheritsLoose(BaccaratGame, _BaseGame);
        function BaccaratGame() {
          return _BaseGame.apply(this, arguments) || this;
        }
        return BaccaratGame;
      }(BaseGame)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratGame2.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGame.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseGame;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGame = module.BaseGame;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "a8db0G/M61ORZpnoviUZr5z", "BaccaratGame", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratGame = exports('BaccaratGame', (_dec = ccclass('BaccaratGame'), _dec(_class = /*#__PURE__*/function (_BaseGame) {
        _inheritsLoose(BaccaratGame, _BaseGame);
        function BaccaratGame() {
          return _BaseGame.apply(this, arguments) || this;
        }
        return BaccaratGame;
      }(BaseGame)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratGameTale.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGameTale.ts', './BaccaratOpenCardState.ts', './BaccaratDealCardState.ts', './BaccaratSettleState.ts', './BaccaratTableController.ts', './BaccaratTableModel.ts', './BaccaratPrepareState.ts', './bc_baccarat.ts', './BaccaratTableProxy.ts', './BaccaratBettingState.ts', './BaccaratStopBetState.ts', './BaseAllCardVerifyInfoView.ts', './BaseCardVerifyView.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BaseGameTale, BaccaratOpenCardState, BaccaratDealCardState, BaccaratSettleState, BaccaratTableController, BaccaratTableModel, BaccaratPrepareState, Phase, BaccaratTableProxy, BaccaratBettingState, BaccaratStopBetState, BaseAllCardVerifyInfoView, BaseCardVerifyView;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGameTale = module.BaseGameTale;
    }, function (module) {
      BaccaratOpenCardState = module.BaccaratOpenCardState;
    }, function (module) {
      BaccaratDealCardState = module.BaccaratDealCardState;
    }, function (module) {
      BaccaratSettleState = module.BaccaratSettleState;
    }, function (module) {
      BaccaratTableController = module.BaccaratTableController;
    }, function (module) {
      BaccaratTableModel = module.BaccaratTableModel;
    }, function (module) {
      BaccaratPrepareState = module.BaccaratPrepareState;
    }, function (module) {
      Phase = module.Phase;
    }, function (module) {
      BaccaratTableProxy = module.BaccaratTableProxy;
    }, function (module) {
      BaccaratBettingState = module.BaccaratBettingState;
    }, function (module) {
      BaccaratStopBetState = module.BaccaratStopBetState;
    }, function (module) {
      BaseAllCardVerifyInfoView = module.BaseAllCardVerifyInfoView;
    }, function (module) {
      BaseCardVerifyView = module.BaseCardVerifyView;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3;
      cclegacy._RF.push({}, "8d2a5m+X4ZDUI0+hxh/j2u4", "BaccaratGameTale", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratGameTale = exports('BaccaratGameTale', (_dec = ccclass('BaccaratGameTale'), _dec2 = property({
        type: BaccaratTableProxy
      }), _dec3 = property({
        type: BaccaratTableController
      }), _dec4 = property({
        type: BaccaratTableModel
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseGameTale) {
        _inheritsLoose(BaccaratGameTale, _BaseGameTale);
        function BaccaratGameTale() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseGameTale.call.apply(_BaseGameTale, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "tableProxy", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableController", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableModel", _descriptor3, _assertThisInitialized(_this));
          _this.states = [{
            stateCode: Phase.Prepare,
            state: new BaccaratPrepareState()
          }, {
            stateCode: Phase.DealCards,
            state: new BaccaratDealCardState()
          }, {
            stateCode: Phase.Betting,
            state: new BaccaratBettingState()
          }, {
            stateCode: Phase.StopBet,
            state: new BaccaratStopBetState()
          }, {
            stateCode: Phase.OpenCards,
            state: new BaccaratOpenCardState()
          }, {
            stateCode: Phase.Settle,
            state: new BaccaratSettleState()
          }];
          return _this;
        }
        var _proto = BaccaratGameTale.prototype;
        _proto.onDestroy = function onDestroy() {
          this.getView(BaseAllCardVerifyInfoView).onDestroy();
          this.getView(BaseCardVerifyView).onDestroy();
        };
        return BaccaratGameTale;
      }(BaseGameTale), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tableProxy", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tableController", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "tableModel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratMainGameView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseMainGameView.ts', './BaccaratTableBetView.ts', './PlayerMgr.ts', './BaccaratEnum.ts', './GameClock.ts', './NumberFormatUtil.ts', './BaseMenuView.ts', './BaseAllCardVerifyInfoView.ts', './GlobalData.ts', './PopupMgr.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, Label, Sprite, SpriteFrame, BaseMainGameView, BaccaratTableBetView, PlayerMgr, BaccaratBetBtn, GameClock, NumberFormatUtil, BaseMenuView, BaseAllCardVerifyInfoView, TipMessage, PopupMgr, BaccaratEvents;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Label = module.Label;
      Sprite = module.Sprite;
      SpriteFrame = module.SpriteFrame;
    }, function (module) {
      BaseMainGameView = module.BaseMainGameView;
    }, function (module) {
      BaccaratTableBetView = module.BaccaratTableBetView;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      BaccaratBetBtn = module.BaccaratBetBtn;
    }, function (module) {
      GameClock = module.GameClock;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaseMenuView = module.BaseMenuView;
    }, function (module) {
      BaseAllCardVerifyInfoView = module.BaseAllCardVerifyInfoView;
    }, function (module) {
      TipMessage = module.TipMessage;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      BaccaratEvents = module.BaccaratEvents;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7;
      cclegacy._RF.push({}, "9804dydLXFCzY3TZDRO3Rll", "BaccaratMainGameView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratMainGameView = exports('BaccaratMainGameView', (_dec = ccclass('BaccaratMainGameView'), _dec2 = property(Label), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(GameClock), _dec7 = property(Sprite), _dec8 = property(SpriteFrame), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseMainGameView) {
        _inheritsLoose(BaccaratMainGameView, _BaseMainGameView);
        function BaccaratMainGameView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseMainGameView.call.apply(_BaseMainGameView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _initializerDefineProperty(_this, "userIdLabel", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableNumLabel", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "roundIdLabel", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "limitLabel", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "gameClock", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "autoBtnSprite", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "autoBtnSpriteFrame", _descriptor7, _assertThisInitialized(_this));
          _this.regeistEvents = [{
            eventName: BaccaratEvents.RefreshBetCoin,
            method: _this.refreshBetCoinShow,
            caller: _assertThisInitialized(_this)
          }, {
            eventName: BaccaratEvents.RefreshCurrentCoin,
            method: _this.refreshCoinShow,
            caller: _assertThisInitialized(_this)
          }, {
            eventName: BaccaratEvents.RefreshAutoBtnStatus,
            method: _this.refreshAutoBtnStatus,
            caller: _assertThisInitialized(_this)
          }];
          return _this;
        }
        var _proto = BaccaratMainGameView.prototype;
        _proto.initView = function initView() {
          this.hideGameClock();
        };
        _proto.updateView = function updateView() {
          //刷新房间信息
          this.refreshRoomInfo();
          this.refreshBetOpreateStatus();
        };
        _proto.sendBetData = function sendBetData() {
          if (!PlayerMgr.instance.profile.betStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Bet);
            return;
          }
          //發送下注籌碼
          this.gameTable.tableController.requestBet({
            tableId: this.gameTable.tableModel.tableId,
            details: this.gameTable.tableModel.preBetData
          });
        };
        _proto.cancleBetData = function cancleBetData() {
          //获取预下注区域
          var preBetAreas = this.gameTable.tableModel.getPreBetAreas();
          this.gameTable.tableModel.preBetData = [];
          //刷新預下注籌碼
          for (var i = 0; i < preBetAreas.length; i++) {
            this.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(preBetAreas[i]);
          }
          //刷新按钮
          this.refreshBetOpreateStatus();
        };
        _proto.againBetData = function againBetData() {
          if (!PlayerMgr.instance.profile.betStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Bet);
            return;
          }
          var lastBetData = this.gameTable.tableModel.lastBetData;
          if (lastBetData && lastBetData.length > 0) {
            for (var i = 0; i < lastBetData.length; i++) {
              var element = lastBetData[i];
              this.gameTable.tableModel.addBet(true, element);
              this.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(element.type);
            }
            this.refreshBetOpreateStatus();
          }
        };
        _proto.refreshAllBtnsStatus = function refreshAllBtnsStatus() {
          //重复下注
          this.refreshBtnState(BaccaratBetBtn.Again, this.gameTable.tableModel.getIsCanAgainBet());
          //确认下注
          this.refreshBtnState(BaccaratBetBtn.Sure, this.gameTable.tableModel.getIsCanSureBet());
          //取消下注
          this.refreshBtnState(BaccaratBetBtn.Cancle, this.gameTable.tableModel.getIsCanCancleBet());
        };
        _proto.refreshBetOpreateStatus = function refreshBetOpreateStatus() {
          this.gameTable.tableModel.refreshTableCoin();
          this.gameTable.tableModel.refreshTableBetCoin();
          this.refreshAllBtnsStatus();
        };
        _proto.refreshBetCoinShow = function refreshBetCoinShow() {
          this.betLabel.string = "" + NumberFormatUtil.formatNumDistance(this.gameTable.tableModel.tableBetCoin);
        };
        _proto.refreshCoinShow = function refreshCoinShow() {
          this.coinLabel.string = "" + NumberFormatUtil.formatNumDistance(this.gameTable.tableModel.tableCoin);
        };
        _proto.refreshRoomInfo = function refreshRoomInfo() {
          //刷新房间信息
          var tableName = "" + this.gameTable.tableModel.tableInfo.name;
          var roundId = "" + this.gameTable.tableModel.tableInfo.roundId;
          var betLimit = this.gameTable.tableModel.personLimits;
          var limitStr = NumberFormatUtil.formatUnit(betLimit[0]) + "~" + NumberFormatUtil.formatUnit(betLimit[1]);
          this.userIdLabel.string = "" + PlayerMgr.instance.profile.nickname;
          this.tableNumLabel.string = tableName;
          this.roundIdLabel.string = roundId;
          this.limitLabel.string = limitStr;
          this.gameTable.getView(BaseMenuView).showTableInfo(tableName, roundId, limitStr);
        };
        _proto.refreshRoundId = function refreshRoundId(roundId) {
          this.roundIdLabel.string = roundId;
          this.gameTable.getView(BaseMenuView).refreshRoundId(roundId);
        };
        _proto.refreshAutoBtnStatus = function refreshAutoBtnStatus() {
          this.autoBtnSprite.spriteFrame = this.autoBtnSpriteFrame[this.gameTable.tableModel.isAutoBet || this.gameTable.tableModel.isAutoSeekRoad ? 1 : 0];
        };
        _proto.setBetNodeStatus = function setBetNodeStatus(isShow) {
          this.betOpreateBtnsNode.active = isShow;
        };
        _proto.showGameClock = function showGameClock() {
          this.gameClock.startClock(this.gameTable.tableModel.clockInfo.duration / 1000, this.gameTable.tableModel.clockInfo.total / 1000);
        };
        _proto.hideGameClock = function hideGameClock() {
          this.gameClock.stopClock();
        };
        _proto.verifyBtnClicked = function verifyBtnClicked() {
          this.gameTable.getView(BaseAllCardVerifyInfoView).showAllCardVerifyInfo();
        };
        _proto.exitBtnClicked = /*#__PURE__*/function () {
          var _exitBtnClicked = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  this.gameTable.tableController.exitSure();
                case 1:
                case "end":
                  return _context.stop();
              }
            }, _callee, this);
          }));
          function exitBtnClicked() {
            return _exitBtnClicked.apply(this, arguments);
          }
          return exitBtnClicked;
        }();
        return BaccaratMainGameView;
      }(BaseMainGameView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "userIdLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tableNumLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "roundIdLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "limitLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gameClock", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "autoBtnSprite", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "autoBtnSpriteFrame", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratOpenCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratTableTipView.ts', './BaccaratTableCardView.ts', './BaccaratVerifyCardView.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratTableTipView, BaccaratTableCardView, BaccaratVerifyCardView, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratTableTipView = module.BaccaratTableTipView;
    }, function (module) {
      BaccaratTableCardView = module.BaccaratTableCardView;
    }, function (module) {
      BaccaratVerifyCardView = module.BaccaratVerifyCardView;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "29777IyGqpDL4Pq4hvQdeRo", "BaccaratOpenCardState", undefined);
      var BaccaratOpenCardState = exports('BaccaratOpenCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratOpenCardState, _BaseState);
        function BaccaratOpenCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratOpenCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Deal_Card);
          if (!isConnectAgain) {
            this.gameTable.getView(BaccaratTableCardView).startOpenCard();
            this.gameTable.getView(BaccaratVerifyCardView).startOpenCard();
          }
        };
        _proto.exit = function exit() {
          this.gameTable.getView(BaccaratTableTipView).hideTip();
        };
        return BaccaratOpenCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratPrepareState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "86420+OsOBPeo//CEYQkGgJ", "BaccaratPrepareState", undefined);
      var BaccaratPrepareState = exports('BaccaratPrepareState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratPrepareState, _BaseState);
        function BaccaratPrepareState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratPrepareState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableModel.initData();
          this.gameTable.initView();
        };
        _proto.exit = function exit() {};
        return BaccaratPrepareState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratSettleState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaraTableSettleView.ts', './BaccaratTableBetView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaraTableSettleView, BaccaratTableBetView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaraTableSettleView = module.BaccaraTableSettleView;
    }, function (module) {
      BaccaratTableBetView = module.BaccaratTableBetView;
    }],
    execute: function () {
      cclegacy._RF.push({}, "01f51egzVND2Kbn0Gt/Cw8B", "BaccaratSettleState", undefined);
      var BaccaratSettleState = exports('BaccaratSettleState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratSettleState, _BaseState);
        function BaccaratSettleState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratSettleState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.getView(BaccaraTableSettleView).showResult();
          this.gameTable.getView(BaccaratTableBetView).showWinAreaLight();
        };
        _proto.exit = function exit() {};
        return BaccaratSettleState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratStopBetState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratTableTipView.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratTableTipView, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratTableTipView = module.BaccaratTableTipView;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "a5fcb+T1cZGbZSUwL3tGoyD", "BaccaratStopBetState", undefined);
      var BaccaratStopBetState = exports('BaccaratStopBetState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BaccaratStopBetState, _BaseState);
        function BaccaratStopBetState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BaccaratStopBetState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Stop_Bet);
          AudioManager.playSound('Female/Female_EndBet');
        };
        _proto.exit = function exit() {};
        return BaccaratStopBetState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableBetView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableBetView.ts', './bc_baccarat.ts', './BaccaratMainGameView.ts', './NumberFormatUtil.ts', './BacaratAutoLogic.ts', './BaccaratEnum.ts', './AudioManager.ts', './PopupMgr.ts', './PlayerMgr.ts', './GlobalData.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Label, Toggle, sys, BaseTableBetView, BetType, BaccaratMainGameView, NumberFormatUtil, BaccaratAutoLogic, BaccaratBetType, AudioManager, PopupMgr, PlayerMgr, TipMessage, BaccaratEvents, LocalStorageKey;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Label = module.Label;
      Toggle = module.Toggle;
      sys = module.sys;
    }, function (module) {
      BaseTableBetView = module.BaseTableBetView;
    }, function (module) {
      BetType = module.BetType;
    }, function (module) {
      BaccaratMainGameView = module.BaccaratMainGameView;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      BaccaratBetType = module.BaccaratBetType;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      TipMessage = module.TipMessage;
    }, function (module) {
      BaccaratEvents = module.BaccaratEvents;
      LocalStorageKey = module.LocalStorageKey;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8;
      cclegacy._RF.push({}, "4f8acWVhF9MCoRGokBPGqzU", "BaccaratTableBetView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableBetView = exports('BaccaratTableBetView', (_dec = ccclass('BaccaratTableBetView'), _dec2 = property([Label]), _dec3 = property(Toggle), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Label), _dec7 = property(Label), _dec8 = property(Label), _dec9 = property(Label), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableBetView) {
        _inheritsLoose(BaccaratTableBetView, _BaseTableBetView);
        function BaccaratTableBetView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableBetView.call.apply(_BaseTableBetView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _initializerDefineProperty(_this, "oddsLabel", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "isFreeToggle", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bankerCoinLabel", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bankerPercentLabel", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bankerPersonNumLabel", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerCoinLabel", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerPercentLabel", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerPersonNumLabel", _descriptor8, _assertThisInitialized(_this));
          _this.areaLightList = [];
          _this.regeistEvents = [{
            eventName: BaccaratEvents.RefreshNoFreeShow,
            method: _this.refreshNoFreeShow,
            caller: _assertThisInitialized(_this)
          }];
          return _this;
        }
        var _proto = BaccaratTableBetView.prototype;
        _proto.initView = function initView() {
          this.betChipList.forEach(function (element) {
            if (element) {
              element.node.active = false;
            }
          });
          this.areaLightList.forEach(function (element) {
            if (element) {
              element.active = false;
            }
          });
          this.setAreaBtnsTouchStatus(false);
          this.bankerPercentLabel.string = '0%';
          this.bankerPersonNumLabel.string = '0';
          this.playerPercentLabel.string = '0%';
          this.playerPersonNumLabel.string = '0';
          this.bankerCoinLabel.string = '0';
          this.playerCoinLabel.string = '0';
        };
        _proto.updateView = function updateView() {
          //刷新区域赔率
          this.refreshAreaOdds();
          var tableInfo = this.gameTable.tableModel.tableInfo;
          if (tableInfo) {
            //顯示已經下注的數據
            var betDetails = tableInfo.betInfos;
            for (var i = 0; i < betDetails.length; i++) {
              this.gameTable.tableModel.addBet(false, betDetails[i]);
              this.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(betDetails[i].type);
            }
          }
          var isNoFree = sys.localStorage.getItem(LocalStorageKey.Bac_IsFreeBet) !== '0';
          this.isFreeToggle.isChecked = isNoFree;
          this.gameTable.tableModel.isNoFree = isNoFree;
          //this.refreshNoFreeShow();
          this.refreshBankerAndPlayerBetStatistic(this.gameTable.tableModel.tableInfo.betStatInfo);
        };
        _proto.betAreaBtnClicked = function betAreaBtnClicked(_, touchArea) {
          if (!PlayerMgr.instance.profile.betStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Bet);
            return;
          }
          var touchAreaIndex = ~~touchArea;
          if (touchAreaIndex >= 0 && this.gameTable.tableModel.isCanBet) {
            if (touchAreaIndex === BetType.Banker) {
              var noFreeBet = this.gameTable.tableModel.getBetNumByType(BetType.BankerNoFee);
              if (noFreeBet > 0) {
                PopupMgr.instance.showToast('已經下注莊免傭');
                return;
              }
            }
            if (touchAreaIndex === BetType.BankerNoFee) {
              var freeBet = this.gameTable.tableModel.getBetNumByType(BetType.Banker);
              if (freeBet > 0) {
                PopupMgr.instance.showToast('已經下注莊非免傭');
                return;
              }
            }
            var tableModel = this.gameTable.tableModel;
            var bet = tableModel.getCurrectBetChip();
            if (NumberFormatUtil.formatMoneyToNumber(bet) > this.gameTable.tableModel.tableCoin) {
              bet = NumberFormatUtil.formatMoneyToString(this.gameTable.tableModel.tableCoin);
            }
            tableModel.addBet(true, {
              bet: bet,
              type: touchAreaIndex
            });
            this.refreshAreaBetChip(touchAreaIndex);
            this.gameTable.getView(BaccaratMainGameView).refreshBetOpreateStatus();
          }
        };
        _proto.refreshAreaBetChip = function refreshAreaBetChip(type) {
          var tableModel = this.gameTable.tableModel;
          var areaBetNum = tableModel.getBetNumByType(type);
          if (areaBetNum > 0) {
            this.betChipList[type].node.active = true;
            this.betChipList[type].showBetNum(areaBetNum, tableModel.getChipSpriteFrameIndex(areaBetNum));
            AudioManager.playSound('Chips');
          } else {
            this.betChipList[type].node.active = false;
          }
        };
        _proto.refreshAreaOdds = function refreshAreaOdds() {
          //刷新区域赔率
          var odds = this.gameTable.tableModel.tableConfig.odds;
          var super6Odds = this.gameTable.tableModel.tableConfig.super6Odds;
          for (var i = 0; i < this.oddsLabel.length; i++) {
            if (this.oddsLabel[i]) {
              if (i != BetType.Super6) {
                this.oddsLabel[i].string = "1:" + odds[i];
              } else {
                this.oddsLabel[i].string = "1:" + super6Odds[0] + "/1:" + super6Odds[1];
              }
            }
          }
        };
        _proto.refreshNoFreeShow = function refreshNoFreeShow() {
          this.oddsLabel[BetType.BankerNoFee].node.active = this.gameTable.tableModel.isNoFree;
          this.oddsLabel[BetType.Banker].node.active = !this.gameTable.tableModel.isNoFree;
          this.betAreaButton[BetType.BankerNoFee].node.active = this.gameTable.tableModel.isNoFree;
          this.betAreaButton[BetType.Banker].node.active = !this.gameTable.tableModel.isNoFree;
          var noFreeBet = this.gameTable.tableModel.getBetNumByType(BetType.BankerNoFee);
          this.betChipList[BetType.BankerNoFee].node.active = this.gameTable.tableModel.isNoFree && noFreeBet > 0;
          var freeBet = this.gameTable.tableModel.getBetNumByType(BetType.Banker);
          this.betChipList[BetType.Banker].node.active = this.gameTable.tableModel.isNoFree && freeBet > 0;
        };
        _proto.setAreaBtnsTouchStatus = function setAreaBtnsTouchStatus(isTouch) {
          this.betAreaButton.forEach(function (element) {
            if (element) {
              element.interactable = isTouch;
            }
          });
        };
        _proto.nofreeToggleClick = function nofreeToggleClick() {
          this.gameTable.tableModel.isNoFree = !this.isFreeToggle.isChecked;
          sys.localStorage.setItem(LocalStorageKey.Bac_IsFreeBet, this.isFreeToggle.isChecked ? "0" : "1");
        };
        _proto.refreshBankerAndPlayerBetStatistic = function refreshBankerAndPlayerBetStatistic(betStatInfo) {
          if (betStatInfo) {
            this.bankerCoinLabel.string = "$" + NumberFormatUtil.formatNumDistance(NumberFormatUtil.formatMoneyToNumber(betStatInfo.bankerTotalBet));
            this.bankerPercentLabel.string = betStatInfo.bankerPercent + "%";
            this.bankerPersonNumLabel.string = betStatInfo.bankerCount.toString();
            this.playerCoinLabel.string = "$" + NumberFormatUtil.formatNumDistance(NumberFormatUtil.formatMoneyToNumber(betStatInfo.playerTotalBet));
            this.playerPercentLabel.string = betStatInfo.playerPercent + "%";
            this.playerPersonNumLabel.string = betStatInfo.playerCount.toString();
          }
        };
        _proto.showWinAreaLight = function showWinAreaLight() {
          var openCards = this.gameTable.tableModel.cardsInfo;
          if (openCards && openCards.checkResults && openCards.checkResults.length > 0) {
            var checkResults = openCards.checkResults;
            for (var i = 0; i < checkResults.length; i++) {
              var element = checkResults[i];
              if (element && element.match && this.areaLightList[i]) {
                this.areaLightList[i].active = true;
              }
            }
          }
        };
        _proto.autoBet = function autoBet() {
          var _this2 = this;
          if (!PlayerMgr.instance.profile.autoBetStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Auto_Bet);
            return;
          }
          if (this.gameTable.tableModel.autoBetRound <= 0) {
            return;
          }
          var autoBetType = BaccaratAutoLogic.ins.getAutoBetLocalStroge().betType;
          var autoBetValue = BaccaratAutoLogic.ins.getAutoBetLocalStroge().betValue;
          var bet = NumberFormatUtil.formatMoneyToString(autoBetValue);
          var type;
          if (autoBetType == BaccaratBetType.Player) {
            type = BetType.Player;
          } else {
            if (this.isFreeToggle.isChecked) {
              type = BetType.BankerNoFee;
            } else {
              type = BetType.Banker;
            }
          }
          this.gameTable.tableController.requestBet({
            tableId: this.gameTable.tableModel.tableId,
            details: [{
              bet: bet,
              type: type
            }]
          }).then(function () {
            _this2.gameTable.tableModel.autoBetRound--;
            if (_this2.gameTable.tableModel.autoBetRound <= 0) {
              _this2.gameTable.tableModel.setStopAutoBet();
            }
          });
        };
        _proto.autoSeekRoad = function autoSeekRoad() {
          if (!PlayerMgr.instance.profile.autoBetStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Auto_Bet);
            return;
          }
          var seekCount = this.gameTable.tableModel.getCanSeekRoadCount();
          if (seekCount > 0) {
            var autoBetType = BaccaratAutoLogic.ins.getAutoSeekRoadLocalStroge().betType;
            var autoBetValue = BaccaratAutoLogic.ins.getAutoSeekRoadLocalStroge().betValue;
            var bet = NumberFormatUtil.formatMoneyToString(autoBetValue * seekCount);
            var type;
            if (autoBetType == BaccaratBetType.Player) {
              type = BetType.Player;
            } else {
              if (this.isFreeToggle.isChecked) {
                type = BetType.BankerNoFee;
              } else {
                type = BetType.Banker;
              }
            }
            this.gameTable.tableController.requestBet({
              tableId: this.gameTable.tableModel.tableId,
              details: [{
                bet: bet,
                type: type
              }]
            });
          }
        };
        _proto.setNoFreeCheck = function setNoFreeCheck(isChecked) {
          this.isFreeToggle.isChecked = isChecked;
        };
        return BaccaratTableBetView;
      }(BaseTableBetView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "oddsLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "isFreeToggle", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bankerCoinLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "bankerPercentLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "bankerPersonNumLabel", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "playerCoinLabel", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "playerPercentLabel", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "playerPersonNumLabel", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableCardView.ts', './BaccaratEnum.ts', './AudioManager.ts', './Emitter.ts', './GlobalData.ts', './BaccaratData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, Label, Tween, tween, BaseTableCardView, BaccaratCardIndex, AudioManager, Emitter, GlobalEvent, BaccaratConsts;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Label = module.Label;
      Tween = module.Tween;
      tween = module.tween;
    }, function (module) {
      BaseTableCardView = module.BaseTableCardView;
    }, function (module) {
      BaccaratCardIndex = module.BaccaratCardIndex;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }, function (module) {
      BaccaratConsts = module.BaccaratConsts;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2;
      cclegacy._RF.push({}, "cf214sM/W1IXaspHvtUr/m3", "BaccaratTableCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableCardView = exports('BaccaratTableCardView', (_dec = ccclass('BaccaratTableCardView'), _dec2 = property({
        type: Label
      }), _dec3 = property({
        type: Label
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableCardView) {
        _inheritsLoose(BaccaratTableCardView, _BaseTableCardView);
        function BaccaratTableCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableCardView.call.apply(_BaseTableCardView, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "playerPointLabel", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bankerPointLabel", _descriptor2, _assertThisInitialized(_this));
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BaccaratTableCardView.prototype;
        _proto.initView = function initView() {
          this.hide();
          this.hideCards();
          this.unscheduleAllCallbacks();
          if (this.playerPointLabel) {
            this.playerPointLabel.node.active = false;
          }
          if (this.bankerPointLabel) {
            this.bankerPointLabel.node.active = false;
          }
          Tween.stopAllByTarget(this.node);
        };
        _proto.updateView = function updateView() {
          this.showAllCards();
        };
        _proto.startOpenCard = /*#__PURE__*/function () {
          var _startOpenCard = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            var _this2 = this;
            var cardsInfo, cardTween;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  cardsInfo = this.gameTable.tableModel.cardsInfo;
                  if (cardsInfo) {
                    cardTween = tween(this.node);
                    this.show();
                    //发牌
                    //发第一次牌(闲家两张)
                    cardTween.call(function () {
                      _this2.firstShowCards();
                    });
                    // await Utils.sleep(BaccaratConsts.showCardTime);
                    cardTween.delay(BaccaratConsts.showCardTime);
                    //发第二次牌(庄家两张)
                    cardTween.call(function () {
                      _this2.secondShowCards();
                    });
                    // await Utils.sleep(BaccaratConsts.showCardTime);
                    cardTween.delay(BaccaratConsts.showCardTime);
                    //第一次开牌(闲家两张)
                    cardTween.call(function () {
                      _this2.firstFlopCards();
                    });
                    //await Utils.sleep(BaccaratConsts.disCardTime);
                    cardTween.delay(BaccaratConsts.flopCardTime);
                    cardTween.call(function () {
                      var playerPoint = _this2.gameTable.tableModel.getCardsPoint([cardsInfo.playerCards[0], cardsInfo.playerCards[1]]);
                      _this2.showPoint(playerPoint, null, true);
                    });
                    cardTween.delay(BaccaratConsts.pointSoundTime);
                    //第二次开牌
                    cardTween.call(function () {
                      _this2.secondFlopCards();
                    });

                    //await Utils.sleep(BaccaratConsts.disCardTime);
                    cardTween.delay(BaccaratConsts.flopCardTime);
                    cardTween.call(function () {
                      var bankerPoint = _this2.gameTable.tableModel.getCardsPoint([cardsInfo.bankerCards[0], cardsInfo.bankerCards[1]]);
                      _this2.showPoint(null, bankerPoint, false);
                    });
                    cardTween.delay(BaccaratConsts.pointSoundTime);
                    if (cardsInfo.playerCards[2] != null) {
                      //发第三次牌
                      cardTween.call(function () {
                        _this2.thirdShowCards();
                        AudioManager.playSound('Female/Female_PlayerDraw');
                      });
                      cardTween.delay(BaccaratConsts.cardDrawTime);
                      //await Utils.sleep(BaccaratConsts.showCardTime);
                      //第三次开牌
                      cardTween.call(function () {
                        _this2.thirdFlopCards();
                      });
                      cardTween.delay(BaccaratConsts.flopCardTime);
                      //await Utils.sleep(BaccaratConsts.disCardTime);
                      cardTween.call(function () {
                        _this2.showPoint(cardsInfo.playerScore, 0, true);
                      });
                      cardTween.delay(BaccaratConsts.pointSoundTime);
                    }
                    if (cardsInfo.bankerCards[2] != null) {
                      //发第四次牌
                      cardTween.call(function () {
                        _this2.fourShowCards();
                        AudioManager.playSound('Female/Female_BankerDraws');
                      });
                      cardTween.delay(BaccaratConsts.cardDrawTime);
                      //await Utils.sleep(BaccaratConsts.showCardTime);
                      //第四次开牌
                      cardTween.call(function () {
                        _this2.fourFlopCards();
                      });
                      cardTween.delay(BaccaratConsts.flopCardTime);
                      //await Utils.sleep(BaccaratConsts.disCardTime);
                      cardTween.call(function () {
                        _this2.showPoint(cardsInfo.playerScore, cardsInfo.bankerScore, false);
                      });
                      cardTween.delay(BaccaratConsts.pointSoundTime);
                    }
                    cardTween.start();
                  }
                case 2:
                case "end":
                  return _context.stop();
              }
            }, _callee, this);
          }));
          function startOpenCard() {
            return _startOpenCard.apply(this, arguments);
          }
          return startOpenCard;
        }();
        _proto.showPoint = function showPoint(playerPoint, bankerPoint, isPlayer, playSound) {
          if (playSound === void 0) {
            playSound = true;
          }
          if (this.playerPointLabel && isPlayer) {
            this.playerPointLabel.node.active = true;
            this.playerPointLabel.string = "" + playerPoint;
            if (playSound) {
              AudioManager.playSound("Female/Female_Player");
              this.scheduleOnce(function () {
                AudioManager.playSound("Female/Female_Point_" + playerPoint);
              }, 0.8);
            }
          }
          if (this.bankerPointLabel && !isPlayer) {
            this.bankerPointLabel.node.active = true;
            this.bankerPointLabel.string = "" + bankerPoint;
            if (playSound) {
              AudioManager.playSound("Female/Female_Banker");
              this.scheduleOnce(function () {
                AudioManager.playSound("Female/Female_Point_" + bankerPoint);
              }, 0.8);
            }
          }
        };
        _proto.firstShowCards = function firstShowCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          this.showCards([BaccaratCardIndex.Player1, BaccaratCardIndex.Player2], [cardsInfo.playerCards[0], cardsInfo.playerCards[1]]);
        };
        _proto.firstFlopCards = function firstFlopCards() {
          this.flopCards([BaccaratCardIndex.Player1, BaccaratCardIndex.Player2]);
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, cardsInfo.playerCards.slice(0, 2));
        };
        _proto.secondShowCards = function secondShowCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          this.showCards([BaccaratCardIndex.Banker1, BaccaratCardIndex.Banker2], [cardsInfo.bankerCards[0], cardsInfo.bankerCards[1]]);
        };
        _proto.secondFlopCards = function secondFlopCards() {
          this.flopCards([BaccaratCardIndex.Banker1, BaccaratCardIndex.Banker2]);
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, cardsInfo.bankerCards.slice(0, 2));
        };
        _proto.thirdShowCards = function thirdShowCards(isShowBack) {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          this.showCards([BaccaratCardIndex.Player3], [cardsInfo.playerCards[2]]);
        };
        _proto.thirdFlopCards = function thirdFlopCards() {
          this.flopCards([BaccaratCardIndex.Player3]);
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, cardsInfo.playerCards.slice(2));
        };
        _proto.fourShowCards = function fourShowCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          this.showCards([BaccaratCardIndex.Banker3], [cardsInfo.bankerCards[2]]);
        };
        _proto.fourFlopCards = function fourFlopCards() {
          this.flopCards([BaccaratCardIndex.Banker3]);
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, cardsInfo.bankerCards.slice(2));
        };
        _proto.showCards = function showCards(cardIndexs, cardsInfos) {
          var _this3 = this;
          if (cardIndexs.length > 0 && cardsInfos.length > 0 && cardIndexs.length === cardsInfos.length) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this3.cards[index];
              if (card && cardsInfos[cardIndex]) {
                card.setCard(cardsInfos[cardIndex], true);
              }
            });
          }
        };
        _proto.flopCards = function flopCards(cardIndexs) {
          var _this4 = this;
          if (cardIndexs.length > 0) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this4.cards[index];
              if (card && card.node.active) {
                card.flopCard();
              }
            });
          }
        };
        _proto.hideCards = function hideCards() {
          this.cards.forEach(function (card) {
            card.node.active = false;
          });
        };
        _proto.showAllCards = function showAllCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo) {
            this.show();
            var bankerCardsInfo = cardsInfo.bankerCards;
            var playerCardsInfo = cardsInfo.playerCards;
            var bankerCards = [this.cards[BaccaratCardIndex.Banker1], this.cards[BaccaratCardIndex.Banker2], this.cards[BaccaratCardIndex.Banker3]];
            var playerCards = [this.cards[BaccaratCardIndex.Player1], this.cards[BaccaratCardIndex.Player2], this.cards[BaccaratCardIndex.Player3]];
            bankerCards.forEach(function (card, index) {
              if (bankerCardsInfo[index]) {
                card.setCard(bankerCardsInfo[index]);
              }
            });
            playerCards.forEach(function (card, index) {
              if (playerCardsInfo[index]) {
                card.setCard(playerCardsInfo[index]);
              }
            });
            this.showPoint(cardsInfo.playerScore, cardsInfo.bankerScore, false, false);
            this.showPoint(cardsInfo.playerScore, cardsInfo.bankerScore, true, false);
          }
        };
        return BaccaratTableCardView;
      }(BaseTableCardView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "playerPointLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "bankerPointLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableChipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableChipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableChipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableChipView = module.BaseTableChipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "c8ad00qNllEGamXkX6QnC7+", "BaccaratTableChipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableChipView = exports('BaccaratTableChipView', (_dec = ccclass('BaccaratTableChipView'), _dec(_class = /*#__PURE__*/function (_BaseTableChipView) {
        _inheritsLoose(BaccaratTableChipView, _BaseTableChipView);
        function BaccaratTableChipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableChipView.call.apply(_BaseTableChipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BaccaratTableChipView.prototype;
        _proto.initView = function initView() {};
        _proto.updateView = function updateView() {
          this.refreshCoinValue();
        };
        return BaccaratTableChipView;
      }(BaseTableChipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableController.ts', './bc_baccarat.ts', './BaccaratTableBetView.ts', './PlayerMgr.ts', './NumberFormatUtil.ts', './BaccaratMainGameView.ts', './Logger.ts', './Emitter.ts', './GlobalData.ts', './PopupMgr.ts', './BaseReplayView.ts', './AudioManager.ts', './BaccaratTableCardView.ts', './BaccaratVerifyCardView.ts', './BaccaraTableSettleView.ts', './BaccaratTableChipView.ts', './GameModel.ts', './ClientEnum.ts', './BaseAllCardVerifyInfoView.ts'], function (exports) {
  var _inheritsLoose, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, director, BaseTableController, Phase, BetType, BaccaratTableBetView, PlayerMgr, NumberFormatUtil, BaccaratMainGameView, Logger, Emitter, GlobalEvent, GlobalData, TipMessage, ErrorCodeTip, BacaratBetTypeName, PopupMgr, BaseReplayView, AudioManager, BaccaratTableCardView, BaccaratVerifyCardView, BaccaraTableSettleView, BaccaratTableChipView, GameModel, Scenes, BaseAllCardVerifyInfoView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      director = module.director;
    }, function (module) {
      BaseTableController = module.BaseTableController;
    }, function (module) {
      Phase = module.Phase;
      BetType = module.BetType;
    }, function (module) {
      BaccaratTableBetView = module.BaccaratTableBetView;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaccaratMainGameView = module.BaccaratMainGameView;
    }, function (module) {
      Logger = module.Logger;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
      GlobalData = module.GlobalData;
      TipMessage = module.TipMessage;
      ErrorCodeTip = module.ErrorCodeTip;
      BacaratBetTypeName = module.BacaratBetTypeName;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      BaseReplayView = module.BaseReplayView;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratTableCardView = module.BaccaratTableCardView;
    }, function (module) {
      BaccaratVerifyCardView = module.BaccaratVerifyCardView;
    }, function (module) {
      BaccaraTableSettleView = module.BaccaraTableSettleView;
    }, function (module) {
      BaccaratTableChipView = module.BaccaratTableChipView;
    }, function (module) {
      GameModel = module.GameModel;
    }, function (module) {
      Scenes = module.Scenes;
    }, function (module) {
      BaseAllCardVerifyInfoView = module.BaseAllCardVerifyInfoView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "afcbboTJhZNX64D5cFGjPnl", "BaccaratTableController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableController = exports('BaccaratTableController', (_dec = ccclass('BaccaratTableController'), _dec(_class = /*#__PURE__*/function (_BaseTableController) {
        _inheritsLoose(BaccaratTableController, _BaseTableController);
        function BaccaratTableController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableController.call.apply(_BaseTableController, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BaccaratTableController.prototype;
        _proto.onLoad = function onLoad() {
          Emitter.on(GlobalEvent.EVENT_GAME_CONNECT_AGAIN_REFRESH, this.startGame, this);
        };
        _proto.startGame = function startGame() {
          this.gameTable.tableModel.initData();
          this.gameTable.initView();
          if (GlobalData.isReplay) {
            this.startRePlay();
          } else {
            this.joinTable();
          }
        };
        _proto.joinTable = /*#__PURE__*/function () {
          var _joinTable = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            var _this2 = this;
            var tableId;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  //加入牌桌
                  //const tableId = ~~LinkParasUtil.getParameterValue("table");
                  tableId = GameModel.ins.enterTableId;
                  _context.next = 3;
                  return this.gameTable.tableProxy.sendJoinTabelRequest({
                    tableId: tableId
                  }).then(function (tableJoinData) {
                    Emitter.emit(GlobalEvent.EVENT_GAME_INIT_VIDEO, tableJoinData.table.broadcastInfo);
                    AudioManager.playMusic("BGM-OriginalVolume");
                    //設置數據
                    var tableData = tableJoinData.table;
                    if (tableData) {
                      var _tableData$dealtCards;
                      var betLimits = PlayerMgr.instance.profile.betLimits;
                      _this2.gameTable.tableModel.personLimits = [NumberFormatUtil.formatMoneyToNumber(betLimits[0]), NumberFormatUtil.formatMoneyToNumber(betLimits[1])];
                      _this2.gameTable.tableModel.tableInfo = tableData;
                      _this2.gameTable.tableModel.tableConfig = tableData.config;
                      _this2.gameTable.tableModel.cardsInfo = tableData.openCards;
                      _this2.gameTable.tableModel.dealCardsInfo = (_tableData$dealtCards = tableData.dealtCards) == null ? void 0 : _tableData$dealtCards.dealtCards;
                      _this2.gameTable.tableModel.openedCards = tableData.openedCards;
                      _this2.gameTable.tableModel.unOpenedCards = tableData.hashedCards;
                      if (tableData.phase === Phase.Settle) {
                        _this2.gameTable.tableModel.settleData = tableData.roadInfos[tableData.roadInfos.length - 1];
                        if (tableData.settlementSummary) {
                          _this2.gameTable.tableModel.playerSettlementSummary = tableData.settlementSummary;
                        }
                      }
                      _this2.gameTable.tableModel.roadInfos = tableData.roadInfos;
                      _this2.gameTable.updateView();
                      _this2.gameTable.stateMachineManager.transitionTo(tableData.phase, true);
                      //显示历史聊天记录内容
                      _this2.gameTable.gameChatView.showChatHistoryMsg(tableData.historyMessages);
                      _this2.gameTable.getView(BaccaratMainGameView).hideLoadNode();
                    }
                  });
                case 3:
                case "end":
                  return _context.stop();
              }
            }, _callee, this);
          }));
          function joinTable() {
            return _joinTable.apply(this, arguments);
          }
          return joinTable;
        }();
        _proto.leaveTable = /*#__PURE__*/function () {
          var _leaveTable = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  _context2.next = 2;
                  return this.gameTable.tableProxy.sendLeaveTabelRequest({
                    tableId: 1
                  }).then(function () {
                    director.loadScene(Scenes.LOBBY_SCENE);
                  });
                case 2:
                case "end":
                  return _context2.stop();
              }
            }, _callee2, this);
          }));
          function leaveTable() {
            return _leaveTable.apply(this, arguments);
          }
          return leaveTable;
        }();
        _proto.requestBet = /*#__PURE__*/function () {
          var _requestBet = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(betRequest) {
            var _this3 = this;
            return _regeneratorRuntime().wrap(function _callee3$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  _context3.next = 2;
                  return this.gameTable.tableProxy.sendGameBetRequest(betRequest).then(function (betResponse) {
                    _this3.gameTable.tableModel.preBetData = [];
                    var successBetInfos = betResponse.successDetails;
                    //成功下注
                    for (var i = 0; i < successBetInfos.length; i++) {
                      _this3.gameTable.tableModel.addBet(false, successBetInfos[i]);
                      _this3.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(successBetInfos[i].type);
                    }
                    var failedDetails = betResponse.failedResults;
                    //失败下注 提示 退回筹码
                    var _loop = function _loop(_i) {
                      Logger.errNet('下注失败:', failedDetails[_i].code);
                      _this3.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(failedDetails[_i].detail.type);
                      _this3.scheduleOnce(function () {
                        var errorMsg = ErrorCodeTip[failedDetails[_i].code] || "未知";
                        PopupMgr.instance.showToast(BacaratBetTypeName[failedDetails[_i].detail.type] + "\u4E0B\u6CE8\u5931\u6557:" + errorMsg);
                      }, 0.5 * _i);
                    };
                    for (var _i = 0; _i < failedDetails.length; _i++) {
                      _loop(_i);
                    }
                    PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(betResponse.coin);
                    _this3.gameTable.getView(BaccaratMainGameView).refreshBetOpreateStatus();
                  });
                case 2:
                case "end":
                  return _context3.stop();
              }
            }, _callee3, this);
          }));
          function requestBet(_x) {
            return _requestBet.apply(this, arguments);
          }
          return requestBet;
        }();
        _proto.sendChatMeaasge = function sendChatMeaasge(msg) {
          return this.gameTable.tableProxy.sendChatMsg({
            tableId: this.gameTable.tableModel.tableId,
            textContent: msg
          });
        };
        _proto.sendGift = function sendGift(giftId) {
          var _this4 = this;
          this.gameTable.tableProxy.sendGift({
            tableId: this.gameTable.tableModel.tableId,
            giftId: giftId,
            count: 1
          }).then(function (sendGift) {
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(sendGift.coin);
            _this4.gameTable.tableModel.refreshTableCoin();
          });
        };
        _proto.onBcBaccaratPrepare = function onBcBaccaratPrepare(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Prepare);
          //刷新roundId
          this.gameTable.getView(BaccaratMainGameView).refreshRoundId(data.roundId);
          //判断是否清空牌靴
          if (data.isRoadsCleared) {
            this.gameTable.tableModel.openedCards = [];
            this.gameTable.tableModel.unOpenedCards = data.hashedCards;
            this.gameTable.getView(BaseAllCardVerifyInfoView).resetAllCards();
          }
        };
        _proto.onBcBaccaratDealCards = function onBcBaccaratDealCards(data) {
          this.gameTable.tableModel.dealCardsInfo = data.dealtCards;
          this.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
        };
        _proto.onBcBaccaratBet = function onBcBaccaratBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Betting);
        };
        _proto.onBcBaccaratStopBet = function onBcBaccaratStopBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.StopBet);
        };
        _proto.onBcBaccaratOpenCards = function onBcBaccaratOpenCards(data) {
          this.gameTable.tableModel.cardsInfo = data.cardsInfo;
          this.gameTable.tableModel.refreshAllCardsOpenStatus(data.cardsInfo);
          this.gameTable.stateMachineManager.transitionTo(Phase.OpenCards);
        };
        _proto.onBcBaccaratSettlement = function onBcBaccaratSettlement(data) {
          this.gameTable.tableModel.settleData = data.roadInfos[data.roadInfos.length - 1];
          this.gameTable.stateMachineManager.transitionTo(Phase.Settle);
          this.gameTable.tableModel.roadInfos = data.roadInfos;
        };
        _proto.onGameBetPush = function onGameBetPush(data) {
          this.gameTable.getView(BaccaratTableBetView).refreshBankerAndPlayerBetStatistic(data.betStatInfo);
        };
        _proto.onBcBaccaratPlayerSettlement = function onBcBaccaratPlayerSettlement(data) {
          this.gameTable.tableModel.playerSettlementSummary = data;
          PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(data.coin);
          this.gameTable.tableModel.refreshTableCoin();
        };
        _proto.onBcBaccaratTextMessage = function onBcBaccaratTextMessage(data) {
          if (data.tableId === this.gameTable.tableModel.tableId) {
            // Emitter.emit(GlobalEvent.Event_Game_ON_CHAT_MESSAGE,data);
            this.gameTable.gameChatView.addNewChatMsg(data.message);
          }
        };
        _proto.onKickout = function onKickout(data) {
          PopupMgr.instance.showToast(TipMessage.Kickout);
          this.scheduleOnce(function () {
            //离开游戏
          }, 1);
        };
        _proto.startRePlay = function startRePlay() {
          var _detail$settleInfo,
            _detail$settleInfo2,
            _this5 = this;
          var replayData = GameModel.ins.replayData;
          var detail = replayData.detail;
          PlayerMgr.instance.id = replayData.playerId;
          this.gameTable.getView(BaseReplayView).show();
          this.gameTable.getView(BaccaratMainGameView).hideLoadNode();
          var showTableInfoTime = 1;
          var discardTime = 3;
          var betTime = 3;
          var openCardTime = 11;
          var profile = detail.profileMap[PlayerMgr.instance.id];
          if (profile) {
            PlayerMgr.instance.profile = profile;
            var betLimits = PlayerMgr.instance.profile.betLimits;
            this.gameTable.tableModel.personLimits = [NumberFormatUtil.formatMoneyToNumber(betLimits[0]), NumberFormatUtil.formatMoneyToNumber(betLimits[1])];
          }
          var config = detail.config;
          this.gameTable.tableModel.tableInfo = {
            /** 桌 ID */
            id: replayData.tableId,
            /** 桌名 */
            name: replayData.tableName,
            /** 局 ID */
            roundId: replayData.roundId,
            /** 游戏阶段 */
            phase: 0,
            /** 当前阶段剩余时长信息 */
            durationInfo: null,
            /** 当前玩家在本局的下注信息 */
            betInfos: [],
            /** 当前局的庄闲下注统计信息 */
            betStatInfo: null,
            /** 当前牌靴的明牌信息 */
            openedCards: [],
            /** 当前牌靴的非明牌信息 */
            hashedCards: [],
            /** 当前牌靴的路单信息 */
            roadInfos: [],
            /** 历史聊天信息 */
            historyMessages: [],
            /** 发出的暗牌，< 开牌阶段时都会包含这个字段 */

            /** 玩家的结算结果 */
            settlementSummary: null,
            /** 桌配置 */
            config: config,
            onlinePlayers: 0,
            broadcastInfo: null
          };
          this.gameTable.tableModel.tableConfig = config;
          var playerSettleInfo = detail.settleMap[PlayerMgr.instance.id];
          var playCoinInfo = detail.initCoinMap[PlayerMgr.instance.id];
          if (playCoinInfo) {
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playCoinInfo);
            this.gameTable.tableModel.refreshTableCoin();
          }
          //关闭视频
          Emitter.emit(GlobalEvent.EVENT_GAME_CLOSE_VIDEO);
          //显示牌桌信息
          this.gameTable.getView(BaccaratMainGameView).refreshRoomInfo();
          //刷新筹码显示
          this.gameTable.getView(BaccaratTableChipView).refreshCoinValue();
          //显示各区域赔率
          this.gameTable.getView(BaccaratTableBetView).refreshAreaOdds();
          //顯示莊免傭
          if (playerSettleInfo) {
            var settlementInfos = playerSettleInfo.settlementInfos;
            if (settlementInfos.findIndex(function (betInfo) {
              return betInfo.betType === BetType.BankerNoFee;
            }) > -1) {
              this.gameTable.tableModel.isNoFree = true;
              this.gameTable.getView(BaccaratTableBetView).setNoFreeCheck(true);
            }
            if (settlementInfos.findIndex(function (betInfo) {
              return betInfo.betType === BetType.Banker;
            }) > -1) {
              this.gameTable.tableModel.isNoFree = false;
              this.gameTable.getView(BaccaratTableBetView).setNoFreeCheck(false);
            }
          }
          //刷新起始路单
          this.gameTable.tableModel.roadInfos = (_detail$settleInfo = detail.settleInfo) == null ? void 0 : _detail$settleInfo.roadInfos.slice(0, ((_detail$settleInfo2 = detail.settleInfo) == null ? void 0 : _detail$settleInfo2.roadInfos.length) - 1);
          //this.gameTable.getView(BaccaratRoadMapView).refreshRoadMap(this.gameTable.tableModel.roadInfos);
          // 发牌
          this.scheduleOnce(function () {
            _this5.gameTable.tableModel.dealCardsInfo = detail.dealCardsInfo.dealtCards;
            _this5.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
          }, showTableInfoTime);

          // 下注
          if (playerSettleInfo) {
            //AudioManager.playSound('Female/Female_StartBet');
            this.scheduleOnce(function () {
              var _detail$bettingInfo;
              var settlementInfos = playerSettleInfo.settlementInfos;
              for (var i = 0; i < settlementInfos.length; i++) {
                _this5.gameTable.tableModel.addBet(false, {
                  type: settlementInfos[i].betType,
                  bet: settlementInfos[i].bet
                });
                _this5.gameTable.getView(BaccaratTableBetView).refreshAreaBetChip(settlementInfos[i].betType);
              }
              //刷新庄闲下注信息
              var statInfo = (_detail$bettingInfo = detail.bettingInfo) == null || (_detail$bettingInfo = _detail$bettingInfo.statInfoMap) == null ? void 0 : _detail$bettingInfo[replayData.currency];
              if (statInfo) {
                _this5.gameTable.tableModel.tableInfo.betStatInfo = statInfo;
                _this5.gameTable.getView(BaccaratTableBetView).refreshBankerAndPlayerBetStatistic(statInfo);
              }
              _this5.gameTable.tableModel.refreshTableBetCoin();
              PlayerMgr.instance.coin -= _this5.gameTable.tableModel.getTotalBetNum();
              //刷新玩家金币
              _this5.gameTable.tableModel.refreshTableCoin();
            }, discardTime + showTableInfoTime);
          }
          this.gameTable.tableModel.cardsInfo = detail.openCardsInfo;
          //开牌
          this.scheduleOnce(function () {
            _this5.gameTable.getView(BaccaratTableCardView).startOpenCard();
            _this5.gameTable.getView(BaccaratVerifyCardView).startOpenCard();
          }, discardTime + betTime + showTableInfoTime);

          //结算
          this.scheduleOnce(function () {
            var _detail$settleInfo3, _detail$settleInfo4, _detail$settleInfo5;
            _this5.gameTable.tableModel.playerSettlementSummary = playerSettleInfo;
            _this5.gameTable.tableModel.settleData = (_detail$settleInfo3 = detail.settleInfo) == null ? void 0 : _detail$settleInfo3.roadInfos[((_detail$settleInfo4 = detail.settleInfo) == null ? void 0 : _detail$settleInfo4.roadInfos.length) - 1];
            _this5.gameTable.getView(BaccaraTableSettleView).showResult();
            _this5.gameTable.getView(BaccaratTableBetView).showWinAreaLight();
            if (playerSettleInfo) {
              _this5.gameTable.getView(BaccaraTableSettleView).showSelfResult();
              //刷新玩家金币
              PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playerSettleInfo.coin);
              _this5.gameTable.tableModel.refreshTableCoin();
            }

            //刷新路单
            _this5.gameTable.tableModel.roadInfos = (_detail$settleInfo5 = detail.settleInfo) == null ? void 0 : _detail$settleInfo5.roadInfos;
            //this.gameTable.getView(BaccaratRoadMapView).refreshRoadMap();
          }, discardTime + betTime + openCardTime + showTableInfoTime);
        };
        _proto.exitSure = /*#__PURE__*/function () {
          var _exitSure = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
            var _this6 = this;
            return _regeneratorRuntime().wrap(function _callee4$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  _context4.next = 2;
                  return PopupMgr.instance.showAlert('是否離開游戲');
                case 2:
                  _context4.sent.confirm(function () {
                    _this6.leaveTable();
                  }).cancel(function () {});
                case 3:
                case "end":
                  return _context4.stop();
              }
            }, _callee4);
          }));
          function exitSure() {
            return _exitSure.apply(this, arguments);
          }
          return exitSure;
        }();
        _proto.onDestroy = function onDestroy() {
          Emitter.off(GlobalEvent.EVENT_GAME_CONNECT_AGAIN_REFRESH, this.startGame);
        };
        return BaccaratTableController;
      }(BaseTableController)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableModel.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableModel.ts', './bc_baccarat.ts', './NumberFormatUtil.ts', './Emitter.ts', './PlayerMgr.ts', './BacaratAutoLogic.ts', './BaccaratData.ts', './BaccaratRoadMapView.ts'], function (exports) {
  var _inheritsLoose, _createClass, cclegacy, _decorator, BaseTableModel, WinnerType, Phase, NumberFormatUtil, Emitter, PlayerMgr, BaccaratAutoLogic, BaccaratEvents, BaccaratRoadMapView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableModel = module.BaseTableModel;
    }, function (module) {
      WinnerType = module.WinnerType;
      Phase = module.Phase;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      BaccaratEvents = module.BaccaratEvents;
    }, function (module) {
      BaccaratRoadMapView = module.BaccaratRoadMapView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "93b7c3IBcZC2o1kPlGYJr0y", "BaccaratTableModel", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableModel = exports('BaccaratTableModel', (_dec = ccclass('BaccaratTableModel'), _dec(_class = /*#__PURE__*/function (_BaseTableModel) {
        _inheritsLoose(BaccaratTableModel, _BaseTableModel);
        function BaccaratTableModel() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableModel.call.apply(_BaseTableModel, [this].concat(args)) || this;
          _this.gameTable = void 0;
          /**牌桌咨詢 */
          _this._tableInfo = null;
          /**房間配置 */
          _this._tableConfig = null;
          /**预下注 */
          _this._preBetData = [];
          /**确定下注 */
          _this.sureBetData = [];
          /**上次下注 */
          _this._lastBetData = [];
          /**是否免佣 */
          _this._isNoFree = false;
          /**发牌信息 */
          _this._dealCardsInfo = null;
          /**开牌信息 */
          _this._cardsInfo = null;
          /**倒計時信息 */
          _this._clockInfo = null;
          /**牌桌金币 */
          _this._tableCoin = 0;
          /**牌桌下注金币 */
          _this._tableBetCoin = 0;
          /**当局结算数据 */
          _this._settleData = null;
          /**自己當侷結算信息 */
          _this._playerSettlementSummary = null;
          _this._roadInfos = null;
          /**庄追路 */
          _this._isSeekBankerRoad = false;
          /**
           * 闲追路
           * @returns 
           */
          _this._isSeekPlayerRoad = false;
          /**是否开启自动下注 */
          _this._isAutoBet = false;
          /**是否自动追路 */
          _this._isAutoSeekRoad = false;
          /**當前自動押注局數 */
          _this._autoBetRound = 0;
          return _this;
        }
        var _proto = BaccaratTableModel.prototype;
        _proto.initData = function initData() {
          this.lastBetData = this.sureBetData;
          this.sureBetData = [];
          this.preBetData = [];
        };
        _proto.getSureBetData = function getSureBetData() {
          return this.sureBetData;
        };
        _proto.setSureBetData = function setSureBetData(value) {
          this.sureBetData = value;
        };
        _proto.setStopAutoBet = function setStopAutoBet() {
          this.isAutoBet = false;
          this.autoBetRound = 0;
        };
        _proto.getCurrectBetChip = function getCurrectBetChip() {
          return this.selectBetChipGroup[this.selectBetChipIndex];
        };
        _proto.addBet = function addBet(isPreBet, betInfo) {
          var setBetData = isPreBet ? this.preBetData : this.sureBetData;
          var index = setBetData.findIndex(function (value) {
            return value.type === betInfo.type;
          });
          if (index > -1) {
            var bet = NumberFormatUtil.formatMoneyToNumber(betInfo.bet);
            if (bet > 0) {
              setBetData[index].bet = NumberFormatUtil.formatMoneyToString(NumberFormatUtil.formatMoneyToNumber(setBetData[index].bet) + bet);
            }
          } else {
            setBetData.push(betInfo);
          }
        };
        _proto.getPreBetNum = function getPreBetNum() {
          var totalBetNum = 0;
          this.preBetData.forEach(function (value) {
            totalBetNum += NumberFormatUtil.formatMoneyToNumber(value.bet);
          });
          return totalBetNum;
        };
        _proto.getTotalBetNum = function getTotalBetNum() {
          var totalBetNum = 0;
          totalBetNum += this.getPreBetNum();
          this.sureBetData.forEach(function (value) {
            totalBetNum += NumberFormatUtil.formatMoneyToNumber(value.bet);
          });
          return totalBetNum;
        };
        _proto.getBetNumByType = function getBetNumByType(type) {
          var areaBet = 0;
          var preBetInfo = this.preBetData.find(function (value) {
            return value.type === type;
          });
          if (preBetInfo) {
            areaBet += NumberFormatUtil.formatMoneyToNumber(preBetInfo.bet);
          }
          var sureBetInfo = this.sureBetData.find(function (value) {
            return value.type === type;
          });
          if (sureBetInfo) {
            areaBet += NumberFormatUtil.formatMoneyToNumber(sureBetInfo.bet);
          }
          return areaBet;
        };
        _proto.getChipSpriteFrameIndex = function getChipSpriteFrameIndex(betNum) {
          for (var index = this.selectBetChipGroup.length - 1; index > -1; index--) {
            if (betNum >= NumberFormatUtil.formatMoneyToNumber(this.selectBetChipGroup[index])) {
              return index;
            }
          }
          return 0;
        };
        _proto.getPreBetAreas = function getPreBetAreas() {
          var areas = [];
          for (var index = 0; index < this.preBetData.length; index++) {
            var element = this.preBetData[index];
            if (NumberFormatUtil.formatMoneyToNumber(element.bet) > 0) {
              areas.push(element.type);
            }
          }
          return areas;
        };
        _proto.refreshTableCoin = function refreshTableCoin() {
          this.tableCoin = PlayerMgr.instance.coin - this.getPreBetNum();
        };
        _proto.refreshTableBetCoin = function refreshTableBetCoin() {
          this.tableBetCoin = this.getTotalBetNum();
        };
        _proto.getIsCanAgainBet = function getIsCanAgainBet() {
          return this.lastBetData.length > 0 && this.getTotalBetNum() === 0;
        };
        _proto.getIsCanSureBet = function getIsCanSureBet() {
          return this.preBetData.length > 0;
        };
        _proto.getIsCanCancleBet = function getIsCanCancleBet() {
          return this.preBetData.length > 0;
        };
        _proto.getLimitNums = function getLimitNums() {
          var betLimit = this.tableConfig.betLimit;
          if (betLimit.length === 0) {
            return [0, 0];
          }
          var minVal = Infinity;
          var maxVal = -Infinity;
          for (var i = 0; i < betLimit.length; i++) {
            var currentMin = NumberFormatUtil.formatMoneyToNumber(betLimit[i].min);
            var currentMax = NumberFormatUtil.formatMoneyToNumber(betLimit[i].max);
            if (currentMin < minVal) {
              minVal = currentMin;
            }
            if (currentMax > maxVal) {
              maxVal = currentMax;
            }
          }
          return [minVal, maxVal];
        };
        _proto.getCanSeekRoadCount = function getCanSeekRoadCount() {
          var autoSeekOption = BaccaratAutoLogic.ins.getCustomSeekRoadStoge();
          var seek4Tie = BaccaratAutoLogic.ins.getAutoSeekRoadLocalStroge().seek4Tie;
          var currentRoadInfo = seek4Tie ? this.roadInfos.filter(function (elemet) {
            return elemet.winnerType != WinnerType.WinnerDraw;
          }) : this.roadInfos.slice();
          var isCanSeekCount = 0;
          for (var index = 0; index < autoSeekOption.length; index++) {
            var _currentRoadInfo;
            var element = autoSeekOption[index];
            var isCanSeek = true;
            if (element.length > currentRoadInfo.length) {
              isCanSeek = false;
            } else {
              for (var j = element.length - 1; j >= 0; j--) {
                var customRoad = element[j];
                var currentRoad = currentRoadInfo[currentRoadInfo.length - element.length + j];
                if (customRoad.winnerType !== currentRoad.winnerType) {
                  isCanSeek = false;
                  break;
                }
              }
            }
            if (isCanSeek && currentRoadInfo[currentRoadInfo.length - element.length].winnerType != ((_currentRoadInfo = currentRoadInfo[currentRoadInfo.length - element.length - 1]) == null ? void 0 : _currentRoadInfo.winnerType)) {
              isCanSeekCount++;
            }
          }
          return isCanSeekCount;
        };
        _proto.getCardsPoint = function getCardsPoint(cards) {
          var point = 0;
          for (var i = 0; i < cards.length; i++) {
            var card = cards[i];
            var value = Number(card.value);
            if (value >= 10) {
              point += 10;
            } else {
              point += value;
            }
          }
          point = point % 10;
          return point;
        };
        _createClass(BaccaratTableModel, [{
          key: "tableInfo",
          get: function get() {
            return this._tableInfo;
          },
          set: function set(value) {
            this._tableInfo = value;
            this.sureBetData = value.betInfos;
            this.clockInfo = value.durationInfo;
            this.tableId = value.id;
          }
        }, {
          key: "isCanBet",
          get: function get() {
            return this.gameTable.stateMachineManager.getCurrentState().statCode === Phase.Betting;
          }
        }, {
          key: "tableConfig",
          get: function get() {
            return this._tableConfig;
          },
          set: function set(value) {
            this._tableConfig = value;
            this.selectBetChipGroup = value.chipsCandidate;
          }
        }, {
          key: "preBetData",
          get: function get() {
            return this._preBetData;
          },
          set: function set(value) {
            this._preBetData = value;
          }
        }, {
          key: "lastBetData",
          get: function get() {
            return this._lastBetData;
          },
          set: function set(value) {
            this._lastBetData = value;
          }
        }, {
          key: "isNoFree",
          get: function get() {
            return this._isNoFree;
          },
          set: function set(value) {
            this._isNoFree = value;
            Emitter.emit(BaccaratEvents.RefreshNoFreeShow);
          }
        }, {
          key: "dealCardsInfo",
          get: function get() {
            return this._dealCardsInfo;
          },
          set: function set(value) {
            this._dealCardsInfo = value;
          }
        }, {
          key: "cardsInfo",
          get: function get() {
            return this._cardsInfo;
          },
          set: function set(value) {
            this._cardsInfo = value;
          }
        }, {
          key: "clockInfo",
          get: function get() {
            return this._clockInfo;
          },
          set: function set(value) {
            this._clockInfo = value;
          }
        }, {
          key: "tableCoin",
          get: function get() {
            return this._tableCoin;
          },
          set: function set(value) {
            this._tableCoin = value;
            Emitter.emit(BaccaratEvents.RefreshCurrentCoin);
          }
        }, {
          key: "tableBetCoin",
          get: function get() {
            return this._tableBetCoin;
          },
          set: function set(value) {
            this._tableBetCoin = value;
            Emitter.emit(BaccaratEvents.RefreshBetCoin);
          }
        }, {
          key: "settleData",
          get: function get() {
            return this._settleData;
          },
          set: function set(value) {
            this._settleData = value;
          }
        }, {
          key: "playerSettlementSummary",
          get: function get() {
            return this._playerSettlementSummary;
          },
          set: function set(value) {
            if (value) {
              this._playerSettlementSummary = value;
              PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(this.playerSettlementSummary.coin);
              Emitter.emit(BaccaratEvents.RefreshSelfResult);
            }
          }
        }, {
          key: "roadInfos",
          get: function get() {
            return this._roadInfos;
          },
          set: function set(value) {
            this._roadInfos = value;
            //Emitter.emit(GlobalEvent.EVENT_GAME_REFRESH_ROAD_INFO,value);
            this.gameTable.getView(BaccaratRoadMapView).refreshRoadMap(value);
          }
        }, {
          key: "isSeekBankerRoad",
          get: function get() {
            return this._isSeekBankerRoad;
          },
          set: function set(value) {
            this._isSeekBankerRoad = value;
          }
        }, {
          key: "isSeekPlayerRoad",
          get: function get() {
            return this._isSeekPlayerRoad;
          },
          set: function set(value) {
            this._isSeekPlayerRoad = value;
          }
        }, {
          key: "isAutoBet",
          get: function get() {
            return this._isAutoBet;
          },
          set: function set(value) {
            this._isAutoBet = value;
            if (value) {
              this.isAutoSeekRoad = false;
            }
            Emitter.emit(BaccaratEvents.RefreshAutoBtnStatus);
          }
        }, {
          key: "isAutoSeekRoad",
          get: function get() {
            return this._isAutoSeekRoad;
          },
          set: function set(value) {
            this._isAutoSeekRoad = value;
            if (value) {
              this.isAutoBet = false;
            }
            Emitter.emit(BaccaratEvents.RefreshAutoBtnStatus);
          }
        }, {
          key: "autoBetRound",
          get: function get() {
            return this._autoBetRound;
          },
          set: function set(value) {
            this._autoBetRound = value;
          }
        }, {
          key: "isCanAutoBet",
          get: function get() {
            return this.isAutoBet && this.autoBetRound > 0;
          }
        }]);
        return BaccaratTableModel;
      }(BaseTableModel)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableProxy.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableProxy.ts', './NetConnect.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableProxy, NetConnect;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableProxy = module.BaseTableProxy;
    }, function (module) {
      NetConnect = module.default;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "f932bwaMfpPYpzDrlm3Go1d", "BaccaratTableProxy", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableProxy = exports('BaccaratTableProxy', (_dec = ccclass('BaccaratTableProxy'), _dec(_class = /*#__PURE__*/function (_BaseTableProxy) {
        _inheritsLoose(BaccaratTableProxy, _BaseTableProxy);
        function BaccaratTableProxy() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableProxy.call.apply(_BaseTableProxy, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _this.serverInterfaces = {
            onBcBaccaratPrepare: 'onBcBaccaratPrepare',
            onBcBaccaratDealCards: 'onBcBaccaratDealCards',
            onBcBaccaratBet: 'onBcBaccaratBet',
            onBcBaccaratStopBet: 'onBcBaccaratStopBet',
            onBcBaccaratOpenCards: 'onBcBaccaratOpenCards',
            onBcBaccaratSettlement: 'onBcBaccaratSettlement',
            onGameBetPush: 'onBcBaccaratBetStat',
            onBcBaccaratPlayerSettlement: 'onBcBaccaratPlayerSettlement',
            onBcBaccaratTextMessage: 'onBcBaccaratTextMessage',
            onKickout: 'onKickout'
          };
          return _this;
        }
        var _proto = BaccaratTableProxy.prototype;
        _proto.processServerMsg = function processServerMsg(msgName, msg) {
          if (msg.duration) {
            this.gameTable.tableModel.clockInfo = msg.duration;
          }
          switch (msgName) {
            case this.serverInterfaces.onBcBaccaratPrepare:
              //處理服務端的準備消息
              this.gameTable.tableController.onBcBaccaratPrepare(msg);
              break;
            case this.serverInterfaces.onBcBaccaratDealCards:
              //處理服務端的發牌消息
              this.gameTable.tableController.onBcBaccaratDealCards(msg);
              break;
            case this.serverInterfaces.onBcBaccaratBet:
              //處理服務端的下注消息
              this.gameTable.tableController.onBcBaccaratBet(msg);
              break;
            case this.serverInterfaces.onBcBaccaratStopBet:
              //處理服務端的下注消息
              this.gameTable.tableController.onBcBaccaratStopBet(msg);
              break;
            case this.serverInterfaces.onBcBaccaratOpenCards:
              //處理服務端的開牌消息
              this.gameTable.tableController.onBcBaccaratOpenCards(msg);
              break;
            case this.serverInterfaces.onBcBaccaratSettlement:
              //處理服務端的結算消息
              this.gameTable.tableController.onBcBaccaratSettlement(msg);
              break;
            case this.serverInterfaces.onGameBetPush:
              //處理服務端的有人下注消息
              this.gameTable.tableController.onGameBetPush(msg);
              break;
            case this.serverInterfaces.onBcBaccaratPlayerSettlement:
              //處理自己結算信息
              this.gameTable.tableController.onBcBaccaratPlayerSettlement(msg);
              break;
            case this.serverInterfaces.onBcBaccaratTextMessage:
              //處理服務端的聊天消息
              this.gameTable.tableController.onBcBaccaratTextMessage(msg);
              break;
            case this.serverInterfaces.onKickout:
              //處理服務端的踢出消息
              this.gameTable.tableController.onKickout(msg);
              break;
          }
        }
        /**
         * 入桌
         * @param request 
         * @returns 
         */;
        _proto.sendJoinTabelRequest = function sendJoinTabelRequest(request) {
          return NetConnect.sendRequest('bc_baccarat.table.join', request);
        }

        /**
        * 離桌
        * @param request 
        * @returns 
        */;
        _proto.sendLeaveTabelRequest = function sendLeaveTabelRequest(request) {
          return NetConnect.sendRequest('bc_baccarat.table.leave', request);
        }

        /**
         * 下注
         * @param request 
         * @returns 
         */;
        _proto.sendGameBetRequest = function sendGameBetRequest(request) {
          return NetConnect.sendRequest('bc_baccarat.game.bet', request);
        }
        /**
         * 發送聊天消息
         * @param request
         * @returns
         */;
        _proto.sendChatMsg = function sendChatMsg(request) {
          return NetConnect.sendRequest('bc_baccarat.chat.talk', request);
        };
        _proto.requestRecordByRound = function requestRecordByRound(request) {
          return NetConnect.sendRequest('public.game_record.listbyround', request);
        };
        _proto.requestRecordByDate = function requestRecordByDate(request) {
          return NetConnect.sendRequest('public.game_record.list', request);
        };
        _proto.sendGift = function sendGift(request) {
          return NetConnect.sendRequest('bc_baccarat.gift.send', request);
        };
        return BaccaratTableProxy;
      }(BaseTableProxy)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratTableTipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableTipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableTipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableTipView = module.BaseTableTipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "8b9f5DdVe1OYawBHOVB7dsA", "BaccaratTableTipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratTableTipView = exports('BaccaratTableTipView', (_dec = ccclass('BaccaratTableTipView'), _dec(_class = /*#__PURE__*/function (_BaseTableTipView) {
        _inheritsLoose(BaccaratTableTipView, _BaseTableTipView);
        function BaccaratTableTipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableTipView.call.apply(_BaseTableTipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BaccaratTableTipView.prototype;
        _proto.initView = function initView() {
          this.hideTip();
        };
        _proto.updateView = function updateView() {};
        return BaccaratTableTipView;
      }(BaseTableTipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccaratVerifyCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaccaratTableCardView.ts', './BaccaratEnum.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, tween, v3, BaccaratTableCardView, BaccaratCardIndex, BaccaratConsts;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      tween = module.tween;
      v3 = module.v3;
    }, function (module) {
      BaccaratTableCardView = module.BaccaratTableCardView;
    }, function (module) {
      BaccaratCardIndex = module.BaccaratCardIndex;
    }, function (module) {
      BaccaratConsts = module.BaccaratConsts;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "cca3a4EUS5Jm4HiJnm8es+h", "BaccaratVerifyCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccaratVerifyCardView = exports('BaccaratVerifyCardView', (_dec = ccclass('BaccaratVerifyCardView'), _dec(_class = /*#__PURE__*/function (_BaccaratTableCardVie) {
        _inheritsLoose(BaccaratVerifyCardView, _BaccaratTableCardVie);
        function BaccaratVerifyCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaccaratTableCardVie.call.apply(_BaccaratTableCardVie, [this].concat(args)) || this;
          _this.waitPostions = [v3(252, 53), v3(318, 53)];
          _this.showPostions = [v3(-188, -86), v3(192, -86)];
          return _this;
        }
        var _proto = BaccaratVerifyCardView.prototype;
        _proto.updateView = function updateView() {
          if (this.gameTable.tableModel.dealCardsInfo) {
            this.disCards();
          }
          if (this.gameTable.tableModel.cardsInfo) {
            this.showVerifyCards();
          }
        };
        _proto.disCards = function disCards() {
          var cardsInfo = this.gameTable.tableModel.dealCardsInfo;
          if (cardsInfo) {
            this.node.active = true;
            var sortCardsInfo = [cardsInfo[0], cardsInfo[2], cardsInfo[1], cardsInfo[3], cardsInfo[4], cardsInfo[5]];
            this.cards.forEach(function (card, index) {
              card.disCard(sortCardsInfo[index]);
            });
            this.cards[BaccaratCardIndex.Player3].node.setPosition(this.waitPostions[0]);
            this.cards[BaccaratCardIndex.Banker3].node.setPosition(this.waitPostions[1]);
            this.cards[BaccaratCardIndex.Player3].node.angle = 0;
            this.cards[BaccaratCardIndex.Banker3].node.angle = 0;
          }
        };
        _proto.thirdShowCards = function thirdShowCards(isShowBack) {
          if (isShowBack === void 0) {
            isShowBack = true;
          }
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          var playerAddCard = this.cards[BaccaratCardIndex.Player3];
          //判断是否有闲补牌和庄补牌
          if (cardsInfo.playerCards[2]) {
            tween(playerAddCard.node).to(BaccaratConsts.showCardTime, {
              position: this.showPostions[0]
            }).call(function () {
              playerAddCard.setCard(cardsInfo.playerCards[2], isShowBack);
              playerAddCard.node.angle = -90;
            }).start();
          }
        };
        _proto.thirdFlopCards = function thirdFlopCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo.playerCards[2]) {
            this.cards[BaccaratCardIndex.Player3].flopCard();
          }
        };
        _proto.fourShowCards = function fourShowCards(isShowBack) {
          if (isShowBack === void 0) {
            isShowBack = true;
          }
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          var bankerAddCard = cardsInfo.playerCards[2] ? this.cards[BaccaratCardIndex.Banker3] : this.cards[BaccaratCardIndex.Player3];
          //判断是否有闲补牌和庄补牌
          if (cardsInfo.bankerCards[2]) {
            tween(bankerAddCard.node).to(BaccaratConsts.showCardTime, {
              position: this.showPostions[1]
            }).call(function () {
              bankerAddCard.setCard(cardsInfo.bankerCards[2], isShowBack);
              bankerAddCard.node.angle = -90;
            }).start();
          }
        };
        _proto.fourFlopCards = function fourFlopCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo.bankerCards[2]) {
            var flopCard = cardsInfo.playerCards[2] ? this.cards[BaccaratCardIndex.Banker3] : this.cards[BaccaratCardIndex.Player3];
            flopCard.flopCard();
          }
        };
        _proto.showVerifyCards = function showVerifyCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          this.cards[BaccaratCardIndex.Player1].setCard(cardsInfo.playerCards[0], false);
          this.cards[BaccaratCardIndex.Player2].setCard(cardsInfo.playerCards[1], false);
          this.cards[BaccaratCardIndex.Banker1].setCard(cardsInfo.bankerCards[0], false);
          this.cards[BaccaratCardIndex.Banker2].setCard(cardsInfo.bankerCards[1], false);
          this.thirdShowCards(false);
          this.fourShowCards(false);
        };
        return BaccaratVerifyCardView;
      }(BaccaratTableCardView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccartAutoBetSettingNode.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BacaratAutoLogic.ts', './NumberFormatUtil.ts', './BaccaratEnum.ts', './PopupMgr.ts', './GlobalData.ts', './PlayerMgr.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Toggle, EditBox, Node, Component, BaccaratAutoLogic, NumberFormatUtil, BaccaratBetType, PopupMgr, TipMessage, PlayerMgr;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Toggle = module.Toggle;
      EditBox = module.EditBox;
      Node = module.Node;
      Component = module.Component;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaccaratBetType = module.BaccaratBetType;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TipMessage = module.TipMessage;
    }, function (module) {
      PlayerMgr = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9;
      cclegacy._RF.push({}, "7d664KFQJNOdpRMDLpYvY4E", "BaccartAutoBetSettingNode", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccartAutoBetSettingNode = exports('BaccartAutoBetSettingNode', (_dec = ccclass('BaccartAutoBetSettingNode'), _dec2 = property(Toggle), _dec3 = property(Toggle), _dec4 = property(EditBox), _dec5 = property(EditBox), _dec6 = property(EditBox), _dec7 = property(EditBox), _dec8 = property(Node), _dec9 = property(Node), _dec10 = property(Node), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(BaccartAutoBetSettingNode, _Component);
        function BaccartAutoBetSettingNode() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this._autoSettingView = null;
          _initializerDefineProperty(_this, "bankerBetToggle", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerBetToggle", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "betEditBox", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "roundEditBox", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopForWinEditBox", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopForLoseEditBox", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "startBtnNode", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopBtnNode", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "maskNode", _descriptor9, _assertThisInitialized(_this));
          _this._currentSetOpention = void 0;
          return _this;
        }
        var _proto = BaccartAutoBetSettingNode.prototype;
        _proto.init = function init(autoSettingView) {
          this._autoSettingView = autoSettingView;
        };
        _proto.onLoad = function onLoad() {
          this.initView();
        };
        _proto.onEnable = function onEnable() {
          this.setViewNodeStatus();
        };
        _proto.initView = function initView() {
          var autoBetStorage = BaccaratAutoLogic.ins.getAutoBetLocalStroge();
          this._currentSetOpention = autoBetStorage;
          var betType = autoBetStorage.betType;
          var betValue = autoBetStorage.betValue;
          var betRound = autoBetStorage.betRound;
          var stop4Win = autoBetStorage.stop4Win;
          var stop4Lose = autoBetStorage.stop4Lose;
          this.bankerBetToggle.isChecked = betType == BaccaratBetType.Banker;
          this.playerBetToggle.isChecked = betType == BaccaratBetType.Player;
          this.betEditBox.string = NumberFormatUtil.formatNumDistance(betValue);
          this.roundEditBox.string = NumberFormatUtil.formatNumDistance(betRound);
          this.stopForWinEditBox.string = NumberFormatUtil.formatNumDistance(stop4Win);
          this.stopForLoseEditBox.string = NumberFormatUtil.formatNumDistance(stop4Lose);
          //this.setViewNodeStatus();
        };

        _proto.setViewNodeStatus = function setViewNodeStatus() {
          var isAutoBet = this._autoSettingView.gameTable.tableModel.isAutoBet;
          this.maskNode.active = isAutoBet;
          this.startBtnNode.active = !isAutoBet;
          this.stopBtnNode.active = isAutoBet;
        };
        _proto.btnClicked = function btnClicked(_, data) {
          switch (data) {
            case 'start':
              this.startAutoBet();
              break;
            case 'stop':
              this.stopAutoBet();
              break;
            case 'rest':
              this.resetAutoBet();
              break;
          }
        };
        _proto.startAutoBet = function startAutoBet() {
          if (!PlayerMgr.instance.profile.autoBetStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Auto_Bet);
            return;
          }
          var betValue = this._currentSetOpention.betValue;
          var personLimits = this._autoSettingView.gameTable.tableModel.personLimits;
          if (betValue < personLimits[0]) {
            PopupMgr.instance.showToast(TipMessage.Bet_Value_Less_Min);
            return;
          }
          if (betValue > personLimits[1]) {
            PopupMgr.instance.showToast(TipMessage.Bet_Value_Over_Max);
            return;
          }
          var betRound = this._currentSetOpention.betRound;
          if (!(betRound > 0 && betRound <= 10000)) {
            PopupMgr.instance.showToast(TipMessage.Round_Value_Error);
            return;
          }
          this._autoSettingView.gameTable.tableModel.autoBetRound = betRound;
          this._autoSettingView.gameTable.tableModel.isAutoBet = true;
          this.setViewNodeStatus();
          this._autoSettingView.hide();
          PopupMgr.instance.showToast(TipMessage.Start_Auto_Bet);
          this._currentSetOpention.betType = this.bankerBetToggle.isChecked ? BaccaratBetType.Banker : BaccaratBetType.Player;
          BaccaratAutoLogic.ins.setAutoBetLocalStroge(this._currentSetOpention);
        };
        _proto.stopAutoBet = function stopAutoBet() {
          this._autoSettingView.gameTable.tableModel.isAutoBet = false;
          this.setViewNodeStatus();
        };
        _proto.resetAutoBet = function resetAutoBet() {
          BaccaratAutoLogic.ins.resetAutoBetLocalStroge();
          this._autoSettingView.gameTable.tableModel.isAutoBet = false;
          this.initView();
        };
        _proto.betEditBoxEnd = function betEditBoxEnd() {
          if (!this.betEditBox.string) {
            this.betEditBox.string = '0';
          }
          var betValue = parseInt(this.betEditBox.string);
          this._currentSetOpention.betValue = betValue;
          this.betEditBox.string = NumberFormatUtil.formatNumDistance(betValue);
        };
        _proto.roundEditBoxEnd = function roundEditBoxEnd() {
          if (!this.roundEditBox.string) {
            this.roundEditBox.string = '0';
          }
          var betRound = parseInt(this.roundEditBox.string);
          this._currentSetOpention.betRound = betRound;
          this.roundEditBox.string = NumberFormatUtil.formatNumDistance(betRound);
        };
        _proto.stopForWinEditBoxEnd = function stopForWinEditBoxEnd() {
          if (!this.stopForWinEditBox.string) {
            this.stopForWinEditBox.string = '0';
          }
          var stop4WinValue = parseInt(this.stopForWinEditBox.string);
          this._currentSetOpention.stop4Win = stop4WinValue;
          this.stopForWinEditBox.string = NumberFormatUtil.formatNumDistance(stop4WinValue);
        };
        _proto.stopForLoseEditBoxEnd = function stopForLoseEditBoxEnd() {
          if (!this.stopForLoseEditBox.string) {
            this.stopForLoseEditBox.string = '0';
          }
          var stop4LoseValue = parseInt(this.stopForLoseEditBox.string);
          this._currentSetOpention.stop4Lose = stop4LoseValue;
          this.stopForLoseEditBox.string = NumberFormatUtil.formatNumDistance(parseInt(this.stopForLoseEditBox.string));
        };
        return BaccartAutoBetSettingNode;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "bankerBetToggle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "playerBetToggle", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "betEditBox", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "roundEditBox", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "stopForWinEditBox", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "stopForLoseEditBox", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "startBtnNode", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "stopBtnNode", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "maskNode", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BaccartAutoSeekRoadSettingNode.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BacaratAutoLogic.ts', './NumberFormatUtil.ts', './BaccaratEnum.ts', './PopupMgr.ts', './GlobalData.ts', './BacaraCustomRoadLogic.ts', './PlayerMgr.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, Toggle, EditBox, Node, Component, BaccaratAutoLogic, NumberFormatUtil, BaccaratBetType, PopupMgr, TipMessage, BacaraCustomRoadLogic, PlayerMgr;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      Toggle = module.Toggle;
      EditBox = module.EditBox;
      Node = module.Node;
      Component = module.Component;
    }, function (module) {
      BaccaratAutoLogic = module.BaccaratAutoLogic;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      BaccaratBetType = module.BaccaratBetType;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      TipMessage = module.TipMessage;
    }, function (module) {
      BacaraCustomRoadLogic = module.BacaraCustomRoadLogic;
    }, function (module) {
      PlayerMgr = module.default;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9;
      cclegacy._RF.push({}, "e5d367/eWVAs585EvL25tPJ", "BaccartAutoSeekRoadSettingNode", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BaccartAutoSeekRoadSettingNode = exports('BaccartAutoSeekRoadSettingNode', (_dec = ccclass('BaccartAutoSeekRoadSettingNode'), _dec2 = property(Toggle), _dec3 = property(Toggle), _dec4 = property(EditBox), _dec5 = property(EditBox), _dec6 = property(EditBox), _dec7 = property(Node), _dec8 = property(Node), _dec9 = property(Node), _dec10 = property(Toggle), _dec(_class = (_class2 = /*#__PURE__*/function (_Component) {
        _inheritsLoose(BaccartAutoSeekRoadSettingNode, _Component);
        function BaccartAutoSeekRoadSettingNode() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _Component.call.apply(_Component, [this].concat(args)) || this;
          _this._autoSettingView = null;
          _initializerDefineProperty(_this, "bankerBetToggle", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerBetToggle", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "betEditBox", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopForWinEditBox", _descriptor4, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopForLoseEditBox", _descriptor5, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "startBtnNode", _descriptor6, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "stopBtnNode", _descriptor7, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "maskNode", _descriptor8, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "seekForTieToggle", _descriptor9, _assertThisInitialized(_this));
          _this._currentSetOpention = void 0;
          return _this;
        }
        var _proto = BaccartAutoSeekRoadSettingNode.prototype;
        _proto.init = function init(autoSettingView) {
          this._autoSettingView = autoSettingView;
        };
        _proto.onLoad = function onLoad() {
          this.initView();
        };
        _proto.onEnable = function onEnable() {
          this.setViewNodeStatus();
        };
        _proto.initView = function initView() {
          var autoBetStorage = BaccaratAutoLogic.ins.getAutoSeekRoadLocalStroge();
          this._currentSetOpention = autoBetStorage;
          var betType = autoBetStorage.betType;
          var betValue = autoBetStorage.betValue;
          var stop4Win = autoBetStorage.stop4Win;
          var stop4Lose = autoBetStorage.stop4Lose;
          this.bankerBetToggle.isChecked = betType == BaccaratBetType.Banker;
          this.playerBetToggle.isChecked = betType == BaccaratBetType.Player;
          this.betEditBox.string = NumberFormatUtil.formatNumDistance(betValue);
          this.stopForWinEditBox.string = NumberFormatUtil.formatNumDistance(stop4Win);
          this.stopForLoseEditBox.string = NumberFormatUtil.formatNumDistance(stop4Lose);
          this.seekForTieToggle.isChecked = autoBetStorage.seek4Tie;
          //this.setViewNodeStatus();
        };

        _proto.setViewNodeStatus = function setViewNodeStatus() {
          var isAutoSeekRoad = this._autoSettingView.gameTable.tableModel.isAutoSeekRoad;
          this.maskNode.active = isAutoSeekRoad;
          this.startBtnNode.active = !isAutoSeekRoad;
          this.stopBtnNode.active = isAutoSeekRoad;
        };
        _proto.btnClicked = function btnClicked(_, data) {
          switch (data) {
            case 'start':
              this.startAutoBet();
              break;
            case 'stop':
              this.stopAutoBet();
              break;
            case 'rest':
              this.resetAutoBet();
              break;
          }
        };
        _proto.startAutoBet = function startAutoBet() {
          if (!PlayerMgr.instance.profile.autoBetStatus) {
            PopupMgr.instance.showToast(TipMessage.Limit_Auto_Bet);
            return;
          }
          var isSetRoad = BacaraCustomRoadLogic.ins.getIsSetSeekRoadInfo();
          if (!isSetRoad) {
            PopupMgr.instance.showToast(TipMessage.Please_Set_Road);
            return;
          }
          var betValue = this._currentSetOpention.betValue;
          var personLimits = this._autoSettingView.gameTable.tableModel.personLimits;
          if (betValue < personLimits[0]) {
            PopupMgr.instance.showToast(TipMessage.Bet_Value_Less_Min);
            return;
          }
          if (betValue > personLimits[1]) {
            PopupMgr.instance.showToast(TipMessage.Bet_Value_Over_Max);
            return;
          }
          this._autoSettingView.gameTable.tableModel.isAutoSeekRoad = true;
          this.setViewNodeStatus();
          this._autoSettingView.hide();
          PopupMgr.instance.showToast(TipMessage.Star_Auto_Seek_Road);
          this._currentSetOpention.betType = this.bankerBetToggle.isChecked ? BaccaratBetType.Banker : BaccaratBetType.Player;
          this._currentSetOpention.seek4Tie = this.seekForTieToggle.isChecked;
          BaccaratAutoLogic.ins.setAutoSeekRoadLocalStroge(this._currentSetOpention);
        };
        _proto.stopAutoBet = function stopAutoBet() {
          this._autoSettingView.gameTable.tableModel.isAutoSeekRoad = false;
          this.setViewNodeStatus();
        };
        _proto.resetAutoBet = function resetAutoBet() {
          BaccaratAutoLogic.ins.resetAutoSeekRoadLocalStroge();
          this._autoSettingView.gameTable.tableModel.isAutoSeekRoad = false;
          this.initView();
        };
        _proto.betEditBoxEnd = function betEditBoxEnd() {
          if (!this.betEditBox.string) {
            this.betEditBox.string = '0';
          }
          var betValue = parseInt(this.betEditBox.string);
          this._currentSetOpention.betValue = betValue;
          this.betEditBox.string = NumberFormatUtil.formatNumDistance(betValue);
        };
        _proto.stopForWinEditBoxEnd = function stopForWinEditBoxEnd() {
          if (!this.stopForWinEditBox.string) {
            this.stopForWinEditBox.string = '0';
          }
          var stop4WinValue = parseInt(this.stopForWinEditBox.string);
          this._currentSetOpention.stop4Win = stop4WinValue;
          this.stopForWinEditBox.string = NumberFormatUtil.formatNumDistance(stop4WinValue);
        };
        _proto.stopForLoseEditBoxEnd = function stopForLoseEditBoxEnd() {
          if (!this.stopForLoseEditBox.string) {
            this.stopForLoseEditBox.string = '0';
          }
          var stop4LoseValue = parseInt(this.stopForLoseEditBox.string);
          this._currentSetOpention.stop4Lose = stop4LoseValue;
          this.stopForLoseEditBox.string = NumberFormatUtil.formatNumDistance(parseInt(this.stopForLoseEditBox.string));
        };
        return BaccartAutoSeekRoadSettingNode;
      }(Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "bankerBetToggle", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "playerBetToggle", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "betEditBox", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "stopForWinEditBox", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "stopForLoseEditBox", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "startBtnNode", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "stopBtnNode", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "maskNode", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "seekForTieToggle", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/baccaratBundle', 'chunks:///_virtual/baccaratBundle'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});