window.gameConfig = {
    WS_URL: "wss://bcg-demo.t9live.cc/ws.rd",
    PROTO_URL: "https://bcg-demo.t9live.cc/conf.rd/assets/cyber.games.bin",
    HTTP_URL: "https://bcg-demo.t9live.cc/bridge.rd.api/",
    IS_ACCESS: false,
    VERSION: "v08311735",
}