System.register("chunks:///_virtual/BacNiuniuSBettingState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "54079VMjXlCLJp7+csG3uXw", "BacNiuniuSBettingState", undefined);
      var BacNiuniuSBettingState = exports('BacNiuniuSBettingState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSBettingState, _BaseState);
        function BacNiuniuSBettingState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSBettingState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableMainGameView.showGameClock();
          this.gameTable.tableBetView.setAreaBtnsTouchStatus(true);
          this.gameTable.tableMainGameView.setBetNodeStatus(true);
          this.gameTable.tableMainGameView.refreshAllBtnsStatus();
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Please_Bet);
          AudioManager.playSound('Female/Female_StartBet');
        };
        _proto.exit = function exit() {
          this.gameTable.tableBetView.setAreaBtnsTouchStatus(false);
          this.gameTable.tableMainGameView.setBetNodeStatus(false);
          this.gameTable.tableMainGameView.cancleBetData();
          this.gameTable.tableMainGameView.hideGameClock();
        };
        return BacNiuniuSBettingState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/bacNiuniuSBundle", ['./BacNiuniuSBettingState.ts', './BacNiuniuSDealCardState.ts', './BacNiuniuSGame.ts', './BacNiuniuSGameTale.ts', './BacNiuniuSOpenCardState.ts', './BacNiuniuSPrepareState.ts', './BacNiuniuSTableController.ts', './BacNiuniuSTableReplayController.ts', './BacNiuniuSettleState.ts', './BacNiuniuStopBetState.ts', './BacNiuniuSEnum.ts', './BacNiuniuSTableModel.ts', './BacNiuniuSTableProxy.ts', './BacNiuniuSMainGameView.ts', './BacNiuniuSTableBetView.ts', './BacNiuniuSTableCardView.ts', './BacNiuniuSTableChipView.ts', './BacNiuniuSTableSettleView.ts', './BacNiuniuSTableTipView.ts', './BacNiuniuSVerifyCardView.ts'], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function () {}
  };
});

System.register("chunks:///_virtual/BacNiuniuSDealCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "58a92CJfs5Dq6ij7IATg72d", "BacNiuniuSDealCardState", undefined);
      var BacNiuniuSDealCardState = exports('BacNiuniuSDealCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSDealCardState, _BaseState);
        function BacNiuniuSDealCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSDealCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          //this.gameTable.getView(BaccaratTableTipView).showTipInfo(BaccaratStatusTip.Deal_Card);
          this.gameTable.tableVerifyCardView.disCards();
        };
        _proto.exit = function exit() {};
        return BacNiuniuSDealCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSEnum.ts", ['cc'], function (exports) {
  var cclegacy;
  return {
    setters: [function (module) {
      cclegacy = module.cclegacy;
    }],
    execute: function () {
      cclegacy._RF.push({}, "45565F8GnNAbY5aI1S5I0lk", "BacNiuniuSEnum", undefined);
      var BacNiuniuSCardIndex = exports('BacNiuniuSCardIndex', /*#__PURE__*/function (BacNiuniuSCardIndex) {
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Player1"] = 0] = "Player1";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Player2"] = 1] = "Player2";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Player3"] = 2] = "Player3";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Player4"] = 3] = "Player4";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Player5"] = 4] = "Player5";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Banker1"] = 5] = "Banker1";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Banker2"] = 6] = "Banker2";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Banker3"] = 7] = "Banker3";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Banker4"] = 8] = "Banker4";
        BacNiuniuSCardIndex[BacNiuniuSCardIndex["Banker5"] = 9] = "Banker5";
        return BacNiuniuSCardIndex;
      }({}));
      var BacNiuniuSCardTypes = exports('BacNiuniuSCardTypes', ["無牛", "牛1", "牛2", "牛3", "牛4", "牛5", "牛6", "牛7", "牛8", "牛9", "牛牛", "五公"]);
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSettleState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "9186anyKA9D1qbTvv085Ieo", "BacNiuniuSettleState", undefined);
      var BacNiuniuSSettleState = exports('BacNiuniuSSettleState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSSettleState, _BaseState);
        function BacNiuniuSSettleState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSSettleState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableSettleView.showResult();
          this.gameTable.tableBetView.showWinAreaLight();
        };
        _proto.exit = function exit() {};
        return BacNiuniuSSettleState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSGame.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGame.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseGame;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGame = module.BaseGame;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "e975cLcBjBHMKMVUJst2Eyu", "BacNiuniuSGame", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSGame = exports('BacNiuniuSGame', (_dec = ccclass('BacNiuniuSGame'), _dec(_class = /*#__PURE__*/function (_BaseGame) {
        _inheritsLoose(BacNiuniuSGame, _BaseGame);
        function BacNiuniuSGame() {
          return _BaseGame.apply(this, arguments) || this;
        }
        return BacNiuniuSGame;
      }(BaseGame)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSGameTale.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseGameTale.ts', './BaseTableReplayController.ts', './BacNiuniuSTableProxy.ts', './BacNiuniuSTableController.ts', './BacNiuniuSTableModel.ts', './BacNiuniuSBettingState.ts', './BacNiuniuSDealCardState.ts', './BacNiuniuSettleState.ts', './BacNiuniuSOpenCardState.ts', './BacNiuniuSPrepareState.ts', './BacNiuniuStopBetState.ts', './bc_niuniu_s.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BaseGameTale, BaseTableReplayController, BacNiuniuSTableProxy, BacNiuniuSTableController, BacNiuniuSTableModel, BacNiuniuSBettingState, BacNiuniuSDealCardState, BacNiuniuSSettleState, BacNiuniuSOpenCardState, BacNiuniuSPrepareState, BacNiuniuSStopBetState, Phase;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseGameTale = module.BaseGameTale;
    }, function (module) {
      BaseTableReplayController = module.BaseTableReplayController;
    }, function (module) {
      BacNiuniuSTableProxy = module.BacNiuniuSTableProxy;
    }, function (module) {
      BacNiuniuSTableController = module.BacNiuniuSTableController;
    }, function (module) {
      BacNiuniuSTableModel = module.BacNiuniuSTableModel;
    }, function (module) {
      BacNiuniuSBettingState = module.BacNiuniuSBettingState;
    }, function (module) {
      BacNiuniuSDealCardState = module.BacNiuniuSDealCardState;
    }, function (module) {
      BacNiuniuSSettleState = module.BacNiuniuSSettleState;
    }, function (module) {
      BacNiuniuSOpenCardState = module.BacNiuniuSOpenCardState;
    }, function (module) {
      BacNiuniuSPrepareState = module.BacNiuniuSPrepareState;
    }, function (module) {
      BacNiuniuSStopBetState = module.BacNiuniuSStopBetState;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;
      cclegacy._RF.push({}, "17088m9szFLe5C5NsCxcFQj", "BacNiuniuSGameTale", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSGameTale = exports('BacNiuniuSGameTale', (_dec = ccclass('BacNiuniuSGameTale'), _dec2 = property({
        type: BacNiuniuSTableProxy
      }), _dec3 = property({
        type: BaseTableReplayController
      }), _dec4 = property({
        type: BacNiuniuSTableController
      }), _dec5 = property({
        type: BacNiuniuSTableModel
      }), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseGameTale) {
        _inheritsLoose(BacNiuniuSGameTale, _BaseGameTale);
        function BacNiuniuSGameTale() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseGameTale.call.apply(_BaseGameTale, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "tableProxy", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableReplayController", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableController", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "tableModel", _descriptor4, _assertThisInitialized(_this));
          _this.states = [{
            stateCode: Phase.Prepare,
            state: new BacNiuniuSPrepareState()
          }, {
            stateCode: Phase.DealCards,
            state: new BacNiuniuSDealCardState()
          }, {
            stateCode: Phase.Betting,
            state: new BacNiuniuSBettingState()
          }, {
            stateCode: Phase.StopBet,
            state: new BacNiuniuSStopBetState()
          }, {
            stateCode: Phase.OpenCards,
            state: new BacNiuniuSOpenCardState()
          }, {
            stateCode: Phase.Settle,
            state: new BacNiuniuSSettleState()
          }];
          return _this;
        }
        var _proto = BacNiuniuSGameTale.prototype;
        _proto.onDestroy = function onDestroy() {
          this.tableAllCardVerifyInfoView.onDestroy();
          this.tableSingCardVerifyInfoView.onDestroy();
        };
        return BacNiuniuSGameTale;
      }(BaseGameTale), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "tableProxy", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tableReplayController", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "tableController", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "tableModel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSMainGameView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseMainGameView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseMainGameView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseMainGameView = module.BaseMainGameView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "66ed4QjLT9LMqdWaB5qS8p8", "BacNiuniuSMainGameView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSMainGameView = exports('BacNiuniuSMainGameView', (_dec = ccclass('BacNiuniuSMainGameView'), _dec(_class = /*#__PURE__*/function (_BaseMainGameView) {
        _inheritsLoose(BacNiuniuSMainGameView, _BaseMainGameView);
        function BacNiuniuSMainGameView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseMainGameView.call.apply(_BaseMainGameView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        return BacNiuniuSMainGameView;
      }(BaseMainGameView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSOpenCardState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "256eaqJADVNJqewpoUrK1vN", "BacNiuniuSOpenCardState", undefined);
      var BacNiuniuSOpenCardState = exports('BacNiuniuSOpenCardState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSOpenCardState, _BaseState);
        function BacNiuniuSOpenCardState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSOpenCardState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Deal_Card);
          if (!isConnectAgain) {
            this.gameTable.tableCardView.startOpenCard();
            this.gameTable.tableVerifyCardView.startOpenCard();
          }
        };
        _proto.exit = function exit() {
          this.gameTable.tableTipView.hideTip();
        };
        return BacNiuniuSOpenCardState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSPrepareState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }],
    execute: function () {
      cclegacy._RF.push({}, "c63552LvNNOvaDkvarAhFiw", "BacNiuniuSPrepareState", undefined);
      var BacNiuniuSPrepareState = exports('BacNiuniuSPrepareState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSPrepareState, _BaseState);
        function BacNiuniuSPrepareState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSPrepareState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableModel.initData();
          this.gameTable.initView();
        };
        _proto.exit = function exit() {};
        return BacNiuniuSPrepareState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableBetView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableBetView.ts', './BetPercentItem.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, BaseTableBetView, BetPercentItem;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableBetView = module.BaseTableBetView;
    }, function (module) {
      BetPercentItem = module.BetPercentItem;
    }],
    execute: function () {
      var _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;
      cclegacy._RF.push({}, "060455BHhxN0Yyvfn0ZuIfr", "BacNiuniuSTableBetView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableBetView = exports('BacNiuniuSTableBetView', (_dec = ccclass('BacNiuniuSTableBetView'), _dec2 = property(BetPercentItem), _dec3 = property(BetPercentItem), _dec4 = property(BetPercentItem), _dec5 = property(BetPercentItem), _dec(_class = (_class2 = /*#__PURE__*/function (_BaseTableBetView) {
        _inheritsLoose(BacNiuniuSTableBetView, _BaseTableBetView);
        function BacNiuniuSTableBetView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableBetView.call.apply(_BaseTableBetView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          _initializerDefineProperty(_this, "bankerBetPairPercentItem", _descriptor, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerBetPairPercentItem", _descriptor2, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "bankerBetSuperPercentItem", _descriptor3, _assertThisInitialized(_this));
          _initializerDefineProperty(_this, "playerBetSuperPercentItem", _descriptor4, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = BacNiuniuSTableBetView.prototype;
        _proto.initView = function initView() {
          _BaseTableBetView.prototype.initView.call(this);
          this.bankerBetPairPercentItem.showBetPercentInfo({
            betNum: '0',
            betPercent: 0,
            betPerosnNum: 0
          });
          this.playerBetPairPercentItem.showBetPercentInfo({
            betNum: '0',
            betPercent: 0,
            betPerosnNum: 0
          });
          this.bankerBetSuperPercentItem.showBetPercentInfo({
            betNum: '0',
            betPercent: 0,
            betPerosnNum: 0
          });
          this.playerBetSuperPercentItem.showBetPercentInfo({
            betNum: '0',
            betPercent: 0,
            betPerosnNum: 0
          });
        };
        _proto.bettingDecisions = function bettingDecisions(touchAreaIndex) {
          return true;
        };
        _proto.refreshNoFreeShow = function refreshNoFreeShow() {};
        _proto.refreshAreaOdds = function refreshAreaOdds() {
          //刷新区域赔率
          var odds = this.gameTable.tableModel.tableConfig.odds;
          for (var i = 0; i < this.oddsLabel.length; i++) {
            if (this.oddsLabel[i]) {
              this.oddsLabel[i].string = "1:" + odds[i];
            }
          }
        };
        _proto.refreshBankerAndPlayerBetStatistic = function refreshBankerAndPlayerBetStatistic(betStatInfo) {
          if (betStatInfo) {
            this.setBetPercentItemInfo(this.bankerPercentItem, betStatInfo.normalBanker);
            this.setBetPercentItemInfo(this.playerPercentItem, betStatInfo.normalPlayer);
            this.setBetPercentItemInfo(this.bankerBetPairPercentItem, betStatInfo.doubleBanker);
            this.setBetPercentItemInfo(this.playerBetPairPercentItem, betStatInfo.doublePlayer);
            this.setBetPercentItemInfo(this.bankerBetSuperPercentItem, betStatInfo.superBanker);
            this.setBetPercentItemInfo(this.playerBetSuperPercentItem, betStatInfo.superPlayer);
          }
        };
        _proto.setBetPercentItemInfo = function setBetPercentItemInfo(betPercentItem, betStatUnit) {
          betPercentItem.showBetPercentInfo({
            betNum: betStatUnit == null ? void 0 : betStatUnit.totalBet,
            betPercent: betStatUnit == null ? void 0 : betStatUnit.percent,
            betPerosnNum: betStatUnit == null ? void 0 : betStatUnit.count
          });
        };
        return BacNiuniuSTableBetView;
      }(BaseTableBetView), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "bankerBetPairPercentItem", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "playerBetPairPercentItem", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "bankerBetSuperPercentItem", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "playerBetSuperPercentItem", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableCardView.ts', './Emitter.ts', './GlobalData.ts', './BaccaratData.ts', './BacNiuniuSEnum.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, tween, BaseTableCardView, Emitter, GlobalEvent, BaccaratConsts, BacNiuniuSCardTypes;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
      tween = module.tween;
    }, function (module) {
      BaseTableCardView = module.BaseTableCardView;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }, function (module) {
      BaccaratConsts = module.BaccaratConsts;
    }, function (module) {
      BacNiuniuSCardTypes = module.BacNiuniuSCardTypes;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "55063pK+xNNkZfpgE2+MvQc", "BacNiuniuSTableCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableCardView = exports('BacNiuniuSTableCardView', (_dec = ccclass('BacNiuniuSTableCardView'), _dec(_class = /*#__PURE__*/function (_BaseTableCardView) {
        _inheritsLoose(BacNiuniuSTableCardView, _BaseTableCardView);
        function BacNiuniuSTableCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableCardView.call.apply(_BaseTableCardView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuSTableCardView.prototype;
        _proto.disCards = function disCards() {};
        _proto.startOpenCard = function startOpenCard() {
          var _this2 = this;
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo) {
            var playerCardsInfo = cardsInfo.playerCards;
            var bankerCardsInfo = cardsInfo.bankerCards;
            var cardTween = tween(this.node);
            this.show();
            var _loop = function _loop() {
              var playerIndex = i;
              var bankerIndex = i + 5;
              var playerCardInfo = playerCardsInfo[i];
              var bankerCardInfo = bankerCardsInfo[i];
              cardTween.call(function () {
                _this2.showCards([playerIndex], [playerCardInfo]);
                _this2.showCards([bankerIndex], [bankerCardInfo]);
                Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, [playerCardInfo, bankerCardInfo]);
              }).delay(BaccaratConsts.showCardTime).call(function () {
                _this2.flopCards([playerIndex]);
                _this2.flopCards([bankerIndex]);
              }).delay(BaccaratConsts.flopCardTime);
            };
            for (var i = 0; i < 5; i++) {
              _loop();
            }
            cardTween.call(function () {
              _this2.showPoint(cardsInfo.playerType, cardsInfo.bankerType, false, false);
              _this2.showPoint(cardsInfo.playerType, cardsInfo.bankerType, true, false);
            }).start();
          }
        };
        _proto.showPoint = function showPoint(playerPoint, bankerPoint, isPlayer, playSound) {
          if (playSound === void 0) {
            playSound = true;
          }
          if (this.playerPointLabel && isPlayer) {
            this.playerPointLabel.node.active = true;
            this.playerPointLabel.string = BacNiuniuSCardTypes[playerPoint];
            if (playSound) {
              //AudioManager.playSound(`Female/Female_Player`);
              this.scheduleOnce(function () {
                //AudioManager.playSound(`Female/Female_Point_${playerPoint}`);
              }, 0.8);
            }
          }
          if (this.bankerPointLabel && !isPlayer) {
            this.bankerPointLabel.node.active = true;
            this.bankerPointLabel.string = BacNiuniuSCardTypes[bankerPoint];
            if (playSound) {
              //AudioManager.playSound(`Female/Female_Banker`);
              this.scheduleOnce(function () {
                //AudioManager.playSound(`Female/Female_Point_${bankerPoint}`);
              }, 0.8);
            }
          }
        };
        _proto.showCards = function showCards(cardIndexs, cardsInfos) {
          var _this3 = this;
          if (cardIndexs.length > 0 && cardsInfos.length > 0 && cardIndexs.length === cardsInfos.length) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this3.cards[index];
              if (card && cardsInfos[cardIndex]) {
                card.setCard(cardsInfos[cardIndex], true);
              }
            });
          }
        };
        _proto.flopCards = function flopCards(cardIndexs) {
          var _this4 = this;
          if (cardIndexs.length > 0) {
            cardIndexs.forEach(function (index, cardIndex) {
              var card = _this4.cards[index];
              if (card && card.node.active) {
                card.flopCard();
              }
            });
          }
        };
        _proto.hideCards = function hideCards() {
          this.cards.forEach(function (card) {
            card.node.active = false;
          });
        };
        _proto.showAllCards = function showAllCards() {
          var cardsInfo = this.gameTable.tableModel.cardsInfo;
          if (cardsInfo) {
            this.show();
            var bankerCardsInfo = cardsInfo.bankerCards;
            var playerCardsInfo = cardsInfo.playerCards;
            var bankerCards = this.cards.slice(0, 5);
            var playerCards = this.cards.slice(5, 10);
            bankerCards.forEach(function (card, index) {
              if (bankerCardsInfo[index]) {
                card.setCard(bankerCardsInfo[index]);
              }
            });
            playerCards.forEach(function (card, index) {
              if (playerCardsInfo[index]) {
                card.setCard(playerCardsInfo[index]);
              }
            });
            this.showPoint(cardsInfo.playerType, cardsInfo.bankerType, false, false);
            this.showPoint(cardsInfo.playerType, cardsInfo.bankerType, true, false);
          }
        };
        return BacNiuniuSTableCardView;
      }(BaseTableCardView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableChipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableChipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableChipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableChipView = module.BaseTableChipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "4de77OJXZVEvJ5l5DMXTuCA", "BacNiuniuSTableChipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableChipView = exports('BacNiuniuSTableChipView', (_dec = ccclass('BacNiuniuTableChipView'), _dec(_class = /*#__PURE__*/function (_BaseTableChipView) {
        _inheritsLoose(BacNiuniuSTableChipView, _BaseTableChipView);
        function BacNiuniuSTableChipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableChipView.call.apply(_BaseTableChipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuSTableChipView.prototype;
        _proto.initView = function initView() {};
        _proto.updateView = function updateView() {
          this.refreshCoinValue();
        };
        return BacNiuniuSTableChipView;
      }(BaseTableChipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableController.ts', './PlayerMgr.ts', './NumberFormatUtil.ts', './bc_niuniu_s.ts', './PopupMgr.ts', './GlobalData.ts', './Logger.ts'], function (exports) {
  var _inheritsLoose, _asyncToGenerator, _regeneratorRuntime, cclegacy, _decorator, BaseTableController, PlayerMgr, NumberFormatUtil, Phase, PopupMgr, BacNiuniuSBetTypeName, ErrorCodeTip, Logger;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _asyncToGenerator = module.asyncToGenerator;
      _regeneratorRuntime = module.regeneratorRuntime;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableController = module.BaseTableController;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      Phase = module.Phase;
    }, function (module) {
      PopupMgr = module.PopupMgr;
    }, function (module) {
      BacNiuniuSBetTypeName = module.BacNiuniuSBetTypeName;
      ErrorCodeTip = module.ErrorCodeTip;
    }, function (module) {
      Logger = module.Logger;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "4d586gD+yhDlI/lJOfE5oos", "BacNiuniuSTableController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableController = exports('BacNiuniuSTableController', (_dec = ccclass('BacNiuniuSTableController'), _dec(_class = /*#__PURE__*/function (_BaseTableController) {
        _inheritsLoose(BacNiuniuSTableController, _BaseTableController);
        function BacNiuniuSTableController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableController.call.apply(_BaseTableController, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuSTableController.prototype;
        _proto.onGamePrepare = function onGamePrepare(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Prepare);
          //刷新roundId
          this.gameTable.tableMainGameView.refreshRoundId(data.roundId);
          //判断是否清空牌靴
          if (data.isShoeCleared) {
            this.gameTable.tableModel.openedCards = [];
            this.gameTable.tableModel.unOpenedCards = data.hashedCards;
            this.gameTable.tableAllCardVerifyInfoView.resetAllCards();
          }
          if (data.isRoadsCleared) {
            this.gameTable.tableModel.roadInfos = [];
          }
        };
        _proto.setGameTableShow = function setGameTableShow(tableData) {
          if (tableData.table.headCard) {
            this.gameTable.tableModel.headCard = tableData.table.headCard;
          }
          _BaseTableController.prototype.setGameTableShow.call(this, tableData);
        };
        _proto.onGameDealCards = function onGameDealCards(data) {
          this.gameTable.tableModel.dealCardsInfo = data.dealtCards;
          this.gameTable.tableModel.headCard = data.headCard;
          this.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
        };
        _proto.onGameBet = function onGameBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.Betting);
        };
        _proto.onGameStopBet = function onGameStopBet(data) {
          this.gameTable.stateMachineManager.transitionTo(Phase.StopBet);
        };
        _proto.onGameOpenCards = function onGameOpenCards(data) {
          var openCards = data.cardsInfo;
          openCards.playerCards.sort(function (a, b) {
            return a.index - b.index;
          });
          openCards.bankerCards.sort(function (a, b) {
            return a.index - b.index;
          });
          this.gameTable.tableModel.cardsInfo = openCards;
          this.gameTable.tableModel.refreshAllCardsOpenStatus(data.cardsInfo);
          this.gameTable.stateMachineManager.transitionTo(Phase.OpenCards);
        };
        _proto.onGameSettlement = function onGameSettlement(data) {
          this.gameTable.tableModel.settleData = data.roadInfos[data.roadInfos.length - 1];
          this.gameTable.stateMachineManager.transitionTo(Phase.Settle);
          this.gameTable.tableModel.roadInfos = data.roadInfos;
        };
        _proto.onGameBetPush = function onGameBetPush(data) {
          this.gameTable.tableBetView.refreshBankerAndPlayerBetStatistic(data.betStatInfo);
        };
        _proto.onGamePlayerSettlement = function onGamePlayerSettlement(data) {
          this.gameTable.tableModel.playerSettlementSummary = data;
          PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(data.coin);
          this.gameTable.tableModel.refreshTableCoin();
        };
        _proto.showBetError = function showBetError(type, errorMsg) {
          PopupMgr.instance.showToast(BacNiuniuSBetTypeName[type] + "\u4E0B\u6CE8\u5931\u6557:" + errorMsg);
        };
        _proto.isSettlePhase = function isSettlePhase(phase) {
          return phase === Phase.Settle;
        };
        _proto.requestBet = /*#__PURE__*/function () {
          var _requestBet = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(betRequest) {
            var _this2 = this;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return this.gameTable.tableProxy.sendGameBetRequest(betRequest).then(function (betResponse) {
                    _this2.gameTable.tableModel.preBetData = [];
                    var successBetInfos = betResponse.successDetails;
                    //成功下注
                    for (var i = 0; i < successBetInfos.length; i++) {
                      var betDetail = successBetInfos[i].detail;
                      _this2.gameTable.tableModel.addBet(false, betDetail);
                      _this2.gameTable.tableBetView.refreshAreaBetChip(betDetail.type);
                    }
                    var failedDetails = betResponse.failedResults;
                    //失败下注 提示 退回筹码
                    var _loop = function _loop(_i) {
                      Logger.errNet('下注失败:', failedDetails[_i].code);
                      _this2.gameTable.tableBetView.refreshAreaBetChip(failedDetails[_i].detail.type);
                      _this2.scheduleOnce(function () {
                        var errorMsg = ErrorCodeTip[failedDetails[_i].code] || "未知";
                        _this2.showBetError(failedDetails[_i].detail.type, errorMsg);
                      }, 0.5 * _i);
                    };
                    for (var _i = 0; _i < failedDetails.length; _i++) {
                      _loop(_i);
                    }
                    PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(betResponse.coin);
                    _this2.gameTable.tableMainGameView.refreshBetOpreateStatus();
                  });
                case 2:
                case "end":
                  return _context.stop();
              }
            }, _callee, this);
          }));
          function requestBet(_x) {
            return _requestBet.apply(this, arguments);
          }
          return requestBet;
        }();
        return BacNiuniuSTableController;
      }(BaseTableController)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableModel.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableModel.ts', './bc_niuniu_s.ts'], function (exports) {
  var _inheritsLoose, _createClass, cclegacy, _decorator, BaseTableModel, Phase;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
      _createClass = module.createClass;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableModel = module.BaseTableModel;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "dbfa3SRjmhO3ogj1ZV1PwPo", "BacNiuniuSTableModel", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableModel = exports('BacNiuniuSTableModel', (_dec = ccclass('BacNiuniuSTableModel'), _dec(_class = /*#__PURE__*/function (_BaseTableModel) {
        _inheritsLoose(BacNiuniuSTableModel, _BaseTableModel);
        function BacNiuniuSTableModel() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableModel.call.apply(_BaseTableModel, [this].concat(args)) || this;
          _this.gameTable = void 0;
          /**头牌 */
          _this._headCard = null;
          return _this;
        }
        var _proto = BacNiuniuSTableModel.prototype;
        _proto.getCardsPoint = function getCardsPoint(cards) {
          var point = 0;
          for (var i = 0; i < cards.length; i++) {
            var card = cards[i];
            var value = Number(card.value);
            if (value >= 10) {
              point += 10;
            } else {
              point += value;
            }
          }
          point = point % 10;
          return point;
        };
        _proto.openHeadAndRefreshAllCardsData = function openHeadAndRefreshAllCardsData() {
          this.refreshAllCardsData(this.openedCards, this.unOpenedCards, [this.headCard]);
        };
        _createClass(BacNiuniuSTableModel, [{
          key: "isCanBet",
          get: function get() {
            return this.gameTable.stateMachineManager.getCurrentState().statCode === Phase.Betting;
          }
        }, {
          key: "headCard",
          get: function get() {
            return this._headCard;
          },
          set: function set(value) {
            this._headCard = value;
            this.openHeadAndRefreshAllCardsData();
          }
        }]);
        return BacNiuniuSTableModel;
      }(BaseTableModel)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableProxy.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableProxy.ts', './ClientEnum.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableProxy, GameName;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableProxy = module.BaseTableProxy;
    }, function (module) {
      GameName = module.GameName;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "6f186p+Ej9EOoti41xAMuvA", "BacNiuniuSTableProxy", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableProxy = exports('BacNiuniuSTableProxy', (_dec = ccclass('BacNiuniuSTableProxy'), _dec(_class = /*#__PURE__*/function (_BaseTableProxy) {
        _inheritsLoose(BacNiuniuSTableProxy, _BaseTableProxy);
        function BacNiuniuSTableProxy() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableProxy.call.apply(_BaseTableProxy, [this].concat(args)) || this;
          _this.gameName = GameName.Bc_Niuniu_S;
          _this.gameTable = void 0;
          return _this;
        }
        return BacNiuniuSTableProxy;
      }(BaseTableProxy)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableReplayController.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableReplayController.ts', './GameModel.ts', './GlobalData.ts', './PlayerMgr.ts', './Emitter.ts', './NumberFormatUtil.ts', './BaccaratData.ts', './AudioManager.ts', './bc_niuniu_s.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableReplayController, GameModel, GlobalEvent, PlayerMgr, Emitter, NumberFormatUtil, ReplayConstsData, AudioManager, Phase;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableReplayController = module.BaseTableReplayController;
    }, function (module) {
      GameModel = module.GameModel;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }, function (module) {
      PlayerMgr = module.default;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      NumberFormatUtil = module.NumberFormatUtil;
    }, function (module) {
      ReplayConstsData = module.ReplayConstsData;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      Phase = module.Phase;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "e2fe0Mp5ThJYbq4Z7riPWep", "BacNiuniuSTableReplayController", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSTableReplayController = exports('BacNiuniuSTableReplayController', (_dec = ccclass('BacNiuniuSTableReplayController'), _dec(_class = /*#__PURE__*/function (_BaseTableReplayContr) {
        _inheritsLoose(BacNiuniuSTableReplayController, _BaseTableReplayContr);
        function BacNiuniuSTableReplayController() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableReplayContr.call.apply(_BaseTableReplayContr, [this].concat(args)) || this;
          _this.gameTable = null;
          return _this;
        }
        var _proto = BacNiuniuSTableReplayController.prototype;
        _proto.setReplayData = function setReplayData() {
          var replayData = GameModel.ins.replayData;
          var detail = replayData.detail;
          PlayerMgr.instance.id = replayData.playerId;
          this.gameTable.tableReplayView.show();
          this.gameTable.tableMainGameView.hideLoadNode();
          var profile = detail.profileMap[PlayerMgr.instance.id];
          if (profile) {
            PlayerMgr.instance.profile = profile;
            var betLimits = PlayerMgr.instance.profile.betLimits;
            this.gameTable.tableModel.personLimits = [NumberFormatUtil.formatMoneyToNumber(betLimits[0]), NumberFormatUtil.formatMoneyToNumber(betLimits[1])];
          }
          var config = replayData.config;
          this.gameTable.tableModel.tableInfo = {
            /** 桌 ID */
            id: replayData.tableId,
            /** 桌名 */
            name: replayData.tableName,
            /** 局 ID */
            roundId: replayData.roundId,
            /** 游戏阶段 */
            phase: 0,
            /** 当前阶段剩余时长信息 */
            durationInfo: null,
            /** 当前玩家在本局的下注信息 */
            betInfos: [],
            /** 当前局的庄闲下注统计信息 */
            betStatInfo: null,
            /** 当前牌靴的明牌信息 */
            openedCards: [],
            /** 当前牌靴的非明牌信息 */
            hashedCards: [],
            /** 当前牌靴的路单信息 */
            roadInfos: [],
            /** 历史聊天信息 */
            historyMessages: [],
            /** 发出的暗牌，< 开牌阶段时都会包含这个字段 */

            /** 玩家的结算结果 */
            settlementSummary: null,
            /** 桌配置 */
            config: config,
            onlinePlayers: 0,
            broadcastInfo: null
          };
          this.gameTable.tableModel.tableConfig = config;
        };
        _proto.setTableInfoShow = function setTableInfoShow() {
          var _detail$settleInfo, _detail$settleInfo2;
          var detail = GameModel.ins.replayData.detail;
          var playerSettleInfo = detail.settleMap[PlayerMgr.instance.id];
          var playCoinInfo = detail.initCoinMap[PlayerMgr.instance.id];
          if (playCoinInfo) {
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playCoinInfo);
            this.gameTable.tableModel.refreshTableCoin();
          }
          this.gameTable.tableModel.cardsInfo = detail.openCardsInfo;

          //关闭视频
          Emitter.emit(GlobalEvent.EVENT_GAME_CLOSE_VIDEO);
          //显示牌桌信息
          this.gameTable.tableMainGameView.refreshRoomInfo();
          //刷新筹码显示
          this.gameTable.tableChipView.refreshCoinValue();
          //显示各区域赔率
          this.gameTable.tableBetView.refreshAreaOdds();

          //刷新起始路单
          this.gameTable.tableModel.roadInfos = (_detail$settleInfo = detail.settleInfo) == null ? void 0 : _detail$settleInfo.roadInfos.slice(0, ((_detail$settleInfo2 = detail.settleInfo) == null ? void 0 : _detail$settleInfo2.roadInfos.length) - 1);
        };
        _proto.setReplayProcess = function setReplayProcess() {
          var _this2 = this;
          var replayData = GameModel.ins.replayData;
          var detail = replayData.detail;
          var playerSettleInfo = detail.settleMap[PlayerMgr.instance.id];
          var processTimes = ReplayConstsData.showTableInfoTime;
          // 发牌
          this.scheduleOnce(function () {
            _this2.processForDisCards(detail);
          }, processTimes);
          processTimes += ReplayConstsData.discardTime;
          // 下注
          if (playerSettleInfo) {
            AudioManager.playSound('Female/Female_StartBet');
            this.scheduleOnce(function () {
              var settlementInfos = playerSettleInfo.settlementInfos;
              _this2.processForBetting(settlementInfos, replayData);
            }, processTimes);
            processTimes += ReplayConstsData.betTime;
          }
          //开牌
          this.scheduleOnce(function () {
            _this2.processForOpenCard();
          }, processTimes);
          processTimes += ReplayConstsData.openCardTime;
          //结算
          this.scheduleOnce(function () {
            _this2.processForSettle(playerSettleInfo, detail);
          }, processTimes);
        };
        _proto.processForDisCards = function processForDisCards(detail) {
          this.gameTable.tableModel.dealCardsInfo = detail.dealCardsInfo.dealtCards;
          this.gameTable.tableModel.headCard = detail.dealCardsInfo.headCard;
          this.gameTable.stateMachineManager.transitionTo(Phase.DealCards);
        };
        _proto.processForBetting = function processForBetting(settlementInfos, replayData) {
          var _replayData$detail$be;
          for (var i = 0; i < settlementInfos.length; i++) {
            this.gameTable.tableModel.addBet(false, {
              type: settlementInfos[i].betType,
              bet: settlementInfos[i].bet
            });
            this.gameTable.tableBetView.refreshAreaBetChip(settlementInfos[i].betType);
          }
          //刷新庄闲下注信息
          var statInfo = (_replayData$detail$be = replayData.detail.bettingInfo) == null || (_replayData$detail$be = _replayData$detail$be.statInfoMap) == null ? void 0 : _replayData$detail$be[replayData.currency];
          if (statInfo) {
            this.gameTable.tableModel.tableInfo.betStatInfo = statInfo;
            this.gameTable.tableBetView.refreshBankerAndPlayerBetStatistic(statInfo);
          }
          this.gameTable.tableModel.refreshTableBetCoin();
          PlayerMgr.instance.coin -= this.gameTable.tableModel.getTotalBetNum();
          //刷新玩家金币
          this.gameTable.tableModel.refreshTableCoin();
        };
        _proto.processForOpenCard = function processForOpenCard() {
          this.gameTable.tableCardView.startOpenCard();
          this.gameTable.tableVerifyCardView.startOpenCard();
        };
        _proto.processForSettle = function processForSettle(playerSettleInfo, detail) {
          var _detail$settleInfo3, _detail$settleInfo4, _detail$settleInfo5;
          this.gameTable.tableModel.playerSettlementSummary = playerSettleInfo;
          this.gameTable.tableModel.settleData = (_detail$settleInfo3 = detail.settleInfo) == null ? void 0 : _detail$settleInfo3.roadInfos[((_detail$settleInfo4 = detail.settleInfo) == null ? void 0 : _detail$settleInfo4.roadInfos.length) - 1];
          this.gameTable.tableSettleView.showResult();
          this.gameTable.tableBetView.showWinAreaLight();
          if (playerSettleInfo) {
            this.gameTable.tableSettleView.showSelfResult();
            //刷新玩家金币
            PlayerMgr.instance.coin = NumberFormatUtil.formatMoneyToNumber(playerSettleInfo.coin);
            this.gameTable.tableModel.refreshTableCoin();
          }
          //刷新路单
          this.gameTable.tableModel.roadInfos = (_detail$settleInfo5 = detail.settleInfo) == null ? void 0 : _detail$settleInfo5.roadInfos;
          this.gameTable.tableRoadMapView.refreshRoadMap(this.gameTable.tableModel.roadInfos);
        };
        return BacNiuniuSTableReplayController;
      }(BaseTableReplayController)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableSettleView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableSettleView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableSettleView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableSettleView = module.BaseTableSettleView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "339bfOqlrJK9pI2QM5XR0Xi", "BacNiuniuSTableSettleView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuTableSettleView = exports('BacNiuniuTableSettleView', (_dec = ccclass('BacNiuniuSTableSettleView'), _dec(_class = /*#__PURE__*/function (_BaseTableSettleView) {
        _inheritsLoose(BacNiuniuTableSettleView, _BaseTableSettleView);
        function BacNiuniuTableSettleView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableSettleView.call.apply(_BaseTableSettleView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        return BacNiuniuTableSettleView;
      }(BaseTableSettleView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSTableTipView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseTableTipView.ts'], function (exports) {
  var _inheritsLoose, cclegacy, _decorator, BaseTableTipView;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      BaseTableTipView = module.BaseTableTipView;
    }],
    execute: function () {
      var _dec, _class;
      cclegacy._RF.push({}, "898feF3zfxAxKgQ2iy2KwUi", "BacNiuniuSTableTipView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuTableTipView = exports('BacNiuniuTableTipView', (_dec = ccclass('BacNiuniuSTableTipView'), _dec(_class = /*#__PURE__*/function (_BaseTableTipView) {
        _inheritsLoose(BacNiuniuTableTipView, _BaseTableTipView);
        function BacNiuniuTableTipView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BaseTableTipView.call.apply(_BaseTableTipView, [this].concat(args)) || this;
          _this.gameTable = void 0;
          return _this;
        }
        var _proto = BacNiuniuTableTipView.prototype;
        _proto.updateView = function updateView() {};
        return BacNiuniuTableTipView;
      }(BaseTableTipView)) || _class));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuStopBetState.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './BaseState.ts', './AudioManager.ts', './BaccaratData.ts'], function (exports) {
  var _inheritsLoose, cclegacy, BaseState, AudioManager, BaccaratStatusTip;
  return {
    setters: [function (module) {
      _inheritsLoose = module.inheritsLoose;
    }, function (module) {
      cclegacy = module.cclegacy;
    }, function (module) {
      BaseState = module.BaseState;
    }, function (module) {
      AudioManager = module.AudioManager;
    }, function (module) {
      BaccaratStatusTip = module.BaccaratStatusTip;
    }],
    execute: function () {
      cclegacy._RF.push({}, "cb770zyXDFPv5tZx/GvfsyY", "BacNiuniuStopBetState", undefined);
      var BacNiuniuSStopBetState = exports('BacNiuniuSStopBetState', /*#__PURE__*/function (_BaseState) {
        _inheritsLoose(BacNiuniuSStopBetState, _BaseState);
        function BacNiuniuSStopBetState() {
          return _BaseState.apply(this, arguments) || this;
        }
        var _proto = BacNiuniuSStopBetState.prototype;
        _proto.enter = function enter(isConnectAgain) {
          this.gameTable.tableTipView.showTipInfo(BaccaratStatusTip.Stop_Bet);
          AudioManager.playSound('Female/Female_EndBet');
        };
        _proto.exit = function exit() {};
        return BacNiuniuSStopBetState;
      }(BaseState));
      cclegacy._RF.pop();
    }
  };
});

System.register("chunks:///_virtual/BacNiuniuSVerifyCardView.ts", ['./rollupPluginModLoBabelHelpers.js', 'cc', './VerifyCardItem.ts', './BacNiuniuSTableCardView.ts', './BaccaratData.ts', './Emitter.ts', './GlobalData.ts'], function (exports) {
  var _applyDecoratedDescriptor, _inheritsLoose, _initializerDefineProperty, _assertThisInitialized, cclegacy, _decorator, VerifyCardItem, BacNiuniuSTableCardView, BaccaratConsts, Emitter, GlobalEvent;
  return {
    setters: [function (module) {
      _applyDecoratedDescriptor = module.applyDecoratedDescriptor;
      _inheritsLoose = module.inheritsLoose;
      _initializerDefineProperty = module.initializerDefineProperty;
      _assertThisInitialized = module.assertThisInitialized;
    }, function (module) {
      cclegacy = module.cclegacy;
      _decorator = module._decorator;
    }, function (module) {
      VerifyCardItem = module.VerifyCardItem;
    }, function (module) {
      BacNiuniuSTableCardView = module.BacNiuniuSTableCardView;
    }, function (module) {
      BaccaratConsts = module.BaccaratConsts;
    }, function (module) {
      Emitter = module.Emitter;
    }, function (module) {
      GlobalEvent = module.GlobalEvent;
    }],
    execute: function () {
      var _dec, _dec2, _class, _class2, _descriptor;
      cclegacy._RF.push({}, "e9222YnqkBFpoK7vm4RNfHI", "BacNiuniuSVerifyCardView", undefined);
      var ccclass = _decorator.ccclass,
        property = _decorator.property;
      var BacNiuniuSVerifyCardView = exports('BacNiuniuSVerifyCardView', (_dec = ccclass('BacNiuniuVerifyCardView'), _dec2 = property(VerifyCardItem), _dec(_class = (_class2 = /*#__PURE__*/function (_BacNiuniuSTableCardV) {
        _inheritsLoose(BacNiuniuSVerifyCardView, _BacNiuniuSTableCardV);
        function BacNiuniuSVerifyCardView() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _BacNiuniuSTableCardV.call.apply(_BacNiuniuSTableCardV, [this].concat(args)) || this;
          _initializerDefineProperty(_this, "headCardItem", _descriptor, _assertThisInitialized(_this));
          return _this;
        }
        var _proto = BacNiuniuSVerifyCardView.prototype;
        _proto.updateView = function updateView() {
          if (this.gameTable.tableModel.dealCardsInfo) {
            this.disCards();
          }
          if (this.gameTable.tableModel.cardsInfo) {
            this.showVerifyCards();
          }
        };
        _proto.disCards = function disCards() {
          var _this2 = this;
          var cardsInfo = this.gameTable.tableModel.dealCardsInfo;
          var headCard = this.gameTable.tableModel.headCard;
          this.headCardItem.setCard(headCard, false);
          Emitter.emit(GlobalEvent.EVENT_GAME_UPDATE_OPEN_VERIFY_INFO, [headCard]);
          var isEventNum = headCard.value % 2 === 0;
          var playerCards = isEventNum ? cardsInfo.slice(0, 5) : cardsInfo.slice(5, 10);
          var bankerCards = isEventNum ? cardsInfo.slice(5, 10) : cardsInfo.slice(0, 5);
          if (cardsInfo) {
            this.scheduleOnce(function () {
              _this2.node.active = true;
              //const sortCardsInfo = [cardsInfo[0], cardsInfo[2], cardsInfo[1], cardsInfo[3], cardsInfo[4], cardsInfo[5]];
              _this2.cards.forEach(function (card, index) {
                if (index < 5) {
                  card.disCard(playerCards[index]);
                } else {
                  card.disCard(bankerCards[index - 5]);
                }
              });
            }, BaccaratConsts.showCardTime);
          }
        };
        _proto.showVerifyCards = function showVerifyCards() {
          var cardsInfos = this.gameTable.tableModel.cardsInfo;
          if (cardsInfos) {
            this.cards.forEach(function (card, index) {
              card.setCard(cardsInfos[index], false);
            });
          }
        };
        return BacNiuniuSVerifyCardView;
      }(BacNiuniuSTableCardView), _descriptor = _applyDecoratedDescriptor(_class2.prototype, "headCardItem", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _class2)) || _class));
      cclegacy._RF.pop();
    }
  };
});

(function(r) {
  r('virtual:///prerequisite-imports/bacNiuniuSBundle', 'chunks:///_virtual/bacNiuniuSBundle'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});