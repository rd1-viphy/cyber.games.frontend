window.gameConfig = {
    WS_URL: 'wss://gs.jojo99.dev/ws.lm',
    PROTO_URL: 'https://gs.jojo99.dev/conf.lm/static/little.mary.bin',
    HTTP_URL: 'https://bcg-demo.t9live.cc/bridge.api/',
    IS_ACCESS: false,
    VERSION: "v08202116",
}