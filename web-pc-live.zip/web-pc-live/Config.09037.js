window.gameConfig = {
    WS_URL: "ws://ec2-54-178-46-143.ap-northeast-1.compute.amazonaws.com/ws.rd",
    PROTO_URL: "http://ec2-54-178-46-143.ap-northeast-1.compute.amazonaws.com/conf.rd/assets/cyber.games.bin",
    HTTP_URL: "http://ec2-54-178-46-143.ap-northeast-1.compute.amazonaws.com/bridge.rd.api/",
    IS_ACCESS: false,
    VERSION: "v1.0.0",
}